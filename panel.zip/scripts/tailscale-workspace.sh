#!/usr/bin/env bash
set -Eeuo pipefail

TAILSCALE_BIN="$(command -v tailscale)"
TAILSCALED_BIN="$(command -v tailscaled)"
AUTH_KEY="${TAILSCALE_AUTH_KEY:-}"
unset TAILSCALE_AUTH_KEY

STATE_DIR="${HOME:-/home/runner}/.local/state/tailscale-workspace"
STATE_FILE="${STATE_DIR}/tailscaled.state"
HAS_SAVED_STATE=0
if [[ -s "${STATE_FILE}" ]]; then
  HAS_SAVED_STATE=1
fi
RUNTIME_DIR="$(mktemp -d "${TMPDIR:-/tmp}/tailscale-workspace.XXXXXX")"
SOCKET="${RUNTIME_DIR}/tailscaled.sock"
AUTH_FILE="${RUNTIME_DIR}/auth-key"
DAEMON_LOG="${RUNTIME_DIR}/tailscaled.log"
DAEMON_PID=""

if [[ -z "${AUTH_KEY}" && ! -s "${STATE_FILE}" ]]; then
  echo "Missing TAILSCALE_AUTH_KEY. Add it in Replit Secrets for the first login."
  exit 1
fi

mkdir -p "${STATE_DIR}"
chmod 700 "${STATE_DIR}"

export XDG_CONFIG_HOME="${RUNTIME_DIR}/config"
export XDG_DATA_HOME="${RUNTIME_DIR}/data"
export XDG_CACHE_HOME="${RUNTIME_DIR}/cache"

cleanup() {
  if [[ -n "${DAEMON_PID}" ]]; then
    kill "${DAEMON_PID}" 2>/dev/null || true
    wait "${DAEMON_PID}" 2>/dev/null || true
  fi
  rm -f "${AUTH_FILE}"
  rm -rf "${RUNTIME_DIR}"
}

trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

umask 077

"${TAILSCALED_BIN}" \
  -tun=userspace-networking \
  -socks5-server=127.0.0.1:1055 \
  -outbound-http-proxy-listen=127.0.0.1:1055 \
  -no-logs-no-support \
  -socket="${SOCKET}" \
  -statedir="${STATE_DIR}" \
  -state="${STATE_FILE}" >>"${DAEMON_LOG}" 2>&1 &
DAEMON_PID=$!

for _ in $(seq 1 60); do
  [[ -S "${SOCKET}" ]] && break
  if ! kill -0 "${DAEMON_PID}" 2>/dev/null; then
    wait "${DAEMON_PID}"
    echo "tailscaled exited before its control socket was ready."
    exit 1
  fi
  sleep 0.5
done

if [[ ! -S "${SOCKET}" ]]; then
  echo "Timed out waiting for tailscaled to start."
  exit 1
fi

CONNECTED=0
if [[ "${HAS_SAVED_STATE}" -eq 1 ]]; then
  for _ in $(seq 1 60); do
    if "${TAILSCALE_BIN}" --socket="${SOCKET}" status >/dev/null 2>&1; then
      CONNECTED=1
      break
    fi
    if ! kill -0 "${DAEMON_PID}" 2>/dev/null; then
      wait "${DAEMON_PID}"
      echo "tailscaled exited while restoring its saved identity."
      exit 1
    fi
    sleep 0.5
  done
fi

if [[ "${CONNECTED}" -eq 0 ]]; then
  if [[ -z "${AUTH_KEY}" ]]; then
    echo "Saved Tailscale identity could not reconnect and no auth key is available."
    exit 1
  fi
  printf '%s' "${AUTH_KEY}" > "${AUTH_FILE}"
  unset AUTH_KEY
  "${TAILSCALE_BIN}" --socket="${SOCKET}" up \
    --auth-key="file:${AUTH_FILE}" \
    --hostname=replit-workspace
  rm -f "${AUTH_FILE}"
  chmod 600 "${STATE_FILE}" 2>/dev/null || true
fi

unset AUTH_KEY
rm -f "${AUTH_FILE}"

echo "Tailscale userspace is connected."
echo "SOCKS5/HTTP proxy listening on 127.0.0.1:1055."

wait "${DAEMON_PID}"
