let _allAllocationsCache = [];
let _portTagsList = []; // multi-tag array untuk ports
let _deleteMode = false;
let _selectedIds = new Set();

/* ═══ TOGGLE DELETE MODE ═══ */
function toggleDeleteMode() {
  _deleteMode = !_deleteMode;
  const btn = document.getElementById('btn-toggle-del');
  if (_deleteMode) {
    btn.classList.add('ring-2', 'ring-red-400', 'ring-offset-1', 'ring-offset-[#1a2234]');
  } else {
    btn.classList.remove('ring-2', 'ring-red-400', 'ring-offset-1', 'ring-offset-[#1a2234]');
    // Reset semua pilihan saat mode dimatikan
    _selectedIds.clear();
    document.querySelectorAll('[id^="chk-"]').forEach(el => {
      el.classList.remove('bg-red-600', 'border-red-600');
      el.classList.add('border-white');
      const mark = el.querySelector('.chk-mark');
      if (mark) mark.classList.add('hidden');
    });
    updateDeleteSelBar();
  }
  // Tampilkan / sembunyikan checkbox per baris
  document.querySelectorAll('.del-row-btn').forEach(el => {
    if (_deleteMode) {
      el.classList.remove('hidden');
      el.classList.add('inline-flex');
    } else {
      el.classList.add('hidden');
      el.classList.remove('inline-flex');
    }
  });
}

/* ═══ TOGGLE SELECT CHECKBOX ═══ */
function toggleSelectAlloc(id) {
  const btn = document.getElementById('chk-' + id);
  if (!btn) return;
  const mark = btn.querySelector('.chk-mark');
  if (_selectedIds.has(id)) {
    _selectedIds.delete(id);
    btn.classList.remove('bg-red-600', 'border-red-600');
    btn.classList.add('border-white');
    if (mark) mark.classList.add('hidden');
  } else {
    _selectedIds.add(id);
    btn.classList.add('bg-red-600', 'border-red-600');
    btn.classList.remove('border-white');
    if (mark) mark.classList.remove('hidden');
  }
  updateDeleteSelBar();
}

/* ═══ UPDATE BAR PILIHAN ═══ */
function updateDeleteSelBar() {
  const bar = document.getElementById('del-sel-bar');
  if (!bar) return;
  const count = _selectedIds.size;
  if (count > 0 && _deleteMode) {
    bar.classList.remove('hidden');
    document.getElementById('del-sel-count').textContent = count;
  } else {
    bar.classList.add('hidden');
  }
}

/* ═══ PILIH SEMUA YANG KOSONG ═══ */
function selectAllFreeAllocs() {
  const freeAllocs = _allAllocationsCache.filter(a => !a.ownerServer);
  freeAllocs.forEach(a => {
    const btn = document.getElementById('chk-' + a.id);
    if (!btn || _selectedIds.has(a.id)) return;
    _selectedIds.add(a.id);
    btn.classList.add('bg-red-600', 'border-red-600');
    btn.classList.remove('border-white');
    const mark = btn.querySelector('.chk-mark');
    if (mark) mark.classList.remove('hidden');
  });
  updateDeleteSelBar();
}

/* ═══ HAPUS YANG DIPILIH ═══ */
function confirmDeleteSelected() {
  const count = _selectedIds.size;
  if (count === 0) return;
  document.getElementById('del-bulk-count').textContent = count;
  document.getElementById('modal-del-bulk').classList.remove('hidden');
}
async function executeDeleteSelected() {
  document.getElementById('modal-del-bulk').classList.add('hidden');
  const ids = [..._selectedIds];
  try {
    const res = await fetch('/api/admin/allocations/delete-bulk', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ids })
    });
    const data = await res.json();
    if (res.ok) {
      showToast(`${data.deleted} alokasi dihapus.`);
      _selectedIds.clear();
      _deleteMode = false;
      const btn = document.getElementById('btn-toggle-del');
      if (btn) btn.classList.remove('ring-2', 'ring-red-400', 'ring-offset-1', 'ring-offset-[#1a2234]');
      updateDeleteSelBar();
      loadAllocationsAdmin();
    } else showToast(data.error || 'Gagal menghapus', 'error');
  } catch(e) { showToast('Error jaringan', 'error'); }
}

/* ═══ IP TAG INPUT ═══ */
function isValidIPv4(value) {
  const parts = String(value || '').trim().split('.');
  return parts.length === 4 && parts.every(part =>
    /^\\d{1,3}$/.test(part) && Number(part) >= 0 && Number(part) <= 255
  );
}
function rejectInvalidIp(input) {
  input.value = '';
  showToast('IP tidak valid. Gunakan format IPv4, contoh 51.79.1.10', 'error');
}
function handleIpInput(input) {
  // Spasi mengunci nilai sebagai satu IP; jangan izinkan angka acak/multi-token.
  if (input.value.includes(' ') && input.value.trim()) {
    const val = input.value.trim();
    if (isValidIPv4(val)) lockIpTag(val);
    else rejectInvalidIp(input);
  }
}
function handleIpKeydown(e) {
  if (e.key === 'Enter' || e.key === ' ' || e.key === 'Tab') {
    const val = e.target.value.trim();
    if (val) {
      e.preventDefault();
      if (isValidIPv4(val)) lockIpTag(val);
      else rejectInvalidIp(e.target);
    }
  } else if (e.key === 'Backspace' && !e.target.value) {
    const tagDisplay = document.getElementById('ip-tag-display');
    if (!tagDisplay.classList.contains('hidden')) {
      e.preventDefault();
      const tagText = document.getElementById('ip-tag-text').textContent;
      tagDisplay.classList.add('hidden');
      const inp = document.getElementById('alloc-add-ip');
      inp.value = tagText; inp.placeholder = '51.79.1.10'; inp.style.width = '';
      inp.focus();
      inp.setSelectionRange(tagText.length, tagText.length);
    }
  }
}
function lockIpTag(val) {
  if (!isValidIPv4(val)) {
    showToast('IP tidak valid. Gunakan format IPv4, contoh 51.79.1.10', 'error');
    return;
  }
  document.getElementById('ip-tag-text').textContent = val;
  document.getElementById('ip-tag-display').classList.remove('hidden');
  const inp = document.getElementById('alloc-add-ip');
  inp.value = ''; inp.placeholder = ''; inp.style.width = '1px';
}
function clearIpTag(e) {
  e.stopPropagation();
  document.getElementById('ip-tag-display').classList.add('hidden');
  const inp = document.getElementById('alloc-add-ip');
  inp.value = ''; inp.placeholder = '51.79.1.10'; inp.style.width = '';
  inp.focus();
}

/* ═══ ALIAS TAG INPUT ═══ */
function handleAliasInput(input) {
  if (input.value.includes(' ') && input.value.trim()) lockAliasTag(input.value.trim());
}
function handleAliasKeydown(e) {
  if (e.key === 'Enter' || e.key === 'Tab') {
    const val = e.target.value.trim();
    if (val) { e.preventDefault(); lockAliasTag(val); }
  } else if (e.key === 'Backspace' && !e.target.value) {
    // Kalau input kosong & ada chip → kembalikan teks ke input (bukan hapus)
    const tagDisplay = document.getElementById('alias-tag-display');
    if (!tagDisplay.classList.contains('hidden')) {
      e.preventDefault();
      const tagText = document.getElementById('alias-tag-text').textContent;
      tagDisplay.classList.add('hidden');
      const inp = document.getElementById('alloc-add-alias');
      inp.value = tagText;
      inp.placeholder = 'alias';
      inp.style.width = '';
      inp.focus();
      inp.setSelectionRange(tagText.length, tagText.length); // cursor di ujung
    }
  }
}
function lockAliasTag(val) {
  document.getElementById('alias-tag-text').textContent = val;
  document.getElementById('alias-tag-display').classList.remove('hidden');
  const inp = document.getElementById('alloc-add-alias');
  inp.value = ''; inp.placeholder = ''; inp.style.width = '1px';
}
function clearAliasTag(e) {
  e.stopPropagation();
  document.getElementById('alias-tag-display').classList.add('hidden');
  const inp = document.getElementById('alloc-add-alias');
  inp.value = ''; inp.placeholder = 'alias'; inp.style.width = '';
  inp.focus();
}

/* ═══ PORT MULTI-TAG INPUT ═══ */
function isValidPortToken(value) {
  const token = String(value || '').trim();
  // Port tunggal manual: terima digit tanpa batas maksimum.
  if (/^\d+$/.test(token)) return true;
  const range = token.match(/^(\d+)-(\d+)$/);
  if (!range) return false;
  const first = Number(range[1]);
  const last = Number(range[2]);
  return Number.isInteger(first) && Number.isInteger(last) &&
    first >= 1 && first <= 65535 &&
    last >= 1 && last <= 65535 &&
    first <= last;
}

function handlePortInput(input) {
  // Port hanya menerima digit, spasi, koma, dan tanda hubung untuk range.
  // Titik/huruf/simbol lain tidak boleh diam-diam dihapus karena bisa
  // mengubah IP menjadi angka port yang berbeda.
  const rawBefore = input.value;
  if (/[^0-9\s,-]/.test(rawBefore)) {
    input.value = '';
    showToast('Port hanya boleh angka 1–65535 atau range, bukan alamat IP', 'error');
    input.focus();
    return;
  }

  const raw = input.value;
  const tokens = raw.split(/[\s,]+/).filter(Boolean);

  // Batas 1–65535 hanya berlaku jika token memakai format range (angka-angka).
  // Angka tunggal yang diketik manual tidak dibatasi maksimum.
  for (const token of tokens) {
    if (token.includes('-')) {
      const range = token.match(/^(\d+)-(\d+)$/);
      if (range) {
        const first = Number(range[1]);
        const last = Number(range[2]);
        if (first < 1 || first > 65535 || last < 1 || last > 65535 || first > last) {
          input.value = '';
          showToast('Range port harus dari 1 sampai 65535 dan angka awal tidak boleh melebihi angka akhir', 'error');
          input.focus();
          return;
        }
      }
    }
  }

  if (!/[\s,]/.test(raw)) return;

  const parts = raw.split(/[\s,]+/).map(v => v.trim()).filter(Boolean);
  if (parts.length) {
    parts.forEach(part => addPortTag(part));
    input.value = '';
    input.focus();
  }
}

function handlePortKeydown(e) {
  if (e.key === ' ' || e.key === 'Enter' || e.key === ',' || e.key === 'Tab') {
    const parts = e.target.value.split(/[\s,]+/).map(v => v.trim()).filter(Boolean);
    if (parts.length) {
      e.preventDefault();
      parts.forEach(part => addPortTag(part));
      e.target.value = '';
      e.target.focus();
    }
  } else if (e.key === 'Backspace' && !e.target.value && _portTagsList.length > 0) {
    e.preventDefault();
    const lastTag = _portTagsList.pop();
    renderPortTags();
    const inp = document.getElementById('alloc-add-range');
    inp.value = lastTag;
    inp.focus();
    inp.setSelectionRange(lastTag.length, lastTag.length);
  }
}

function addPortTag(val) {
  const token = String(val || '').trim();
  if (!isValidPortToken(token)) {
    if (token) showToast('Port tunggal harus angka, sedangkan range harus 1–65535', 'error');
    return false;
  }
  if (!_portTagsList.includes(token)) _portTagsList.push(token);
  renderPortTags();
  return true;
}
function removePortTag(idx) {
  _portTagsList.splice(idx, 1);
  renderPortTags();
  const inp = document.getElementById('alloc-add-range');
  if (inp) inp.focus();
}
function renderPortTags() {
  const container = document.getElementById('port-tags-container');
  if (!container) return;
  container.innerHTML = _portTagsList.map((t, i) =>
    `<span class="ptero-port-chip">${t}<button type="button" onclick="removePortTag(${i})">×</button></span>`
  ).join('');
  const inp = document.getElementById('alloc-add-range');
  if (inp) inp.placeholder = _portTagsList.length ? '' : '25565 atau 25555-25556';
}
function clearAllPortTags() {
  _portTagsList = [];
  renderPortTags();
}

/* ═══ LOAD ALLOCATIONS ═══ */
async function loadAllocationsAdmin() {
  const tbody = document.getElementById('alloc-admin-list-table');
  const mobileList = document.getElementById('alloc-admin-list-mobile');
  tbody.innerHTML = '<tr><td colspan="4" class="text-center text-slate-500 text-xs py-10">Memuat...</td></tr>';
  mobileList.innerHTML = '<div class="text-center text-slate-500 text-xs py-10">Memuat...</div>';

  try {
    const res = await fetch('/api/admin/allocations');
    if (res.status === 401 || res.status === 403) { window.location.href = '/'; return; }
    const data = await res.json();
    _allAllocationsCache = data;

    const free = data.filter(a => !a.ownerServer).length;
    const used = data.length - free;
    document.getElementById('stat-total').textContent = data.length;
    document.getElementById('stat-free').textContent = free;
    document.getElementById('stat-used').textContent = used;
    document.getElementById('alloc-admin-summary').textContent = `${data.length} total · ${free} kosong · ${used} dipakai`;

    if (data.length === 0) {
      tbody.innerHTML = '<tr><td colspan="4" class="text-center text-slate-500 text-xs py-10">Belum ada allocation. Tambah lewat form di samping.</td></tr>';
      mobileList.innerHTML = '<div class="text-center text-slate-500 text-xs py-8 px-4">Belum ada allocation.</div>';
      return;
    }

    /* ── Table rows (semua ukuran layar) ── */
    tbody.innerHTML = data.map(a => {
      const safeAlias = (a.alias||'').replace(/"/g,'&quot;');
      const assigned = !!a.ownerServer;
      // Checkbox: tersembunyi by default, muncul saat delete mode ON
      // assigned = disabled (abu2), kosong = bisa dipilih
      const deleteBtn = assigned
        ? `<button disabled title="Port masih dipakai — hapus server dulu"
              class="del-row-btn hidden items-center justify-center w-[18px] h-[18px] rounded border-2 border-slate-600 bg-slate-800/50 cursor-not-allowed flex-shrink-0 opacity-40">
           </button>`
        : `<button onclick="toggleSelectAlloc('${a.id}')" id="chk-${a.id}"
              class="del-row-btn hidden items-center justify-center w-[18px] h-[18px] rounded border-2 border-white bg-transparent transition active:scale-90 flex-shrink-0">
              <svg class="w-2.5 h-2.5 text-white hidden chk-mark" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"/></svg>
           </button>`;
      return `<tr id="alloc-row-${a.id}">
        <td style="white-space:nowrap;">
          <div class="flex items-center gap-2">
            ${deleteBtn}
            <span class="font-mono text-sm text-slate-300">${a.ip}</span>
          </div>
        </td>
        <td style="width:99%;">
          <input id="alias-input-${a.id}" type="text" value="${safeAlias}" placeholder="alias" maxlength="100"
            class="alias-inline-input"
            onfocus="this.dataset.original=this.value"
            onkeydown="if(event.key==='Enter')this.blur();if(event.key==='Escape'){this.value=this.dataset.original||'';this.blur();}"
            onblur="saveAliasInline('${a.id}',this)">
        </td>
        <td class="font-mono text-sm text-slate-300" style="white-space:nowrap;">${a.port}</td>
        <td>
          ${assigned
            ? `<button onclick="goToServer('${a.ownerServer}','${a.ownerUsername}')" title="Buka panel server" class="flex items-center gap-1 text-xs text-slate-400 hover:text-blue-400 transition-colors group">
                <span class="group-hover:underline underline-offset-2">${a.ownerUsername}/${a.ownerServer}</span>
                <svg class="w-2.5 h-2.5 flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
               </button>`
            : ''}
        </td>
      </tr>`;
    }).join('');

    /* ── Mobile card list ── */
    mobileList.innerHTML = data.map(a => {
      const aliasHtml = a.alias
        ? `<span class="tbl-alias-chip">${a.alias} <span style="font-size:10px">⚡</span></span>`
        : `<span class="text-xs text-slate-600 italic">No alias</span>`;
      const editPencil = `<button onclick="startEditAlias('${a.id}', \`${(a.alias||'').replace(/`/g,'\\`')}\`, true)" class="ml-1 text-slate-600 hover:text-amber-400 transition">
        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
      </button>`;
      return `<div id="alloc-mob-${a.id}" class="px-4 py-3 border-b border-slate-800/60 last:border-0">
        <div class="flex items-start justify-between gap-2">
          <div class="min-w-0 flex flex-col gap-1">
            <div class="flex items-center gap-2 flex-wrap">
              <span class="tbl-ip-chip">${a.ip}</span>
              <span class="font-mono text-sm font-bold text-slate-300">:${a.port}</span>
              ${a.primary ? '<span class="text-[9px] font-black uppercase bg-blue-600/80 text-blue-100 px-1.5 py-0.5 rounded">Primary</span>' : ''}
            </div>
            <div>
              ${a.ownerServer
                ? `<button onclick="goToServer('${a.ownerServer}','${a.ownerUsername}')" title="Buka panel server" class="flex items-center gap-1 text-[11px] text-slate-400 hover:text-blue-400 transition-colors group text-left">
                    <span class="group-hover:underline underline-offset-2">${a.ownerUsername}/${a.ownerServer}</span>
                    <svg class="w-2.5 h-2.5 flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
                   </button>`
                : `<span class="text-[10px] font-black text-emerald-400 uppercase tracking-wide">● Unassigned</span>`}
            </div>
          </div>
          ${!a.ownerServer
            ? `<button onclick="deleteAllocationAdmin('${a.id}')"
                class="flex-shrink-0 w-7 h-7 rounded flex items-center justify-center bg-red-500/10 hover:bg-red-500 text-red-400 hover:text-white transition border border-red-500/20" title="Hapus">
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M6 18L18 6M6 6l12 12"/></svg>
               </button>`
            : ''}
        </div>
        <!-- Alias row mobile -->
        <div class="mt-2 flex items-center gap-1.5">
          <svg class="w-3 h-3 text-slate-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 010 5.656m-1.414-1.414a2 2 0 010-2.828M6.343 17.657A8 8 0 1117.657 6.343"/></svg>
          <div class="alias-display flex-1 flex-wrap" id="alias-display-mob-${a.id}">
            ${aliasHtml}${editPencil}
          </div>
          <div class="alias-edit flex-1" id="alias-edit-mob-${a.id}">
            <input id="alias-input-mob-${a.id}" type="text" value="${a.alias||''}" placeholder="alias" maxlength="100"
              class="flex-1 bg-slate-900 border border-amber-500/50 text-amber-200 text-xs font-mono px-2 py-1 rounded outline-none transition w-28"
              onkeydown="if(event.key==='Enter')saveAlias('${a.id}',true);if(event.key==='Escape')cancelAlias('${a.id}',true)">
            <button onclick="saveAlias('${a.id}',true)" class="bg-amber-600 hover:bg-amber-500 text-white text-[10px] font-black px-1.5 py-1 rounded transition ml-1">✓</button>
            <button onclick="cancelAlias('${a.id}',true)" class="text-slate-500 hover:text-red-400 text-[10px] px-1 py-1 rounded transition">✕</button>
          </div>
        </div>
      </div>`;
    }).join('');

  } catch(e) {
    tbody.innerHTML = '<tr><td colspan="4" class="text-center text-red-400 text-xs py-10">Gagal memuat data.</td></tr>';
    mobileList.innerHTML = '<div class="text-center text-red-400 text-xs py-8">Gagal memuat.</div>';
  }
}

/* ═══ ADD ALLOCATION ═══ */
async function addAllocationRange() {
  const ipTagText = document.getElementById('ip-tag-text').textContent.trim();
  const ipInput   = document.getElementById('alloc-add-ip').value.trim();
  const ip = ipTagText || ipInput;

  // Ambil sisa nilai di input port (jika belum di-tag)
  const portInputVal = document.getElementById('alloc-add-range').value.trim();
  if (portInputVal) { addPortTag(portInputVal); document.getElementById('alloc-add-range').value = ''; }

  const aliasTagText = document.getElementById('alias-tag-text').textContent.trim();
  const aliasInput   = document.getElementById('alloc-add-alias').value.trim();
  const defaultAlias = aliasTagText || aliasInput;

  if (!ip) return showToast('IP wajib diisi', 'error');
  if (!isValidIPv4(ip)) return showToast('IP tidak valid. Gunakan format IPv4, contoh 51.79.1.10', 'error');
  if (_portTagsList.length === 0) return showToast('Ports wajib diisi', 'error');

  // Kirim satu per satu tiap range
  let added = 0, errors = 0;
  const errorMessages = [];
  for (const rangeRaw of _portTagsList) {
    let portStart, portEnd;
    if (rangeRaw.includes('-')) {
      const parts = rangeRaw.split('-').map(s => s.trim());
      portStart = parts[0]; portEnd = parts[1];
    } else {
      portStart = rangeRaw; portEnd = rangeRaw;
    }
    // Validasi frontend: port harus angka dan antara 1-65535
    const s = parseInt(portStart), e = parseInt(portEnd);
    if (!portStart || !portEnd || isNaN(s) || isNaN(e)) {
      errorMessages.push(`"${rangeRaw}" bukan angka valid`);
      errors++; continue;
    }
    if (s < 1 || s > 65535 || e < 1 || e > 65535) {
      errorMessages.push(`Port "${rangeRaw}" di luar range (1–65535)`);
      errors++; continue;
    }
    if (s > e) {
      errorMessages.push(`Range "${rangeRaw}" tidak valid (awal > akhir)`);
      errors++; continue;
    }
    try {
      const res = await fetch('/api/admin/allocations/add', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ip, portStart, portEnd, defaultAlias })
      });
      const data = await res.json();
      if (res.ok) added += (data.added || 0);
      else { errorMessages.push(data.error || `Range "${rangeRaw}" gagal`); errors++; }
    } catch(e) { errorMessages.push(`Error jaringan untuk "${rangeRaw}"`); errors++; }
  }

  if (added > 0) {
    showToast(`${added} port ditambahkan ke pool!`);
    clearIpTag({ stopPropagation: ()=>{} });
    clearAliasTag({ stopPropagation: ()=>{} });
    clearAllPortTags();
    loadAllocationsAdmin();
  }
  if (errors > 0) {
    // Tampilkan pesan error spesifik (maksimal 2 baris)
    const msg = errorMessages.slice(0, 2).join(' | ') + (errorMessages.length > 2 ? ` (+${errorMessages.length - 2} lagi)` : '');
    showToast(msg, 'error');
  }
}

/* ═══ DELETE SATU ═══ */
function deleteAllocationAdmin(id) {
  // Tampilkan modal konfirmasi hapus satu
  const alloc = _allAllocationsCache.find(a => a.id === id);
  if (!alloc) return;
  const modal = document.getElementById('modal-del-one');
  document.getElementById('del-one-label').textContent = `${alloc.ip}:${alloc.port}`;
  modal.dataset.targetId = id;
  modal.classList.remove('hidden');
}
async function executeDeleteOne() {
  const modal = document.getElementById('modal-del-one');
  const id = modal.dataset.targetId;
  modal.classList.add('hidden');
  try {
    const res = await fetch('/api/admin/allocations/delete', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) });
    const data = await res.json();
    if (res.ok) { showToast('Allocation dihapus.'); loadAllocationsAdmin(); }
    else showToast(data.error || 'Gagal menghapus', 'error');
  } catch(e) { showToast('Error jaringan', 'error'); }
}

/* ═══ DELETE SEMUA KOSONG ═══ */
function confirmDeleteAllFree() {
  const free = _allAllocationsCache.filter(a => !a.ownerServer).length;
  if (free === 0) { showToast('Tidak ada alokasi kosong untuk dihapus.', 'error'); return; }
  document.getElementById('del-all-count').textContent = free;
  document.getElementById('modal-del-all').classList.remove('hidden');
}
async function executeDeleteAllFree() {
  document.getElementById('modal-del-all').classList.add('hidden');
  try {
    const res = await fetch('/api/admin/allocations/delete-all-free', { method: 'POST', headers: { 'Content-Type': 'application/json' } });
    const data = await res.json();
    if (res.ok) { showToast(`${data.deleted} alokasi kosong dihapus.`); loadAllocationsAdmin(); }
    else showToast(data.error || 'Gagal', 'error');
  } catch(e) { showToast('Error jaringan', 'error'); }
}

/* ═══ ALIAS INLINE EDIT — klik kotak langsung edit, blur = auto-save ═══ */
async function saveAliasInline(id, input) {
  const alias = input.value.trim();
  const original = input.dataset.original ?? '';
  if (alias === original) return; // tidak ada perubahan
  try {
    const res = await fetch('/api/admin/allocations/set-alias', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, alias })
    });
    const data = await res.json();
    if (!res.ok) {
      showToast(data.error || 'Gagal simpan alias', 'error');
      input.value = original; // kembalikan nilai lama
      return;
    }
    const alloc = _allAllocationsCache.find(a => a.id === id);
    if (alloc) alloc.alias = data.alias;
    input.value = data.alias;
    input.dataset.original = data.alias;
    showToast(data.alias ? `Alias disimpan: ${data.alias}` : 'Alias dihapus.');
  } catch(e) {
    showToast('Error jaringan', 'error');
    input.value = original;
  }
}

/* ═══ TOAST ═══ */
function showToast(message, type = 'success') {
  const container = document.getElementById('toast-container');
  if (container.children.length >= 5) container.removeChild(container.lastChild);
  const ok = type === 'success';
  const toast = document.createElement('div');
  toast.className = `pointer-events-auto relative bg-[#1e293b] border ${ok ? 'border-green-500/40' : 'border-red-500/40'} text-white px-4 py-3 rounded-2xl flex items-center gap-3 shadow-2xl shadow-black/40 overflow-hidden fade-in`;
  toast.style.animation = 'toastIn 0.3s cubic-bezier(0.34,1.56,0.64,1)';
  const iconBg = ok ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400';
  const icon   = ok
    ? '<svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"/></svg>'
    : '<svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v4m0 4h.01M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/></svg>';
  const barColor = ok ? 'bg-green-500' : 'bg-red-500';
  toast.innerHTML = `<div class="w-7 h-7 rounded-full ${iconBg} flex items-center justify-center flex-shrink-0">${icon}</div><span class="text-[13px] font-semibold leading-snug flex-1">${message}</span><button class="text-slate-500 hover:text-white text-xl leading-none flex-shrink-0 ml-1">×</button><div class="absolute bottom-0 left-0 h-[2px] ${barColor} toast-bar rounded-full" style="width:100%;transition:width 4s linear;"></div>`;
  container.insertBefore(toast, container.firstChild);
  requestAnimationFrame(() => { requestAnimationFrame(() => { const b = toast.querySelector('.toast-bar'); if(b) b.style.width='0%'; }); });
  const t = setTimeout(() => { toast.style.animation='toastOut .3s ease-in forwards'; setTimeout(()=>toast.remove(),300); }, 4200);
  toast.querySelector('button').addEventListener('click', () => { clearTimeout(t); toast.style.animation='toastOut .3s ease-in forwards'; setTimeout(()=>toast.remove(),300); });
}

async function goToServer(serverName, ownerUsername) {
  try {
    const res = await fetch('/api/admin/view-server', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ serverName, ownerUsername }) });
    if (!res.ok) { showToast('Gagal masuk ke server', 'error'); return; }
    const data = await res.json();
    window.location.href = data.id ? ('/server/' + data.id + '/console') : '/panel';
  } catch(e) { showToast('Gagal masuk ke server', 'error'); }
}

loadAllocationsAdmin();

function toggleAdminDrawer(force) {
  const open = typeof force === 'boolean' ? force : !document.body.classList.contains('drawer-open');
  document.body.classList.toggle('drawer-open', open);
  const drawer = document.getElementById('admin-drawer');
  if (drawer) drawer.setAttribute('aria-hidden', String(!open));
}
document.addEventListener('keydown', event => { if (event.key === 'Escape') toggleAdminDrawer(false); });