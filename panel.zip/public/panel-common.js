/**
 * panel-common.js
 * Shared: page transitions + skeleton CSS injection
 */
(function () {
  /* ── 1. INJECT SHARED CSS ── */
  const style = document.createElement('style');
  style.textContent = `
    /* Smooth font rendering — teks crisp di semua layar */
    *, *::before, *::after {
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
      text-rendering: optimizeLegibility;
    }

    /* Momentum scroll — iOS scroll meluncur mulus */
    html, body {
      -webkit-overflow-scrolling: touch;
      scroll-behavior: smooth;
    }
    /* Semua elemen scrollable juga dapat momentum scroll */
    [class*="overflow-y-"], [class*="overflow-auto"], [class*="overflow-scroll"],
    .scrollbar-hide, .scrollable-form {
      -webkit-overflow-scrolling: touch;
    }

    /* Page transition */
    html { opacity: 0; transition: opacity 0.22s ease; }
    html.page-visible { opacity: 1; }
    html.page-exit { opacity: 0 !important; transition: opacity 0.18s ease !important; }

    /* Skeleton shimmer */
    @keyframes skShimmer {
      0%   { background-position: -400px 0; }
      100% { background-position:  400px 0; }
    }
    .sk {
      background: linear-gradient(90deg,
        #1a2540 25%,
        #243050 50%,
        #1a2540 75%
      );
      background-size: 800px 100%;
      animation: skShimmer 1.4s infinite linear;
      border-radius: 6px;
      display: block;
    }

    /* Skeleton user row (admin list) */
    .sk-user-row {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 14px 16px;
      border-bottom: 1px solid rgba(30,41,59,0.5);
    }
    .sk-user-row:last-child { border-bottom: none; }

    /* Skeleton server card (dashboard) */
    .sk-srv-card {
      background: #141d2e;
      border: 1px solid rgba(51,65,85,0.35);
      border-radius: 16px;
      padding: 16px;
      margin-bottom: 12px;
    }

    /* Skeleton user summary (manageuser) */
    .sk-summary {
      padding: 20px;
    }
  `;
  document.head.appendChild(style);

  /* ── 2. PAGE FADE-IN ON LOAD ── */
  function revealPage() {
    document.documentElement.classList.add('page-visible');
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', revealPage);
  } else {
    // already loaded (script deferred / at bottom)
    requestAnimationFrame(revealPage);
  }

  /* ── 3. PAGE FADE-OUT ON NAVIGATION ── */
  function navigateTo(url) {
    if (!url || url === '#' || url.startsWith('javascript')) return;
    document.documentElement.classList.add('page-exit');
    setTimeout(function () { location.href = url; }, 200);
  }

  // Intercept <a> clicks
  document.addEventListener('click', function (e) {
    const link = e.target.closest('a[href]');
    if (!link) return;
    const href = link.getAttribute('href');
    if (!href || href.startsWith('#') || href.startsWith('javascript') ||
        link.target === '_blank' || link.hasAttribute('download')) return;
    try {
      const u = new URL(href, location.href);
      if (u.origin !== location.origin) return; // external link — don't intercept
    } catch (_) { return; }
    e.preventDefault();
    navigateTo(href);
  }, true);

  // Expose globally so buttons using onclick="window.location.href=..." also work
  window.panelNavigate = navigateTo;
})();
