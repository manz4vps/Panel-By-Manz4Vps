/* =========================================
 MODULE: FILE MANAGER (FRONTEND)
 ========================================= */

// localStorage key scoped ke server tab ini — cegah bleed antar tab beda server
function _LS(key) {
 const sid = (typeof PANEL_SERVER_ID !== 'undefined' && PANEL_SERVER_ID)
  || (window.location.pathname.match(/^\/server\/([^\/]+)/) || [])[1]
  || 'shared';
 return sid + ':' + key;
}

let currentPath = ''; 
let currentEditFile = '';
let isNewFile = false;
let _loadFilesGen = 0;
let selectedFiles = new Set();
let editor = null;
let progressInterval = null;
let folderCache = {}; 
let searchCursor = null;
let lastQuery = '';
let currentSearchMark = null;

let moveTargetPath = '';
let currentLangLabel = 'Plain Text';

// 
// LANGUAGE LIST (matches Pterodactyl's list)
// 
const LANGUAGES = [
 { label: 'Plain Text', mode: null },
 { label: 'C', mode: 'text/x-csrc' },
 { label: 'C++', mode: 'text/x-c++src' },
 { label: 'C#', mode: 'text/x-csharp' },
 { label: 'CSS', mode: 'css' },
 { label: 'Diff', mode: 'text/x-diff' },
 { label: 'Dockerfile', mode: 'text/x-dockerfile' },
 { label: 'Golang', mode: 'text/x-go' },
 { label: 'HTML', mode: 'text/html' },
 { label: 'HTTP', mode: 'message/http' },
 { label: 'Java', mode: 'text/x-java' },
 { label: 'JavaScript', mode: 'javascript' },
 { label: 'JSON', mode: 'application/json' },
 { label: 'Lua', mode: 'text/x-lua' },
 { label: 'Markdown', mode: 'text/x-markdown' },
 { label: 'MySQL', mode: 'text/x-mysql' },
 { label: 'Nginx', mode: 'text/x-nginx-conf' },
 { label: 'PHP', mode: 'application/x-httpd-php' },
 { label: 'PostgreSQL', mode: 'text/x-pgsql' },
 { label: 'Properties', mode: 'text/x-properties' },
 { label: 'Python', mode: 'python' },
 { label: 'Ruby', mode: 'text/x-ruby' },
 { label: 'Rust', mode: 'text/x-rustsrc' },
 { label: 'SCSS', mode: 'text/x-scss' },
 { label: 'Shell', mode: 'text/x-sh' },
 { label: 'SQL', mode: 'text/x-sql' },
 { label: 'TOML', mode: 'text/x-toml' },
 { label: 'TypeScript', mode: 'text/typescript' },
 { label: 'XML', mode: 'application/xml' },
 { label: 'YAML', mode: 'text/x-yaml' },
];

// Global language detector 
function detectLanguage(fileName) {
 const base = (fileName || '').split('/').pop().toLowerCase();
 const ext = base.includes('.') ? base.split('.').pop() : '';
 const map = {
 'js':['javascript','JavaScript'],'mjs':['javascript','JavaScript'],'cjs':['javascript','JavaScript'],
 'ts':['text/typescript','TypeScript'],
 'json':['application/json','JSON'],
 'html':['text/html','HTML'],'htm':['text/html','HTML'],
 'css':['css','CSS'],'scss':['text/x-scss','SCSS'],
 'yml':['text/x-yaml','YAML'],'yaml':['text/x-yaml','YAML'],
 'toml':['text/x-toml','TOML'],
 'properties':['text/x-properties','Properties'],'ini':['text/x-properties','Properties'],
 'conf':['text/x-nginx-conf','Nginx'],'nginx':['text/x-nginx-conf','Nginx'],
 'xml':['application/xml','XML'],'svg':['application/xml','XML'],
 'py':['python','Python'],'pyw':['python','Python'],
 'sh':['text/x-sh','Shell'],'bash':['text/x-sh','Shell'],'zsh':['text/x-sh','Shell'],
 'java':['text/x-java','Java'],
 'c':['text/x-csrc','C'],'h':['text/x-csrc','C'],
 'cpp':['text/x-c++src','C++'],'cc':['text/x-c++src','C++'],'hpp':['text/x-c++src','C++'],
 'cs':['text/x-csharp','C#'],
 'go':['text/x-go','Golang'],
 'rb':['text/x-ruby','Ruby'],
 'rs':['text/x-rustsrc','Rust'],
 'php':['application/x-httpd-php','PHP'],
 'lua':['text/x-lua','Lua'],
 'sql':['text/x-sql','SQL'],
 'md':['text/x-markdown','Markdown'],'markdown':['text/x-markdown','Markdown'],
 'txt':[null,'Plain Text'],
 'diff':['text/x-diff','Diff'],'patch':['text/x-diff','Diff'],
 };
 if (base === 'dockerfile') return ['text/x-dockerfile','Dockerfile'];
 return map[ext] || [null,'Plain Text'];
}

function setEditorLanguage(mode, label) {
 currentLangLabel = label || 'Plain Text';
 const langLabelEl = document.getElementById('langLabel');
 if (langLabelEl) langLabelEl.textContent = currentLangLabel;
 if (editor) editor.setOption('mode', mode || null);
}

function openLangSelector() {
 const modal = document.getElementById('langSelectorModal');
 const list = document.getElementById('langList');
 if (!modal || !list) return;
 list.innerHTML = LANGUAGES.map(lang => {
 const isActive = lang.label === currentLangLabel;
 return `<button onclick="selectLanguage(${JSON.stringify(lang.label)},${JSON.stringify(lang.mode)})"
 class="w-full flex items-center justify-between px-5 py-3 text-sm transition hover:bg-slate-700/60 active:bg-slate-700 ${isActive ? 'text-blue-400 font-bold' : 'text-[#abb2bf]'}">
 <span>${lang.label}</span>
 ${isActive ? '<svg class="w-4 h-4 text-blue-400" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/></svg>' : ''}
 </button>`;
 }).join('');
 modal.classList.remove('hidden');
 modal.style.animation = 'none';
 requestAnimationFrame(() => {
 const sheet = modal.querySelector('div');
 if (sheet) { sheet.style.transform = 'translateY(100%)'; requestAnimationFrame(() => { sheet.style.transition = 'transform 0.25s cubic-bezier(0.32,0.72,0,1)'; sheet.style.transform = 'translateY(0)'; }); }
 });
}

function closeLangSelector() {
 const modal = document.getElementById('langSelectorModal');
 if (!modal) return;
 const sheet = modal.querySelector('div');
 if (sheet) {
 sheet.style.transform = 'translateY(100%)';
 setTimeout(() => modal.classList.add('hidden'), 250);
 } else { modal.classList.add('hidden'); }
}

function selectLanguage(label, mode) {
 setEditorLanguage(mode, label);
 closeLangSelector();
}

const editorEl = document.getElementById('fileContent');
if(editorEl) {
 editor = CodeMirror(editorEl, {
 value: "",
 theme: "ayu-mirage",
 mode: null,
 indentUnit: 4,
 smartIndent: true,
 tabSize: 4,
 indentWithTabs: false,
 lineWrapping: true,
 lineNumbers: true,
 foldGutter: true,
 fixedGutter: true,
 scrollbarStyle: 'overlay',
 styleActiveLine: true,
 showCursorWhenSelecting: false,
 autofocus: false,
 spellcheck: false,
 autocorrect: false,
 autocapitalize: false,
 inputStyle: 'textarea',
 autoCloseBrackets: true,
 matchBrackets: true,
 gutters: ['CodeMirror-linenumbers', 'CodeMirror-foldgutter'],
 });

 // CUSTOM CSS: Warna Select All ala Pterodactyl (Biru Keputihan) 
 const style = document.createElement('style');
 style.innerHTML = `
 .CodeMirror-selected { background-color: rgba(59, 130, 246, 0.35) !important; }
 .CodeMirror-line::selection, .CodeMirror-line > span::selection, .CodeMirror-line > span > span::selection { background-color: rgba(59, 130, 246, 0.35) !important; }
 .CodeMirror-line::-moz-selection, .CodeMirror-line > span::-moz-selection, .CodeMirror-line > span > span::-moz-selection { background-color: rgba(59, 130, 246, 0.35) !important; }
 `;
 document.head.appendChild(style);
}

window.startProgress = function() {
 let bar = document.getElementById('top-progress-bar');
 if (!bar) {
 bar = document.createElement('div');
 bar.id = 'top-progress-bar';
 bar.className = 'fixed top-0 left-0 h-1 bg-blue-500 z-[9999] shadow-[0_0_10px_rgba(59,130,246,0.8)] transition-all ease-out';
 bar.style.width = '0%';
 document.body.appendChild(bar);
 }

 if (bar._running) return;
 bar._running = true;

 clearInterval(progressInterval);
 bar.style.transitionDuration = '0ms';
 bar.style.width = '0%';
 bar.style.opacity = '1';

 setTimeout(() => {
 bar.style.transitionDuration = '300ms';
 bar.style.width = '30%';
 progressInterval = setInterval(() => {
 let w = parseFloat(bar.style.width);
 if (w < 85) bar.style.width = (w + Math.random() * 10) + '%';
 }, 300);
 }, 10);
};

window.finishProgress = function() {
 let bar = document.getElementById('top-progress-bar');
 if (!bar) return;
 bar._running = false;
 clearInterval(progressInterval);
 bar.style.width = '100%';

 setTimeout(() => {
 bar.style.opacity = '0';
 setTimeout(() => {
 bar.style.width = '0%';
 bar.style.transitionDuration = '0ms';
 }, 300);
 }, 400);
};

window.toggleSearchBar = function() {
 const bar = document.getElementById('customSearchBar');
 if (!bar) return;
 if (bar.classList.contains('hidden')) {
 bar.classList.remove('hidden');
 document.getElementById('editorSearchInput').focus();
 } else {
 bar.classList.add('hidden');
 clearAllSearchMarks(); 
 document.getElementById('editorSearchInput').value = '';
 lastQuery = '';
 editor.focus();
 }
};

let allSearchMarks = [];
function clearAllSearchMarks() {
 allSearchMarks.forEach(m => m.clear());
 allSearchMarks = [];
 if (currentSearchMark) currentSearchMark.clear();
 currentSearchMark = null;
}

function highlightAllMatches(query) {
 clearAllSearchMarks();
 if (!query) return;
 let cursor = editor.getSearchCursor(query, CodeMirror.Pos(0, 0), true);
 while (cursor.findNext()) {
 let mark = editor.markText(cursor.from(), cursor.to(), {className: "cm-search-match"});
 allSearchMarks.push(mark);
 }
}

window.performEditorSearch = function(reverse, isTyping = false) {
 if (!editor) return;
 const searchInput = document.getElementById('editorSearchInput');
 if (!searchInput) return;
 
 const query = searchInput.value;
 
 if (query !== lastQuery) {
 lastQuery = query;
 highlightAllMatches(query);
 searchCursor = editor.getSearchCursor(query, CodeMirror.Pos(0, 0), true);
 }

 if (!query) {
 clearAllSearchMarks();
 return;
 }
 if (!searchCursor) return;

 let found = reverse ? searchCursor.findPrevious() : searchCursor.findNext();
 if (!found) {
 searchCursor = editor.getSearchCursor(query, reverse ? CodeMirror.Pos(editor.lastLine(), 99999) : CodeMirror.Pos(0, 0), true);
 found = reverse ? searchCursor.findPrevious() : searchCursor.findNext();
 }

 if (found) {
 if (currentSearchMark) currentSearchMark.clear();
 currentSearchMark = editor.markText(searchCursor.from(), searchCursor.to(), {className: "cm-search-active"});
 
 if (!isTyping) editor.setSelection(searchCursor.from(), searchCursor.to());
 editor.scrollIntoView({from: searchCursor.from(), to: searchCursor.to()}, 150);
 } else if (!isTyping) {
 if(typeof showToast === 'function') showToast('Teks tidak ditemukan', 'error');
 }
};

window.editorSearchNext = () => performEditorSearch(false);
window.editorSearchPrev = () => performEditorSearch(true);

document.addEventListener('DOMContentLoaded', () => {
 const searchInput = document.getElementById('editorSearchInput');
 if (searchInput) {
 searchInput.addEventListener('input', function() { performEditorSearch(false, true); });
 searchInput.addEventListener('keydown', function(e) {
 if (e.key === 'Enter') { e.preventDefault(); performEditorSearch(false); }
 });
 }
});

const fallbackCopyTextToClipboard = (text) => {
 const textArea = document.createElement("textarea");
 textArea.value = text;
 textArea.style.top = "0";
 textArea.style.left = "0";
 textArea.style.position = "fixed";
 document.body.appendChild(textArea);
 textArea.focus();
 textArea.select();
 try {
 const successful = document.execCommand('copy');
 document.body.removeChild(textArea);
 return successful;
 } catch (err) {
 document.body.removeChild(textArea);
 return false;
 }
};

// FUNGSI BARU UNTUK MANGGIL POP-UP PANEL CUSTOM 
function showCustomConfirm(icon, title, msg, onConfirm) {
 if(document.getElementById('genericModalIcon')) document.getElementById('genericModalIcon').innerText = icon;
 if(document.getElementById('genericModalTitle')) document.getElementById('genericModalTitle').innerText = title;
 if(document.getElementById('genericModalMsg')) document.getElementById('genericModalMsg').innerHTML = msg; 
 const gModal = document.getElementById('genericModal');
 if(gModal) gModal.classList.remove('hidden');
 
 const confirmBtn = document.getElementById('genericConfirmBtn');
 if(confirmBtn) {
 // Clone button biar event listener sebelumnya ilang
 const newBtn = confirmBtn.cloneNode(true);
 confirmBtn.parentNode.replaceChild(newBtn, confirmBtn);
 newBtn.onclick = () => {
 document.getElementById('genericModal').classList.add('hidden');
 if (onConfirm) onConfirm();
 };
 }
}

window.editorAction = async function(action) {
 if (!editor) return;
 
 const isSecure = window.isSecureContext && navigator.clipboard;

 switch(action) {
 case 'search': toggleSearchBar(); break;
 case 'selectAll': editor.execCommand('selectAll'); editor.focus(); break;
 
 // FITUR KOSONGKAN FILE PAKE MODAL ELEGAN 
 case 'clear':
 showCustomConfirm(
 '', 
 'Kosongkan File', 
 'Yakin mau menghapus <b>SEMUA</b> isi file ini?<br><br><span class="text-red-400 text-xs font-medium">(Teks akan kosong, pastikan kamu belum menekan tombol Simpan jika ini tidak disengaja!)</span>',
 () => {
 editor.setValue("");
 if(typeof showToast === 'function') showToast(' Isi file dikosongkan!');
 }
 );
 break;
 
 case 'copy':
 const copyText = editor.getSelection();
 if (copyText) {
 if (isSecure) {
 try { await navigator.clipboard.writeText(copyText); if(typeof showToast === 'function') showToast(' Teks disalin!'); } 
 catch(err) { if(typeof showToast === 'function') showToast('Gagal menyalin teks', 'error'); }
 } else {
 if(fallbackCopyTextToClipboard(copyText)) {
 if(typeof showToast === 'function') showToast(' Teks disalin (Mode HTTP)!');
 } else {
 if(typeof showToast === 'function') showToast('Gagal menyalin. Gunakan HTTPS.', 'error');
 }
 }
 } else { if(typeof showToast === 'function') showToast('Pilih teks dulu!', 'error'); }
 break;
 
 case 'cut':
 const cutText = editor.getSelection();
 if (cutText) {
 if (isSecure) {
 try { await navigator.clipboard.writeText(cutText); editor.replaceSelection(''); if(typeof showToast === 'function') showToast(' Teks dipotong!'); } 
 catch(err) { if(typeof showToast === 'function') showToast('Gagal memotong teks', 'error'); }
 } else {
 if(fallbackCopyTextToClipboard(cutText)) {
 editor.replaceSelection('');
 if(typeof showToast === 'function') showToast(' Teks dipotong (Mode HTTP)!');
 } else {
 if(typeof showToast === 'function') showToast('Gagal memotong. Gunakan HTTPS.', 'error');
 }
 }
 } else { if(typeof showToast === 'function') showToast('Pilih teks dulu!', 'error'); }
 break;
 
 case 'paste':
 if (isSecure && navigator.clipboard.readText) {
 try { const pasteText = await navigator.clipboard.readText(); editor.replaceSelection(pasteText); if(typeof showToast === 'function') showToast(' Teks ditempel!'); } 
 catch(err) { if(typeof showToast === 'function') showToast('Gagal menempel (Cek izin clipboard browser)', 'error'); }
 } else {
 if(typeof showToast === 'function') showToast(' Tombol Paste butuh HTTPS! Gunakan tahan-layar lalu "Tempel"', 'error');
 }
 break;
 }
};

function updateRowBorder(filePath, selected) {
 const cb = document.querySelector(`.file-checkbox[value="${CSS.escape(filePath)}"]`);
 if (cb) { const li = cb.closest('li'); if (li) li.style.borderLeftColor = selected ? '#3b82f6' : 'transparent'; }
}
function toggleSelect(filePath) {
 if (selectedFiles.has(filePath)) { selectedFiles.delete(filePath); updateRowBorder(filePath, false); }
 else { selectedFiles.add(filePath); updateRowBorder(filePath, true); }
 updateDeleteButton();
}
function toggleSelectAll() {
 const checkboxes = document.querySelectorAll('.file-checkbox');
 const selectAll = document.getElementById('selectAll');
 if(!selectAll) return;
 const isChecked = selectAll.checked;
 selectedFiles.clear();
 checkboxes.forEach(cb => {
  cb.checked = isChecked;
  if (isChecked) selectedFiles.add(cb.value);
  const li = cb.closest('li');
  if (li) li.style.borderLeftColor = isChecked ? '#3b82f6' : 'transparent';
 });
 updateDeleteButton();
}

function updateDeleteButton() { 
 const bar = document.getElementById('pteroFloatingBar'); if(!bar) return; 
 const count = selectedFiles.size; 
 if (count > 0) { 
 bar.classList.remove('hidden'); 
 setTimeout(() => { bar.classList.remove('opacity-0', 'scale-90', '-translate-y-4'); bar.classList.add('opacity-100', 'scale-100', 'translate-y-0'); }, 10); 
 } else { 
 bar.classList.remove('opacity-100', 'scale-100', 'translate-y-0'); bar.classList.add('opacity-0', 'scale-90', '-translate-y-4'); 
 setTimeout(() => { bar.classList.add('hidden'); }, 300); 
 const selectAll = document.getElementById('selectAll'); if(selectAll) selectAll.checked = false; 
 } 
}

function showDeleteModal(itemsArray, msg) { 
 if(typeof closeAllDropdowns === 'function') closeAllDropdowns();
 if(document.getElementById('genericModalIcon')) document.getElementById('genericModalIcon').innerText = ''; 
 if(document.getElementById('genericModalTitle')) document.getElementById('genericModalTitle').innerText = 'Delete Files'; 
 if(document.getElementById('genericModalMsg')) document.getElementById('genericModalMsg').innerText = msg; 
 const gModal = document.getElementById('genericModal'); if(gModal) gModal.classList.remove('hidden'); 
 const confirmBtn = document.getElementById('genericConfirmBtn'); 
 if(confirmBtn) { 
 const newBtn = confirmBtn.cloneNode(true); confirmBtn.parentNode.replaceChild(newBtn, confirmBtn); 
 newBtn.onclick = async () => { 
 document.getElementById('genericModal').classList.add('hidden'); 
 startProgress();
 try { 
 const res = await fetch('/api/delete', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ items: itemsArray }) }); 
 if (res.ok) { 
 delete folderCache[currentPath]; 
 selectedFiles.clear(); updateDeleteButton(); await loadFiles(currentPath); 
 if(typeof showToast === 'function') showToast('File berhasil dihapus!');
 } 
 } catch(e) { } finally { finishProgress(); }
 }; 
 } 
}
function deleteSelectedMulti() { showDeleteModal(Array.from(selectedFiles), `Are you sure you want to delete ${selectedFiles.size} items?`); }

window.downloadSelectedFiles = function() {
 const files = Array.from(selectedFiles);
 if (files.length === 0) { if(typeof showToast === 'function') showToast('Pilih file dulu!', 'error'); return; }

 const existing = document.getElementById('bulkDownloadModal');
 if (existing) existing.remove();

 const cachedFiles = folderCache[currentPath] || [];
 const sizeMap = {};
 cachedFiles.forEach(f => { sizeMap[f.path] = f.size || ''; });

 function getBulkFileIcon(filePath) {
  const cachedFiles = folderCache[currentPath] || [];
  const entry = cachedFiles.find(f => f.path === filePath);
  if (entry && entry.isDirectory) {
   return `<svg class="w-4 h-4 text-slate-400 shrink-0" fill="currentColor" viewBox="0 0 512 512"><path d="M464 128H272l-64-64H48C21.49 64 0 85.49 0 112v288c0 26.51 21.49 48 48 48h416c26.51 0 48-21.49 48-48V176c0-26.51-21.49-48-48-48z"/></svg>`;
  }
  const lname = (filePath || '').toLowerCase();
  const isArchive = lname.endsWith('.zip') || lname.endsWith('.tar.gz') || lname.endsWith('.tgz') || lname.endsWith('.tar') || lname.endsWith('.gz') || lname.endsWith('.rar') || lname.endsWith('.7z');
  if (isArchive) {
   return `<svg class="w-4 h-4 text-slate-400 shrink-0" fill="currentColor" viewBox="0 0 384 512"><path d="M377 105L279.1 7c-4.5-4.5-10.6-7-17-7H256v128h128v-6.1c0-6.3-2.5-12.4-7-16.9zm-153 31V0H24C10.7 0 0 10.7 0 24v464c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H248c-13.2 0-24-10.8-24-24zM96 72c0-4.4 3.6-8 8-8h48c4.4 0 8 3.6 8 8v8c0 4.4-3.6 8-8 8h-48c-4.4 0-8-3.6-8-8v-8zm0 64c0-4.4 3.6-8 8-8h48c4.4 0 8 3.6 8 8v8c0 4.4-3.6 8-8 8h-48c-4.4 0-8-3.6-8-8v-8zm160 268c0 17.7-14.3 32-32 32s-32-14.3-32-32v-16h-16c-8.8 0-16-7.2-16-16v-48c0-8.8 7.2-16 16-16h16v-16c0-17.7 14.3-32 32-32s32 14.3 32 32v16h16c8.8 0 16 7.2 16 16v48c0 8.8-7.2 16-16 16h-16v16zm16-332c0 4.4-3.6 8-8 8h-48c-4.4 0-8-3.6-8-8v-8c0-4.4 3.6-8 8-8h48c4.4 0 8 3.6 8 8v8zm0 64c0 4.4-3.6 8-8 8h-48c-4.4 0-8-3.6-8-8v-8c0-4.4 3.6-8 8-8h48c4.4 0 8 3.6 8 8v8z"/></svg>`;
  }
  return `<svg class="w-4 h-4 text-slate-400 shrink-0" fill="currentColor" viewBox="0 0 384 512"><path d="M224 136V0H24C10.7 0 0 10.7 0 24v464c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H248c-13.2 0-24-10.8-24-24zm64 236c0 6.6-5.4 12-12 12H108c-6.6 0-12-5.4-12-12v-8c0-6.6 5.4-12 12-12h168c6.6 0 12 5.4 12 12v8zm0-64c0 6.6-5.4 12-12 12H108c-6.6 0-12-5.4-12-12v-8c0-6.6 5.4-12 12-12h168c6.6 0 12 5.4 12 12v8zm0-72v8c0 6.6-5.4 12-12 12H108c-6.6 0-12-5.4-12-12v-8c0-6.6 5.4-12 12-12h168c6.6 0 12 5.4 12 12zm96-114.1v6.1H256V0h6.1c6.4 0 12.5 2.5 17 7l97.9 98c4.5 4.5 7 10.6 7 16.9z"/></svg>`;
 }

 const fileRows = files.map(filePath => {
  const name = filePath.split('/').pop();
  const size = sizeMap[filePath] || '';
  const icon = getBulkFileIcon(filePath);
  return `<div class="flex items-center gap-3 py-2.5 border-b border-slate-700/50 last:border-0">
   ${icon}
   <span class="text-white font-mono text-sm break-all flex-1 leading-snug">${name}</span>
   ${size ? `<span class="text-blue-400 font-mono font-bold text-xs shrink-0">${size}</span>` : ''}
  </div>`;
 }).join('');

 const modal = document.createElement('div');
 modal.id = 'bulkDownloadModal';
 modal.className = 'fixed inset-0 z-[300] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm tab-fade-in';
 modal.innerHTML = `
  <div class="bg-[#1e293b] w-full max-w-sm rounded-2xl border border-blue-500/40 shadow-2xl overflow-hidden" style="box-shadow:0 0 40px rgba(0,0,0,0.6)">
   <div class="px-6 pt-6 pb-5">
    <div class="flex flex-col items-center text-center gap-2 mb-5">
     <div class="w-14 h-14 rounded-2xl bg-blue-500/15 border border-blue-500/40 flex items-center justify-center"><svg class="w-6 h-6 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M3 16.5v2.25A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75V16.5M7.5 12l4.5 4.5m0 0 4.5-4.5M12 16.5V3"/></svg></div>
     <div>
      <h3 class="text-white font-black text-lg leading-tight">Download ${files.length} File</h3>
      <p class="text-slate-400 text-xs mt-1">Semua file terpilih akan diunduh</p>
     </div>
    </div>
    <div class="bg-slate-900/70 rounded-xl px-4 py-1 border border-slate-700/60 mb-5 max-h-48 overflow-y-auto">
     ${fileRows}
    </div>
    <div class="flex gap-3">
     <button id="bulkDlCancelBtn" class="flex-1 bg-slate-700 hover:bg-slate-600 active:scale-95 text-slate-200 font-bold py-3 rounded-xl transition text-sm">Batal</button>
     <button id="bulkDlConfirmBtn" class="flex-1 bg-blue-600 hover:bg-blue-500 active:scale-95 text-white font-bold py-3 rounded-xl transition text-sm flex items-center justify-center gap-2 shadow-lg shadow-blue-900/40">
      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
      Download Semua
     </button>
    </div>
   </div>
  </div>
 `;

 document.body.appendChild(modal);

 const close = () => { modal.style.opacity = '0'; modal.style.transition = 'opacity 0.15s'; setTimeout(() => modal.remove(), 150); };
 document.getElementById('bulkDlCancelBtn').onclick = close;
 modal.addEventListener('click', e => { if (e.target === modal) close(); });

 document.getElementById('bulkDlConfirmBtn').onclick = () => {
  close();
  let delay = 0;
  files.forEach(filePath => {
   const name = filePath.split('/').pop();
   setTimeout(() => {
    const link = document.createElement('a');
    link.href = `/api/download?path=${encodeURIComponent(filePath)}`;
    link.download = name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
   }, delay);
   delay += 400;
  });
  if(typeof showToast === 'function') showToast(`Mendownload ${files.length} file...`);
 };
};
function deleteSingle(filePath, fileName) { showDeleteModal([filePath], `Delete ${fileName}?`); }
function openRenameModal(filePath, currentName) { if(typeof closeAllDropdowns === 'function') closeAllDropdowns(); if(document.getElementById('renameOldPath')) document.getElementById('renameOldPath').value = filePath; if(document.getElementById('renameInput')) document.getElementById('renameInput').value = currentName; const rModal = document.getElementById('renameModal'); if(rModal) rModal.classList.remove('hidden'); const rInput = document.getElementById('renameInput'); if(rInput) rInput.focus(); }

async function executeRename() { 
 const oldPath = document.getElementById('renameOldPath').value; const newName = document.getElementById('renameInput').value; if(!newName) return; 
 document.getElementById('renameModal').classList.add('hidden'); 
 startProgress();
 try { 
 const res = await fetch('/api/rename', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ oldPath, newName }) }); 
 if (res.ok) { 
 delete folderCache[currentPath]; 
 await loadFiles(currentPath); 
 if(typeof showToast === 'function') showToast('Nama file diubah!');
 } 
 } catch(e) {} finally { finishProgress(); }
}

function showCreateModal(type) {
 if (type === 'file') {
 isNewFile = true;
 currentEditFile = '';
 const editNameEl = document.getElementById('editingFileName');
 if (editNameEl) editNameEl.innerText = 'File Baru (belum disimpan)';

 if (typeof showTab === 'function') showTab('edit', false);
 history.pushState({ tab: 'edit', file: 'new' }, '', ((typeof tabUrlPath === 'function') ? tabUrlPath('files') : window.location.pathname) + '#edit/new');

 // Tampilkan spinner sebentar saat persiapan editor
 const fileContentParent = document.getElementById('fileContent') && document.getElementById('fileContent').parentElement;
 let editorSpinner = document.getElementById('editor-spinner');
 if (fileContentParent && !editorSpinner) {
 editorSpinner = document.createElement('div');
 editorSpinner.id = 'editor-spinner';
 editorSpinner.className = 'absolute inset-0 bg-[#1a1d23] z-[60] flex flex-col items-center justify-center gap-3';
 editorSpinner.innerHTML = `
 <div class="w-8 h-8 border-4 border-slate-600 border-t-blue-500 rounded-full animate-spin"></div>
 <span class="text-slate-400 font-bold text-sm tracking-wide">Menyiapkan editor...</span>
 `;
 fileContentParent.appendChild(editorSpinner);
 }
 if (editorSpinner) editorSpinner.classList.remove('hidden');

 setTimeout(() => {
 if (editor) { editor.setValue(""); editor.clearHistory(); }
 setEditorLanguage(null, 'Plain Text');
 if (editorSpinner) editorSpinner.classList.add('hidden');
 if (editor) editor.focus();
 }, 350);
 return;
 }
 if(document.getElementById('createType')) document.getElementById('createType').value = type; 
 if(document.getElementById('createModalTitle')) document.getElementById('createModalTitle').innerText = 'Create Directory'; 
 const cInput = document.getElementById('createInput'); if(cInput) cInput.value = ''; 
 const cModal = document.getElementById('createModal'); if(cModal) cModal.classList.remove('hidden'); 
 if(cInput) cInput.focus(); 
}

async function executeCreate() { 
 const type = document.getElementById('createType').value; const name = document.getElementById('createInput').value.trim(); if (!name) return; 
 const targetPath = currentPath === '' ? name : `${currentPath}/${name}`; document.getElementById('createModal').classList.add('hidden'); 
 startProgress();
 try { 
 let res;
 if (type === 'file') { res = await fetch('/api/file', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ path: targetPath, content: '' }) }); } 
 else { res = await fetch('/api/folder', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ path: targetPath }) }); } 
 if (res && res.ok) {
 delete folderCache[currentPath]; 
 await loadFiles(currentPath);
 if(typeof showToast === 'function') showToast(`${type === 'file' ? 'File' : 'Folder'} berhasil dibuat!`);
 }
 } catch (e) {} finally { finishProgress(); }
}

function formatLocalTime(isoString) { if (!isoString || isoString === '-') return '-'; const date = new Date(isoString); return `${String(date.getDate()).padStart(2, '0')}/${String(date.getMonth() + 1).padStart(2, '0')}/${date.getFullYear()} ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`; }

window.downloadFile = function(filePath, fileName, fileSize) {
 if(typeof closeAllDropdowns === 'function') closeAllDropdowns();

 const existing = document.getElementById('downloadConfirmModal');
 if (existing) existing.remove();

 const ext = fileName.includes('.') ? fileName.split('.').pop().toLowerCase() : '';
 const iconMap = {
  jar: { icon: '📦', color: 'text-orange-400', bg: 'bg-orange-500/15', border: 'border-orange-500/40' },
  zip: { icon: '🗜️', color: 'text-yellow-400', bg: 'bg-yellow-500/15', border: 'border-yellow-500/40' },
  gz: { icon: '🗜️', color: 'text-yellow-400', bg: 'bg-yellow-500/15', border: 'border-yellow-500/40' },
  json: { icon: '📋', color: 'text-blue-400', bg: 'bg-blue-500/15', border: 'border-blue-500/40' },
  yml: { icon: '⚙️', color: 'text-purple-400', bg: 'bg-purple-500/15', border: 'border-purple-500/40' },
  yaml: { icon: '⚙️', color: 'text-purple-400', bg: 'bg-purple-500/15', border: 'border-purple-500/40' },
  properties: { icon: '⚙️', color: 'text-slate-300', bg: 'bg-slate-500/15', border: 'border-slate-500/40' },
  txt: { icon: '📄', color: 'text-slate-300', bg: 'bg-slate-500/15', border: 'border-slate-500/40' },
  log: { icon: '📜', color: 'text-green-400', bg: 'bg-green-500/15', border: 'border-green-500/40' },
  png: { icon: '🖼️', color: 'text-pink-400', bg: 'bg-pink-500/15', border: 'border-pink-500/40' },
  jpg: { icon: '🖼️', color: 'text-pink-400', bg: 'bg-pink-500/15', border: 'border-pink-500/40' },
  sh: { icon: '💻', color: 'text-green-400', bg: 'bg-green-500/15', border: 'border-green-500/40' },
 };
 const style = iconMap[ext] || { icon: '📁', color: 'text-slate-300', bg: 'bg-slate-500/15', border: 'border-slate-500/40' };

 const modal = document.createElement('div');
 modal.id = 'downloadConfirmModal';
 modal.className = 'fixed inset-0 z-[300] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm tab-fade-in';
 modal.innerHTML = `
  <div class="bg-[#1e293b] w-full max-w-sm rounded-2xl border ${style.border} shadow-2xl overflow-hidden" style="box-shadow:0 0 40px rgba(0,0,0,0.6)">
   <div class="px-6 pt-6 pb-5">
    <div class="flex flex-col items-center text-center gap-3 mb-5">
     <div class="w-16 h-16 rounded-2xl ${style.bg} border ${style.border} flex items-center justify-center text-3xl shadow-inner">
      ${style.icon}
     </div>
     <div>
      <h3 class="text-white font-black text-lg leading-tight">Download File</h3>
      <p class="text-slate-400 text-xs mt-1">Siap untuk diunduh ke perangkat kamu</p>
     </div>
    </div>
    <div class="bg-slate-900/70 rounded-xl px-4 py-3 border border-slate-700/60 mb-5">
     <div class="flex items-start justify-between gap-3">
      <div class="min-w-0 flex-1">
       <p class="text-xs text-slate-400 mb-1 font-semibold uppercase tracking-wider">Nama File</p>
       <p class="text-white font-mono text-sm break-all leading-snug">${fileName}</p>
      </div>
      ${fileSize ? `<div class="shrink-0 text-right">
       <p class="text-xs text-slate-400 mb-1 font-semibold uppercase tracking-wider">Ukuran</p>
       <p class="text-blue-400 font-mono font-bold text-sm">${fileSize}</p>
      </div>` : ''}
     </div>
    </div>
    <div class="flex gap-3">
     <button id="dlCancelBtn" class="flex-1 bg-slate-700 hover:bg-slate-600 active:scale-95 text-slate-200 font-bold py-3 rounded-xl transition text-sm">Batal</button>
     <button id="dlConfirmBtn" class="flex-1 bg-blue-600 hover:bg-blue-500 active:scale-95 text-white font-bold py-3 rounded-xl transition text-sm flex items-center justify-center gap-2 shadow-lg shadow-blue-900/40">
      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
      Download
     </button>
    </div>
   </div>
  </div>
 `;

 document.body.appendChild(modal);

 const close = () => { modal.style.opacity = '0'; modal.style.transition = 'opacity 0.15s'; setTimeout(() => modal.remove(), 150); };

 document.getElementById('dlCancelBtn').onclick = close;
 modal.addEventListener('click', (e) => { if (e.target === modal) close(); });

 document.getElementById('dlConfirmBtn').onclick = () => {
  close();
  if(typeof showToast === 'function') showToast('Mendownload: ' + fileName);
  const link = document.createElement('a');
  link.href = `/api/download?path=${encodeURIComponent(filePath)}`;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
 };
}

window.executeSingleAction = function(filePath, action) { 
 if(typeof closeAllDropdowns === 'function') closeAllDropdowns(); 
 selectedFiles.clear(); selectedFiles.add(filePath); 
 const checkboxes = document.querySelectorAll('.file-checkbox'); checkboxes.forEach(cb => cb.checked = false); 
 const cb = document.querySelector(`input[value="${filePath}"]`); if (cb) cb.checked = true; updateDeleteButton(); 
 if (action === 'move') showMoveModal(); 
 if (action === 'archive') showArchiveModal(); 
}

function formatFileDate(isoDate) {
 if (!isoDate) return '';
 try {
  const d = new Date(isoDate);
  const now = new Date();
  const diffMs = now - d;
  const diffSec = Math.floor(diffMs / 1000);
  const diffMin = Math.floor(diffSec / 60);
  const diffHr = Math.floor(diffMin / 60);
  const diffDay = Math.floor(diffHr / 24);

  if (diffSec < 60) return 'less than a minute ago';
  if (diffMin < 60) return diffMin === 1 ? '1 minute ago' : diffMin + ' minutes ago';
  if (diffHr < 24) return diffHr === 1 ? 'about 1 hour ago' : 'about ' + diffHr + ' hours ago';
  if (diffDay === 1) return '1 day ago';

  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const day = d.getDate();
  const ord = day === 1 || day === 21 || day === 31 ? 'st' : day === 2 || day === 22 ? 'nd' : day === 3 || day === 23 ? 'rd' : 'th';
  let hr = d.getHours();
  const ampm = hr >= 12 ? 'PM' : 'AM';
  hr = hr % 12 || 12;
  const min = String(d.getMinutes()).padStart(2, '0');
  return months[d.getMonth()] + ' ' + day + ord + ', ' + d.getFullYear() + ' ' + hr + ':' + min + ampm;
 } catch(e) { return ''; }
}

// SVG paths diambil dari FontAwesome Free Solid (sama persis seperti Pterodactyl)
const _FA_FOLDER    = `<svg class="w-4 h-4" fill="currentColor" viewBox="0 0 512 512"><path d="M464 128H272l-64-64H48C21.49 64 0 85.49 0 112v288c0 26.51 21.49 48 48 48h416c26.51 0 48-21.49 48-48V176c0-26.51-21.49-48-48-48z"/></svg>`;
const _FA_FILE_ALT  = `<svg class="w-4 h-4" fill="currentColor" viewBox="0 0 384 512"><path d="M224 136V0H24C10.7 0 0 10.7 0 24v464c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H248c-13.2 0-24-10.8-24-24zm64 236c0 6.6-5.4 12-12 12H108c-6.6 0-12-5.4-12-12v-8c0-6.6 5.4-12 12-12h168c6.6 0 12 5.4 12 12v8zm0-64c0 6.6-5.4 12-12 12H108c-6.6 0-12-5.4-12-12v-8c0-6.6 5.4-12 12-12h168c6.6 0 12 5.4 12 12v8zm0-72v8c0 6.6-5.4 12-12 12H108c-6.6 0-12-5.4-12-12v-8c0-6.6 5.4-12 12-12h168c6.6 0 12 5.4 12 12zm96-114.1v6.1H256V0h6.1c6.4 0 12.5 2.5 17 7l97.9 98c4.5 4.5 7 10.6 7 16.9z"/></svg>`;
const _FA_FILE_ARCH = `<svg class="w-4 h-4" fill="currentColor" viewBox="0 0 384 512"><path d="M377 105L279.1 7c-4.5-4.5-10.6-7-17-7H256v128h128v-6.1c0-6.3-2.5-12.4-7-16.9zm-153 31V0H24C10.7 0 0 10.7 0 24v464c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H248c-13.2 0-24-10.8-24-24zM96 72c0-4.4 3.6-8 8-8h48c4.4 0 8 3.6 8 8v8c0 4.4-3.6 8-8 8h-48c-4.4 0-8-3.6-8-8v-8zm0 64c0-4.4 3.6-8 8-8h48c4.4 0 8 3.6 8 8v8c0 4.4-3.6 8-8 8h-48c-4.4 0-8-3.6-8-8v-8zm160 268c0 17.7-14.3 32-32 32s-32-14.3-32-32v-16h-16c-8.8 0-16-7.2-16-16v-48c0-8.8 7.2-16 16-16h16v-16c0-17.7 14.3-32 32-32s32 14.3 32 32v16h16c8.8 0 16 7.2 16 16v48c0 8.8-7.2 16-16 16h-16v16zm16-332c0 4.4-3.6 8-8 8h-48c-4.4 0-8-3.6-8-8v-8c0-4.4 3.6-8 8-8h48c4.4 0 8 3.6 8 8v8zm0 64c0 4.4-3.6 8-8 8h-48c-4.4 0-8-3.6-8-8v-8c0-4.4 3.6-8 8-8h48c4.4 0 8 3.6 8 8v8z"/></svg>`;
const _FA_FILE_IMP  = `<svg class="w-4 h-4" fill="currentColor" viewBox="0 0 512 512"><path d="M16 288c-8.8 0-16 7.2-16 16v32c0 8.8 7.2 16 16 16h112v-64zm489-183L407.1 7c-4.5-4.5-10.6-7-17-7H384v128h128v-6.1c0-6.3-2.5-12.4-7-16.9zm-153 31V0H152c-13.3 0-24 10.7-24 24v264h128v-65.2c0-14.3 17.3-21.4 27.4-11.3L379 308c6.6 6.3 6.6 16.4 0 22.6l-95.7 96.4c-10.1 10.1-27.4 3-27.4-11.3V352H128v136c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H376c-13.2 0-24-10.8-24-24z"/></svg>`;

function getFileIconBadge(name, isDirectory) {
 const lname = (name || '').toLowerCase();
 const DEF = { bg: 'bg-slate-700/60 border-slate-600/50', color: 'text-slate-400' };

 if (isDirectory) return { ...DEF, svg: _FA_FOLDER };

 const isArchive = lname.endsWith('.zip') || lname.endsWith('.tar.gz') || lname.endsWith('.tgz') || lname.endsWith('.tar') || lname.endsWith('.gz') || lname.endsWith('.rar') || lname.endsWith('.7z');
 if (isArchive) return { ...DEF, svg: _FA_FILE_ARCH };

 if (lname.endsWith('.lnk')) return { ...DEF, svg: _FA_FILE_IMP };

 return { ...DEF, svg: _FA_FILE_ALT };
}

function getFileIcon(name, isDirectory) {
 const b = getFileIconBadge(name, isDirectory);
 return `<div class="w-8 h-8 rounded-lg ${b.bg} border ${b.color} flex items-center justify-center shrink-0">${b.svg}</div>`;
}

const _VS_ROW_H = 48;
const _VS_THRESH = 80;
let _vsScrollCb = null;
let _vsScrollEl = null;

function _applyVirtualScroll(htmlBuffer, listElement) {
 if (!listElement) return;
 const scrollEl = listElement.parentElement;
 if (_vsScrollCb && _vsScrollEl) { _vsScrollEl.removeEventListener('scroll', _vsScrollCb); _vsScrollCb = null; }
 const tempDiv = document.createElement('div');
 tempDiv.innerHTML = `<ul>${htmlBuffer}</ul>`;
 const items = Array.from(tempDiv.querySelectorAll('li')).map(li => li.outerHTML);
 if (items.length <= _VS_THRESH) { listElement.innerHTML = htmlBuffer; return; }
 function renderVisible() {
  const scrollTop = scrollEl.scrollTop;
  const viewH = scrollEl.clientHeight || 600;
  const startIdx = Math.max(0, Math.floor(scrollTop / _VS_ROW_H) - 10);
  const endIdx = Math.min(items.length - 1, Math.ceil((scrollTop + viewH) / _VS_ROW_H) + 10);
  const topPad = startIdx * _VS_ROW_H;
  const botPad = (items.length - endIdx - 1) * _VS_ROW_H;
  listElement.innerHTML =
   (topPad > 0 ? `<li style="height:${topPad}px;pointer-events:none;border:none"></li>` : '') +
   items.slice(startIdx, endIdx + 1).join('') +
   (botPad > 0 ? `<li style="height:${botPad}px;pointer-events:none;border:none"></li>` : '');
 }
 _vsScrollCb = renderVisible;
 _vsScrollEl = scrollEl;
 scrollEl.addEventListener('scroll', _vsScrollCb, { passive: true });
 renderVisible();
}

function renderFileListHTML(files, dir, listElement) {
 if(!listElement) return;
 let htmlBuffer = ""; 
 
 if (dir !== '') { 
  const parentPath = dir.split('/').slice(0, -1).join('/'); 
  htmlBuffer += `
  <li onclick="loadFiles('${parentPath}')" class="flex items-center gap-3 px-4 py-2.5 cursor-pointer hover:bg-slate-700/40 border-b border-slate-700/40 transition-all duration-150 group" style="border-left:3px solid transparent" onmouseenter="this.style.borderLeftColor='#3b82f6'" onmouseleave="this.style.borderLeftColor='transparent'">
   <span class="w-4 h-4 shrink-0"></span>
   <div class="w-8 h-8 rounded-lg bg-slate-700/50 border border-slate-600/40 flex items-center justify-center shrink-0">
    <svg class="w-4 h-4 text-slate-400 group-hover:text-blue-400 transition" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
   </div>
   <span class="text-slate-400 group-hover:text-slate-200 text-sm font-medium transition select-none">..</span>
  </li>`; 
 } 
 
 files.forEach((file, index) => { 
  const iconSvg = getFileIcon(file.name, file.isDirectory);
  const action = file.isDirectory ? `loadFiles('${file.path}')` : `openFile('${file.path}', '${file.name}')`; 
  const menuId = `menu-${index}`; 
  const lname = file.name.toLowerCase(); 

  let unarchiveBtn = ''; 
  if (!file.isDirectory && (lname.endsWith('.zip') || lname.endsWith('.tar.gz') || lname.endsWith('.tgz'))) { 
   unarchiveBtn = `
   <div onclick="event.stopPropagation(); executeExtract('${file.path}')" class="px-4 py-2.5 hover:bg-white/10 text-slate-300 text-sm cursor-pointer flex items-center gap-3 transition">
    <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"/></svg>
    Extract
   </div>`; 
  } 
 
  let downloadBtn = '';
  if (!file.isDirectory) {
   downloadBtn = `
   <div onclick="event.stopPropagation(); downloadFile('${file.path}', '${file.name}', '${file.size || ''}')" class="px-4 py-2.5 hover:bg-white/10 text-slate-300 text-sm cursor-pointer flex items-center gap-3 transition">
    <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
    Download
   </div>`;
  }

  const fileDateStr = formatFileDate(file.date);
  const sizeHtml = file.size ? `<span class="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-slate-700/70 text-slate-300 font-mono border border-slate-600/40 whitespace-nowrap">${file.size}</span>` : '';
  htmlBuffer += `
  <li onclick="${action}" class="flex items-center gap-3 px-4 py-2.5 cursor-pointer hover:bg-slate-700/40 border-b border-slate-700/40 last:border-0 transition-all duration-150 group relative" style="border-left:3px solid transparent" onmouseenter="this.style.borderLeftColor='#3b82f6'" onmouseleave="this.style.borderLeftColor=selectedFiles.has('${file.path}')?'#3b82f6':'transparent'">
   <input type="checkbox" value="${file.path}" class="file-checkbox w-4 h-4 rounded cursor-pointer accent-blue-500 shrink-0 opacity-100 sm:opacity-40 sm:group-hover:opacity-100 transition-opacity" onclick="event.stopPropagation(); toggleSelect(this.value)">
   ${iconSvg}
   <span class="flex-grow text-slate-100 text-sm truncate min-w-0 font-medium">${file.name}</span>
   <div class="flex items-center shrink-0 gap-2.5">
    ${sizeHtml}
    <span class="text-[10px] text-slate-500 whitespace-nowrap">${fileDateStr || ''}</span>
   </div>
   <div class="relative shrink-0">
    <button onclick="toggleMenu(event, '${menuId}')" class="w-8 h-8 flex items-center justify-center text-slate-500 hover:text-slate-200 hover:bg-blue-500/20 rounded-lg transition opacity-100 sm:opacity-0 sm:group-hover:opacity-100">
     <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path d="M6 10a2 2 0 11-4 0 2 2 0 014 0zM12 10a2 2 0 11-4 0 2 2 0 014 0zM16 12a2 2 0 100-4 2 2 0 000 4z"/></svg>
    </button>
    <div id="${menuId}" class="dropdown-menu hidden w-48 bg-[#1e293b] border border-slate-600/80 rounded-lg shadow-2xl py-1 origin-top-right">
     ${unarchiveBtn}
     ${downloadBtn}
     <div onclick="event.stopPropagation(); openRenameModal('${file.path}', '${file.name}')" class="px-4 py-2.5 hover:bg-white/10 text-slate-300 text-sm cursor-pointer flex items-center gap-3 transition">
      <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
      Rename
     </div>
     <div onclick="event.stopPropagation(); executeSingleAction('${file.path}', 'move')" class="px-4 py-2.5 hover:bg-white/10 text-slate-300 text-sm cursor-pointer flex items-center gap-3 transition">
      <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4"/></svg>
      Move
     </div>
     <div onclick="event.stopPropagation(); executeSingleAction('${file.path}', 'archive')" class="px-4 py-2.5 hover:bg-white/10 text-slate-300 text-sm cursor-pointer flex items-center gap-3 transition">
      <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"/></svg>
      Archive
     </div>
     <div class="h-px bg-slate-600/50 my-1"></div>
     <div onclick="event.stopPropagation(); deleteSingle('${file.path}', '${file.name}')" class="px-4 py-2.5 hover:bg-red-500/10 text-red-400 text-sm font-medium cursor-pointer flex items-center gap-3 transition">
      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
      Delete
     </div>
    </div>
   </div>
  </li>`; 
 });
 
 _applyVirtualScroll(htmlBuffer, listElement);
}

async function loadFiles(dir = '', addToHistory = true) {
 const gen = ++_loadFilesGen;
 startProgress();
 currentPath = dir;

 const pathEl = document.getElementById('currentDirPath');
 if (pathEl) {
  let breadcrumbHTML = `
  <span class="text-slate-500 cursor-not-allowed select-none">/ home</span>
  <span class="text-slate-600 mx-1.5">/</span>
  <span onclick="loadFiles('')" class="cursor-pointer hover:text-blue-400 transition text-slate-300 font-bold">container</span>
  `;
  if (dir !== '') {
   const parts = dir.replace(/^\/+/, '').split('/').filter(Boolean);
   let buildPath = '';
   parts.forEach((part, idx) => {
    buildPath += (idx === 0 ? part : '/' + part);
    breadcrumbHTML += `<span class="text-slate-600 mx-1.5">/</span>`;
    if (idx === parts.length - 1) {
     breadcrumbHTML += `<span class="font-black text-slate-100">${part}</span>`;
    } else {
     breadcrumbHTML += `<span onclick="loadFiles('${buildPath}')" class="cursor-pointer hover:text-blue-400 transition text-slate-300">${part}</span>`;
    }
   });
  }
  pathEl.innerHTML = breadcrumbHTML;
 }

 selectedFiles.clear();
 updateDeleteButton();

 const list = document.getElementById('fileList');
 if (addToHistory) {
  const newHash = dir === '' ? '' : `#${dir}`;
  const basePath = (typeof tabUrlPath === 'function') ? tabUrlPath('files') : window.location.pathname;
  const newUrl = basePath + newHash;
  if (window.location.pathname + window.location.hash !== newUrl) history.pushState({ tab: 'files', path: dir }, '', newUrl);
 }

 if (folderCache[dir]) {
  const _cachedFiles = folderCache[dir];
  setTimeout(() => {
   if (gen !== _loadFilesGen) return;
   renderFileListHTML(_cachedFiles, dir, list);
   finishProgress();
  }, 10);
  return;
 }

 if (list) {
  list.innerHTML = `
  <li class="p-8 bg-[#1e293b] rounded-xl text-center text-slate-400 font-bold flex flex-col items-center justify-center gap-3 w-full h-full min-h-[200px] border border-slate-700/50 shadow-sm">
  <div class="w-8 h-8 border-4 border-slate-600 border-t-blue-500 rounded-full animate-spin"></div>
  <span class="text-sm tracking-wide">Memuat folder...</span>
  </li>
  `;
 }

 try {
  const res = await fetch(`/api/files?path=${encodeURIComponent(dir)}`);
  if (gen !== _loadFilesGen) return;
  if (res.status === 401) return window.location.href = '/';
  const files = await res.json();
  if (gen !== _loadFilesGen) return;
  folderCache[dir] = files;
  renderFileListHTML(files, dir, list);
 } catch(e) {
 } finally {
  if (gen === _loadFilesGen) finishProgress();
 }
}

const BINARY_EXTENSIONS = new Set(['jar','zip','tar','gz','tgz','war','ear','rar','7z','bz2','xz','zst','whl','egg','apk','ipa','exe','dll','so','dylib','bin','dat','db','sqlite','sqlite3','class','pyc','pyd','pyo','pdf','png','jpg','jpeg','gif','webp','bmp','ico','tiff','svg','mp3','mp4','wav','ogg','webm','mov','avi','mkv','flac','aac','woff','woff2','ttf','eot','otf']);

async function openFile(filePath, fileName, addToHistory = true) {
 isNewFile = false;
 if(!fileName) fileName = filePath.split('/').pop();

 const ext = fileName.includes('.') ? fileName.split('.').pop().toLowerCase() : '';
 const base = fileName.toLowerCase();
 const isBinary = BINARY_EXTENSIONS.has(ext) || base.endsWith('.tar.gz') || base.endsWith('.tar.bz2') || base.endsWith('.tar.xz');

 if (isBinary) {
 if(typeof showToast === 'function') showToast(`File "${fileName}" adalah file binary dan tidak bisa dibuka sebagai teks. Gunakan menu ⋮ untuk Extract atau Download.`, 'error');
 return;
 }

 startProgress(); 
 currentEditFile = filePath;
 // Build Pterodactyl-style breadcrumb: / home / container / server.properties
 (function buildBreadcrumb(fp) {
  const el = document.getElementById('editorBreadcrumb');
  if (!el) return;
  const parts = fp.replace(/^\/+/, '').split('/').filter(Boolean);
  if (!parts.length) { el.innerHTML = '<span class="text-slate-500">Edit File</span>'; return; }
  let html = '<span class="text-slate-600 px-0.5">/</span>';
  let accPath = '';
  parts.forEach(function(part, i) {
   accPath += '/' + part;
   const isLast = i === parts.length - 1;
   const esc = accPath.replace(/\\/g,'\\\\').replace(/'/g,"\\'");
   if (isLast) {
    html += '<span class="text-white font-semibold px-1">' + part + '</span>';
   } else {
    html += '<span class="text-slate-400 hover:text-blue-400 cursor-pointer transition-colors px-1" onclick="closeEditor();loadFiles(\'' + esc + '\')">' + part + '</span>';
    html += '<span class="text-slate-600 px-0.5">/</span>';
   }
  });
  el.innerHTML = html;
 })(filePath);

 lastQuery = '';
 searchCursor = null;
 clearAllSearchMarks();
 
 const searchInput = document.getElementById('editorSearchInput');
 if(searchInput) searchInput.value = '';
 
 const searchBar = document.getElementById('customSearchBar');
 if(searchBar) searchBar.classList.add('hidden');

 const [mode, langLabel] = detectLanguage(filePath);

 const fileContentParent = document.getElementById('fileContent').parentElement;
 let editorSpinner = document.getElementById('editor-spinner');
 if (!editorSpinner) {
 editorSpinner = document.createElement('div');
 editorSpinner.id = 'editor-spinner';
 editorSpinner.className = 'absolute inset-0 bg-[#1d1f21] z-[60] flex flex-col items-center justify-center gap-3';
 editorSpinner.innerHTML = `
 <div class="w-8 h-8 border-4 border-slate-600 border-t-blue-500 rounded-full animate-spin"></div>
 <span class="text-slate-400 font-bold text-sm tracking-wide">Memuat teks...</span>
 `;
 fileContentParent.appendChild(editorSpinner);
 }
 editorSpinner.classList.remove('hidden');

 setEditorLanguage(null, 'Plain Text');
 if (editor) editor.setValue("");

 if(typeof showTab === 'function') showTab('edit', false);
 if (addToHistory) history.pushState({ tab: 'edit', file: filePath }, '', ((typeof tabUrlPath === 'function') ? tabUrlPath('files') : window.location.pathname) + '#edit/' + filePath);

 try {
 const res = await fetch(`/api/file?path=${encodeURIComponent(filePath)}`); 
 if (res.status === 401) return window.location.href = "/"; 
 const content = await res.text(); 
 if (editor) { editor.setValue(content); editor.clearHistory(); }
 setEditorLanguage(mode, langLabel);
 } catch(e) {
 if (editor) editor.setValue("// Gagal memuat isi file. Coba lagi.");
 setEditorLanguage(null, 'Plain Text');
 } finally { 
 finishProgress(); 
 if (editorSpinner) editorSpinner.classList.add('hidden'); 
 }
}

function closeEditor() {
 const savedPath = currentPath;
 window._skipFileReset = true;
 if(typeof showTab === 'function') showTab('files', false);
 currentPath = savedPath;
 const newHash = savedPath === '' ? '' : `#${savedPath}`;
 history.pushState({ tab: 'files', path: savedPath }, '', ((typeof tabUrlPath === 'function') ? tabUrlPath('files') : window.location.pathname) + newHash);
 delete folderCache[savedPath];
 loadFiles(savedPath, false);
}

async function saveFile() { 
 if (!editor) return;
 if (isNewFile || !currentEditFile) {
 const modal = document.getElementById('saveAsModal');
 if (modal) {
 document.getElementById('saveAsInput').value = '';
 modal.classList.remove('hidden');
 setTimeout(() => document.getElementById('saveAsInput').focus(), 100);
 }
 return;
 }
 startProgress(); 
 try { 
 const res = await fetch('/api/file', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ path: currentEditFile, content: editor.getValue() }) }); 
 if(res.ok && typeof showToast === 'function') showToast('File Tersimpan!'); 
 } catch(e) {} finally { finishProgress(); }
}

async function executeSaveAs() {
 const nameInput = document.getElementById('saveAsInput');
 const name = nameInput ? nameInput.value.trim() : '';
 if (!name) { if (typeof showToast === 'function') showToast('Nama file wajib diisi!', 'error'); return; }
 const targetPath = currentPath === '' ? name : `${currentPath}/${name}`;
 document.getElementById('saveAsModal').classList.add('hidden');
 startProgress();
 try {
 const res = await fetch('/api/file', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ path: targetPath, content: editor.getValue() }) });
 if (res.ok) {
 isNewFile = false;
 currentEditFile = targetPath;
 const editNameEl = document.getElementById('editingFileName');
 if (editNameEl) editNameEl.innerText = name;
 history.replaceState({ tab: 'edit', file: targetPath }, '', ((typeof tabUrlPath === 'function') ? tabUrlPath('files') : window.location.pathname) + '#edit/' + targetPath);
 delete folderCache[currentPath];
 const [detectedMode, detectedLabel] = detectLanguage(name);
 setEditorLanguage(detectedMode, detectedLabel);
 if (typeof showToast === 'function') showToast('File berhasil disimpan!');
 } else {
 if (typeof showToast === 'function') showToast('Gagal menyimpan file', 'error');
 }
 } catch(e) { if (typeof showToast === 'function') showToast('Error jaringan', 'error'); } 
 finally { finishProgress(); }
}

// === UPLOAD: Sistem baru akan ditambahkan di sini ===

async function executeExtract(filePath) { 
 if(typeof closeAllDropdowns === 'function') closeAllDropdowns(); 
 startProgress(); 
 try { 
 const res = await fetch('/api/extract', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ filePath: filePath, destination: currentPath }) }); 
 if(res.ok) {
 delete folderCache[currentPath];
 await loadFiles(currentPath); 
 if(typeof showToast === 'function') showToast('Ekstrak berhasil!');
 } else {
 if(typeof showToast === 'function') showToast('Gagal mengekstrak', 'error');
 }
 } catch(e) {} finally { finishProgress(); }
}

function showArchiveModal() {
 const now = new Date();
 const pad = n => String(n).padStart(2, '0');
 const datePart = `${now.getFullYear()}-${pad(now.getMonth()+1)}-${pad(now.getDate())}`;
 const timePart = `${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;
 const archiveName = `archive-${datePart}T${timePart}Z.tar.gz`;
 executeArchiveWithName(archiveName);
}

async function executeArchiveWithName(name) {
 startProgress();
 try {
 const res = await fetch('/api/archive', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ items: Array.from(selectedFiles), archiveName: name, currentPath: currentPath }) });
 if(res.ok) {
 delete folderCache[currentPath];
 selectedFiles.clear(); updateDeleteButton(); await loadFiles(currentPath);
 if(typeof showToast === 'function') showToast('Arsip berhasil dibuat: ' + name);
 } else {
 if(typeof showToast === 'function') showToast('Gagal membuat arsip', 'error');
 }
 } catch(e) {} finally { finishProgress(); }
}

async function executeArchive() { 
 const name = document.getElementById('archiveInput').value.trim(); if(!name) return; 
 document.getElementById('archiveModal').classList.add('hidden'); 
 await executeArchiveWithName(name);
}

window.showMoveModal = function() { 
 moveTargetPath = currentPath; 
 const mModal = document.getElementById('moveModal'); 
 if(mModal) mModal.classList.remove('hidden'); 
 
 const mInput = document.getElementById('moveNewDirInput'); 
 if(mInput) mInput.value = ''; 
 
 loadMoveFolders(moveTargetPath); 
}

window.loadMoveFolders = async function(targetDir) {
 moveTargetPath = targetDir;
 const listEl = document.getElementById('moveFolderList');
 const pathText = document.getElementById('moveCurrentPathText');
 
 if(pathText) { pathText.innerText = targetDir === '' ? '/home/container/' : `/home/container/${targetDir}/`; }
 if(listEl) { listEl.innerHTML = '<div class="flex justify-center py-6"><div class="w-6 h-6 border-4 border-slate-600 border-t-blue-500 rounded-full animate-spin"></div></div>'; }
 
 try {
 const res = await fetch(`/api/files?path=${encodeURIComponent(targetDir)}`);
 if (!res.ok) throw new Error('Failed');
 const files = await res.json();
 
 let htmlBuffer = '';
 
 if (targetDir !== '') {
 const parentPath = targetDir.split('/').slice(0, -1).join('/');
 htmlBuffer += `
 <button onclick="loadMoveFolders('${parentPath}')" class="w-full bg-slate-800/80 hover:bg-slate-700 border border-slate-700/80 p-3 rounded-xl flex items-center justify-center gap-2 text-slate-300 font-bold transition active:scale-95 shadow-sm mb-1">
 <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
 Go back
 </button>
 `;
 }
 
 const dirs = files.filter(f => f.isDirectory);
 if (dirs.length === 0) {
 htmlBuffer += '<p class="text-center text-slate-500 py-6 text-xs font-bold">Tidak ada sub-folder di sini.</p>';
 } else {
 dirs.forEach(dir => {
 htmlBuffer += `
 <div onclick="loadMoveFolders('${dir.path}')" class="w-full bg-slate-800 hover:bg-slate-700 border border-slate-700/80 p-3.5 rounded-xl flex items-center gap-3 text-slate-200 font-bold transition cursor-pointer active:scale-95 shadow-sm group">
 <svg class="w-4 h-4 text-blue-400 shrink-0" fill="currentColor" viewBox="0 0 24 24"><path d="M10 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z"/></svg>
 <span class="truncate">${dir.name}</span>
 </div>
 `;
 });
 }
 
 if(listEl) listEl.innerHTML = htmlBuffer;
 } catch (e) {
 if(listEl) listEl.innerHTML = '<p class="text-center text-red-400 py-4 text-xs font-bold">Gagal memuat direktori.</p>';
 }
}

window.createDirInMove = async function() {
 const input = document.getElementById('moveNewDirInput');
 if (!input) return;
 const name = input.value.trim();
 if (!name) return;
 
 const targetPath = moveTargetPath === '' ? name : `${moveTargetPath}/${name}`;
 input.disabled = true;
 
 try {
 const res = await fetch('/api/folder', { 
 method: 'POST', 
 headers: { 'Content-Type': 'application/json' }, 
 body: JSON.stringify({ path: targetPath }) 
 });
 
 if (res.ok) {
 input.value = '';
 delete folderCache[moveTargetPath]; 
 await loadMoveFolders(moveTargetPath); 
 if(typeof showToast === 'function') showToast('Folder ' + name + ' berhasil dibuat!');
 } else {
 if(typeof showToast === 'function') showToast('Nama sudah ada / gagal dibuat', 'error');
 }
 } catch(e) {
 if(typeof showToast === 'function') showToast('Error jaringan', 'error');
 } finally {
 input.disabled = false;
 input.focus();
 }
}

window.executeInteractiveMove = async function() { 
 document.getElementById('moveModal').classList.add('hidden'); 
 startProgress(); 
 try { 
 const res = await fetch('/api/move', { 
 method: 'POST', 
 headers: { 'Content-Type': 'application/json' }, 
 body: JSON.stringify({ items: Array.from(selectedFiles), destination: moveTargetPath }) 
 }); 
 
 if(res.ok) {
 delete folderCache[currentPath]; 
 delete folderCache[moveTargetPath]; 
 selectedFiles.clear(); 
 updateDeleteButton(); 
 await loadFiles(currentPath); 
 if(typeof showToast === 'function') showToast('File berhasil dipindah!');
 } else {
 if(typeof showToast === 'function') showToast('Gagal memindah file', 'error');
 }
 } catch(e) {
 if(typeof showToast === 'function') showToast('Error jaringan', 'error');
 } finally { 
 finishProgress(); 
 }
}

window.addEventListener('popstate', function(event) {
 const hash = window.location.hash;
 const pathTab = (typeof getTabFromPath === 'function') ? getTabFromPath() : null;
 if (hash.startsWith('#edit/')) {
  if(typeof showTab === 'function') showTab('edit', false);
  let file = hash.replace('#edit/', '');
  openFile(file, '', false);
 } else if (pathTab === 'files' || hash === '#files' || hash.startsWith('#files/')) {
  window._skipFileReset = true;
  if(typeof showTab === 'function') showTab('files', false);
  let dir = hash.replace(/^#files/, '');
  if (dir.startsWith('/')) dir = dir.substring(1);
  else if (dir.startsWith('#')) dir = dir.substring(1);
  loadFiles(dir, false);
 }
});

/* =========================================
 MODULE: CHUNKED UPLOAD MANAGER
 ========================================= */

const UPLOAD_CHUNK_SIZE        = 15 * 1024; // 15KB per chunk
const UPLOAD_CONCURRENCY_MIN   = 1;
const UPLOAD_CONCURRENCY_MAX   = 128; // batas atas worker; adaptive naik sampai sini
const UPLOAD_CONCURRENCY_START = 10;  // mulai dari 10, naik +5 tiap stabil, turun -5 kalau lambat

const MAX_CONCURRENT_UPLOADS = 4; // maks 4 upload bersamaan, sisanya antrian
let _activeUploadCount = 0;   // berapa upload sedang berjalan
let _activeUploadJobs = new Map(); // safeId → { cancelFn, fileName }

let _uploadQueue = [];        // antrian file yang mau diupload
let _uploadActive = false;    // lagi ada upload ga
let _uploadPaused = false;    // sedang di-pause (global — pause semua)
let _uploadCancelled = false; // di-cancel (global — cancel semua)
let _uploadCurrentId = null;  // uploadId yang paling terakhir (compat restore mode)
let _heartbeatInterval = null; // interval heartbeat untuk jaga session tetap hidup (restore mode)

// -- Heartbeat: kirim ping ke server setiap 4 menit agar session tidak di-expire saat dijeda --
function _startHeartbeat(uploadId) {
 _stopHeartbeat();
 if (!uploadId) return;
 _heartbeatInterval = setInterval(async () => {
  try {
   const r = await fetch('/api/upload/heartbeat', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ uploadId })
   });
   const data = await r.json().catch(() => ({}));
   if (data.expired) _stopHeartbeat(); // session sudah hilang, stop ping
  } catch(e) {}
 }, 4 * 60 * 1000); // setiap 4 menit
}
function _stopHeartbeat() {
 if (_heartbeatInterval) { clearInterval(_heartbeatInterval); _heartbeatInterval = null; }
}

// -- Tombol upload di toolbar --
function triggerUpload() {
 const input = document.getElementById('uploadFileInput');
 if (input) { input.value = ''; input.click(); }
}

function onUploadFilesSelected(event) {
 const files = Array.from(event.target.files);
 if (!files.length) return;
 queueUploadFiles(files);
}

function queueUploadFiles(files) {
 const destPath = (typeof currentPath !== 'undefined') ? currentPath : '';
 _uploadQueue.push(...files.map(f => ({ file: f, destPath })));
 showUploadPanel();
 _updateQueueListUI();
 _fillUploadSlots();
}

let _lastUploadSucceeded = true; // status hasil upload terakhir, dipakai buat nentuin auto-close panel

function _scheduleAutoClosePanel() {
 // Jangan tutup panel kalau URL download masih aktif
 setTimeout(() => { if (!_uploadActive && _activeRemoteDownloadJobs.size === 0) closeUploadPanel(); }, 2200);
}

// -- Isi slot upload sampai batas MAX_CONCURRENT_UPLOADS --
function _fillUploadSlots() {
 while (_uploadQueue.length > 0 && _activeUploadCount < MAX_CONCURRENT_UPLOADS) {
  const item = _uploadQueue.shift();
  _runSingleUpload(item);
 }
 _updateQueueListUI();
}

// -- Jalankan 1 file upload; setelah selesai, ambil slot berikutnya dari antrian --
async function _runSingleUpload(item) {
 _activeUploadCount++;
 _uploadActive = true;
 // Selalu chunked: 5KB × 10 paralel → progress smooth + resume support
 await _startChunkedUpload(item);
 const dp = (typeof currentPath !== 'undefined') ? currentPath : '';
 if (!_uploadCancelled && item.destPath === dp) {
  if (typeof folderCache !== 'undefined') delete folderCache[dp];
  if (typeof loadFiles === 'function') await loadFiles(dp);
 }
 _activeUploadCount--;
 if (_uploadCancelled) {
  if (_activeUploadCount === 0) {
   _uploadQueue = [];
   _uploadCancelled = false;
   _uploadActive = false;
   _setUploadDone();
   _updateQueueListUI();
  }
  return;
 }
 // Slot bebas — ambil file berikutnya dari antrian (jika ada)
 _fillUploadSlots();
 // Kalau benar-benar semua selesai (tidak ada yang aktif + antrian kosong)
 if (_activeUploadCount === 0 && _uploadQueue.length === 0) {
  _uploadActive = false;
  _setUploadDone();
  if (_lastUploadSucceeded) _scheduleAutoClosePanel();
 }
}

// -- Core: upload langsung tanpa chunk (progress via XHR) --
async function _startDirectUpload({ file, destPath }) {
 // Buat ID unik untuk kartu UI (bukan dari server, langsung di client)
 const cardId = 'dir_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
 const _safeCardId = cardId.replace(/[^a-zA-Z0-9_-]/g, '');

 _createUploadCard(_safeCardId, file.name, file.size);
 _updateUploadCard(_safeCardId, { size: file.size, progress: 0, speed: 0, done: 0, total: 1, status: 'uploading' });

 let _localCancelled = false;
 let _xhr = null;

 _activeUploadJobs.set(_safeCardId, {
  cancelFn: () => { _localCancelled = true; if (_xhr) _xhr.abort(); },
  fileName: file.name
 });

 let _lastLoaded = 0;
 let _lastTime = performance.now();
 let _speed = 0;

 return new Promise((resolve) => {
  const fd = new FormData();
  fd.append('file', file, file.name);
  fd.append('destPath', destPath || '');

  _xhr = new XMLHttpRequest();

  // Progress real-time dari XHR upload
  _xhr.upload.addEventListener('progress', (e) => {
   if (!e.lengthComputable) return;
   const now = performance.now();
   const elapsed = (now - _lastTime) / 1000;
   if (elapsed >= 0.3 && e.loaded > _lastLoaded) {
    _speed = (e.loaded - _lastLoaded) / elapsed;
    _lastLoaded = e.loaded;
    _lastTime = now;
   }
   const pct = (e.loaded / e.total) * 100;
   _updateUploadCard(_safeCardId, { size: file.size, progress: pct, speed: _speed, done: Math.floor(e.loaded / 1024), total: Math.ceil(e.total / 1024), status: 'uploading' });
  });

  // Upload selesai (sukses atau error HTTP)
  _xhr.addEventListener('load', () => {
   if (_localCancelled) { _removeUploadCard(_safeCardId); _activeUploadJobs.delete(_safeCardId); return resolve(); }
   if (_xhr.status >= 200 && _xhr.status < 300) {
    _lastUploadSucceeded = true;
    if (typeof showToast === 'function') showToast('Upload selesai: ' + file.name);
    _updateUploadCard(_safeCardId, { size: file.size, progress: 100, speed: 0, done: 1, total: 1, status: 'done' });
    setTimeout(() => _removeUploadCard(_safeCardId), 1500);
   } else {
    _lastUploadSucceeded = false;
    let errMsg = 'Error ' + _xhr.status;
    try { errMsg = JSON.parse(_xhr.responseText).error || errMsg; } catch(e) {}
    if (typeof showToast === 'function') showToast('Gagal upload: ' + errMsg, 'error');
    _updateUploadCard(_safeCardId, { size: file.size, progress: 0, speed: 0, done: 0, total: 1, status: 'paused' });
   }
   _activeUploadJobs.delete(_safeCardId);
   resolve();
  });

  // Error jaringan
  _xhr.addEventListener('error', () => {
   if (_localCancelled) { _removeUploadCard(_safeCardId); }
   else {
    _lastUploadSucceeded = false;
    if (typeof showToast === 'function') showToast('Koneksi error: ' + file.name, 'error');
    _updateUploadCard(_safeCardId, { size: file.size, progress: 0, speed: 0, done: 0, total: 1, status: 'paused' });
   }
   _activeUploadJobs.delete(_safeCardId);
   resolve();
  });

  // Di-abort (tombol X atau cancel global)
  _xhr.addEventListener('abort', () => {
   _removeUploadCard(_safeCardId);
   _activeUploadJobs.delete(_safeCardId);
   resolve();
  });

  _xhr.open('POST', '/api/upload/direct');
  _xhr.send(fd);
 });
}

// -- Core: upload satu file secara chunked --
async function _startChunkedUpload({ file, destPath }) {
 const totalChunks = Math.max(1, Math.ceil(file.size / UPLOAD_CHUNK_SIZE));

 // Cek localStorage untuk resume session yang tersimpan sebelumnya
 const resumeKey = `${_LS('upload_resume')}_${file.name}_${file.size}_${destPath}`;
 const savedResumeId = localStorage.getItem(resumeKey) || null;

 // Init session (backend balikin uploadId + chunk mana yg udah ada)
 let initData;
 try {
  const r = await fetch('/api/upload/init', {
   method: 'POST', headers: { 'Content-Type': 'application/json' },
   body: JSON.stringify({ fileName: file.name, fileSize: file.size, destPath, totalChunks, resumeId: savedResumeId })
  });
  if (!r.ok) throw new Error('HTTP ' + r.status);
  initData = await r.json();
 } catch(e) {
  if(typeof showToast === 'function') showToast('Gagal memulai upload: ' + e.message, 'error');
  return;
 }

 const { uploadId, receivedChunks } = initData;
 // safeId = key yang sama dipakai oleh tombol X di kartu UI (cancelSingleUpload)
 const _safeId = String(uploadId).replace(/[^a-zA-Z0-9_-]/g, '');
 try { localStorage.setItem(resumeKey, uploadId); } catch(e) {}
 try { localStorage.setItem(_LS('upload_active'), JSON.stringify({ fileName: file.name, fileSize: file.size, destPath, totalChunks })); } catch(e) {}
 _uploadCurrentId = uploadId;

 // XHR tracker — ganti fetch+AbortController → XHR supaya bisa dapat progress
 // per-byte di dalam tiap chunk lewat xhr.upload.onprogress.
 // Semua worker yang aktif share Set ini; cancel tinggal abort() semua XHR sekaligus.
 let _activeChunkXHRs = new Set();
 // Map: chunkIndex → bytes yang sudah terkirim (in-flight, belum selesai).
 // Dipakai untuk menghitung progress smooth = bytesSelesai + Σ inFlight.
 let _chunkInFlightBytes = new Map();

 // Per-job cancel state (tidak ganggu upload lain)
 let _localCancelled = false;
 // BUGFIX: pakai _safeId sebagai key (sama dengan yang dikirim tombol X via cancelSingleUpload)
 _activeUploadJobs.set(_safeId, {
  cancelFn: () => {
   _localCancelled = true;
   // Abort semua XHR chunk yang sedang in-flight sekaligus
   for (const xhr of _activeChunkXHRs) { try { xhr.abort(); } catch(e) {} }
   _activeChunkXHRs.clear();
   _chunkInFlightBytes.clear();
  },
  fileName: file.name
 });

 // Per-job heartbeat (tidak override global)
 let _localHeartbeatTimer = null;
 const _startLocalHB = () => {
  if (_localHeartbeatTimer) clearInterval(_localHeartbeatTimer);
  _localHeartbeatTimer = setInterval(async () => {
   try { const r = await fetch('/api/upload/heartbeat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ uploadId }) }); const d = await r.json().catch(() => ({})); if (d.expired) clearInterval(_localHeartbeatTimer); } catch(e) {}
  }, 4 * 60 * 1000);
 };
 const _stopLocalHB = () => { if (_localHeartbeatTimer) { clearInterval(_localHeartbeatTimer); _localHeartbeatTimer = null; } };
 _startLocalHB();

 const received = new Set(receivedChunks || []);
 let bytesUploaded = [...received].reduce((sum, i) => sum + (i < totalChunks - 1 ? UPLOAD_CHUNK_SIZE : (file.size - i * UPLOAD_CHUNK_SIZE)), 0);
 let lastBytes = bytesUploaded; let lastTime = performance.now(); let speed = 0;

 // Buat kartu UI untuk file ini
 _createUploadCard(uploadId, file.name, file.size);
 _updateUploadCard(uploadId, { size: file.size, progress: received.size / totalChunks * 100, speed: 0, done: received.size, total: totalChunks, status: 'uploading' });

 const pending = [];
 for (let i = 0; i < totalChunks; i++) { if (!received.has(i)) pending.push(i); }
 let pendingCursor = 0;

 let _currentLimit = Math.min(UPLOAD_CONCURRENCY_START, Math.max(1, pending.length));

 // Adaptive concurrency — ngitung dari kecepatan terukur
 // Rolling window 3 sample — lebih kecil biar lebih cepet bereaksi
 let _chunkTimeWindow = [];
 let _lastSpeedAt = performance.now();
 let _lastSpeedBytes = bytesUploaded;

 // Adaptive concurrency: naik +5 tiap sinyal stabil, turun -5 kalau lambat
 // 15KB chunk: stabil = RTT+transfer < 600ms, lambat = > 1500ms
 function _adjustConcurrency(chunkMs) {
  _chunkTimeWindow.push(chunkMs);
  if (_chunkTimeWindow.length > 5) _chunkTimeWindow.shift();
  const avgMs = _chunkTimeWindow.reduce((a, b) => a + b, 0) / _chunkTimeWindow.length;
  if (avgMs < 600) {
   // Sinyal stabil → naik +5
   _currentLimit = Math.min(UPLOAD_CONCURRENCY_MAX, _currentLimit + 5);
  } else if (avgMs <= 1500) {
   // Zona aman → tahan, tidak naik tidak turun
  } else {
   // Sinyal tidak stabil → turun -5
   _currentLimit = Math.max(UPLOAD_CONCURRENCY_MIN, _currentLimit - 5);
  }
  // Update speed display
  const now = performance.now();
  const elapsed = (now - _lastSpeedAt) / 1000;
  if (elapsed >= 0.3) {
   const bytesDelta = bytesUploaded - _lastSpeedBytes;
   if (bytesDelta > 0) { speed = bytesDelta / elapsed; _lastSpeedBytes = bytesUploaded; _lastSpeedAt = now; }
  }
 }

 // Sleep yang bisa dicancel — cek kondisi tiap 50ms, tidak perlu tunggu delay penuh
 async function _cancellableSleep(ms) {
  const deadline = Date.now() + ms;
  while (Date.now() < deadline) {
   if (_localCancelled || _uploadCancelled) return;
   await new Promise(r => setTimeout(r, Math.min(50, deadline - Date.now())));
  }
 }

 async function _sendChunk(i) {
  while (_uploadPaused && !_uploadCancelled && !_localCancelled) {
   const _inFlight = [..._chunkInFlightBytes.values()].reduce((a, b) => a + b, 0);
   _updateUploadCard(uploadId, { size: file.size, progress: Math.min(100, (bytesUploaded + _inFlight) / file.size * 100), speed: 0, done: received.size, total: totalChunks, status: 'paused', concurrency: _currentLimit });
   await _cancellableSleep(300);
  }
  if (_uploadCancelled || _localCancelled) return;

  const start = i * UPLOAD_CHUNK_SIZE;
  const end = Math.min(start + UPLOAD_CHUNK_SIZE, file.size);
  const chunkBlob = file.slice(start, end);

  let ok = false;
  const chunkStart = performance.now();
  let attempt = 0;

  while (!ok && !_uploadCancelled && !_localCancelled) {
   try {
    const fd = new FormData();
    fd.append('chunk', chunkBlob, file.name);
    fd.append('uploadId', uploadId);
    fd.append('chunkIndex', i);

    // -- Pakai XHR supaya bisa dapat progress per-byte dalam chunk via xhr.upload.onprogress --
    const result = await new Promise((resolve, reject) => {
     const xhr = new XMLHttpRequest();
     _activeChunkXHRs.add(xhr);

     // Progress smooth real-time — update setiap ada byte terkirim
     xhr.upload.addEventListener('progress', (e) => {
      if (!e.lengthComputable) return;
      _chunkInFlightBytes.set(i, e.loaded);
      // Total bytes = chunk yang sudah selesai + Σ semua in-flight sekarang (multi-worker)
      const inFlight = [..._chunkInFlightBytes.values()].reduce((a, b) => a + b, 0);
      const totalBytes = bytesUploaded + inFlight;
      const pct = Math.min(100, (totalBytes / file.size) * 100);
      // Speed update real-time (tidak menunggu chunk selesai)
      const now = performance.now();
      const elapsed = (now - _lastSpeedAt) / 1000;
      if (elapsed >= 0.3 && totalBytes > _lastSpeedBytes) {
       speed = (totalBytes - _lastSpeedBytes) / elapsed;
       _lastSpeedBytes = totalBytes;
       _lastSpeedAt = now;
      }
      _updateUploadCard(uploadId, { size: file.size, progress: pct, speed, done: received.size, total: totalChunks, status: 'uploading', concurrency: _currentLimit });
     });

     xhr.addEventListener('load', () => {
      _activeChunkXHRs.delete(xhr);
      _chunkInFlightBytes.delete(i);
      if (xhr.status >= 200 && xhr.status < 300) resolve({ ok: true });
      else resolve({ ok: false });
     });

     xhr.addEventListener('error', () => {
      _activeChunkXHRs.delete(xhr);
      _chunkInFlightBytes.delete(i);
      reject(new Error('Network error'));
     });

     xhr.addEventListener('abort', () => {
      _activeChunkXHRs.delete(xhr);
      _chunkInFlightBytes.delete(i);
      // Buat error dengan name AbortError agar bisa dibedakan dari network error
      const err = new Error('Upload aborted');
      err.name = 'AbortError';
      reject(err);
     });

     xhr.open('POST', '/api/upload/chunk');
     xhr.send(fd);
    });

    if (result.ok) { ok = true; received.add(i); }
    else {
     attempt++;
     _currentLimit = Math.max(UPLOAD_CONCURRENCY_MIN, _currentLimit - 1);
     // Delay bisa diinterrupt saat X ditekan (cek tiap 50ms)
     await _cancellableSleep(Math.min(800 * attempt, 4000));
    }
   } catch(e) {
    if (e.name === 'AbortError') return;
    if (_localCancelled || _uploadCancelled) return;
    attempt++;
    await _cancellableSleep(Math.min(800 * attempt, 4000));
   }
  }

  if (!ok) return; // hanya terjadi kalau di-cancel

  bytesUploaded += (end - start);
  _adjustConcurrency(performance.now() - chunkStart);
  // Update progress akhir chunk berdasarkan bytes (bukan chunk count) untuk konsistensi
  const _inFlight = [..._chunkInFlightBytes.values()].reduce((a, b) => a + b, 0);
  _updateUploadCard(uploadId, { size: file.size, progress: Math.min(100, (bytesUploaded + _inFlight) / file.size * 100), speed, done: received.size, total: totalChunks, status: 'uploading', concurrency: _currentLimit });
 }

 // Worker: ambil chunk dari antrian, jumlah aktif dikontrol lewat _currentLimit
 async function _worker(slotIndex) {
  while (pendingCursor < pending.length) {
   if (_uploadCancelled || _localCancelled) return;
   if (slotIndex >= _currentLimit) { await _cancellableSleep(100); continue; }
   const i = pending[pendingCursor++];
   if (i === undefined) return;
   await _sendChunk(i);
  }
 }

 // Spawn worker sebanyak pending atau 128 (hardcap), dikontrol lewat _currentLimit
 const workerCount = Math.min(128, Math.max(1, pending.length));
 await Promise.all(Array.from({ length: workerCount }, (_, idx) => _worker(idx)));

 if (_uploadCancelled || _localCancelled) {
  _stopLocalHB();
  try { await fetch('/api/upload/cancel', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ uploadId }) }); } catch(e) {}
  try { localStorage.removeItem(resumeKey); } catch(e) {}
  try { localStorage.removeItem(_LS('upload_active')); } catch(e) {}
  _activeUploadJobs.delete(_safeId);
  _removeUploadCard(uploadId);
  return;
 }

 _stopLocalHB();
 _updateUploadCard(uploadId, { size: file.size, progress: 100, speed: 0, done: totalChunks, total: totalChunks, status: 'finishing' });
 try {
  const r = await fetch('/api/upload/finish', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ uploadId }) });
  if (r.ok) {
   try { localStorage.removeItem(resumeKey); } catch(e) {}
   try { localStorage.removeItem(_LS('upload_active')); } catch(e) {}
   _lastUploadSucceeded = true;
   if(typeof showToast === 'function') showToast('Upload selesai: ' + file.name);
   _updateUploadCard(uploadId, { size: file.size, progress: 100, speed: 0, done: totalChunks, total: totalChunks, status: 'done' });
   setTimeout(() => { _removeUploadCard(uploadId); }, 1500);
  } else {
   _lastUploadSucceeded = false;
   const err = await r.json().catch(() => ({}));
   if(typeof showToast === 'function') showToast('Gagal menyimpan: ' + (err.error || 'Error'), 'error');
   _updateUploadCard(uploadId, { size: file.size, progress: received.size / totalChunks * 100, speed: 0, done: received.size, total: totalChunks, status: 'paused' });
  }
 } catch(e) {
  _lastUploadSucceeded = false;
  if(typeof showToast === 'function') showToast(e.message, 'error');
 }
 _activeUploadJobs.delete(_safeId);
}

// -- UI Upload Panel (Sidebar) --
// Tampilkan/sembunyikan floating toggle tab di tepi kanan
function _showToggleTab() {
 const tab = document.getElementById('uploadToggleTab');
 if (tab) tab.classList.remove('hidden');
}
function _hideToggleTab() {
 const tab = document.getElementById('uploadToggleTab');
 if (tab) tab.classList.add('hidden');
}
// Perbarui badge di toggle tab
function _updateToggleTabBadge() {
 const badge = document.getElementById('uploadToggleBadge');
 if (!badge) return;
 const q = _remoteDownloadQueue.length + (typeof _uploadQueue !== 'undefined' ? _uploadQueue.length : 0);
 if (q > 0) { badge.textContent = '+' + q; badge.classList.remove('hidden'); }
 else badge.classList.add('hidden');
}

function showUploadPanel() {
 const panel = document.getElementById('uploadProgressPanel');
 const backdrop = document.getElementById('uploadPanelBackdrop');
 if (!panel) return;
 // Sembunyikan toggle tab saat sidebar terbuka
 _hideToggleTab();
 // Tampilkan elemen lalu animate slide-in dari kanan
 panel.classList.remove('hidden');
 if (backdrop) { backdrop.classList.remove('hidden'); backdrop.style.opacity = '0'; requestAnimationFrame(() => { backdrop.style.transition = 'opacity 0.3s'; backdrop.style.opacity = '1'; }); }
 // rAF ganda supaya transition berjalan setelah display berubah
 requestAnimationFrame(() => requestAnimationFrame(() => { panel.style.transform = 'translateX(0)'; }));
 // BUG FIX: Kalau ada download URL yang masih aktif, pastikan section-nya terlihat lagi
 // (bisa tersembunyi oleh _hideUrlDlSection() saat panel pernah ditutup sebelumnya)
 if (typeof _activeRemoteDownloadJobs !== 'undefined' && _activeRemoteDownloadJobs.size > 0) {
  const dlContainer = document.getElementById('urlDlActiveContainer');
  if (dlContainer) dlContainer.classList.remove('hidden');
 }
 const doneBtn = document.getElementById('uploadDoneBtn');
 const pauseBtn = document.getElementById('uploadPauseBtn');
 const cancelBtn = document.getElementById('uploadClosePanelBtnNoop');
 const resumeBtn = document.getElementById('uploadResumeBtn');
 const spinner = document.getElementById('uploadPanelSpinner');
 const fileSection = document.getElementById('uploadFileSection');
 if (doneBtn) doneBtn.classList.add('hidden');
 if (pauseBtn) pauseBtn.classList.remove('hidden');
 if (cancelBtn) cancelBtn.classList.remove('hidden');
 if (resumeBtn) resumeBtn.classList.add('hidden');
 if (spinner) spinner.classList.remove('hidden');
 // uploadFileSection hanya untuk restore mode — jangan auto-show di sini
}

function closeUploadPanel() {
 const panel = document.getElementById('uploadProgressPanel');
 const backdrop = document.getElementById('uploadPanelBackdrop');
 if (!panel) return;
 // Slide keluar ke kanan, tampilkan toggle tab kalau masih ada transfer
 panel.style.transform = 'translateX(100%)';
 if (backdrop) { backdrop.style.opacity = '0'; }
 setTimeout(() => {
  panel.classList.add('hidden');
  if (backdrop) { backdrop.classList.add('hidden'); backdrop.style.opacity = ''; backdrop.style.transition = ''; }
  _hideUrlDlSection();
  // Selalu tampilkan toggle tab setelah panel ditutup
  _updateToggleTabBadge();
  _showToggleTab();
 }, 310);
}

function _setUploadDone() {
 const spinner = document.getElementById('uploadPanelSpinner');
 const pauseBtn = document.getElementById('uploadPauseBtn');
 const cancelBtn = document.getElementById('uploadClosePanelBtnNoop');
 const doneBtn = document.getElementById('uploadDoneBtn');
 if (spinner) spinner.classList.add('hidden');
 if (pauseBtn) pauseBtn.classList.add('hidden');
 // Kalau URL download masih aktif, tetap tampilkan tombol cancel & sembunyikan "Selesai"
 // supaya user bisa batalkan download yang masih berjalan
 if (_activeRemoteDownloadJobs.size > 0) {
  if (cancelBtn) cancelBtn.classList.remove('hidden');
  if (doneBtn) doneBtn.classList.add('hidden');
 } else {
  if (cancelBtn) cancelBtn.classList.add('hidden');
  if (doneBtn) doneBtn.classList.remove('hidden');
 }
}

// --- URL download section: compat stub (diganti sistem multi-concurrent) ---
function _updateUrlDlUI() { /* digantikan _updateUrlDlCard per jobId */ }

function _hideUrlDlSection() {
 // Sembunyikan semua kartu download aktif (dipanggil saat panel ditutup)
 const container = document.getElementById('urlDlActiveContainer');
 if (container) container.classList.add('hidden');
}

// ===== UPLOAD CARD UI (multi-concurrent) =====

function _createUploadCard(uploadId, name, size) {
 const container = document.getElementById('uploadFileContainer');
 const list = document.getElementById('uploadActiveList');
 if (!container || !list) return;
 container.classList.remove('hidden');
 const safeName = String(name || '-').replace(/</g,'&lt;').replace(/>/g,'&gt;');
 const safeId = String(uploadId).replace(/[^a-zA-Z0-9_-]/g, '');
 const card = document.createElement('div');
 card.id = 'upCard_' + safeId;
 card.className = 'bg-slate-800/60 rounded-xl p-3 transition-opacity duration-300';
 card.innerHTML = `<div class="flex items-center gap-2 mb-1.5"><p class="up-name text-white text-xs font-bold truncate flex-1 min-w-0">${safeName}</p><button onclick="cancelSingleUpload('${safeId}')" class="flex-shrink-0 w-5 h-5 flex items-center justify-center text-slate-500 hover:text-red-400 hover:bg-red-500/10 rounded transition active:scale-90" title="Batalkan upload ini"><svg xmlns='http://www.w3.org/2000/svg' class='w-3.5 h-3.5' fill='none' viewBox='0 0 24 24' stroke='currentColor' stroke-width='2.5'><path stroke-linecap='round' stroke-linejoin='round' d='M6 18L18 6M6 6l12 12'/></svg></button></div><div class="flex items-center justify-between text-[10px] text-slate-400 mb-1.5"><span class="up-size font-mono">...</span><span class="up-speed text-blue-300">-</span><span class="up-eta text-slate-500">-</span></div><div class="w-full bg-slate-700/60 rounded-full h-1.5 overflow-hidden"><div class="up-bar h-full bg-blue-500 rounded-full transition-all duration-300" style="width:0%"></div></div>`;
 list.appendChild(card);
 _updateUploadCountLabel();
}

function _updateUploadCard(uploadId, { size, progress, speed, done, total, status, concurrency }) {
 const safeId = String(uploadId).replace(/[^a-zA-Z0-9_-]/g, '');
 const card = document.getElementById('upCard_' + safeId);
 if (!card) return;
 const sizeEl = card.querySelector('.up-size');
 const speedEl = card.querySelector('.up-speed');
 const etaEl = card.querySelector('.up-eta');
 const barEl = card.querySelector('.up-bar');
 const pct = Math.min(100, progress || 0);
 if (barEl) {
  barEl.style.width = pct.toFixed(1) + '%';
  barEl.classList.remove('bg-blue-500','bg-yellow-500','bg-green-500');
  if (status === 'paused') barEl.classList.add('bg-yellow-500');
  else if (status === 'done') barEl.classList.add('bg-green-500');
  else barEl.classList.add('bg-blue-500');
 }
 if (sizeEl) { const doneBytes = (size || 0) * (pct / 100); sizeEl.textContent = _fmtBinary(doneBytes) + ' / ' + _fmtBinary(size || 0); }
 if (speedEl) {
  if (status === 'uploading' && speed > 0) speedEl.textContent = _fmtBytes(speed) + '/s';
  else if (status === 'paused') speedEl.textContent = 'Dijeda';
  else if (status === 'finishing') speedEl.textContent = 'Menyimpan...';
  else if (status === 'done') speedEl.textContent = '✓';
  else speedEl.textContent = '-';
 }
 if (etaEl) {
  if (status === 'uploading' && speed > 0 && size > 0) { const rem = (size) * (1 - pct / 100); etaEl.textContent = 'ETA ' + _fmtEta(rem / speed); }
  else if (status === 'finishing') etaEl.textContent = '...';
  else if (status === 'done') etaEl.textContent = 'Selesai';
  else etaEl.textContent = (done !== undefined && total !== undefined) ? `${done}/${total} chunk` : '-';
 }
 _updateRemoteDlQueueBadge();
}

function _removeUploadCard(uploadId) {
 const safeId = String(uploadId).replace(/[^a-zA-Z0-9_-]/g, '');
 const card = document.getElementById('upCard_' + safeId);
 if (card) {
  card.style.opacity = '0';
  setTimeout(() => { if (card.parentNode) card.parentNode.removeChild(card); _updateUploadCountLabel(); _checkHideUploadContainer(); }, 300);
 } else { _updateUploadCountLabel(); _checkHideUploadContainer(); }
}

function _updateUploadCountLabel() {
 const label = document.getElementById('uploadActiveCount');
 const n = _activeUploadJobs.size;
 if (label) label.textContent = n > 0 ? '— ' + n + ' aktif' : '— selesai';
}

function _checkHideUploadContainer() {
 const list = document.getElementById('uploadActiveList');
 const container = document.getElementById('uploadFileContainer');
 if (container && list && list.children.length === 0) container.classList.add('hidden');
}

// Batalkan SATU upload berdasarkan uploadId
function cancelSingleUpload(uploadId) {
 const job = _activeUploadJobs.get(uploadId);
 if (job && job.cancelFn) job.cancelFn();
 // Kartu + Map entry dihapus otomatis saat _startChunkedUpload mendeteksi _localCancelled
}

function _fmtBytes(b) { if (!b || b < 0) return '0 B'; const k = 1024, u = ['B','KB','MB','GB']; const i = Math.floor(Math.log(b) / Math.log(k)); return (b / Math.pow(k,i)).toFixed(i?1:0) + ' ' + u[i]; }
function _fmtBinary(b) { if (!b || b < 0) return '0.00MiB'; const k = 1024, u = ['B','KiB','MiB','GiB']; let i = Math.floor(Math.log(b) / Math.log(k)); if (i < 0) i = 0; if (i > u.length - 1) i = u.length - 1; return (b / Math.pow(k,i)).toFixed(i === 0 ? 0 : 2) + u[i]; }
function _fmtEta(sec) {
 if (!isFinite(sec) || sec < 0) return '-';
 sec = Math.round(sec);
 if (sec < 1) return 'Hampir selesai';
 const m = Math.floor(sec / 60), s = sec % 60;
 return m > 0 ? `${m}m ${s}s lagi` : `${s}s lagi`;
}

function _updateUploadUI({ name, size, progress, speed, done, total, status, concurrency, sourceLabel, queueCount }) {
 const nameEl = document.getElementById('uploadFileName');
 const barEl = document.getElementById('uploadProgressBar');
 const pctEl = document.getElementById('uploadProgressText');
 const speedEl = document.getElementById('uploadSpeedText');
 const chunkEl = document.getElementById('uploadChunkText');
 const queueEl = document.getElementById('uploadQueueBadge');
 const spinner = document.getElementById('uploadPanelSpinner');
 const sizeEl = document.getElementById('uploadSizeText');
 const etaEl = document.getElementById('uploadEtaText');

 if (nameEl) nameEl.textContent = name || '-';
 if (barEl) barEl.style.width = Math.min(100, progress || 0).toFixed(1) + '%';
 if (pctEl) {
  const pct = Math.min(100, progress || 0).toFixed(0);
  if (status === 'paused') pctEl.textContent = pct + '% (Dijeda)';
  else if (status === 'finishing') pctEl.textContent = 'Menyimpan...';
  else if (status === 'done') pctEl.textContent = '100% ✓';
  else if (status === 'cancelled') pctEl.textContent = 'Dibatalkan';
  else pctEl.textContent = pct + '%';
 }
 if (speedEl) {
  if (status === 'uploading' && speed > 0) speedEl.textContent = _fmtBytes(speed) + '/s';
  else if (status === 'paused') speedEl.textContent = 'Dijeda';
  else if (status === 'finishing') speedEl.textContent = '';
  else speedEl.textContent = '-';
 }
 if (sizeEl) {
  const doneBytes = Math.min(size || 0, (size || 0) * ((progress || 0) / 100));
  sizeEl.textContent = `${_fmtBinary(doneBytes)} / ${_fmtBinary(size || 0)}`;
 }
 if (etaEl) {
  if (status === 'uploading' && speed > 0) {
   const doneBytes = (size || 0) * ((progress || 0) / 100);
   const remaining = (size || 0) - doneBytes;
   etaEl.textContent = 'ETA ' + _fmtEta(remaining / speed);
  } else if (status === 'finishing') etaEl.textContent = 'Menyimpan...';
  else if (status === 'done') etaEl.textContent = 'Selesai';
  else if (status === 'paused') etaEl.textContent = '-';
  else if (status === 'cancelled') etaEl.textContent = '-';
  else etaEl.textContent = '-';
 }
 if (chunkEl) chunkEl.textContent = sourceLabel ? sourceLabel : (concurrency ? `${done}/${total} chunk • ${concurrency}x paralel` : `${done}/${total} chunk`);
 if (queueEl) {
  // Badge total: antrian upload biasa + antrian URL download
  const remoteQ = (typeof _remoteDownloadQueue !== 'undefined' ? _remoteDownloadQueue.length : 0);
  const uploadQ = (typeof queueCount === 'number') ? queueCount : _uploadQueue.length;
  const q = uploadQ + remoteQ;
  if (q > 0) { queueEl.textContent = '+' + q + ' antrian'; queueEl.classList.remove('hidden'); }
  else queueEl.classList.add('hidden');
 }
 if (spinner) {
  if (status === 'done' || status === 'cancelled') spinner.classList.add('hidden');
  else spinner.classList.remove('hidden');
 }
 // Warna progress bar
 if (barEl) {
  if (status === 'paused') { barEl.classList.remove('bg-blue-500','bg-green-500'); barEl.classList.add('bg-yellow-500'); }
  else if (status === 'done') { barEl.classList.remove('bg-blue-500','bg-yellow-500'); barEl.classList.add('bg-green-500'); }
  else { barEl.classList.remove('bg-yellow-500','bg-green-500'); barEl.classList.add('bg-blue-500'); }
 }
 if (status === 'done') _setUploadDone();
 // Perbarui list file menunggu (upload biasa)
 _updateQueueListUI();
}

function toggleUploadPause() {
 _uploadPaused = !_uploadPaused;
 const icon = document.getElementById('uploadPauseIcon');
 const label = document.getElementById('uploadPauseLabel');
 if (_uploadPaused) {
  if (icon) icon.innerHTML = '<polygon points="5 3 19 12 5 21 5 3"/>';
  if (label) label.textContent = 'Lanjut';
 } else {
  if (icon) icon.innerHTML = '<rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/>';
  if (label) label.textContent = 'Pause';
 }
}

function cancelUpload() {
 _uploadCancelled = true; _uploadPaused = false;
 // Cancel semua upload aktif (per-job)
 for (const [, job] of _activeUploadJobs) { if (job.cancelFn) job.cancelFn(); }
 // Jika tidak ada upload aktif tapi ada restore session, hapus langsung
 if (!_uploadActive && _uploadCurrentId) {
  const cid = _uploadCurrentId; _uploadCurrentId = null;
  _stopHeartbeat();
  fetch('/api/upload/cancel', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ uploadId: cid }) }).catch(() => {});
  try { Object.keys(localStorage).filter(k => k.startsWith(_LS('upload'))).forEach(k => localStorage.removeItem(k)); } catch(e) {}
 }
}

// -- Lanjutkan upload yang terjeda setelah page refresh: minta user pilih ulang file yang sama --
function triggerResumeUpload() {
 const input = document.getElementById('uploadResumeFileInput');
 if (input) { input.value = ''; input.click(); }
}

function onResumeFileSelected(event) {
 const files = Array.from(event.target.files || []);
 event.target.value = '';
 if (!files.length) return;
 const f = files[0];
 let active;
 try { active = JSON.parse(localStorage.getItem(_LS('upload_active')) || 'null'); } catch(e) { active = null; }
 if (!active || !active.fileName) {
  if(typeof showToast === 'function') showToast('Tidak ada upload yang bisa dilanjutkan', 'error');
  return;
 }
 if (f.name !== active.fileName || f.size !== active.fileSize) {
  if(typeof showToast === 'function') showToast('File berbeda, pilih file "' + active.fileName + '" untuk melanjutkan', 'error');
  return;
 }
 // File cocok, lanjutkan upload dari titik terakhir (uploadId resume otomatis lewat localStorage)
 _stopHeartbeat();
 _uploadCurrentId = null;
 const fileSection = document.getElementById('uploadFileSection');
 if (fileSection) fileSection.classList.add('hidden');
 _uploadQueue.unshift({ file: f, destPath: active.destPath || '' });
 showUploadPanel();
 _fillUploadSlots();
}

// -- Restore upload yang terjeda saat page refresh --
async function _checkInterruptedUpload() {
 try {
  const activeRaw = localStorage.getItem(_LS('upload_active'));
  if (!activeRaw) return;
  const active = JSON.parse(activeRaw);
  const { fileName, fileSize, destPath, totalChunks } = active;
  if (!fileName || !fileSize) { localStorage.removeItem(_LS('upload_active')); return; }

  // Cari uploadId dari resumeKey
  const resumeKey = `${_LS('upload_resume')}_${fileName}_${fileSize}_${destPath}`;
  const uploadId = localStorage.getItem(resumeKey);
  if (!uploadId) { localStorage.removeItem(_LS('upload_active')); return; }

  // Cek ke server apakah session masih ada
  const r = await fetch(`/api/upload/status?uploadId=${encodeURIComponent(uploadId)}`);
  if (!r.ok) { localStorage.removeItem(_LS('upload_active')); return; }
  const data = await r.json().catch(() => ({}));
  if (!data.exists) {
   // Session sudah hilang/expired di server
   localStorage.removeItem(_LS('upload_active'));
   localStorage.removeItem(resumeKey);
   return;
  }

  // Session masih ada! Tampilkan panel dalam mode dijeda
  const panel = document.getElementById('uploadProgressPanel');
  if (!panel) return;
  panel.classList.remove('hidden');

  const doneChunks = (data.receivedChunks || []).length;
  const tot = data.totalChunks || totalChunks || 1;
  const pct = Math.min(100, (doneChunks / tot) * 100);

  _updateUploadUI({ name: fileName, size: fileSize, progress: pct, speed: 0, done: doneChunks, total: tot, status: 'paused' });

  // Sesuaikan tombol: hide pause (ga bisa resume tanpa File object), tampilkan tombol Lanjutkan + cancel
  const spinner = document.getElementById('uploadPanelSpinner');
  const pauseBtn = document.getElementById('uploadPauseBtn');
  const cancelBtn = document.getElementById('uploadClosePanelBtnNoop');
  const doneBtn = document.getElementById('uploadDoneBtn');
  const resumeBtn = document.getElementById('uploadResumeBtn');
  if (spinner) spinner.classList.add('hidden');
  if (pauseBtn) pauseBtn.classList.add('hidden');
  if (cancelBtn) cancelBtn.classList.remove('hidden');
  if (doneBtn) doneBtn.classList.add('hidden');
  if (resumeBtn) resumeBtn.classList.remove('hidden');

  // Simpan uploadId agar cancel bisa hapus session di server
  _uploadCurrentId = uploadId;

  // Mulai heartbeat agar session tidak expire selama panel terbuka
  _startHeartbeat(uploadId);

  // Tampilkan instruksi resume
  setTimeout(() => {
   if (typeof showToast === 'function') {
    showToast(`Upload "${fileName}" terjeda (${pct.toFixed(0)}% selesai). Klik tombol Upload & pilih file yang sama untuk melanjutkan.`, 'warning');
   }
  }, 800);

 } catch(e) {}
}

// ===== IMPORT FILE DARI URL — max 4 download sekaligus =====
const MAX_CONCURRENT_REMOTE_DL = 4;
let _activeRemoteDownloadJobs = new Map(); // jobId → { pollTimer, lastBytes, lastTime, pollErrors }
let _remoteDownloadQueue = []; // antrian: { url, destPath, fileName }
let _queueListExpanded = false;
let _startingCount = 0; // berapa download sedang dalam proses awal (guard race condition)

// Helper: total slot yang sedang dipakai
function _activeSlots() { return _activeRemoteDownloadJobs.size + _startingCount; }

// --- Helpers: simpan/restore antrian ke localStorage ---
function _saveRemoteDlQueue() {
 try {
  if (_remoteDownloadQueue.length > 0) {
   localStorage.setItem(_LS('remote_dl_queue'), JSON.stringify(_remoteDownloadQueue));
  } else {
   localStorage.removeItem(_LS('remote_dl_queue'));
  }
 } catch(e) {}
}

function _loadRemoteDlQueue() {
 try {
  const raw = localStorage.getItem(_LS('remote_dl_queue'));
  if (!raw) return [];
  return JSON.parse(raw) || [];
 } catch(e) { return []; }
}

// --- UI: toggle expand/collapse list antrian (no-op — sidebar selalu tampil) ---
function _toggleQueueList() { /* sidebar: queue selalu visible */ }

// --- UI: render isi antrian di sidebar ---
function _updateQueueListUI() {
 const section = document.getElementById('remoteDlQueueSection');
 const label = document.getElementById('queueToggleLabel');
 const list = document.getElementById('queueFileList');
 if (!section) return;

 // Gabungkan antrian: upload biasa di atas, URL download di bawah
 const remoteItems = _remoteDownloadQueue.map((item, i) => {
  const name = item.fileName || (() => {
   try { return decodeURIComponent(item.url.split('/').pop().split('?')[0]) || ('file-' + (i + 1)); }
   catch(e) { return 'file-' + (i + 1); }
  })();
  return { name, type: 'url', origIdx: i };
 });
 const uploadItems = (typeof _uploadQueue !== 'undefined' ? _uploadQueue : []).map((item, i) => ({
  name: item.file ? item.file.name : 'file',
  type: 'upload',
  origIdx: i
 }));
 const allItems = [...uploadItems, ...remoteItems];
 const q = allItems.length;

 if (q === 0) {
  section.classList.add('hidden');
  return;
 }

 section.classList.remove('hidden');
 if (label) label.textContent = q + ' file menunggu';

 if (list) {
  list.innerHTML = allItems.map((item, idx) => {
   const isUrl = item.type === 'url';
   const icon = isUrl
    ? `<svg class="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M13.19 8.688a4.5 4.5 0 011.242 7.244l-4.5 4.5a4.5 4.5 0 01-6.364-6.364l1.757-1.757m13.35-.622l1.757-1.757a4.5 4.5 0 00-6.364-6.364l-4.5 4.5a4.5 4.5 0 001.242 7.244"/></svg>`
    : `<svg class="w-3.5 h-3.5 text-blue-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5m-13.5-9L12 3m0 0l4.5 4.5M12 3v13.5"/></svg>`;
   const badge = isUrl
    ? `<span class="text-[9px] bg-emerald-900/60 text-emerald-400 px-1.5 py-0.5 rounded font-bold">URL</span>`
    : `<span class="text-[9px] bg-blue-900/60 text-blue-400 px-1.5 py-0.5 rounded font-bold">FILE</span>`;
   const cancelBtn = `<button onclick="cancelQueueItem('${item.type}',${item.origIdx})" class="flex-shrink-0 ml-1 text-slate-500 hover:text-red-400 transition active:scale-90" title="Batalkan"><svg xmlns='http://www.w3.org/2000/svg' class='w-3.5 h-3.5' fill='none' viewBox='0 0 24 24' stroke='currentColor' stroke-width='2.5'><line x1='18' y1='6' x2='6' y2='18'/><line x1='6' y1='6' x2='18' y2='18'/></svg></button>`;
   return `<div class="flex items-center gap-2.5 bg-slate-800/70 rounded-xl px-3 py-2">
    <span class="text-[10px] text-slate-600 font-mono w-4 text-right flex-shrink-0">${idx + 1}</span>
    ${icon}
    <span class="truncate text-[12px] text-slate-200 font-medium flex-1 min-w-0">${item.name}</span>
    ${badge}
    ${cancelBtn}
   </div>`;
  }).join('');
 }
}

function cancelQueueItem(type, origIdx) {
 if (type === 'url') {
  if (origIdx >= 0 && origIdx < _remoteDownloadQueue.length) {
   const removed = _remoteDownloadQueue.splice(origIdx, 1);
   _saveRemoteDlQueue();
   if (typeof showToast === 'function' && removed.length) showToast('Dibatalkan: ' + (removed[0].fileName || 'file'), 'warning');
  }
 } else if (type === 'upload') {
  if (typeof _uploadQueue !== 'undefined' && origIdx >= 0 && origIdx < _uploadQueue.length) {
   const removed = _uploadQueue.splice(origIdx, 1);
   if (typeof showToast === 'function' && removed.length) showToast('Dibatalkan: ' + (removed[0].file ? removed[0].file.name : 'file'), 'warning');
  }
 }
 _updateRemoteDlQueueBadge();
 _updateQueueListUI();
}

function openRemoteDownloadModal() {
 const modal = document.getElementById('remoteDownloadModal');
 if (!modal) return;
 const urlInput = document.getElementById('remoteDownloadUrl');
 const nameInput = document.getElementById('remoteDownloadFileName');
 if (urlInput) urlInput.value = '';
 if (nameInput) nameInput.value = '';
 modal.classList.remove('hidden');
 if (urlInput) urlInput.focus();
}

function closeRemoteDownloadModal() {
 const modal = document.getElementById('remoteDownloadModal');
 if (modal) modal.classList.add('hidden');
}

async function startRemoteDownload() {
 const urlInput = document.getElementById('remoteDownloadUrl');
 const nameInput = document.getElementById('remoteDownloadFileName');
 const url = urlInput ? urlInput.value.trim() : '';
 const fileName = nameInput ? nameInput.value.trim() : '';
 if (!url) { if (typeof showToast === 'function') showToast('Tempel link file dulu bro!', 'error'); return; }
 closeRemoteDownloadModal();

 // Kalau slot penuh (4 aktif), masukkan ke antrian
 if (_activeSlots() >= MAX_CONCURRENT_REMOTE_DL) {
  _remoteDownloadQueue.push({ url, destPath: currentPath, fileName });
  _saveRemoteDlQueue();
  // BUG FIX: Pastikan panel terbuka & kartu download aktif terlihat saat tambah ke antrian
  showUploadPanel();
  if (typeof showToast === 'function') showToast('Ditambahkan ke antrian (' + _remoteDownloadQueue.length + ' menunggu)', 'warning');
  _updateRemoteDlQueueBadge();
  return;
 }

 await _executeRemoteDownload({ url, destPath: currentPath, fileName });
}

function _updateRemoteDlQueueBadge() {
 const queueEl = document.getElementById('uploadQueueBadge');
 const q = _remoteDownloadQueue.length + (typeof _uploadQueue !== 'undefined' ? _uploadQueue.length : 0);
 if (queueEl) {
  if (q > 0) { queueEl.textContent = '+' + q + ' antrian'; queueEl.classList.remove('hidden'); }
  else queueEl.classList.add('hidden');
 }
 _updateToggleTabBadge();
 _updateQueueListUI();
}

// --- Buat kartu UI untuk satu download aktif ---
function _createUrlDlCard(jobId, name) {
 const container = document.getElementById('urlDlActiveContainer');
 const list = document.getElementById('urlDlActiveList');
 if (!container || !list) return;
 container.classList.remove('hidden');
 const safeName = String(name || 'Mengunduh...').replace(/</g, '&lt;').replace(/>/g, '&gt;');
 const safeJobId = String(jobId).replace(/[^a-zA-Z0-9_-]/g, '');
 const card = document.createElement('div');
 card.id = 'urlDlCard_' + safeJobId;
 card.className = 'bg-slate-800/60 rounded-xl p-3 transition-opacity duration-300';
 card.innerHTML = `<div class="flex items-center gap-2 mb-1.5"><p class="url-dl-name text-white text-xs font-bold truncate flex-1 min-w-0">${safeName}</p><button onclick="cancelSingleRemoteDownload('${safeJobId}')" class="flex-shrink-0 w-5 h-5 flex items-center justify-center text-slate-500 hover:text-red-400 hover:bg-red-500/10 rounded transition active:scale-90" title="Batalkan"><svg xmlns='http://www.w3.org/2000/svg' class='w-3.5 h-3.5' fill='none' viewBox='0 0 24 24' stroke='currentColor' stroke-width='2.5'><path stroke-linecap='round' stroke-linejoin='round' d='M6 18L18 6M6 6l12 12'/></svg></button></div><div class="flex items-center justify-between text-[10px] text-slate-400 mb-1.5"><span class="url-dl-size font-mono">...</span><span class="url-dl-speed text-emerald-300">-</span><span class="url-dl-src text-slate-500">-</span></div><div class="w-full bg-slate-700/60 rounded-full h-1.5 overflow-hidden"><div class="url-dl-bar h-full bg-emerald-500 rounded-full transition-all duration-300" style="width:0%"></div></div>`;
 list.appendChild(card);
 _updateActiveCountLabel();
}

function _updateUrlDlCard(jobId, { name, size, progress, speed, status }) {
 const safeJobId = String(jobId).replace(/[^a-zA-Z0-9_-]/g, '');
 const card = document.getElementById('urlDlCard_' + safeJobId);
 if (!card) return;
 const nameEl = card.querySelector('.url-dl-name');
 const sizeEl = card.querySelector('.url-dl-size');
 const speedEl = card.querySelector('.url-dl-speed');
 const srcEl = card.querySelector('.url-dl-src');
 const barEl = card.querySelector('.url-dl-bar');
 if (nameEl && name) nameEl.textContent = name;
 if (barEl) {
  barEl.style.width = Math.min(100, progress || 0).toFixed(1) + '%';
  if (status === 'done') { barEl.classList.remove('bg-emerald-500'); barEl.classList.add('bg-green-400'); }
  else { barEl.classList.remove('bg-green-400'); barEl.classList.add('bg-emerald-500'); }
 }
 if (sizeEl) {
  if (size > 0) { const done = Math.min(size, size * ((progress || 0) / 100)); sizeEl.textContent = _fmtBinary(done) + ' / ' + _fmtBinary(size); }
  else sizeEl.textContent = status === 'done' ? '✓ Selesai' : '...';
 }
 if (speedEl) {
  if (status === 'uploading' && speed > 0) speedEl.textContent = _fmtBytes(speed) + '/s';
  else if (status === 'done') speedEl.textContent = '✓';
  else speedEl.textContent = '-';
 }
 if (srcEl) {
  if (status === 'done') srcEl.textContent = 'Selesai';
  else if (speed > 0 && size > 0 && status === 'uploading') { const rem = size - size * ((progress || 0) / 100); srcEl.textContent = 'ETA ' + _fmtEta(rem / speed); }
  else srcEl.textContent = '-';
 }
}

function _removeUrlDlCard(jobId) {
 const safeJobId = String(jobId).replace(/[^a-zA-Z0-9_-]/g, '');
 const card = document.getElementById('urlDlCard_' + safeJobId);
 if (card) { card.style.opacity = '0'; setTimeout(() => { if (card.parentNode) card.parentNode.removeChild(card); _updateActiveCountLabel(); _checkHideActiveContainer(); }, 300); }
 else { _updateActiveCountLabel(); _checkHideActiveContainer(); }
}

function _updateActiveCountLabel() {
 const label = document.getElementById('urlDlActiveCount');
 const n = _activeRemoteDownloadJobs.size;
 if (label) label.textContent = n > 0 ? '— ' + n + ' aktif' : '— selesai';
}

function _checkHideActiveContainer() {
 const list = document.getElementById('urlDlActiveList');
 const container = document.getElementById('urlDlActiveContainer');
 if (container && list && list.children.length === 0) container.classList.add('hidden');
}

// BUG FIX: Simpan SEMUA jobId aktif ke localStorage (bukan hanya 1 terakhir)
// agar saat page refresh semua download bisa di-restore, bukan cuma yang terakhir dimulai
function _saveAllActiveRemoteDlJobs() {
 try {
  if (_activeRemoteDownloadJobs.size === 0) {
   localStorage.removeItem(_LS('remote_dl_active'));
   return;
  }
  const allJobs = Array.from(_activeRemoteDownloadJobs.entries()).map(([jid, state]) => ({
   jobId: jid,
   destPath: state.destPath || '',
   startedAt: state.startedAt || Date.now()
  }));
  localStorage.setItem(_LS('remote_dl_active'), JSON.stringify(allJobs));
 } catch(e) {}
}

// --- Jalankan satu download ---
async function _executeRemoteDownload({ url, destPath, fileName }) {
 _startingCount++;
 _updateRemoteDlQueueBadge();
 try {
  const r = await fetch('/api/remote-download/start', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ url, destPath, fileName }) });
  const data = await r.json().catch(() => ({}));
  if (!r.ok || !data.jobId) {
   _startingCount--;
   if (typeof showToast === 'function') showToast(data.error || 'Gagal memulai download', 'error');
   _processNextRemoteDownload();
   return;
  }
  const jobId = data.jobId;
  _activeRemoteDownloadJobs.set(jobId, { pollTimer: null, lastBytes: 0, lastTime: Date.now(), pollErrors: 0, destPath, startedAt: Date.now() });
  _startingCount--;
  // BUG FIX: Simpan SEMUA jobId aktif, bukan hanya yang baru saja dimulai
  _saveAllActiveRemoteDlJobs();
  showUploadPanel();
  const pauseBtn = document.getElementById('uploadPauseBtn');
  if (pauseBtn) pauseBtn.classList.add('hidden');
  _createUrlDlCard(jobId, fileName || 'Mengambil info file...');
  _updateRemoteDlQueueBadge();
  _pollRemoteDownload(jobId);
 } catch(e) {
  _startingCount--;
  if (typeof showToast === 'function') showToast('Gagal memulai download: ' + e.message, 'error');
  _processNextRemoteDownload();
 }
}

// --- Mulai dari antrian sampai slot penuh (maks 4 concurrent) ---
function _processNextRemoteDownload() {
 while (_remoteDownloadQueue.length > 0 && _activeSlots() < MAX_CONCURRENT_REMOTE_DL) {
  const next = _remoteDownloadQueue.shift();
  _saveRemoteDlQueue();
  _executeRemoteDownload(next); // tanpa await — jalankan bersamaan
 }
 _updateQueueListUI();
}

function _pollRemoteDownload(jobId) {
 const state = _activeRemoteDownloadJobs.get(jobId);
 if (!state) return;
 const GIVE_UP_ERRORS = 300;
 if (state.pollTimer) clearInterval(state.pollTimer);
 state.pollTimer = setInterval(async () => {
  try {
   const r = await fetch('/api/remote-download/status?jobId=' + encodeURIComponent(jobId));
   if (!r.ok) throw new Error('status_' + r.status);
   state.pollErrors = 0;
   const job = await r.json();
   const now = Date.now();
   const dt = (now - state.lastTime) / 1000;
   const speed = dt > 0 ? Math.max(0, (job.downloaded - state.lastBytes) / dt) : 0;
   state.lastBytes = job.downloaded; state.lastTime = now;

   const _finishPoll = () => {
    clearInterval(state.pollTimer);
    _activeRemoteDownloadJobs.delete(jobId);
    // BUG FIX: Update localStorage setelah 1 job selesai, agar job lain tetap tersimpan
    _saveAllActiveRemoteDlJobs();
    if (_activeRemoteDownloadJobs.size === 0) {
     const pauseBtn = document.getElementById('uploadPauseBtn');
     if (pauseBtn) pauseBtn.classList.remove('hidden');
    }
   };

   if (job.status === 'starting' || job.status === 'downloading') {
    const pct = job.total ? (job.downloaded / job.total * 100) : 0;
    _updateUrlDlCard(jobId, { name: job.fileName || 'Mengunduh dari internet...', size: job.total, progress: pct, speed, status: 'uploading' });
    _updateRemoteDlQueueBadge();

   } else if (job.status === 'done') {
    _finishPoll();
    _updateUrlDlCard(jobId, { name: job.fileName, size: job.total, progress: 100, speed: 0, status: 'done' });
    if (typeof showToast === 'function') showToast('Berhasil diunduh: ' + job.fileName);
    if (typeof folderCache !== 'undefined') delete folderCache[currentPath];
    if (typeof loadFiles === 'function') loadFiles(currentPath);
    setTimeout(() => {
     _removeUrlDlCard(jobId);
     _processNextRemoteDownload();
     if (_activeRemoteDownloadJobs.size === 0 && _remoteDownloadQueue.length === 0 && !_uploadActive) _scheduleAutoClosePanel();
    }, 1500);

   } else if (job.status === 'error') {
    _finishPoll();
    if (typeof showToast === 'function') showToast(job.error || 'Gagal mengunduh file', 'error');
    _removeUrlDlCard(jobId);
    _processNextRemoteDownload();
    if (_activeRemoteDownloadJobs.size === 0 && !_uploadActive) closeUploadPanel();

   } else if (job.status === 'cancelled') {
    _finishPoll();
    _removeUrlDlCard(jobId);
    _processNextRemoteDownload();
    if (_activeRemoteDownloadJobs.size === 0 && !_uploadActive) closeUploadPanel();
   }
  } catch(e) {
   state.pollErrors++;
   const card = document.getElementById('urlDlCard_' + jobId);
   if (card) { const srcEl = card.querySelector('.url-dl-src'); if (srcEl) srcEl.textContent = 'Menghubungkan...'; }
   if (state.pollErrors < GIVE_UP_ERRORS) return;
   clearInterval(state.pollTimer);
   _activeRemoteDownloadJobs.delete(jobId);
   if (typeof showToast === 'function') showToast('Koneksi terputus, download dihentikan', 'error');
   _removeUrlDlCard(jobId);
   _processNextRemoteDownload();
   if (_activeRemoteDownloadJobs.size === 0 && !_uploadActive) closeUploadPanel();
  }
 }, 1000);
}

// --- Batalkan SATU download aktif ---
function cancelSingleRemoteDownload(jobId) {
 const state = _activeRemoteDownloadJobs.get(jobId);
 if (!state) return;
 if (state.pollTimer) clearInterval(state.pollTimer);
 _activeRemoteDownloadJobs.delete(jobId);
 // BUG FIX: Update localStorage setelah cancel 1 job, agar job lain tetap tersimpan
 _saveAllActiveRemoteDlJobs();
 fetch('/api/remote-download/cancel', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ jobId }) }).catch(() => {});
 if (typeof showToast === 'function') showToast('Download dibatalkan', 'warning');
 _removeUrlDlCard(jobId);
 _updateRemoteDlQueueBadge();
 _processNextRemoteDownload();
 if (_activeRemoteDownloadJobs.size === 0) {
  const pauseBtn = document.getElementById('uploadPauseBtn');
  if (pauseBtn) pauseBtn.classList.remove('hidden');
  if (!_uploadActive) _scheduleAutoClosePanel();
 }
}

// Alias untuk backward compat (dipanggil tombol lama tanpa jobId)
function cancelActiveRemoteDownload(jobId) {
 if (jobId) { cancelSingleRemoteDownload(jobId); return; }
 const firstId = _activeRemoteDownloadJobs.keys().next().value;
 if (firstId) cancelSingleRemoteDownload(firstId);
}

function cancelActiveUpload() {
 if (!_uploadActive && !_uploadCurrentId) return;
 cancelUpload();
 if (typeof showToast === 'function') showToast('Upload dibatalkan', 'warning');
}

// --- Batalkan SEMUA download aktif + antrian ---
function cancelRemoteDownload() {
 const hadQueue = _remoteDownloadQueue.length > 0;
 _remoteDownloadQueue = [];
 _saveRemoteDlQueue();
 _updateQueueListUI();
 for (const [jid, state] of _activeRemoteDownloadJobs) {
  if (state.pollTimer) clearInterval(state.pollTimer);
  fetch('/api/remote-download/cancel', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ jobId: jid }) }).catch(() => {});
  _removeUrlDlCard(jid);
 }
 _activeRemoteDownloadJobs.clear();
 try { localStorage.removeItem(_LS('remote_dl_active')); } catch(e) {}
 const pauseBtn = document.getElementById('uploadPauseBtn');
 if (pauseBtn) pauseBtn.classList.remove('hidden');
 closeUploadPanel();
 if (typeof showToast === 'function') showToast(hadQueue ? 'Download + antrian dibatalkan semua' : 'Download dibatalkan', 'warning');
}

// Override cancelUpload agar juga handle mode restore (ketika tidak ada _startChunkedUpload aktif)
const _origCancelUpload = typeof cancelUpload !== 'undefined' ? cancelUpload : null;
function cancelUpload() {
 if (_activeRemoteDownloadJobs.size > 0) { cancelRemoteDownload(); return; }
 _uploadCancelled = true; _uploadPaused = false;
 // Jika tidak ada upload aktif tapi ada currentId (mode restore), hapus session langsung
 if (!_uploadActive && _uploadCurrentId) {
  const cid = _uploadCurrentId;
  _uploadCurrentId = null;
  _stopHeartbeat();
  fetch('/api/upload/cancel', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ uploadId: cid }) }).catch(() => {});
  // Hapus semua key upload dari localStorage
  try {
   const keys = Object.keys(localStorage).filter(k => k.startsWith(_LS('upload')));
   keys.forEach(k => localStorage.removeItem(k));
  } catch(e) {}
  const panel = document.getElementById('uploadProgressPanel');
  if (panel) { panel.style.opacity = '0'; panel.style.transition = 'opacity 0.25s'; setTimeout(() => { panel.classList.add('hidden'); panel.style.opacity = ''; panel.style.transition = ''; }, 250); }
 }
 // Cleanup juga akan dilakukan di dalam _startChunkedUpload saat detect _uploadCancelled
}

// -- Drag & Drop ke area file manager --
(function _initUploadDragDrop() {
 let _dragCounter = 0;
 document.addEventListener('dragenter', e => {
  if (!e.dataTransfer || !e.dataTransfer.types.includes('Files')) return;
  _dragCounter++;
  const overlay = document.getElementById('uploadDropOverlay');
  const label = document.getElementById('uploadDropPathLabel');
  if (overlay) overlay.classList.remove('hidden');
  if (label) {
   const dp = (typeof currentPath !== 'undefined' && currentPath) ? currentPath : '/';
   label.textContent = 'ke /' + dp;
  }
 });
 document.addEventListener('dragleave', e => {
  _dragCounter--;
  if (_dragCounter <= 0) {
   _dragCounter = 0;
   const overlay = document.getElementById('uploadDropOverlay');
   if (overlay) overlay.classList.add('hidden');
  }
 });
 document.addEventListener('dragover', e => { e.preventDefault(); });
 document.addEventListener('drop', e => {
  e.preventDefault(); _dragCounter = 0;
  const overlay = document.getElementById('uploadDropOverlay');
  if (overlay) overlay.classList.add('hidden');
  const files = Array.from(e.dataTransfer?.files || []);
  if (!files.length) return;
  // Hanya aktif kalau lagi di tab files
  const activeTab = document.querySelector('[id$="-view"]:not(.hidden), #files-view:not(.hidden)');
  const filesView = document.getElementById('files-view');
  if (!filesView || filesView.classList.contains('hidden')) return;
  queueUploadFiles(files);
 });
})();


// -- Restore panel download URL yang masih jalan di background saat page di-refresh --
// BUG FIX: Sekarang support restore SEMUA jobId aktif (format baru: array),
// dengan fallback ke format lama (single object) untuk kompatibilitas
async function _checkInterruptedRemoteDownload() {
 try {
  // Restore antrian yang tersimpan di localStorage
  const savedQueue = _loadRemoteDlQueue();
  if (savedQueue.length > 0) _remoteDownloadQueue = savedQueue;

  const raw = localStorage.getItem(_LS('remote_dl_active'));
  if (!raw) {
   // Tidak ada yang aktif tapi ada antrian tersimpan? Mulai langsung
   if (_remoteDownloadQueue.length > 0) {
    _updateQueueListUI();
    showUploadPanel();
    const pauseBtn = document.getElementById('uploadPauseBtn');
    if (pauseBtn) pauseBtn.classList.add('hidden');
    _processNextRemoteDownload();
   }
   return;
  }

  const parsed = JSON.parse(raw);
  // Normalisasi: format baru = array, format lama = single object { jobId, ... }
  const activeList = Array.isArray(parsed)
   ? parsed
   : (parsed && parsed.jobId ? [parsed] : []);

  if (activeList.length === 0) {
   localStorage.removeItem(_LS('remote_dl_active'));
   if (_remoteDownloadQueue.length > 0) {
    _updateQueueListUI();
    showUploadPanel();
    const pBtn = document.getElementById('uploadPauseBtn');
    if (pBtn) pBtn.classList.add('hidden');
    _processNextRemoteDownload();
   }
   return;
  }

  let anyRestored = false;
  // Cek dan reconnect ke setiap job yang masih aktif di server
  await Promise.all(activeList.map(async (active) => {
   if (!active || !active.jobId) return;
   try {
    const r = await fetch('/api/remote-download/status?jobId=' + encodeURIComponent(active.jobId));
    if (!r.ok) return; // job tidak ditemukan di server, skip
    const job = await r.json();

    if (job.status === 'done') {
     if (typeof showToast === 'function') showToast('Download "' + (job.fileName || active.jobId) + '" sudah selesai di background', 'success');
     if (typeof currentPath !== 'undefined' && active.destPath === currentPath) {
      if (typeof folderCache !== 'undefined') delete folderCache[currentPath];
      if (typeof loadFiles === 'function') loadFiles(currentPath);
     }
     return;
    }
    if (job.status === 'error') {
     if (typeof showToast === 'function') showToast(job.error || 'Download dari URL gagal', 'error');
     return;
    }
    if (job.status === 'cancelled') return;

    // Masih downloading -> reconnect ke job ini
    _activeRemoteDownloadJobs.set(active.jobId, { pollTimer: null, lastBytes: job.downloaded || 0, lastTime: Date.now(), pollErrors: 0, destPath: active.destPath || '', startedAt: active.startedAt || Date.now() });
    anyRestored = true;
    const pct = job.total ? (job.downloaded / job.total * 100) : 0;
    _createUrlDlCard(active.jobId, job.fileName || 'Mengunduh dari internet...');
    _updateUrlDlCard(active.jobId, { name: job.fileName || 'Mengunduh...', size: job.total, progress: pct, speed: 0, status: 'uploading' });
    _pollRemoteDownload(active.jobId);
   } catch(e) { /* skip job ini kalau ada error */ }
  }));

  if (anyRestored) {
   showUploadPanel();
   const pauseBtn2 = document.getElementById('uploadPauseBtn');
   if (pauseBtn2) pauseBtn2.classList.add('hidden');
   _updateRemoteDlQueueBadge();
   _updateQueueListUI();
   // Simpan ulang hanya yang berhasil di-restore
   _saveAllActiveRemoteDlJobs();
  } else {
   localStorage.removeItem(_LS('remote_dl_active'));
  }

  // Proses sisa antrian kalau ada slot kosong
  if (_remoteDownloadQueue.length > 0) {
   if (!anyRestored) {
    _updateQueueListUI();
    showUploadPanel();
    const pb = document.getElementById('uploadPauseBtn');
    if (pb) pb.classList.add('hidden');
   }
   setTimeout(() => _processNextRemoteDownload(), anyRestored ? 400 : 0);
  }
 } catch (e) { try { localStorage.removeItem(_LS('remote_dl_active')); } catch(e2) {} }
}

// ===== PANEL PORTAL + SWIPE-TO-CLOSE =====
(function _initUploadPanelPortal() {
 function _setup() {
  // Teleport panel, backdrop, modal, dan resume input ke level <body>
  // Agar tidak ikut tersembunyi saat tab #files-view di-hide (display:none)
  const els = ['uploadPanelBackdrop', 'uploadToggleTab', 'uploadProgressPanel', 'remoteDownloadModal', 'uploadResumeFileInput'];
  els.forEach(id => {
   const el = document.getElementById(id);
   if (el && el.parentElement !== document.body) document.body.appendChild(el);
  });

  // Swipe-to-close: geser sidebar ke kanan untuk tutup (mobile-friendly)
  const panel = document.getElementById('uploadProgressPanel');
  if (!panel) return;
  let touchStartX = 0, touchCurX = 0, swiping = false;

  panel.addEventListener('touchstart', e => {
   touchStartX = e.touches[0].clientX;
   touchCurX = touchStartX;
   swiping = true;
   panel.style.transition = 'none';
  }, { passive: true });

  panel.addEventListener('touchmove', e => {
   if (!swiping) return;
   touchCurX = e.touches[0].clientX;
   const dx = Math.max(0, touchCurX - touchStartX); // hanya ke kanan
   panel.style.transform = 'translateX(' + dx + 'px)';
  }, { passive: true });

  panel.addEventListener('touchend', () => {
   if (!swiping) return;
   swiping = false;
   panel.style.transition = '';
   const dx = touchCurX - touchStartX;
   if (dx > 80) {
    closeUploadPanel(); // tutup kalau geser cukup jauh
   } else {
    panel.style.transform = 'translateX(0)'; // balik ke posisi terbuka
   }
  });

  // ── Drag atas-bawah untuk toggle tab ──────────────────────────────
  const tab = document.getElementById('uploadToggleTab');
  if (tab) {
   const _getTabTop = () => {
    const saved = sessionStorage.getItem('uploadTabTop');
    return saved ? parseFloat(saved) : window.innerHeight * 0.5;
   };
   const _setTabPosition = (y) => {
    const half = tab.offsetHeight / 2;
    const clamped = Math.min(Math.max(y, half + 8), window.innerHeight - half - 8);
    tab.style.top = clamped + 'px';
    tab.style.transform = 'translateY(-50%)';
    sessionStorage.setItem('uploadTabTop', clamped);
   };
   _setTabPosition(_getTabTop());

   let _tabDragging = false, _tabStartY = 0, _tabOriginTop = 0, _tabMoved = false;
   const _onTabStart = (clientY) => {
    _tabDragging = true; _tabMoved = false;
    _tabStartY = clientY;
    _tabOriginTop = parseFloat(tab.style.top) || _getTabTop();
    tab.style.transition = 'none';
   };
   const _onTabMove = (clientY) => {
    if (!_tabDragging) return;
    const dy = clientY - _tabStartY;
    if (Math.abs(dy) > 5) _tabMoved = true;
    if (_tabMoved) _setTabPosition(_tabOriginTop + dy);
   };
   const _onTabEnd = () => {
    if (!_tabDragging) return;
    _tabDragging = false;
    tab.style.transition = '';
    if (!_tabMoved) showUploadPanel();
   };
   // Tracking X juga supaya swipe kiri = buka sidebar
   let _tabStartX = 0;
   const _onTabStartXY = (cx, cy) => { _tabStartX = cx; _onTabStart(cy); };
   const _onTabMoveXY = (cx, cy) => { _onTabMove(cy); };
   const _onTabEndXY  = (cx) => {
    const dx = _tabStartX - cx; // positif = swipe ke kiri
    if (!_tabDragging) return;
    _tabDragging = false;
    tab.style.transition = '';
    if (_tabMoved) return; // geser vertikal — bukan tap/swipe horizontal
    if (dx > 30) { showUploadPanel(); return; } // swipe kiri ≥30px = buka
    showUploadPanel(); // tap biasa juga buka
   };

   tab.addEventListener('touchstart', e => _onTabStartXY(e.touches[0].clientX, e.touches[0].clientY), { passive: true });
   tab.addEventListener('touchmove',  e => { e.preventDefault(); _onTabMoveXY(e.touches[0].clientX, e.touches[0].clientY); }, { passive: false });
   tab.addEventListener('touchend',   e => { e.preventDefault(); _onTabEndXY(e.changedTouches[0].clientX); });
   tab.addEventListener('mousedown', e => {
    e.preventDefault(); _onTabStartXY(e.clientX, e.clientY);
    const _mm = ev => _onTabMoveXY(ev.clientX, ev.clientY);
    const _mu = ev => { _onTabEndXY(ev.clientX); window.removeEventListener('mousemove', _mm); window.removeEventListener('mouseup', _mu); };
    window.addEventListener('mousemove', _mm); window.addEventListener('mouseup', _mu);
   });
  }
 }

 if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', _setup);
 } else {
  _setup();
 }
})();

// Cek upload / download-URL yang terjeda saat page load (setelah DOM siap)
if (document.readyState === 'loading') {
 document.addEventListener('DOMContentLoaded', () => setTimeout(_checkInterruptedUpload, 1200));
 document.addEventListener('DOMContentLoaded', () => setTimeout(_checkInterruptedRemoteDownload, 1200));
} else {
 setTimeout(_checkInterruptedUpload, 1200);
 setTimeout(_checkInterruptedRemoteDownload, 1200);
}
