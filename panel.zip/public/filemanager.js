/* =========================================
 MODULE: FILE MANAGER (FRONTEND)
 ========================================= */

let currentPath = ''; 
let currentEditFile = '';
let isNewFile = false;
let _loadFilesGen = 0;
let selectedFiles = new Set();
let activeUploadsCount = 0; 
let editor = null;
let progressInterval = null;
let folderCache = {}; 
let searchCursor = null;
let lastQuery = '';
let currentSearchMark = null;

let moveTargetPath = '';
let currentLangLabel = 'Plain Text';

// 
// LANGUAGE LIST (matches Pterodactyl's list)
// 
const LANGUAGES = [
 { label: 'Plain Text', mode: null },
 { label: 'C', mode: 'text/x-csrc' },
 { label: 'C++', mode: 'text/x-c++src' },
 { label: 'C#', mode: 'text/x-csharp' },
 { label: 'CSS', mode: 'css' },
 { label: 'Diff', mode: 'text/x-diff' },
 { label: 'Dockerfile', mode: 'text/x-dockerfile' },
 { label: 'Golang', mode: 'text/x-go' },
 { label: 'HTML', mode: 'text/html' },
 { label: 'HTTP', mode: 'message/http' },
 { label: 'Java', mode: 'text/x-java' },
 { label: 'JavaScript', mode: 'javascript' },
 { label: 'JSON', mode: 'application/json' },
 { label: 'Lua', mode: 'text/x-lua' },
 { label: 'Markdown', mode: 'text/x-markdown' },
 { label: 'MySQL', mode: 'text/x-mysql' },
 { label: 'Nginx', mode: 'text/x-nginx-conf' },
 { label: 'PHP', mode: 'application/x-httpd-php' },
 { label: 'PostgreSQL', mode: 'text/x-pgsql' },
 { label: 'Properties', mode: 'text/x-properties' },
 { label: 'Python', mode: 'python' },
 { label: 'Ruby', mode: 'text/x-ruby' },
 { label: 'Rust', mode: 'text/x-rustsrc' },
 { label: 'SCSS', mode: 'text/x-scss' },
 { label: 'Shell', mode: 'text/x-sh' },
 { label: 'SQL', mode: 'text/x-sql' },
 { label: 'TOML', mode: 'text/x-toml' },
 { label: 'TypeScript', mode: 'text/typescript' },
 { label: 'XML', mode: 'application/xml' },
 { label: 'YAML', mode: 'text/x-yaml' },
];

// Global language detector 
function detectLanguage(fileName) {
 const base = (fileName || '').split('/').pop().toLowerCase();
 const ext = base.includes('.') ? base.split('.').pop() : '';
 const map = {
 'js':['javascript','JavaScript'],'mjs':['javascript','JavaScript'],'cjs':['javascript','JavaScript'],
 'ts':['text/typescript','TypeScript'],
 'json':['application/json','JSON'],
 'html':['text/html','HTML'],'htm':['text/html','HTML'],
 'css':['css','CSS'],'scss':['text/x-scss','SCSS'],
 'yml':['text/x-yaml','YAML'],'yaml':['text/x-yaml','YAML'],
 'toml':['text/x-toml','TOML'],
 'properties':['text/x-properties','Properties'],'ini':['text/x-properties','Properties'],
 'conf':['text/x-nginx-conf','Nginx'],'nginx':['text/x-nginx-conf','Nginx'],
 'xml':['application/xml','XML'],'svg':['application/xml','XML'],
 'py':['python','Python'],'pyw':['python','Python'],
 'sh':['text/x-sh','Shell'],'bash':['text/x-sh','Shell'],'zsh':['text/x-sh','Shell'],
 'java':['text/x-java','Java'],
 'c':['text/x-csrc','C'],'h':['text/x-csrc','C'],
 'cpp':['text/x-c++src','C++'],'cc':['text/x-c++src','C++'],'hpp':['text/x-c++src','C++'],
 'cs':['text/x-csharp','C#'],
 'go':['text/x-go','Golang'],
 'rb':['text/x-ruby','Ruby'],
 'rs':['text/x-rustsrc','Rust'],
 'php':['application/x-httpd-php','PHP'],
 'lua':['text/x-lua','Lua'],
 'sql':['text/x-sql','SQL'],
 'md':['text/x-markdown','Markdown'],'markdown':['text/x-markdown','Markdown'],
 'txt':[null,'Plain Text'],
 'diff':['text/x-diff','Diff'],'patch':['text/x-diff','Diff'],
 };
 if (base === 'dockerfile') return ['text/x-dockerfile','Dockerfile'];
 return map[ext] || [null,'Plain Text'];
}

function setEditorLanguage(mode, label) {
 currentLangLabel = label || 'Plain Text';
 const langLabelEl = document.getElementById('langLabel');
 if (langLabelEl) langLabelEl.textContent = currentLangLabel;
 if (editor) editor.setOption('mode', mode || null);
}

function openLangSelector() {
 const modal = document.getElementById('langSelectorModal');
 const list = document.getElementById('langList');
 if (!modal || !list) return;
 list.innerHTML = LANGUAGES.map(lang => {
 const isActive = lang.label === currentLangLabel;
 return `<button onclick="selectLanguage(${JSON.stringify(lang.label)},${JSON.stringify(lang.mode)})"
 class="w-full flex items-center justify-between px-5 py-3 text-sm transition hover:bg-slate-700/60 active:bg-slate-700 ${isActive ? 'text-blue-400 font-bold' : 'text-[#abb2bf]'}">
 <span>${lang.label}</span>
 ${isActive ? '<svg class="w-4 h-4 text-blue-400" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/></svg>' : ''}
 </button>`;
 }).join('');
 modal.classList.remove('hidden');
 modal.style.animation = 'none';
 requestAnimationFrame(() => {
 const sheet = modal.querySelector('div');
 if (sheet) { sheet.style.transform = 'translateY(100%)'; requestAnimationFrame(() => { sheet.style.transition = 'transform 0.25s cubic-bezier(0.32,0.72,0,1)'; sheet.style.transform = 'translateY(0)'; }); }
 });
}

function closeLangSelector() {
 const modal = document.getElementById('langSelectorModal');
 if (!modal) return;
 const sheet = modal.querySelector('div');
 if (sheet) {
 sheet.style.transform = 'translateY(100%)';
 setTimeout(() => modal.classList.add('hidden'), 250);
 } else { modal.classList.add('hidden'); }
}

function selectLanguage(label, mode) {
 setEditorLanguage(mode, label);
 closeLangSelector();
}

const editorEl = document.getElementById('fileContent');
if(editorEl) {
 editor = CodeMirror(editorEl, {
 value: "",
 theme: "ayu-mirage",
 mode: null,
 indentUnit: 4,
 smartIndent: true,
 tabSize: 4,
 indentWithTabs: false,
 lineWrapping: true,
 lineNumbers: true,
 foldGutter: true,
 fixedGutter: true,
 scrollbarStyle: 'overlay',
 styleActiveLine: true,
 showCursorWhenSelecting: false,
 autofocus: false,
 spellcheck: false,
 autocorrect: false,
 autocapitalize: false,
 inputStyle: 'textarea',
 autoCloseBrackets: true,
 matchBrackets: true,
 gutters: ['CodeMirror-linenumbers', 'CodeMirror-foldgutter'],
 });

 // CUSTOM CSS: Warna Select All ala Pterodactyl (Biru Keputihan) 
 const style = document.createElement('style');
 style.innerHTML = `
 .CodeMirror-selected { background-color: rgba(59, 130, 246, 0.35) !important; }
 .CodeMirror-line::selection, .CodeMirror-line > span::selection, .CodeMirror-line > span > span::selection { background-color: rgba(59, 130, 246, 0.35) !important; }
 .CodeMirror-line::-moz-selection, .CodeMirror-line > span::-moz-selection, .CodeMirror-line > span > span::-moz-selection { background-color: rgba(59, 130, 246, 0.35) !important; }
 `;
 document.head.appendChild(style);
}

window.startProgress = function() {
 let bar = document.getElementById('top-progress-bar');
 if (!bar) {
 bar = document.createElement('div');
 bar.id = 'top-progress-bar';
 bar.className = 'fixed top-0 left-0 h-1 bg-blue-500 z-[9999] shadow-[0_0_10px_rgba(59,130,246,0.8)] transition-all ease-out';
 bar.style.width = '0%';
 document.body.appendChild(bar);
 }

 if (bar._running) return;
 bar._running = true;

 clearInterval(progressInterval);
 bar.style.transitionDuration = '0ms';
 bar.style.width = '0%';
 bar.style.opacity = '1';

 setTimeout(() => {
 bar.style.transitionDuration = '300ms';
 bar.style.width = '30%';
 progressInterval = setInterval(() => {
 let w = parseFloat(bar.style.width);
 if (w < 85) bar.style.width = (w + Math.random() * 10) + '%';
 }, 300);
 }, 10);
};

window.finishProgress = function() {
 let bar = document.getElementById('top-progress-bar');
 if (!bar) return;
 bar._running = false;
 clearInterval(progressInterval);
 bar.style.width = '100%';

 setTimeout(() => {
 bar.style.opacity = '0';
 setTimeout(() => {
 bar.style.width = '0%';
 bar.style.transitionDuration = '0ms';
 }, 300);
 }, 400);
};

window.toggleSearchBar = function() {
 const bar = document.getElementById('customSearchBar');
 if (!bar) return;
 if (bar.classList.contains('hidden')) {
 bar.classList.remove('hidden');
 document.getElementById('editorSearchInput').focus();
 } else {
 bar.classList.add('hidden');
 clearAllSearchMarks(); 
 document.getElementById('editorSearchInput').value = '';
 lastQuery = '';
 editor.focus();
 }
};

let allSearchMarks = [];
function clearAllSearchMarks() {
 allSearchMarks.forEach(m => m.clear());
 allSearchMarks = [];
 if (currentSearchMark) currentSearchMark.clear();
 currentSearchMark = null;
}

function highlightAllMatches(query) {
 clearAllSearchMarks();
 if (!query) return;
 let cursor = editor.getSearchCursor(query, CodeMirror.Pos(0, 0), true);
 while (cursor.findNext()) {
 let mark = editor.markText(cursor.from(), cursor.to(), {className: "cm-search-match"});
 allSearchMarks.push(mark);
 }
}

window.performEditorSearch = function(reverse, isTyping = false) {
 if (!editor) return;
 const searchInput = document.getElementById('editorSearchInput');
 if (!searchInput) return;
 
 const query = searchInput.value;
 
 if (query !== lastQuery) {
 lastQuery = query;
 highlightAllMatches(query);
 searchCursor = editor.getSearchCursor(query, CodeMirror.Pos(0, 0), true);
 }

 if (!query) {
 clearAllSearchMarks();
 return;
 }
 if (!searchCursor) return;

 let found = reverse ? searchCursor.findPrevious() : searchCursor.findNext();
 if (!found) {
 searchCursor = editor.getSearchCursor(query, reverse ? CodeMirror.Pos(editor.lastLine(), 99999) : CodeMirror.Pos(0, 0), true);
 found = reverse ? searchCursor.findPrevious() : searchCursor.findNext();
 }

 if (found) {
 if (currentSearchMark) currentSearchMark.clear();
 currentSearchMark = editor.markText(searchCursor.from(), searchCursor.to(), {className: "cm-search-active"});
 
 if (!isTyping) editor.setSelection(searchCursor.from(), searchCursor.to());
 editor.scrollIntoView({from: searchCursor.from(), to: searchCursor.to()}, 150);
 } else if (!isTyping) {
 if(typeof showToast === 'function') showToast('Teks tidak ditemukan', 'error');
 }
};

window.editorSearchNext = () => performEditorSearch(false);
window.editorSearchPrev = () => performEditorSearch(true);

document.addEventListener('DOMContentLoaded', () => {
 const searchInput = document.getElementById('editorSearchInput');
 if (searchInput) {
 searchInput.addEventListener('input', function() { performEditorSearch(false, true); });
 searchInput.addEventListener('keydown', function(e) {
 if (e.key === 'Enter') { e.preventDefault(); performEditorSearch(false); }
 });
 }
});

const fallbackCopyTextToClipboard = (text) => {
 const textArea = document.createElement("textarea");
 textArea.value = text;
 textArea.style.top = "0";
 textArea.style.left = "0";
 textArea.style.position = "fixed";
 document.body.appendChild(textArea);
 textArea.focus();
 textArea.select();
 try {
 const successful = document.execCommand('copy');
 document.body.removeChild(textArea);
 return successful;
 } catch (err) {
 document.body.removeChild(textArea);
 return false;
 }
};

// FUNGSI BARU UNTUK MANGGIL POP-UP PANEL CUSTOM 
function showCustomConfirm(icon, title, msg, onConfirm) {
 if(document.getElementById('genericModalIcon')) document.getElementById('genericModalIcon').innerText = icon;
 if(document.getElementById('genericModalTitle')) document.getElementById('genericModalTitle').innerText = title;
 if(document.getElementById('genericModalMsg')) document.getElementById('genericModalMsg').innerHTML = msg; 
 const gModal = document.getElementById('genericModal');
 if(gModal) gModal.classList.remove('hidden');
 
 const confirmBtn = document.getElementById('genericConfirmBtn');
 if(confirmBtn) {
 // Clone button biar event listener sebelumnya ilang
 const newBtn = confirmBtn.cloneNode(true);
 confirmBtn.parentNode.replaceChild(newBtn, confirmBtn);
 newBtn.onclick = () => {
 document.getElementById('genericModal').classList.add('hidden');
 if (onConfirm) onConfirm();
 };
 }
}

window.editorAction = async function(action) {
 if (!editor) return;
 
 const isSecure = window.isSecureContext && navigator.clipboard;

 switch(action) {
 case 'search': toggleSearchBar(); break;
 case 'selectAll': editor.execCommand('selectAll'); editor.focus(); break;
 
 // FITUR KOSONGKAN FILE PAKE MODAL ELEGAN 
 case 'clear':
 showCustomConfirm(
 '', 
 'Kosongkan File', 
 'Yakin mau menghapus <b>SEMUA</b> isi file ini?<br><br><span class="text-red-400 text-xs font-medium">(Teks akan kosong, pastikan kamu belum menekan tombol Simpan jika ini tidak disengaja!)</span>',
 () => {
 editor.setValue("");
 if(typeof showToast === 'function') showToast(' Isi file dikosongkan!');
 }
 );
 break;
 
 case 'copy':
 const copyText = editor.getSelection();
 if (copyText) {
 if (isSecure) {
 try { await navigator.clipboard.writeText(copyText); if(typeof showToast === 'function') showToast(' Teks disalin!'); } 
 catch(err) { if(typeof showToast === 'function') showToast('Gagal menyalin teks', 'error'); }
 } else {
 if(fallbackCopyTextToClipboard(copyText)) {
 if(typeof showToast === 'function') showToast(' Teks disalin (Mode HTTP)!');
 } else {
 if(typeof showToast === 'function') showToast('Gagal menyalin. Gunakan HTTPS.', 'error');
 }
 }
 } else { if(typeof showToast === 'function') showToast('Pilih teks dulu!', 'error'); }
 break;
 
 case 'cut':
 const cutText = editor.getSelection();
 if (cutText) {
 if (isSecure) {
 try { await navigator.clipboard.writeText(cutText); editor.replaceSelection(''); if(typeof showToast === 'function') showToast(' Teks dipotong!'); } 
 catch(err) { if(typeof showToast === 'function') showToast('Gagal memotong teks', 'error'); }
 } else {
 if(fallbackCopyTextToClipboard(cutText)) {
 editor.replaceSelection('');
 if(typeof showToast === 'function') showToast(' Teks dipotong (Mode HTTP)!');
 } else {
 if(typeof showToast === 'function') showToast('Gagal memotong. Gunakan HTTPS.', 'error');
 }
 }
 } else { if(typeof showToast === 'function') showToast('Pilih teks dulu!', 'error'); }
 break;
 
 case 'paste':
 if (isSecure && navigator.clipboard.readText) {
 try { const pasteText = await navigator.clipboard.readText(); editor.replaceSelection(pasteText); if(typeof showToast === 'function') showToast(' Teks ditempel!'); } 
 catch(err) { if(typeof showToast === 'function') showToast('Gagal menempel (Cek izin clipboard browser)', 'error'); }
 } else {
 if(typeof showToast === 'function') showToast(' Tombol Paste butuh HTTPS! Gunakan tahan-layar lalu "Tempel"', 'error');
 }
 break;
 }
};

function updateRowBorder(filePath, selected) {
 const cb = document.querySelector(`.file-checkbox[value="${CSS.escape(filePath)}"]`);
 if (cb) { const li = cb.closest('li'); if (li) li.style.borderLeftColor = selected ? '#3b82f6' : 'transparent'; }
}
function toggleSelect(filePath) {
 if (selectedFiles.has(filePath)) { selectedFiles.delete(filePath); updateRowBorder(filePath, false); }
 else { selectedFiles.add(filePath); updateRowBorder(filePath, true); }
 updateDeleteButton();
}
function toggleSelectAll() {
 const checkboxes = document.querySelectorAll('.file-checkbox');
 const selectAll = document.getElementById('selectAll');
 if(!selectAll) return;
 const isChecked = selectAll.checked;
 selectedFiles.clear();
 checkboxes.forEach(cb => {
  cb.checked = isChecked;
  if (isChecked) selectedFiles.add(cb.value);
  const li = cb.closest('li');
  if (li) li.style.borderLeftColor = isChecked ? '#3b82f6' : 'transparent';
 });
 updateDeleteButton();
}

function updateDeleteButton() { 
 const bar = document.getElementById('pteroFloatingBar'); if(!bar) return; 
 const count = selectedFiles.size; 
 if (count > 0) { 
 bar.classList.remove('hidden'); 
 setTimeout(() => { bar.classList.remove('opacity-0', 'scale-90', '-translate-y-4'); bar.classList.add('opacity-100', 'scale-100', 'translate-y-0'); }, 10); 
 } else { 
 bar.classList.remove('opacity-100', 'scale-100', 'translate-y-0'); bar.classList.add('opacity-0', 'scale-90', '-translate-y-4'); 
 setTimeout(() => { bar.classList.add('hidden'); }, 300); 
 const selectAll = document.getElementById('selectAll'); if(selectAll) selectAll.checked = false; 
 } 
}

function showDeleteModal(itemsArray, msg) { 
 if(document.getElementById('genericModalIcon')) document.getElementById('genericModalIcon').innerText = ''; 
 if(document.getElementById('genericModalTitle')) document.getElementById('genericModalTitle').innerText = 'Delete Files'; 
 if(document.getElementById('genericModalMsg')) document.getElementById('genericModalMsg').innerText = msg; 
 const gModal = document.getElementById('genericModal'); if(gModal) gModal.classList.remove('hidden'); 
 const confirmBtn = document.getElementById('genericConfirmBtn'); 
 if(confirmBtn) { 
 const newBtn = confirmBtn.cloneNode(true); confirmBtn.parentNode.replaceChild(newBtn, confirmBtn); 
 newBtn.onclick = async () => { 
 document.getElementById('genericModal').classList.add('hidden'); 
 startProgress();
 try { 
 const res = await fetch('/api/delete', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ items: itemsArray }) }); 
 if (res.ok) { 
 delete folderCache[currentPath]; 
 selectedFiles.clear(); updateDeleteButton(); await loadFiles(currentPath); 
 if(typeof showToast === 'function') showToast('File berhasil dihapus!');
 } 
 } catch(e) { } finally { finishProgress(); }
 }; 
 } 
}
function deleteSelectedMulti() { showDeleteModal(Array.from(selectedFiles), `Are you sure you want to delete ${selectedFiles.size} items?`); }

window.downloadSelectedFiles = function() {
 const files = Array.from(selectedFiles);
 if (files.length === 0) { if(typeof showToast === 'function') showToast('Pilih file dulu!', 'error'); return; }

 const existing = document.getElementById('bulkDownloadModal');
 if (existing) existing.remove();

 const cachedFiles = folderCache[currentPath] || [];
 const sizeMap = {};
 cachedFiles.forEach(f => { sizeMap[f.path] = f.size || ''; });

 function getBulkFileIcon(filePath) {
  const cachedFiles = folderCache[currentPath] || [];
  const entry = cachedFiles.find(f => f.path === filePath);
  if (entry && entry.isDirectory) {
   return `<svg class="w-4 h-4 text-blue-400 shrink-0" fill="currentColor" viewBox="0 0 24 24"><path d="M10 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z"/></svg>`;
  }
  return `<svg class="w-4 h-4 text-slate-400 shrink-0" viewBox="0 0 24 24" fill="currentColor"><path d="M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zM16 18H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/></svg>`;
 }

 const fileRows = files.map(filePath => {
  const name = filePath.split('/').pop();
  const size = sizeMap[filePath] || '';
  const icon = getBulkFileIcon(filePath);
  return `<div class="flex items-center gap-3 py-2.5 border-b border-slate-700/50 last:border-0">
   ${icon}
   <span class="text-white font-mono text-sm break-all flex-1 leading-snug">${name}</span>
   ${size ? `<span class="text-blue-400 font-mono font-bold text-xs shrink-0">${size}</span>` : ''}
  </div>`;
 }).join('');

 const modal = document.createElement('div');
 modal.id = 'bulkDownloadModal';
 modal.className = 'fixed inset-0 z-[300] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm tab-fade-in';
 modal.innerHTML = `
  <div class="bg-[#1e293b] w-full max-w-sm rounded-2xl border border-blue-500/40 shadow-2xl overflow-hidden" style="box-shadow:0 0 40px rgba(0,0,0,0.6)">
   <div class="px-6 pt-6 pb-5">
    <div class="flex flex-col items-center text-center gap-2 mb-5">
     <div class="w-14 h-14 rounded-2xl bg-blue-500/15 border border-blue-500/40 flex items-center justify-center text-2xl">⬇️</div>
     <div>
      <h3 class="text-white font-black text-lg leading-tight">Download ${files.length} File</h3>
      <p class="text-slate-400 text-xs mt-1">Semua file terpilih akan diunduh</p>
     </div>
    </div>
    <div class="bg-slate-900/70 rounded-xl px-4 py-1 border border-slate-700/60 mb-5 max-h-48 overflow-y-auto">
     ${fileRows}
    </div>
    <div class="flex gap-3">
     <button id="bulkDlCancelBtn" class="flex-1 bg-slate-700 hover:bg-slate-600 active:scale-95 text-slate-200 font-bold py-3 rounded-xl transition text-sm">Batal</button>
     <button id="bulkDlConfirmBtn" class="flex-1 bg-blue-600 hover:bg-blue-500 active:scale-95 text-white font-bold py-3 rounded-xl transition text-sm flex items-center justify-center gap-2 shadow-lg shadow-blue-900/40">
      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
      Download Semua
     </button>
    </div>
   </div>
  </div>
 `;

 document.body.appendChild(modal);

 const close = () => { modal.style.opacity = '0'; modal.style.transition = 'opacity 0.15s'; setTimeout(() => modal.remove(), 150); };
 document.getElementById('bulkDlCancelBtn').onclick = close;
 modal.addEventListener('click', e => { if (e.target === modal) close(); });

 document.getElementById('bulkDlConfirmBtn').onclick = () => {
  close();
  let delay = 0;
  files.forEach(filePath => {
   const name = filePath.split('/').pop();
   setTimeout(() => {
    const link = document.createElement('a');
    link.href = `/api/download?path=${encodeURIComponent(filePath)}`;
    link.download = name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
   }, delay);
   delay += 400;
  });
  if(typeof showToast === 'function') showToast(`⬇️ Mendownload ${files.length} file...`);
 };
};
function deleteSingle(filePath, fileName) { showDeleteModal([filePath], `Delete ${fileName}?`); }
function openRenameModal(filePath, currentName) { if(document.getElementById('renameOldPath')) document.getElementById('renameOldPath').value = filePath; if(document.getElementById('renameInput')) document.getElementById('renameInput').value = currentName; const rModal = document.getElementById('renameModal'); if(rModal) rModal.classList.remove('hidden'); const rInput = document.getElementById('renameInput'); if(rInput) rInput.focus(); }

async function executeRename() { 
 const oldPath = document.getElementById('renameOldPath').value; const newName = document.getElementById('renameInput').value; if(!newName) return; 
 document.getElementById('renameModal').classList.add('hidden'); 
 startProgress();
 try { 
 const res = await fetch('/api/rename', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ oldPath, newName }) }); 
 if (res.ok) { 
 delete folderCache[currentPath]; 
 await loadFiles(currentPath); 
 if(typeof showToast === 'function') showToast('Nama file diubah!');
 } 
 } catch(e) {} finally { finishProgress(); }
}

function showCreateModal(type) {
 if (type === 'file') {
 isNewFile = true;
 currentEditFile = '';
 const editNameEl = document.getElementById('editingFileName');
 if (editNameEl) editNameEl.innerText = 'File Baru (belum disimpan)';

 if (typeof showTab === 'function') showTab('edit', false);
 history.pushState({ tab: 'edit', file: 'new' }, '', '#edit/new');

 // Tampilkan spinner sebentar saat persiapan editor
 const fileContentParent = document.getElementById('fileContent') && document.getElementById('fileContent').parentElement;
 let editorSpinner = document.getElementById('editor-spinner');
 if (fileContentParent && !editorSpinner) {
 editorSpinner = document.createElement('div');
 editorSpinner.id = 'editor-spinner';
 editorSpinner.className = 'absolute inset-0 bg-[#1a1d23] z-[60] flex flex-col items-center justify-center gap-3';
 editorSpinner.innerHTML = `
 <div class="w-8 h-8 border-4 border-slate-600 border-t-blue-500 rounded-full animate-spin"></div>
 <span class="text-slate-400 font-bold text-sm tracking-wide">Menyiapkan editor...</span>
 `;
 fileContentParent.appendChild(editorSpinner);
 }
 if (editorSpinner) editorSpinner.classList.remove('hidden');

 setTimeout(() => {
 if (editor) { editor.setValue(""); editor.clearHistory(); }
 setEditorLanguage(null, 'Plain Text');
 if (editorSpinner) editorSpinner.classList.add('hidden');
 if (editor) editor.focus();
 }, 350);
 return;
 }
 if(document.getElementById('createType')) document.getElementById('createType').value = type; 
 if(document.getElementById('createModalTitle')) document.getElementById('createModalTitle').innerText = 'Create Directory'; 
 const cInput = document.getElementById('createInput'); if(cInput) cInput.value = ''; 
 const cModal = document.getElementById('createModal'); if(cModal) cModal.classList.remove('hidden'); 
 if(cInput) cInput.focus(); 
}

async function executeCreate() { 
 const type = document.getElementById('createType').value; const name = document.getElementById('createInput').value.trim(); if (!name) return; 
 const targetPath = currentPath === '' ? name : `${currentPath}/${name}`; document.getElementById('createModal').classList.add('hidden'); 
 startProgress();
 try { 
 let res;
 if (type === 'file') { res = await fetch('/api/file', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ path: targetPath, content: '' }) }); } 
 else { res = await fetch('/api/folder', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ path: targetPath }) }); } 
 if (res && res.ok) {
 delete folderCache[currentPath]; 
 await loadFiles(currentPath);
 if(typeof showToast === 'function') showToast(`${type === 'file' ? 'File' : 'Folder'} berhasil dibuat!`);
 }
 } catch (e) {} finally { finishProgress(); }
}

function formatLocalTime(isoString) { if (!isoString || isoString === '-') return '-'; const date = new Date(isoString); return `${String(date.getDate()).padStart(2, '0')}/${String(date.getMonth() + 1).padStart(2, '0')}/${date.getFullYear()} ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`; }

window.downloadFile = function(filePath, fileName, fileSize) {
 if(typeof closeAllDropdowns === 'function') closeAllDropdowns();

 const existing = document.getElementById('downloadConfirmModal');
 if (existing) existing.remove();

 const ext = fileName.includes('.') ? fileName.split('.').pop().toLowerCase() : '';
 const iconMap = {
  jar: { icon: '📦', color: 'text-orange-400', bg: 'bg-orange-500/15', border: 'border-orange-500/40' },
  zip: { icon: '🗜️', color: 'text-yellow-400', bg: 'bg-yellow-500/15', border: 'border-yellow-500/40' },
  gz: { icon: '🗜️', color: 'text-yellow-400', bg: 'bg-yellow-500/15', border: 'border-yellow-500/40' },
  json: { icon: '📋', color: 'text-blue-400', bg: 'bg-blue-500/15', border: 'border-blue-500/40' },
  yml: { icon: '⚙️', color: 'text-purple-400', bg: 'bg-purple-500/15', border: 'border-purple-500/40' },
  yaml: { icon: '⚙️', color: 'text-purple-400', bg: 'bg-purple-500/15', border: 'border-purple-500/40' },
  properties: { icon: '⚙️', color: 'text-slate-300', bg: 'bg-slate-500/15', border: 'border-slate-500/40' },
  txt: { icon: '📄', color: 'text-slate-300', bg: 'bg-slate-500/15', border: 'border-slate-500/40' },
  log: { icon: '📜', color: 'text-green-400', bg: 'bg-green-500/15', border: 'border-green-500/40' },
  png: { icon: '🖼️', color: 'text-pink-400', bg: 'bg-pink-500/15', border: 'border-pink-500/40' },
  jpg: { icon: '🖼️', color: 'text-pink-400', bg: 'bg-pink-500/15', border: 'border-pink-500/40' },
  sh: { icon: '💻', color: 'text-green-400', bg: 'bg-green-500/15', border: 'border-green-500/40' },
 };
 const style = iconMap[ext] || { icon: '📁', color: 'text-slate-300', bg: 'bg-slate-500/15', border: 'border-slate-500/40' };

 const modal = document.createElement('div');
 modal.id = 'downloadConfirmModal';
 modal.className = 'fixed inset-0 z-[300] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm tab-fade-in';
 modal.innerHTML = `
  <div class="bg-[#1e293b] w-full max-w-sm rounded-2xl border ${style.border} shadow-2xl overflow-hidden" style="box-shadow:0 0 40px rgba(0,0,0,0.6)">
   <div class="px-6 pt-6 pb-5">
    <div class="flex flex-col items-center text-center gap-3 mb-5">
     <div class="w-16 h-16 rounded-2xl ${style.bg} border ${style.border} flex items-center justify-center text-3xl shadow-inner">
      ${style.icon}
     </div>
     <div>
      <h3 class="text-white font-black text-lg leading-tight">Download File</h3>
      <p class="text-slate-400 text-xs mt-1">Siap untuk diunduh ke perangkat kamu</p>
     </div>
    </div>
    <div class="bg-slate-900/70 rounded-xl px-4 py-3 border border-slate-700/60 mb-5">
     <div class="flex items-start justify-between gap-3">
      <div class="min-w-0 flex-1">
       <p class="text-xs text-slate-400 mb-1 font-semibold uppercase tracking-wider">Nama File</p>
       <p class="text-white font-mono text-sm break-all leading-snug">${fileName}</p>
      </div>
      ${fileSize ? `<div class="shrink-0 text-right">
       <p class="text-xs text-slate-400 mb-1 font-semibold uppercase tracking-wider">Ukuran</p>
       <p class="text-blue-400 font-mono font-bold text-sm">${fileSize}</p>
      </div>` : ''}
     </div>
    </div>
    <div class="flex gap-3">
     <button id="dlCancelBtn" class="flex-1 bg-slate-700 hover:bg-slate-600 active:scale-95 text-slate-200 font-bold py-3 rounded-xl transition text-sm">Batal</button>
     <button id="dlConfirmBtn" class="flex-1 bg-blue-600 hover:bg-blue-500 active:scale-95 text-white font-bold py-3 rounded-xl transition text-sm flex items-center justify-center gap-2 shadow-lg shadow-blue-900/40">
      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
      Download
     </button>
    </div>
   </div>
  </div>
 `;

 document.body.appendChild(modal);

 const close = () => { modal.style.opacity = '0'; modal.style.transition = 'opacity 0.15s'; setTimeout(() => modal.remove(), 150); };

 document.getElementById('dlCancelBtn').onclick = close;
 modal.addEventListener('click', (e) => { if (e.target === modal) close(); });

 document.getElementById('dlConfirmBtn').onclick = () => {
  close();
  if(typeof showToast === 'function') showToast('⬇️ Mendownload: ' + fileName);
  const link = document.createElement('a');
  link.href = `/api/download?path=${encodeURIComponent(filePath)}`;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
 };
}

window.executeSingleAction = function(filePath, action) { 
 if(typeof closeAllDropdowns === 'function') closeAllDropdowns(); 
 selectedFiles.clear(); selectedFiles.add(filePath); 
 const checkboxes = document.querySelectorAll('.file-checkbox'); checkboxes.forEach(cb => cb.checked = false); 
 const cb = document.querySelector(`input[value="${filePath}"]`); if (cb) cb.checked = true; updateDeleteButton(); 
 if (action === 'move') showMoveModal(); 
 if (action === 'archive') showArchiveModal(); 
}

function formatFileDate(isoDate) {
 if (!isoDate) return '';
 try {
  const d = new Date(isoDate);
  const now = new Date();
  const diffMs = now - d;
  const diffSec = Math.floor(diffMs / 1000);
  const diffMin = Math.floor(diffSec / 60);
  const diffHr = Math.floor(diffMin / 60);
  const diffDay = Math.floor(diffHr / 24);

  if (diffSec < 60) return 'less than a minute ago';
  if (diffMin < 60) return diffMin === 1 ? '1 minute ago' : diffMin + ' minutes ago';
  if (diffHr < 24) return diffHr === 1 ? 'about 1 hour ago' : 'about ' + diffHr + ' hours ago';
  if (diffDay === 1) return '1 day ago';

  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const day = d.getDate();
  const ord = day === 1 || day === 21 || day === 31 ? 'st' : day === 2 || day === 22 ? 'nd' : day === 3 || day === 23 ? 'rd' : 'th';
  let hr = d.getHours();
  const ampm = hr >= 12 ? 'PM' : 'AM';
  hr = hr % 12 || 12;
  const min = String(d.getMinutes()).padStart(2, '0');
  return months[d.getMonth()] + ' ' + day + ord + ', ' + d.getFullYear() + ' ' + hr + ':' + min + ampm;
 } catch(e) { return ''; }
}

function getFileIconBadge(name, isDirectory) {
 const lname = (name || '').toLowerCase();
 const ext = lname.includes('.') ? lname.split('.').pop() : '';

 const ICON_BOX = 'bg-slate-700/60 border-slate-600/50';
 const ICON_COLOR = 'text-slate-400';

 if (isDirectory) return {
  bg: 'bg-blue-500/20 border-blue-500/40', color: 'text-blue-400',
  svg: `<svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M10 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z"/></svg>`
 };

 const isArchive = lname.endsWith('.tar.gz') || lname.endsWith('.zip') || lname.endsWith('.tgz') || lname.endsWith('.tar') || lname.endsWith('.gz');
 if (isArchive) return {
  bg: ICON_BOX, color: ICON_COLOR,
  svg: `<svg class="w-4 h-4" viewBox="0 0 24 24" fill="currentColor"><path d="M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm-1 7V3.5L18.5 9H13z"/><path d="M8 12h8v1.5H8zm0 3h8v1.5H8zm0 3h5v1.5H8z"/></svg>`
 };

 if (ext === 'jar') return {
  bg: ICON_BOX, color: ICON_COLOR,
  svg: `<svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>`
 };

 return {
  bg: ICON_BOX, color: ICON_COLOR,
  svg: `<svg class="w-4 h-4" viewBox="0 0 24 24" fill="currentColor"><path d="M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zM16 18H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/></svg>`
 };
}

function getFileIcon(name, isDirectory) {
 const b = getFileIconBadge(name, isDirectory);
 return `<div class="w-8 h-8 rounded-lg ${b.bg} border ${b.color} flex items-center justify-center shrink-0">${b.svg}</div>`;
}

const _VS_ROW_H = 48;
const _VS_THRESH = 80;
let _vsScrollCb = null;
let _vsScrollEl = null;

function _applyVirtualScroll(htmlBuffer, listElement) {
 if (!listElement) return;
 const scrollEl = listElement.parentElement;
 if (_vsScrollCb && _vsScrollEl) { _vsScrollEl.removeEventListener('scroll', _vsScrollCb); _vsScrollCb = null; }
 const tempDiv = document.createElement('div');
 tempDiv.innerHTML = `<ul>${htmlBuffer}</ul>`;
 const items = Array.from(tempDiv.querySelectorAll('li')).map(li => li.outerHTML);
 if (items.length <= _VS_THRESH) { listElement.innerHTML = htmlBuffer; return; }
 function renderVisible() {
  const scrollTop = scrollEl.scrollTop;
  const viewH = scrollEl.clientHeight || 600;
  const startIdx = Math.max(0, Math.floor(scrollTop / _VS_ROW_H) - 10);
  const endIdx = Math.min(items.length - 1, Math.ceil((scrollTop + viewH) / _VS_ROW_H) + 10);
  const topPad = startIdx * _VS_ROW_H;
  const botPad = (items.length - endIdx - 1) * _VS_ROW_H;
  listElement.innerHTML =
   (topPad > 0 ? `<li style="height:${topPad}px;pointer-events:none;border:none"></li>` : '') +
   items.slice(startIdx, endIdx + 1).join('') +
   (botPad > 0 ? `<li style="height:${botPad}px;pointer-events:none;border:none"></li>` : '');
 }
 _vsScrollCb = renderVisible;
 _vsScrollEl = scrollEl;
 scrollEl.addEventListener('scroll', _vsScrollCb, { passive: true });
 renderVisible();
}

function renderFileListHTML(files, dir, listElement) {
 if(!listElement) return;
 let htmlBuffer = ""; 
 
 if (dir !== '') { 
  const parentPath = dir.split('/').slice(0, -1).join('/'); 
  htmlBuffer += `
  <li onclick="loadFiles('${parentPath}')" class="flex items-center gap-3 px-4 py-2.5 cursor-pointer hover:bg-slate-700/40 border-b border-slate-700/40 transition-all duration-150 group" style="border-left:3px solid transparent" onmouseenter="this.style.borderLeftColor='#3b82f6'" onmouseleave="this.style.borderLeftColor='transparent'">
   <span class="w-4 h-4 shrink-0"></span>
   <div class="w-8 h-8 rounded-lg bg-slate-700/50 border border-slate-600/40 flex items-center justify-center shrink-0">
    <svg class="w-4 h-4 text-slate-400 group-hover:text-blue-400 transition" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
   </div>
   <span class="text-slate-400 group-hover:text-slate-200 text-sm font-medium transition select-none">..</span>
  </li>`; 
 } 
 
 files.forEach((file, index) => { 
  const iconSvg = getFileIcon(file.name, file.isDirectory);
  const action = file.isDirectory ? `loadFiles('${file.path}')` : `openFile('${file.path}', '${file.name}')`; 
  const menuId = `menu-${index}`; 
  const lname = file.name.toLowerCase(); 

  let unarchiveBtn = ''; 
  if (!file.isDirectory && (lname.endsWith('.zip') || lname.endsWith('.tar.gz') || lname.endsWith('.tgz'))) { 
   unarchiveBtn = `
   <div onclick="event.stopPropagation(); executeExtract('${file.path}')" class="px-4 py-2.5 hover:bg-white/10 text-slate-300 text-sm cursor-pointer flex items-center gap-3 transition">
    <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"/></svg>
    Extract
   </div>`; 
  } 
 
  let downloadBtn = '';
  if (!file.isDirectory) {
   downloadBtn = `
   <div onclick="event.stopPropagation(); downloadFile('${file.path}', '${file.name}', '${file.size || ''}')" class="px-4 py-2.5 hover:bg-white/10 text-slate-300 text-sm cursor-pointer flex items-center gap-3 transition">
    <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
    Download
   </div>`;
  }

  const fileDateStr = formatFileDate(file.date);
  const sizeHtml = file.size ? `<span class="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-slate-700/70 text-slate-300 font-mono border border-slate-600/40 whitespace-nowrap">${file.size}</span>` : '';
  htmlBuffer += `
  <li onclick="${action}" class="flex items-center gap-3 px-4 py-2.5 cursor-pointer hover:bg-slate-700/40 border-b border-slate-700/40 last:border-0 transition-all duration-150 group relative" style="border-left:3px solid transparent" onmouseenter="this.style.borderLeftColor='#3b82f6'" onmouseleave="this.style.borderLeftColor=selectedFiles.has('${file.path}')?'#3b82f6':'transparent'">
   <input type="checkbox" value="${file.path}" class="file-checkbox w-4 h-4 rounded cursor-pointer accent-blue-500 shrink-0 opacity-100 sm:opacity-40 sm:group-hover:opacity-100 transition-opacity" onclick="event.stopPropagation(); toggleSelect(this.value)">
   ${iconSvg}
   <span class="flex-grow text-slate-100 text-sm truncate min-w-0 font-medium">${file.name}</span>
   <div class="flex items-center shrink-0 gap-2.5">
    ${sizeHtml}
    <span class="text-[10px] text-slate-500 whitespace-nowrap">${fileDateStr || ''}</span>
   </div>
   <div class="relative shrink-0">
    <button onclick="toggleMenu(event, '${menuId}')" class="w-8 h-8 flex items-center justify-center text-slate-500 hover:text-slate-200 hover:bg-blue-500/20 rounded-lg transition opacity-100 sm:opacity-0 sm:group-hover:opacity-100">
     <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path d="M6 10a2 2 0 11-4 0 2 2 0 014 0zM12 10a2 2 0 11-4 0 2 2 0 014 0zM16 12a2 2 0 100-4 2 2 0 000 4z"/></svg>
    </button>
    <div id="${menuId}" class="dropdown-menu hidden absolute right-0 top-full mt-1 w-48 bg-[#1e293b] border border-slate-600/80 rounded-lg shadow-2xl z-50 py-1 origin-top-right">
     ${unarchiveBtn}
     ${downloadBtn}
     <div onclick="event.stopPropagation(); openRenameModal('${file.path}', '${file.name}')" class="px-4 py-2.5 hover:bg-white/10 text-slate-300 text-sm cursor-pointer flex items-center gap-3 transition">
      <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
      Rename
     </div>
     <div onclick="event.stopPropagation(); executeSingleAction('${file.path}', 'move')" class="px-4 py-2.5 hover:bg-white/10 text-slate-300 text-sm cursor-pointer flex items-center gap-3 transition">
      <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4"/></svg>
      Move
     </div>
     <div onclick="event.stopPropagation(); executeSingleAction('${file.path}', 'archive')" class="px-4 py-2.5 hover:bg-white/10 text-slate-300 text-sm cursor-pointer flex items-center gap-3 transition">
      <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"/></svg>
      Archive
     </div>
     <div class="h-px bg-slate-600/50 my-1"></div>
     <div onclick="event.stopPropagation(); deleteSingle('${file.path}', '${file.name}')" class="px-4 py-2.5 hover:bg-red-500/10 text-red-400 text-sm font-medium cursor-pointer flex items-center gap-3 transition">
      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
      Delete
     </div>
    </div>
   </div>
  </li>`; 
 });
 
 _applyVirtualScroll(htmlBuffer, listElement);
}

async function loadFiles(dir = '', addToHistory = true) {
 const gen = ++_loadFilesGen;
 startProgress();
 currentPath = dir;

 const pathEl = document.getElementById('currentDirPath');
 if (pathEl) {
  let breadcrumbHTML = `
  <span class="text-slate-500 cursor-not-allowed select-none">/ home</span>
  <span class="text-slate-600 mx-1.5">/</span>
  <span onclick="loadFiles('')" class="cursor-pointer hover:text-blue-400 transition text-slate-300 font-bold">container</span>
  `;
  if (dir !== '') {
   const parts = dir.split('/');
   let buildPath = '';
   parts.forEach((part, idx) => {
    buildPath += (idx === 0 ? part : '/' + part);
    breadcrumbHTML += `<span class="text-slate-600 mx-1.5">/</span>`;
    if (idx === parts.length - 1) {
     breadcrumbHTML += `<span class="font-black text-slate-100">${part}</span>`;
    } else {
     breadcrumbHTML += `<span onclick="loadFiles('${buildPath}')" class="cursor-pointer hover:text-blue-400 transition text-slate-300">${part}</span>`;
    }
   });
  }
  pathEl.innerHTML = breadcrumbHTML;
 }

 selectedFiles.clear();
 updateDeleteButton();

 const list = document.getElementById('fileList');
 if (addToHistory) {
  const newHash = dir === '' ? '#files' : `#files/${dir}`;
  if (window.location.hash !== newHash) history.pushState({ tab: 'files', path: dir }, '', newHash);
 }

 if (folderCache[dir]) {
  const _cachedFiles = folderCache[dir];
  setTimeout(() => {
   if (gen !== _loadFilesGen) return;
   renderFileListHTML(_cachedFiles, dir, list);
   finishProgress();
  }, 10);
  return;
 }

 if (list) {
  list.innerHTML = `
  <li class="p-8 bg-[#1e293b] rounded-xl text-center text-slate-400 font-bold flex flex-col items-center justify-center gap-3 w-full h-full min-h-[200px] border border-slate-700/50 shadow-sm">
  <div class="w-8 h-8 border-4 border-slate-600 border-t-blue-500 rounded-full animate-spin"></div>
  <span class="text-sm tracking-wide">Memuat folder...</span>
  </li>
  `;
 }

 try {
  const res = await fetch(`/api/files?path=${encodeURIComponent(dir)}`);
  if (gen !== _loadFilesGen) return;
  if (res.status === 401) return window.location.href = '/';
  const files = await res.json();
  if (gen !== _loadFilesGen) return;
  folderCache[dir] = files;
  renderFileListHTML(files, dir, list);
 } catch(e) {
 } finally {
  if (gen === _loadFilesGen) finishProgress();
 }
}

const BINARY_EXTENSIONS = new Set(['jar','zip','tar','gz','tgz','war','ear','rar','7z','bz2','xz','zst','whl','egg','apk','ipa','exe','dll','so','dylib','bin','dat','db','sqlite','sqlite3','class','pyc','pyd','pyo','pdf','png','jpg','jpeg','gif','webp','bmp','ico','tiff','svg','mp3','mp4','wav','ogg','webm','mov','avi','mkv','flac','aac','woff','woff2','ttf','eot','otf']);

async function openFile(filePath, fileName, addToHistory = true) {
 isNewFile = false;
 if(!fileName) fileName = filePath.split('/').pop();

 const ext = fileName.includes('.') ? fileName.split('.').pop().toLowerCase() : '';
 const base = fileName.toLowerCase();
 const isBinary = BINARY_EXTENSIONS.has(ext) || base.endsWith('.tar.gz') || base.endsWith('.tar.bz2') || base.endsWith('.tar.xz');

 if (isBinary) {
 if(typeof showToast === 'function') showToast(`File "${fileName}" adalah file binary dan tidak bisa dibuka sebagai teks. Gunakan menu ⋮ untuk Extract atau Download.`, 'error');
 return;
 }

 startProgress(); 
 currentEditFile = filePath;
 const editNameEl = document.getElementById('editingFileName');
 if(editNameEl) editNameEl.innerText = "Edit: " + fileName; 

 lastQuery = '';
 searchCursor = null;
 clearAllSearchMarks();
 
 const searchInput = document.getElementById('editorSearchInput');
 if(searchInput) searchInput.value = '';
 
 const searchBar = document.getElementById('customSearchBar');
 if(searchBar) searchBar.classList.add('hidden');

 const [mode, langLabel] = detectLanguage(filePath);

 const fileContentParent = document.getElementById('fileContent').parentElement;
 let editorSpinner = document.getElementById('editor-spinner');
 if (!editorSpinner) {
 editorSpinner = document.createElement('div');
 editorSpinner.id = 'editor-spinner';
 editorSpinner.className = 'absolute inset-0 bg-[#1d1f21] z-[60] flex flex-col items-center justify-center gap-3';
 editorSpinner.innerHTML = `
 <div class="w-8 h-8 border-4 border-slate-600 border-t-blue-500 rounded-full animate-spin"></div>
 <span class="text-slate-400 font-bold text-sm tracking-wide">Memuat teks...</span>
 `;
 fileContentParent.appendChild(editorSpinner);
 }
 editorSpinner.classList.remove('hidden');

 setEditorLanguage(null, 'Plain Text');
 if (editor) editor.setValue("");

 if(typeof showTab === 'function') showTab('edit', false);
 if (addToHistory) history.pushState({ tab: 'edit', file: filePath }, '', '#edit/' + filePath);

 try {
 const res = await fetch(`/api/file?path=${encodeURIComponent(filePath)}`); 
 if (res.status === 401) return window.location.href = "/"; 
 const content = await res.text(); 
 if (editor) { editor.setValue(content); editor.clearHistory(); }
 setEditorLanguage(mode, langLabel);
 } catch(e) {
 if (editor) editor.setValue("// Gagal memuat isi file. Coba lagi.");
 setEditorLanguage(null, 'Plain Text');
 } finally { 
 finishProgress(); 
 if (editorSpinner) editorSpinner.classList.add('hidden'); 
 }
}

function closeEditor() {
 const savedPath = currentPath;
 window._skipFileReset = true;
 if(typeof showTab === 'function') showTab('files', false);
 currentPath = savedPath;
 const newHash = savedPath === '' ? '#files' : `#files/${savedPath}`;
 history.pushState({ tab: 'files', path: savedPath }, '', newHash);
 delete folderCache[savedPath];
 loadFiles(savedPath, false);
}

async function saveFile() { 
 if (!editor) return;
 if (isNewFile || !currentEditFile) {
 const modal = document.getElementById('saveAsModal');
 if (modal) {
 document.getElementById('saveAsInput').value = '';
 modal.classList.remove('hidden');
 setTimeout(() => document.getElementById('saveAsInput').focus(), 100);
 }
 return;
 }
 startProgress(); 
 try { 
 const res = await fetch('/api/file', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ path: currentEditFile, content: editor.getValue() }) }); 
 if(res.ok && typeof showToast === 'function') showToast('File Tersimpan!'); 
 } catch(e) {} finally { finishProgress(); }
}

async function executeSaveAs() {
 const nameInput = document.getElementById('saveAsInput');
 const name = nameInput ? nameInput.value.trim() : '';
 if (!name) { if (typeof showToast === 'function') showToast('Nama file wajib diisi!', 'error'); return; }
 const targetPath = currentPath === '' ? name : `${currentPath}/${name}`;
 document.getElementById('saveAsModal').classList.add('hidden');
 startProgress();
 try {
 const res = await fetch('/api/file', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ path: targetPath, content: editor.getValue() }) });
 if (res.ok) {
 isNewFile = false;
 currentEditFile = targetPath;
 const editNameEl = document.getElementById('editingFileName');
 if (editNameEl) editNameEl.innerText = name;
 history.replaceState({ tab: 'edit', file: targetPath }, '', '#edit/' + targetPath);
 delete folderCache[currentPath];
 const [detectedMode, detectedLabel] = detectLanguage(name);
 setEditorLanguage(detectedMode, detectedLabel);
 if (typeof showToast === 'function') showToast('File berhasil disimpan!');
 } else {
 if (typeof showToast === 'function') showToast('Gagal menyimpan file', 'error');
 }
 } catch(e) { if (typeof showToast === 'function') showToast('Error jaringan', 'error'); } 
 finally { finishProgress(); }
}

// === UPLOAD MANUAL 100% REALTIME VIA SERVER SOCKET + TOLERANSI 5 DETIK ===
function getOrCreateUnifiedBox() { let box = document.getElementById('unified-upload-box'); if (!box) { box = document.createElement('div'); box.id = 'unified-upload-box'; box.className = 'fixed bottom-6 right-6 w-[320px] bg-[#1e293b] border border-slate-600 rounded-2xl shadow-2xl z-[999] flex flex-col max-h-[50vh] transition-all duration-300'; box.innerHTML = `<div class="p-3 bg-slate-800 border-b border-slate-700 flex justify-between items-center rounded-t-2xl shrink-0"><h4 class="text-sm font-black text-blue-400 flex items-center gap-2"><svg class="w-4 h-4 animate-bounce" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"></path></svg><span id="unified-upload-title">Memproses tugas...</span></h4><button onclick="window.minimizeUpload()" class="bg-slate-700 hover:bg-slate-600 p-1.5 rounded transition text-white" title="Minimize"><svg class="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M19 9l-7 7-7-7"></path></svg></button></div><div id="unified-upload-list" class="p-4 flex flex-col gap-4 overflow-y-auto ptero-scrollbar"></div>`; document.body.appendChild(box); } return box; }
function getOrCreateMiniIndicator() { let mini = document.getElementById('miniUploadIndicator'); if (!mini) { mini = document.createElement('div'); mini.id = 'miniUploadIndicator'; mini.onclick = window.maximizeUpload; mini.className = 'hidden fixed bottom-6 right-6 bg-blue-600 hover:bg-blue-500 text-white px-4 py-2.5 rounded-full shadow-xl z-[200] cursor-pointer flex items-center gap-2 transition-all active:scale-95 border border-blue-400/50'; mini.title = 'Klik untuk memperbesar'; mini.innerHTML = `<div class="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div><span class="text-xs font-black tracking-wider" id="miniUploadText">Memproses file...</span>`; document.body.appendChild(mini); } return mini; }
function updateUploadState() { const titleSpan = document.getElementById('unified-upload-title'); if (titleSpan) { titleSpan.innerText = activeUploadsCount > 0 ? `Memproses ${activeUploadsCount} tugas...` : 'Selesai'; } const miniText = document.getElementById('miniUploadText'); if (miniText) { miniText.innerText = `Memproses ${activeUploadsCount} tugas...`; } if (activeUploadsCount <= 0) { const mini = document.getElementById('miniUploadIndicator'); if (mini) mini.classList.add('hidden'); setTimeout(() => { if (activeUploadsCount <= 0) { const box = document.getElementById('unified-upload-box'); if (box) box.classList.add('hidden'); const list = document.getElementById('unified-upload-list'); if (list) list.innerHTML = ''; } }, 3000); } }
window.minimizeUpload = function() { const box = document.getElementById('unified-upload-box'); if (box) box.classList.add('hidden'); if (activeUploadsCount > 0) { const mini = getOrCreateMiniIndicator(); mini.classList.remove('hidden'); } }
window.maximizeUpload = function() { const box = getOrCreateUnifiedBox(); box.classList.remove('hidden'); const mini = document.getElementById('miniUploadIndicator'); if (mini) mini.classList.add('hidden'); }

function formatDynamicSize(bytes) {
 if (bytes === 0) return '0.00 B';
 const k = 1024;
 const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
 const i = Math.floor(Math.log(bytes) / Math.log(k));
 return (bytes / Math.pow(k, i)).toFixed(2) + ' ' + sizes[i];
}

async function uploadFile() { 
 const fileInput = document.getElementById('fileUploader'); 
 if (!fileInput || fileInput.files.length === 0) return; 
 
 const box = getOrCreateUnifiedBox(); box.classList.remove('hidden'); 
 const mini = document.getElementById('miniUploadIndicator'); if (mini) mini.classList.add('hidden'); 
 const list = document.getElementById('unified-upload-list'); 
 const files = fileInput.files; 
 
 for (let i = 0; i < files.length; i++) { 
 const file = files[i]; 
 const uploadId = 'up_' + Date.now() + '_' + i; 
 activeUploadsCount++; 
 updateUploadState(); 
 
 const fileItem = document.createElement('div'); 
 fileItem.id = uploadId; 
 fileItem.className = 'flex flex-col gap-1.5 transition-all duration-300 opacity-100 border-b border-slate-700/50 pb-3 last:border-0 last:pb-0'; 
 
 const totalSizeStr = formatDynamicSize(file.size);

 fileItem.innerHTML = `
 <div class="flex justify-between items-center">
 <span class="text-xs text-white font-bold truncate w-4/5" title="${file.name}"> ${file.name}</span>
 <button id="cancel_${uploadId}" class="text-slate-500 hover:text-red-400 transition active:scale-95 flex items-center justify-center w-6 h-6 rounded-full hover:bg-red-400/10" title="Batal"><svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M6 18L18 6M6 6l12 12"></path></svg></button>
 </div>
 <div class="w-full bg-slate-900 rounded-full h-2 shadow-inner overflow-hidden border border-slate-700">
 <div id="bar_${uploadId}" class="bg-gradient-to-r from-blue-600 to-blue-400 h-2 rounded-full transition-all duration-100 ease-linear" style="width: 0%"></div>
 </div>
 <div class="flex justify-between items-center text-[10px] font-mono font-bold text-slate-400 mt-0.5">
 <div class="flex items-center gap-2">
 <span id="mb_text_${uploadId}">0.00 B / ${totalSizeStr}</span>
 <span id="speed_${uploadId}" class="text-emerald-400 bg-emerald-400/10 px-1.5 py-0.5 rounded animate-pulse">Menghitung...</span>
 </div>
 <span id="percent_${uploadId}" class="text-blue-400">0.0%</span>
 </div>
 `; 
 list.appendChild(fileItem); 

 const xhr = new XMLHttpRequest();
 let isCancelled = false;

 document.getElementById(`cancel_${uploadId}`).onclick = function() { 
 isCancelled = true;
 xhr.abort(); 
 fileItem.style.opacity = '0'; 
 setTimeout(() => fileItem.remove(), 300); 
 if(typeof showToast === 'function') showToast(' Dibatalkan: ' + file.name, 'error'); 
 activeUploadsCount--; updateUploadState();
 }; 

 let lastLoaded = 0;
 let lastLoadedForSpeed = 0;
 let smoothedSpeed = 0;
 let zeroSpeedCounter = 0; 

 const speedMonitor = setInterval(() => {
 if (isCancelled) { clearInterval(speedMonitor); return; }
 
 let rawSpeed = lastLoaded - lastLoadedForSpeed; 
 lastLoadedForSpeed = lastLoaded;

 if (rawSpeed > 0) {
 zeroSpeedCounter = 0; 
 if (smoothedSpeed === 0) smoothedSpeed = rawSpeed;
 else smoothedSpeed = (rawSpeed * 0.2) + (smoothedSpeed * 0.8);

 const speedEl = document.getElementById(`speed_${uploadId}`);
 if (speedEl) {
 speedEl.innerText = formatDynamicSize(smoothedSpeed) + '/s';
 speedEl.className = 'text-emerald-400 bg-emerald-400/10 px-1.5 py-0.5 rounded';
 }
 } else {
 zeroSpeedCounter++;
 smoothedSpeed = smoothedSpeed * 0.5; 
 
 const speedEl = document.getElementById(`speed_${uploadId}`);
 if (speedEl) {
 if (zeroSpeedCounter >= 5) { 
 speedEl.innerText = '0 B/s (Sinyal Lelet...)';
 speedEl.className = 'text-red-400 bg-red-400/10 px-1.5 py-0.5 rounded animate-pulse';
 } else { 
 speedEl.innerText = formatDynamicSize(smoothedSpeed) + '/s';
 }
 }
 }
 }, 1000);

 const progressHandler = (data) => {
 if (data.uploadId === uploadId) {
 lastLoaded = data.loaded;

 let percentComplete = (data.loaded / file.size) * 100;
 if (percentComplete > 100) percentComplete = 100;

 const bar = document.getElementById(`bar_${uploadId}`);
 const mbTextEl = document.getElementById(`mb_text_${uploadId}`);
 const percentEl = document.getElementById(`percent_${uploadId}`);

 if (bar) bar.style.width = percentComplete + '%';
 if (mbTextEl) mbTextEl.innerText = `${formatDynamicSize(data.loaded)} / ${totalSizeStr}`;
 if (percentEl) percentEl.innerText = percentComplete.toFixed(1) + '%';
 }
 };

 socket.on('manual_upload_progress', progressHandler);

 xhr.onload = function() {
 if (isCancelled) return;
 clearInterval(speedMonitor);
 socket.off('manual_upload_progress', progressHandler);

 if (xhr.status >= 200 && xhr.status < 300) {
 activeUploadsCount--; updateUploadState(); 
 
 const speedEl = document.getElementById(`speed_${uploadId}`);
 if (speedEl) speedEl.remove(); 
 
 if(typeof showToast === 'function') showToast(' Selesai: ' + file.name); 
 const bar = document.getElementById(`bar_${uploadId}`); 
 const mbTextEl = document.getElementById(`mb_text_${uploadId}`);
 const percent = document.getElementById(`percent_${uploadId}`);
 
 if (bar) { bar.classList.remove('from-blue-600', 'to-blue-400'); bar.classList.add('from-green-600', 'to-green-400'); bar.style.width = '100%'; } 
 if (mbTextEl) { mbTextEl.innerText = `${totalSizeStr} / ${totalSizeStr}`; }
 if (percent) { percent.innerText = 'Selesai'; percent.className = 'text-green-400'; }
 
 setTimeout(() => { fileItem.style.opacity = '0'; setTimeout(() => fileItem.remove(), 300); }, 3000); 
 delete folderCache[currentPath]; loadFiles(currentPath); 
 } else {
 handleError();
 }
 };

 xhr.onerror = handleError;
 xhr.onabort = () => { clearInterval(speedMonitor); socket.off('manual_upload_progress', progressHandler); };

 function handleError() {
 if (isCancelled) return;
 clearInterval(speedMonitor);
 socket.off('manual_upload_progress', progressHandler);
 if(typeof showToast === 'function') showToast(' Gagal upload: Server Error', 'error'); 
 fileItem.innerHTML = `<p class="text-red-400 text-xs font-bold text-center py-2"> Upload Gagal</p>`; 
 setTimeout(() => fileItem.remove(), 4000); 
 activeUploadsCount--; updateUploadState();
 }

 xhr.open("POST", `/api/upload?uploadId=${uploadId}`, true);
 const formData = new FormData();
 formData.append("path", currentPath);
 formData.append("filename", file.name);
 formData.append("file", file); 
 xhr.send(formData);
 } 
 fileInput.value = ''; 
}

window.showRemoteDownloadModal = function() {
 document.getElementById('rdlUrlInput').value = '';
 document.getElementById('rdlNameInput').value = '';
 document.getElementById('remoteDlModal').classList.remove('hidden');
 document.getElementById('rdlUrlInput').focus();
}

window.executeRemoteDownload = async function() {
 const url = document.getElementById('rdlUrlInput').value.trim();
 const filename = document.getElementById('rdlNameInput').value.trim();
 
 if (!url || !filename) {
 if(typeof showToast === 'function') showToast('URL dan Nama File wajib diisi!', 'error');
 return;
 }

 document.getElementById('remoteDlModal').classList.add('hidden');
 
 const box = getOrCreateUnifiedBox(); box.classList.remove('hidden'); 
 const mini = document.getElementById('miniUploadIndicator'); if (mini) mini.classList.add('hidden'); 
 const list = document.getElementById('unified-upload-list'); 

 activeUploadsCount++; 
 updateUploadState();

 const dlId = 'dl_' + Date.now(); 
 const fileItem = document.createElement('div'); 
 fileItem.id = dlId; 
 fileItem.className = 'flex flex-col gap-1.5 transition-all duration-300 opacity-100 border-b border-slate-700/50 pb-3 last:border-0 last:pb-0'; 

 let isCancelledDl = false;

 fileItem.innerHTML = `
 <div class="flex justify-between items-center">
 <span class="text-xs text-white font-bold truncate w-4/5 pr-2" title="${filename}"> Menarik: ${filename}</span>
 <button id="cancel_${dlId}" class="text-slate-500 hover:text-red-400 transition active:scale-95 flex items-center justify-center w-6 h-6 rounded-full hover:bg-red-400/10" title="Batal"><svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M6 18L18 6M6 6l12 12"></path></svg></button>
 </div>
 <div class="w-full bg-slate-900 rounded-full h-2 shadow-inner overflow-hidden border border-slate-700">
 <div id="bar_${dlId}" class="bg-gradient-to-r from-purple-600 to-blue-500 h-2 rounded-full w-full animate-pulse"></div>
 </div>
 <div class="flex justify-between items-center text-[10px] font-mono font-bold text-slate-400 mt-0.5">
 <div class="flex items-center gap-2">
 <span id="mb_text_${dlId}">0.00 B Disedot</span>
 <span id="speed_${dlId}" class="text-emerald-400 bg-emerald-400/10 px-1.5 py-0.5 rounded animate-pulse">Menghitung...</span>
 </div>
 </div>
 `;

 list.appendChild(fileItem);

 const cancelBtn = fileItem.querySelector(`#cancel_${dlId}`);
 if (cancelBtn) cancelBtn.onclick = function() {
  isCancelledDl = true;
  cleanup();
  fileItem.style.opacity = '0';
  setTimeout(() => fileItem.remove(), 300);
  if(typeof showToast === 'function') showToast(' Dibatalkan: ' + filename, 'error');
  activeUploadsCount--; updateUploadState();
 };

 let lastLoaded = 0;
 let lastTime = Date.now();
 let smoothedSpeed = 0;

 const progressHandler = (data) => {
 if (data.filename === filename) {
 const now = Date.now();
 const timeDiff = (now - lastTime) / 1000;
 
 if (timeDiff >= 0.5) {
 let rawSpeed = (data.loaded - lastLoaded) / timeDiff;
 if (smoothedSpeed === 0) smoothedSpeed = rawSpeed;
 else smoothedSpeed = (rawSpeed * 0.2) + (smoothedSpeed * 0.8); 

 const speedEl = document.getElementById(`speed_${dlId}`);
 if (speedEl && smoothedSpeed > 0) {
 speedEl.classList.remove('animate-pulse');
 speedEl.innerText = formatDynamicSize(smoothedSpeed) + '/s';
 }
 lastLoaded = data.loaded;
 lastTime = now;
 }

 const mbTextEl = document.getElementById(`mb_text_${dlId}`);
 if (mbTextEl) mbTextEl.innerText = formatDynamicSize(data.loaded) + ' Disedot';
 }
 };

 const successHandler = (doneFilename) => {
 if (doneFilename === filename) {
 cleanup();
 const speedEl = document.getElementById(`speed_${dlId}`);
 if (speedEl) speedEl.remove();

 const bar = document.getElementById(`bar_${dlId}`);
 const mbTextEl = document.getElementById(`mb_text_${dlId}`);

 if (bar) { bar.classList.remove('from-purple-600', 'to-blue-500', 'animate-pulse'); bar.classList.add('from-green-600', 'to-green-400'); }
 if (mbTextEl) mbTextEl.innerText = 'Selesai didownload!';

 activeUploadsCount--; updateUploadState();
 setTimeout(() => { fileItem.style.opacity = '0'; setTimeout(() => fileItem.remove(), 300); }, 3000);
 delete folderCache[currentPath]; loadFiles(currentPath);
 }
 };

 const errorHandler = (failData) => {
 if (failData.filename === filename) {
 cleanup();
 fileItem.innerHTML = `<p class="text-red-400 text-xs font-bold text-center py-2"> Gagal (Error ${failData.code})</p>`;
 setTimeout(() => fileItem.remove(), 4000);
 activeUploadsCount--; updateUploadState();
 }
 };

 socket.on('remote_dl_progress', progressHandler);
 socket.on('remote_dl_done', successHandler);
 socket.on('remote_dl_error', errorHandler);

 function cleanup() {
 socket.off('remote_dl_progress', progressHandler);
 socket.off('remote_dl_done', successHandler);
 socket.off('remote_dl_error', errorHandler);
 }

 try {
 const res = await fetch('/api/remote-download', {
 method: 'POST',
 headers: { 'Content-Type': 'application/json' },
 body: JSON.stringify({ url: url, filename: filename, path: currentPath })
 });
 const data = await res.json();
 if (!res.ok || !data.success) throw new Error('Failed');
 } catch(e) {
 cleanup();
 fileItem.innerHTML = `<p class="text-red-400 text-xs font-bold text-center py-2"> Koneksi Server Error</p>`;
 setTimeout(() => fileItem.remove(), 4000);
 activeUploadsCount--; updateUploadState();
 }
}

async function executeExtract(filePath) { 
 if(typeof closeAllDropdowns === 'function') closeAllDropdowns(); 
 startProgress(); 
 try { 
 const res = await fetch('/api/extract', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ filePath: filePath, destination: currentPath }) }); 
 if(res.ok) {
 delete folderCache[currentPath];
 await loadFiles(currentPath); 
 if(typeof showToast === 'function') showToast('Ekstrak berhasil!');
 } else {
 if(typeof showToast === 'function') showToast('Gagal mengekstrak', 'error');
 }
 } catch(e) {} finally { finishProgress(); }
}

function showArchiveModal() {
 const now = new Date();
 const pad = n => String(n).padStart(2, '0');
 const datePart = `${now.getFullYear()}-${pad(now.getMonth()+1)}-${pad(now.getDate())}`;
 const timePart = `${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;
 const archiveName = `archive-${datePart}T${timePart}Z.tar.gz`;
 executeArchiveWithName(archiveName);
}

async function executeArchiveWithName(name) {
 startProgress();
 try {
 const res = await fetch('/api/archive', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ items: Array.from(selectedFiles), archiveName: name, currentPath: currentPath }) });
 if(res.ok) {
 delete folderCache[currentPath];
 selectedFiles.clear(); updateDeleteButton(); await loadFiles(currentPath);
 if(typeof showToast === 'function') showToast('Arsip berhasil dibuat: ' + name);
 } else {
 if(typeof showToast === 'function') showToast('Gagal membuat arsip', 'error');
 }
 } catch(e) {} finally { finishProgress(); }
}

async function executeArchive() { 
 const name = document.getElementById('archiveInput').value.trim(); if(!name) return; 
 document.getElementById('archiveModal').classList.add('hidden'); 
 await executeArchiveWithName(name);
}

window.showMoveModal = function() { 
 moveTargetPath = currentPath; 
 const mModal = document.getElementById('moveModal'); 
 if(mModal) mModal.classList.remove('hidden'); 
 
 const mInput = document.getElementById('moveNewDirInput'); 
 if(mInput) mInput.value = ''; 
 
 loadMoveFolders(moveTargetPath); 
}

window.loadMoveFolders = async function(targetDir) {
 moveTargetPath = targetDir;
 const listEl = document.getElementById('moveFolderList');
 const pathText = document.getElementById('moveCurrentPathText');
 
 if(pathText) { pathText.innerText = targetDir === '' ? '/home/container/' : `/home/container/${targetDir}/`; }
 if(listEl) { listEl.innerHTML = '<div class="flex justify-center py-6"><div class="w-6 h-6 border-4 border-slate-600 border-t-blue-500 rounded-full animate-spin"></div></div>'; }
 
 try {
 const res = await fetch(`/api/files?path=${encodeURIComponent(targetDir)}`);
 if (!res.ok) throw new Error('Failed');
 const files = await res.json();
 
 let htmlBuffer = '';
 
 if (targetDir !== '') {
 const parentPath = targetDir.split('/').slice(0, -1).join('/');
 htmlBuffer += `
 <button onclick="loadMoveFolders('${parentPath}')" class="w-full bg-slate-800/80 hover:bg-slate-700 border border-slate-700/80 p-3 rounded-xl flex items-center justify-center gap-2 text-slate-300 font-bold transition active:scale-95 shadow-sm mb-1">
 <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
 Go back
 </button>
 `;
 }
 
 const dirs = files.filter(f => f.isDirectory);
 if (dirs.length === 0) {
 htmlBuffer += '<p class="text-center text-slate-500 py-6 text-xs font-bold">Tidak ada sub-folder di sini.</p>';
 } else {
 dirs.forEach(dir => {
 htmlBuffer += `
 <div onclick="loadMoveFolders('${dir.path}')" class="w-full bg-slate-800 hover:bg-slate-700 border border-slate-700/80 p-3.5 rounded-xl flex items-center gap-3 text-slate-200 font-bold transition cursor-pointer active:scale-95 shadow-sm group">
 <svg class="w-4 h-4 text-blue-400 shrink-0" fill="currentColor" viewBox="0 0 24 24"><path d="M10 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z"/></svg>
 <span class="truncate">${dir.name}</span>
 </div>
 `;
 });
 }
 
 if(listEl) listEl.innerHTML = htmlBuffer;
 } catch (e) {
 if(listEl) listEl.innerHTML = '<p class="text-center text-red-400 py-4 text-xs font-bold">Gagal memuat direktori.</p>';
 }
}

window.createDirInMove = async function() {
 const input = document.getElementById('moveNewDirInput');
 if (!input) return;
 const name = input.value.trim();
 if (!name) return;
 
 const targetPath = moveTargetPath === '' ? name : `${moveTargetPath}/${name}`;
 input.disabled = true;
 
 try {
 const res = await fetch('/api/folder', { 
 method: 'POST', 
 headers: { 'Content-Type': 'application/json' }, 
 body: JSON.stringify({ path: targetPath }) 
 });
 
 if (res.ok) {
 input.value = '';
 delete folderCache[moveTargetPath]; 
 await loadMoveFolders(moveTargetPath); 
 if(typeof showToast === 'function') showToast('Folder ' + name + ' berhasil dibuat!');
 } else {
 if(typeof showToast === 'function') showToast('Nama sudah ada / gagal dibuat', 'error');
 }
 } catch(e) {
 if(typeof showToast === 'function') showToast('Error jaringan', 'error');
 } finally {
 input.disabled = false;
 input.focus();
 }
}

window.executeInteractiveMove = async function() { 
 document.getElementById('moveModal').classList.add('hidden'); 
 startProgress(); 
 try { 
 const res = await fetch('/api/move', { 
 method: 'POST', 
 headers: { 'Content-Type': 'application/json' }, 
 body: JSON.stringify({ items: Array.from(selectedFiles), destination: moveTargetPath }) 
 }); 
 
 if(res.ok) {
 delete folderCache[currentPath]; 
 delete folderCache[moveTargetPath]; 
 selectedFiles.clear(); 
 updateDeleteButton(); 
 await loadFiles(currentPath); 
 if(typeof showToast === 'function') showToast('File berhasil dipindah!');
 } else {
 if(typeof showToast === 'function') showToast('Gagal memindah file', 'error');
 }
 } catch(e) {
 if(typeof showToast === 'function') showToast('Error jaringan', 'error');
 } finally { 
 finishProgress(); 
 }
}

window.addEventListener('popstate', function(event) {
 const hash = window.location.hash;
 if (hash === '#files' || hash.startsWith('#files/')) {
  window._skipFileReset = true;
  if(typeof showTab === 'function') showTab('files', false);
  let dir = hash.replace('#files', '');
  if (dir.startsWith('/')) dir = dir.substring(1);
  loadFiles(dir, false);
 } else if (hash.startsWith('#edit/')) {
  if(typeof showTab === 'function') showTab('edit', false);
  let file = hash.replace('#edit/', '');
  openFile(file, '', false);
 }
});
