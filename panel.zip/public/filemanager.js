/* =========================================
 MODULE: FILE MANAGER (FRONTEND)
 ========================================= */

// localStorage key scoped ke server tab ini — cegah bleed antar tab beda server
function _LS(key) {
 const sid = (typeof PANEL_SERVER_ID !== 'undefined' && PANEL_SERVER_ID)
  || (window.location.pathname.match(/^\/server\/([^\/]+)/) || [])[1]
  || 'shared';
 return sid + ':' + key;
}

let currentPath = ''; 
let currentEditFile = '';
let isNewFile = false;
let _loadFilesGen = 0;
let selectedFiles = new Set();
let floatingBarShowTimer = null;
let floatingBarHideTimer = null;
let editor = null;
let editorSavedContent = '';

// Tombol Simpan hanya aktif jika isi editor berbeda dari versi terakhir yang tersimpan.
function syncEditorSaveButton() {
 const btn = document.getElementById('editorSaveBtn');
 if (!btn || !editor) return;
 const dirty = editor.getValue() !== editorSavedContent;
 btn.disabled = !dirty;
 btn.setAttribute('aria-disabled', String(!dirty));
 btn.classList.toggle('bg-blue-600', dirty);
 btn.classList.toggle('hover:bg-blue-500', dirty);
 btn.classList.toggle('border-blue-500', dirty);
 btn.classList.toggle('shadow-[0_4px_15px_rgba(59,130,246,0.25)]', dirty);
 btn.classList.toggle('text-white', dirty);
 btn.classList.toggle('bg-blue-900/55', !dirty);
 btn.classList.toggle('border-blue-800/70', !dirty);
 btn.classList.toggle('text-blue-300/80', !dirty);
 btn.classList.toggle('cursor-not-allowed', !dirty);
 btn.classList.toggle('active:scale-95', dirty);
 btn.title = dirty ? 'Simpan perubahan file' : 'Belum ada perubahan untuk disimpan';
}
let progressInterval = null;
let folderCache = {}; 
let searchCursor = null;
let lastQuery = '';
let currentSearchMark = null;

let moveTargetPath = '';
let currentLangLabel = 'Plain Text';

// 
// LANGUAGE LIST (matches Pterodactyl's list)
// 
const LANGUAGES = [
 { label: 'Plain Text', mode: null },
 { label: 'C', mode: 'text/x-csrc' },
 { label: 'C++', mode: 'text/x-c++src' },
 { label: 'C#', mode: 'text/x-csharp' },
 { label: 'CSS', mode: 'css' },
 { label: 'Diff', mode: 'text/x-diff' },
 { label: 'Dockerfile', mode: 'text/x-dockerfile' },
 { label: 'Golang', mode: 'text/x-go' },
 { label: 'HTML', mode: 'text/html' },
 { label: 'HTTP', mode: 'message/http' },
 { label: 'Java', mode: 'text/x-java' },
 { label: 'JavaScript', mode: 'javascript' },
 { label: 'JSON', mode: 'application/json' },
 { label: 'Lua', mode: 'text/x-lua' },
 { label: 'Markdown', mode: 'text/x-markdown' },
 { label: 'MySQL', mode: 'text/x-mysql' },
 { label: 'Nginx', mode: 'text/x-nginx-conf' },
 { label: 'PHP', mode: 'application/x-httpd-php' },
 { label: 'PostgreSQL', mode: 'text/x-pgsql' },
 { label: 'Properties', mode: 'text/x-properties' },
 { label: 'Python', mode: 'python' },
 { label: 'Ruby', mode: 'text/x-ruby' },
 { label: 'Rust', mode: 'text/x-rustsrc' },
 { label: 'SCSS', mode: 'text/x-scss' },
 { label: 'Shell', mode: 'text/x-sh' },
 { label: 'SQL', mode: 'text/x-sql' },
 { label: 'TOML', mode: 'text/x-toml' },
 { label: 'TypeScript', mode: 'text/typescript' },
 { label: 'XML', mode: 'application/xml' },
 { label: 'YAML', mode: 'text/x-yaml' },
];

// Global language detector 
function detectLanguage(fileName) {
 const base = (fileName || '').split('/').pop().toLowerCase();
 const ext = base.includes('.') ? base.split('.').pop() : '';
 const map = {
 'js':['javascript','JavaScript'],'mjs':['javascript','JavaScript'],'cjs':['javascript','JavaScript'],
 'ts':['text/typescript','TypeScript'],
 'json':['application/json','JSON'],
 'html':['text/html','HTML'],'htm':['text/html','HTML'],
 'css':['css','CSS'],'scss':['text/x-scss','SCSS'],
 'yml':['text/x-yaml','YAML'],'yaml':['text/x-yaml','YAML'],
 'toml':['text/x-toml','TOML'],
 'properties':['text/x-properties','Properties'],'ini':['text/x-properties','Properties'],
 'conf':['text/x-nginx-conf','Nginx'],'nginx':['text/x-nginx-conf','Nginx'],
 'xml':['application/xml','XML'],'svg':['application/xml','XML'],
 'py':['python','Python'],'pyw':['python','Python'],
 'sh':['text/x-sh','Shell'],'bash':['text/x-sh','Shell'],'zsh':['text/x-sh','Shell'],
 'java':['text/x-java','Java'],
 'c':['text/x-csrc','C'],'h':['text/x-csrc','C'],
 'cpp':['text/x-c++src','C++'],'cc':['text/x-c++src','C++'],'hpp':['text/x-c++src','C++'],
 'cs':['text/x-csharp','C#'],
 'go':['text/x-go','Golang'],
 'rb':['text/x-ruby','Ruby'],
 'rs':['text/x-rustsrc','Rust'],
 'php':['application/x-httpd-php','PHP'],
 'lua':['text/x-lua','Lua'],
 'sql':['text/x-sql','SQL'],
 'md':['text/x-markdown','Markdown'],'markdown':['text/x-markdown','Markdown'],
 'txt':[null,'Plain Text'],
 'diff':['text/x-diff','Diff'],'patch':['text/x-diff','Diff'],
 };
 if (base === 'dockerfile') return ['text/x-dockerfile','Dockerfile'];
 return map[ext] || [null,'Plain Text'];
}

function setEditorLanguage(mode, label) {
 currentLangLabel = label || 'Plain Text';
 const langLabelEl = document.getElementById('langLabel');
 if (langLabelEl) langLabelEl.textContent = currentLangLabel;
 if (editor) editor.setOption('mode', mode || null);
}

function openLangSelector() {
 const modal = document.getElementById('langSelectorModal');
 const list = document.getElementById('langList');
 if (!modal || !list) return;
 list.innerHTML = LANGUAGES.map(lang => {
 const isActive = lang.label === currentLangLabel;
 return `<button onclick="selectLanguage(${JSON.stringify(lang.label)},${JSON.stringify(lang.mode)})"
 class="w-full flex items-center justify-between px-5 py-3 text-sm transition hover:bg-slate-700/60 active:bg-slate-700 ${isActive ? 'text-blue-400 font-bold' : 'text-[#abb2bf]'}">
 <span>${lang.label}</span>
 ${isActive ? '<svg class="w-4 h-4 text-blue-400" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/></svg>' : ''}
 </button>`;
 }).join('');
 modal.classList.remove('hidden');
 modal.style.animation = 'none';
 requestAnimationFrame(() => {
 const sheet = modal.querySelector('div');
 if (sheet) { sheet.style.transform = 'translateY(100%)'; requestAnimationFrame(() => { sheet.style.transition = 'transform 0.25s cubic-bezier(0.32,0.72,0,1)'; sheet.style.transform = 'translateY(0)'; }); }
 });
}

function closeLangSelector() {
 const modal = document.getElementById('langSelectorModal');
 if (!modal) return;
 const sheet = modal.querySelector('div');
 if (sheet) {
 sheet.style.transform = 'translateY(100%)';
 setTimeout(() => modal.classList.add('hidden'), 250);
 } else { modal.classList.add('hidden'); }
}

function selectLanguage(label, mode) {
 setEditorLanguage(mode, label);
 closeLangSelector();
}

const editorEl = document.getElementById('fileContent');
if(editorEl) {
 editor = CodeMirror(editorEl, {
 value: "",
 theme: "ayu-mirage",
 mode: null,
 indentUnit: 4,
 smartIndent: true,
 tabSize: 4,
 indentWithTabs: false,
 lineWrapping: true,
 lineNumbers: true,
 foldGutter: true,
 fixedGutter: true,
 scrollbarStyle: 'overlay',
 styleActiveLine: true,
 showCursorWhenSelecting: false,
 autofocus: false,
 spellcheck: false,
 autocorrect: false,
 autocapitalize: false,
 inputStyle: 'contenteditable',
 autoCloseBrackets: true,
 matchBrackets: true,
 gutters: ['CodeMirror-linenumbers', 'CodeMirror-foldgutter'],
 });

 // CUSTOM CSS: Warna Select All ala Pterodactyl (Biru Keputihan) 
 const style = document.createElement('style');
 style.innerHTML = `
 .CodeMirror-selected { background-color: rgba(59, 130, 246, 0.35) !important; }
 .CodeMirror-line::selection, .CodeMirror-line > span::selection, .CodeMirror-line > span > span::selection { background-color: rgba(59, 130, 246, 0.35) !important; }
 .CodeMirror-line::-moz-selection, .CodeMirror-line > span::-moz-selection, .CodeMirror-line > span > span::-moz-selection { background-color: rgba(59, 130, 246, 0.35) !important; }
 `;
 document.head.appendChild(style);
 editor.on('change', syncEditorSaveButton);
 editorSavedContent = editor.getValue();
 syncEditorSaveButton();
}

window.startProgress = function() {
 let bar = document.getElementById('top-progress-bar');
 if (!bar) {
 bar = document.createElement('div');
 bar.id = 'top-progress-bar';
 bar.className = 'fixed top-0 left-0 h-1 bg-blue-500 z-[9999] shadow-[0_0_10px_rgba(59,130,246,0.8)] transition-all ease-out';
 bar.style.width = '0%';
 document.body.appendChild(bar);
 }

 if (bar._running) return;
 bar._running = true;

 clearInterval(progressInterval);
 bar.style.transitionDuration = '0ms';
 bar.style.width = '0%';
 bar.style.opacity = '1';

 setTimeout(() => {
 bar.style.transitionDuration = '300ms';
 bar.style.width = '30%';
 progressInterval = setInterval(() => {
 let w = parseFloat(bar.style.width);
 if (w < 85) bar.style.width = (w + Math.random() * 10) + '%';
 }, 300);
 }, 10);
};

window.finishProgress = function() {
 let bar = document.getElementById('top-progress-bar');
 if (!bar) return;
 bar._running = false;
 clearInterval(progressInterval);
 bar.style.width = '100%';

 setTimeout(() => {
 bar.style.opacity = '0';
 setTimeout(() => {
 bar.style.width = '0%';
 bar.style.transitionDuration = '0ms';
 }, 300);
 }, 400);
};

window.toggleSearchBar = function() {
 const bar = document.getElementById('customSearchBar');
 if (!bar) return;
 if (bar.classList.contains('hidden')) {
 bar.classList.remove('hidden');
 document.getElementById('editorSearchInput').focus();
 } else {
 bar.classList.add('hidden');
 clearAllSearchMarks(); 
 document.getElementById('editorSearchInput').value = '';
 lastQuery = '';
 editor.focus();
 }
};

let allSearchMarks = [];
function clearAllSearchMarks() {
 allSearchMarks.forEach(m => m.clear());
 allSearchMarks = [];
 if (currentSearchMark) currentSearchMark.clear();
 currentSearchMark = null;
}

function highlightAllMatches(query) {
 clearAllSearchMarks();
 if (!query) return;
 let cursor = editor.getSearchCursor(query, CodeMirror.Pos(0, 0), true);
 while (cursor.findNext()) {
 let mark = editor.markText(cursor.from(), cursor.to(), {className: "cm-search-match"});
 allSearchMarks.push(mark);
 }
}

window.performEditorSearch = function(reverse, isTyping = false) {
 if (!editor) return;
 const searchInput = document.getElementById('editorSearchInput');
 if (!searchInput) return;
 
 const query = searchInput.value;
 
 if (query !== lastQuery) {
 lastQuery = query;
 highlightAllMatches(query);
 searchCursor = editor.getSearchCursor(query, CodeMirror.Pos(0, 0), true);
 }

 if (!query) {
 clearAllSearchMarks();
 return;
 }
 if (!searchCursor) return;

 let found = reverse ? searchCursor.findPrevious() : searchCursor.findNext();
 if (!found) {
 searchCursor = editor.getSearchCursor(query, reverse ? CodeMirror.Pos(editor.lastLine(), 99999) : CodeMirror.Pos(0, 0), true);
 found = reverse ? searchCursor.findPrevious() : searchCursor.findNext();
 }

 if (found) {
 if (currentSearchMark) currentSearchMark.clear();
 currentSearchMark = editor.markText(searchCursor.from(), searchCursor.to(), {className: "cm-search-active"});
 
 if (!isTyping) editor.setSelection(searchCursor.from(), searchCursor.to());
 editor.scrollIntoView({from: searchCursor.from(), to: searchCursor.to()}, 150);
 } else if (!isTyping) {
 if(typeof showToast === 'function') showToast('Teks tidak ditemukan', 'error');
 }
};

window.editorSearchNext = () => performEditorSearch(false);
window.editorSearchPrev = () => performEditorSearch(true);

document.addEventListener('DOMContentLoaded', () => {
 const searchInput = document.getElementById('editorSearchInput');
 if (searchInput) {
 searchInput.addEventListener('input', function() { performEditorSearch(false, true); });
 searchInput.addEventListener('keydown', function(e) {
 if (e.key === 'Enter') { e.preventDefault(); performEditorSearch(false); }
 });
 }
});

const fallbackCopyTextToClipboard = (text) => {
 const textArea = document.createElement("textarea");
 textArea.value = text;
 textArea.style.top = "0";
 textArea.style.left = "0";
 textArea.style.position = "fixed";
 document.body.appendChild(textArea);
 textArea.focus();
 textArea.select();
 try {
 const successful = document.execCommand('copy');
 document.body.removeChild(textArea);
 return successful;
 } catch (err) {
 document.body.removeChild(textArea);
 return false;
 }
};

// FUNGSI BARU UNTUK MANGGIL POP-UP PANEL CUSTOM 
function showCustomConfirm(icon, title, msg, onConfirm) {
 if(document.getElementById('genericModalIcon')) document.getElementById('genericModalIcon').innerText = icon;
 if(document.getElementById('genericModalTitle')) document.getElementById('genericModalTitle').innerText = title;
 if(document.getElementById('genericModalMsg')) document.getElementById('genericModalMsg').innerHTML = msg; 
 const gModal = document.getElementById('genericModal');
 if(gModal) gModal.classList.remove('hidden');
 
 const confirmBtn = document.getElementById('genericConfirmBtn');
 if(confirmBtn) {
 // Clone button biar event listener sebelumnya ilang
 const newBtn = confirmBtn.cloneNode(true);
 confirmBtn.parentNode.replaceChild(newBtn, confirmBtn);
 newBtn.onclick = () => {
 document.getElementById('genericModal').classList.add('hidden');
 if (onConfirm) onConfirm();
 };
 }
}

window.editorAction = async function(action) {
 if (!editor) return;
 
 const isSecure = window.isSecureContext && navigator.clipboard;

 switch(action) {
 case 'search': toggleSearchBar(); break;
 case 'selectAll': editor.execCommand('selectAll'); editor.focus(); break;
 
 // FITUR KOSONGKAN FILE PAKE MODAL ELEGAN 
 case 'clear':
 showCustomConfirm(
 '', 
 'Kosongkan File', 
 'Yakin mau menghapus <b>SEMUA</b> isi file ini?<br><br><span class="text-red-400 text-xs font-medium">(Teks akan kosong, pastikan kamu belum menekan tombol Simpan jika ini tidak disengaja!)</span>',
 () => {
 editor.setValue("");
 if(typeof showToast === 'function') showToast(' Isi file dikosongkan!');
 }
 );
 break;
 
 case 'copy':
 const copyText = editor.getSelection();
 if (copyText) {
 if (isSecure) {
 try { await navigator.clipboard.writeText(copyText); if(typeof showToast === 'function') showToast(' Teks disalin!'); } 
 catch(err) { if(typeof showToast === 'function') showToast('Gagal menyalin teks', 'error'); }
 } else {
 if(fallbackCopyTextToClipboard(copyText)) {
 if(typeof showToast === 'function') showToast(' Teks disalin (Mode HTTP)!');
 } else {
 if(typeof showToast === 'function') showToast('Gagal menyalin. Gunakan HTTPS.', 'error');
 }
 }
 } else { if(typeof showToast === 'function') showToast('Pilih teks dulu!', 'error'); }
 break;
 
 case 'cut':
 const cutText = editor.getSelection();
 if (cutText) {
 if (isSecure) {
 try { await navigator.clipboard.writeText(cutText); editor.replaceSelection(''); if(typeof showToast === 'function') showToast(' Teks dipotong!'); } 
 catch(err) { if(typeof showToast === 'function') showToast('Gagal memotong teks', 'error'); }
 } else {
 if(fallbackCopyTextToClipboard(cutText)) {
 editor.replaceSelection('');
 if(typeof showToast === 'function') showToast(' Teks dipotong (Mode HTTP)!');
 } else {
 if(typeof showToast === 'function') showToast('Gagal memotong. Gunakan HTTPS.', 'error');
 }
 }
 } else { if(typeof showToast === 'function') showToast('Pilih teks dulu!', 'error'); }
 break;
 
 case 'paste':
 if (isSecure && navigator.clipboard.readText) {
 try { const pasteText = await navigator.clipboard.readText(); editor.replaceSelection(pasteText); if(typeof showToast === 'function') showToast(' Teks ditempel!'); } 
 catch(err) { if(typeof showToast === 'function') showToast('Gagal menempel (Cek izin clipboard browser)', 'error'); }
 } else {
 if(typeof showToast === 'function') showToast(' Tombol Paste butuh HTTPS! Gunakan tahan-layar lalu "Tempel"', 'error');
 }
 break;
 }
};

function updateRowBorder(filePath, selected) {
 const cb = document.querySelector(`.file-checkbox[value="${CSS.escape(filePath)}"]`);
 if (cb) { const li = cb.closest('li'); if (li) li.style.borderLeftColor = selected ? '#3b82f6' : 'transparent'; }
}
function toggleSelect(filePath) {
 if (selectedFiles.has(filePath)) { selectedFiles.delete(filePath); updateRowBorder(filePath, false); }
 else { selectedFiles.add(filePath); updateRowBorder(filePath, true); }
 updateDeleteButton();
}
function toggleSelectAll() {
 const checkboxes = document.querySelectorAll('.file-checkbox');
 const selectAll = document.getElementById('selectAll');
 if(!selectAll) return;
 const isChecked = selectAll.checked;
 selectedFiles.clear();
 checkboxes.forEach(cb => {
  cb.checked = isChecked;
  if (isChecked) selectedFiles.add(cb.value);
  const li = cb.closest('li');
  if (li) li.style.borderLeftColor = isChecked ? '#3b82f6' : 'transparent';
 });
 updateDeleteButton();
}

function isArchivePath(filePath) {
 const lname = String(filePath || '').toLowerCase();
 return lname.endsWith('.zip') || lname.endsWith('.tar.gz') || lname.endsWith('.tgz') ||
  lname.endsWith('.tar') || lname.endsWith('.tar.bz2') || lname.endsWith('.tbz2') ||
  lname.endsWith('.tar.xz') || lname.endsWith('.txz') || lname.endsWith('.gz') ||
  lname.endsWith('.rar') || lname.endsWith('.7z');
}

function getSelectedFileEntries() {
 const currentEntries = folderCache[currentPath] || [];
 return Array.from(selectedFiles).map(filePath => {
  const entry = currentEntries.find(file => file.path === filePath);
  return entry || { path: filePath, name: filePath.split('/').pop(), isDirectory: false };
 });
}

function updateDeleteButton() { 
 const bar = document.getElementById('pteroFloatingBar'); if(!bar) return; 
 const count = selectedFiles.size; 
 if (count > 0) { 
  if (floatingBarShowTimer) { clearTimeout(floatingBarShowTimer); floatingBarShowTimer = null; }
  if (floatingBarHideTimer) { clearTimeout(floatingBarHideTimer); floatingBarHideTimer = null; }
 bar.classList.remove('hidden'); 
  floatingBarShowTimer = setTimeout(() => {
   bar.classList.remove('opacity-0', 'scale-90', '-translate-y-4');
   bar.classList.add('opacity-100', 'scale-100', 'translate-y-0');
   floatingBarShowTimer = null;
  }, 10);
  const entries = getSelectedFileEntries();
  const regularEntries = entries.filter(entry => entry.isDirectory || !isArchivePath(entry.path));
  const archiveBtn = document.getElementById('archiveSelectedBtn') ||
   bar.querySelector('button[onclick="showArchiveModal()"]');
  // Archive files are extracted from their three-dot menu. Show Archive
  // only when the selection contains a folder or non-archive file.
  if (archiveBtn) archiveBtn.classList.toggle('hidden', regularEntries.length === 0);
 } else { 
  if (floatingBarShowTimer) { clearTimeout(floatingBarShowTimer); floatingBarShowTimer = null; }
  if (floatingBarHideTimer) clearTimeout(floatingBarHideTimer);
 bar.classList.remove('opacity-100', 'scale-100', 'translate-y-0'); bar.classList.add('opacity-0', 'scale-90', '-translate-y-4'); 
  floatingBarHideTimer = setTimeout(() => {
   bar.classList.add('hidden');
   floatingBarHideTimer = null;
  }, 300);
  const archiveBtn = document.getElementById('archiveSelectedBtn') ||
   bar.querySelector('button[onclick="showArchiveModal()"]');
  if (archiveBtn) archiveBtn.classList.remove('hidden');
 const selectAll = document.getElementById('selectAll'); if(selectAll) selectAll.checked = false; 
 } 
}

function escapeDeleteHtml(value) {
 return String(value == null ? '' : value).replace(/[&<>"']/g, ch => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
 }[ch]));
}

function showDeleteModal(itemsArray, msg) {
 if(typeof closeAllDropdowns === 'function') closeAllDropdowns();
 const entries = (itemsArray || []).map(filePath => {
  const cached = (folderCache[currentPath] || []).find(file => file.path === filePath);
  const fallbackName = String(filePath || '').split('/').filter(Boolean).pop() || String(filePath || '/');
  return cached || { path: filePath, name: fallbackName, isDirectory: false };
 });
 const count = entries.length;
 const title = document.getElementById('genericModalTitle');
 const icon = document.getElementById('genericModalIcon');
 const message = document.getElementById('genericModalMsg');
 if (icon) icon.innerText = '';
 if (title) title.innerText = 'Delete Files';
 if (message) {
  // Match the Pterodactyl confirmation style: show only selected names,
  // without absolute paths such as /home/container.
  const rows = entries.map(entry => {
   const name = escapeDeleteHtml(entry.name || String(entry.path || '').split('/').filter(Boolean).pop() || 'Unknown');
   return `<li class="break-all">${name}</li>`;
  }).join('');
  message.innerHTML = `<div class="mb-3">Are you sure you want to delete <b>${count}</b> ${count === 1 ? 'file' : 'files'}? This is a permanent action and the files cannot be recovered.</div><ul class="text-left list-disc pl-5 space-y-1 max-h-56 overflow-y-auto">${rows}</ul>`;
 }
 const gModal = document.getElementById('genericModal');
 if (gModal) gModal.classList.remove('hidden');
 const confirmBtn = document.getElementById('genericConfirmBtn');
 if (confirmBtn) {
  const newBtn = confirmBtn.cloneNode(true);
  confirmBtn.parentNode.replaceChild(newBtn, confirmBtn);
  newBtn.onclick = async () => {
   if (gModal) gModal.classList.add('hidden');
   startProgress();
   try {
    const res = await fetch('/api/delete', {
     method: 'POST',
     headers: { 'Content-Type': 'application/json' },
     body: JSON.stringify({ items: itemsArray })
    });
    if (res.ok) {
     delete folderCache[currentPath];
     selectedFiles.clear();
     updateDeleteButton();
     await loadFiles(currentPath);
     if (typeof showToast === 'function') showToast('File berhasil dihapus!');
    } else if (typeof showToast === 'function') {
     showToast('Gagal menghapus file!', 'error');
    }
   } catch (e) {
    if (typeof showToast === 'function') showToast('Gagal menghapus file!', 'error');
   } finally {
    finishProgress();
   }
  };
 }
}
function deleteSelectedMulti() { showDeleteModal(Array.from(selectedFiles)); }

window.downloadSelectedFiles = function() {
 const files = Array.from(selectedFiles);
 if (files.length === 0) { if(typeof showToast === 'function') showToast('Pilih file dulu!', 'error'); return; }

 const existing = document.getElementById('bulkDownloadModal');
 if (existing) existing.remove();

 const cachedFiles = folderCache[currentPath] || [];
 const sizeMap = {};
 cachedFiles.forEach(f => { sizeMap[f.path] = f.size || ''; });

 function getBulkFileIcon(filePath) {
  const cachedFiles = folderCache[currentPath] || [];
  const entry = cachedFiles.find(f => f.path === filePath);
  if (entry && entry.isDirectory) {
   return `<svg class="w-4 h-4 text-slate-400 shrink-0" fill="currentColor" viewBox="0 0 512 512"><path d="M464 128H272l-64-64H48C21.49 64 0 85.49 0 112v288c0 26.51 21.49 48 48 48h416c26.51 0 48-21.49 48-48V176c0-26.51-21.49-48-48-48z"/></svg>`;
  }
  const lname = (filePath || '').toLowerCase();
  const isArchive = lname.endsWith('.zip') || lname.endsWith('.tar.gz') || lname.endsWith('.tgz') || lname.endsWith('.tar') || lname.endsWith('.gz') || lname.endsWith('.rar') || lname.endsWith('.7z');
  if (isArchive) {
   return `<svg class="w-4 h-4 text-slate-400 shrink-0" fill="currentColor" viewBox="0 0 384 512"><path d="M377 105L279.1 7c-4.5-4.5-10.6-7-17-7H256v128h128v-6.1c0-6.3-2.5-12.4-7-16.9zm-153 31V0H24C10.7 0 0 10.7 0 24v464c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H248c-13.2 0-24-10.8-24-24zM96 72c0-4.4 3.6-8 8-8h48c4.4 0 8 3.6 8 8v8c0 4.4-3.6 8-8 8h-48c-4.4 0-8-3.6-8-8v-8zm0 64c0-4.4 3.6-8 8-8h48c4.4 0 8 3.6 8 8v8c0 4.4-3.6 8-8 8h-48c-4.4 0-8-3.6-8-8v-8zm160 268c0 17.7-14.3 32-32 32s-32-14.3-32-32v-16h-16c-8.8 0-16-7.2-16-16v-48c0-8.8 7.2-16 16-16h16v-16c0-17.7 14.3-32 32-32s32 14.3 32 32v16h16c8.8 0 16 7.2 16 16v48c0 8.8-7.2 16-16 16h-16v16zm16-332c0 4.4-3.6 8-8 8h-48c-4.4 0-8-3.6-8-8v-8c0-4.4 3.6-8 8-8h48c4.4 0 8 3.6 8 8v8zm0 64c0 4.4-3.6 8-8 8h-48c-4.4 0-8-3.6-8-8v-8c0-4.4 3.6-8 8-8h48c4.4 0 8 3.6 8 8v8z"/></svg>`;
  }
  return `<svg class="w-4 h-4 text-slate-400 shrink-0" fill="currentColor" viewBox="0 0 384 512"><path d="M224 136V0H24C10.7 0 0 10.7 0 24v464c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H248c-13.2 0-24-10.8-24-24zm64 236c0 6.6-5.4 12-12 12H108c-6.6 0-12-5.4-12-12v-8c0-6.6 5.4-12 12-12h168c6.6 0 12 5.4 12 12v8zm0-64c0 6.6-5.4 12-12 12H108c-6.6 0-12-5.4-12-12v-8c0-6.6 5.4-12 12-12h168c6.6 0 12 5.4 12 12v8zm0-72v8c0 6.6-5.4 12-12 12H108c-6.6 0-12-5.4-12-12v-8c0-6.6 5.4-12 12-12h168c6.6 0 12 5.4 12 12zm96-114.1v6.1H256V0h6.1c6.4 0 12.5 2.5 17 7l97.9 98c4.5 4.5 7 10.6 7 16.9z"/></svg>`;
 }

 const fileRows = files.map(filePath => {
  const name = filePath.split('/').pop();
  const size = sizeMap[filePath] || '';
  const icon = getBulkFileIcon(filePath);
  return `<div class="flex items-center gap-3 py-2.5 border-b border-slate-700/50 last:border-0">
   ${icon}
   <span class="text-white font-mono text-sm break-all flex-1 leading-snug">${name}</span>
   ${size ? `<span class="text-blue-400 font-mono font-bold text-xs shrink-0">${size}</span>` : ''}
  </div>`;
 }).join('');

 const modal = document.createElement('div');
 modal.id = 'bulkDownloadModal';
 modal.className = 'fixed inset-0 z-[300] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm tab-fade-in';
 modal.innerHTML = `
  <div class="bg-[#1e293b] w-full max-w-sm rounded-2xl border border-blue-500/40 shadow-2xl overflow-hidden" style="box-shadow:0 0 40px rgba(0,0,0,0.6)">
   <div class="px-6 pt-6 pb-5">
    <div class="flex flex-col items-center text-center gap-2 mb-5">
     <div class="w-14 h-14 rounded-2xl bg-blue-500/15 border border-blue-500/40 flex items-center justify-center"><svg class="w-6 h-6 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M3 16.5v2.25A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75V16.5M7.5 12l4.5 4.5m0 0 4.5-4.5M12 16.5V3"/></svg></div>
     <div>
      <h3 class="text-white font-black text-lg leading-tight">Download ${files.length} File</h3>
      <p class="text-slate-400 text-xs mt-1">Semua file terpilih akan diunduh</p>
     </div>
    </div>
    <div class="bg-slate-900/70 rounded-xl px-4 py-1 border border-slate-700/60 mb-5 max-h-48 overflow-y-auto">
     ${fileRows}
    </div>
    <div class="flex gap-3">
     <button id="bulkDlCancelBtn" class="flex-1 bg-slate-700 hover:bg-slate-600 active:scale-95 text-slate-200 font-bold py-3 rounded-xl transition text-sm">Batal</button>
     <button id="bulkDlConfirmBtn" class="flex-1 bg-blue-600 hover:bg-blue-500 active:scale-95 text-white font-bold py-3 rounded-xl transition text-sm flex items-center justify-center gap-2 shadow-lg shadow-blue-900/40">
      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
      Download Semua
     </button>
    </div>
   </div>
  </div>
 `;

 document.body.appendChild(modal);

 const close = () => { modal.style.opacity = '0'; modal.style.transition = 'opacity 0.15s'; setTimeout(() => modal.remove(), 150); };
 document.getElementById('bulkDlCancelBtn').onclick = close;
 modal.addEventListener('click', e => { if (e.target === modal) close(); });

 document.getElementById('bulkDlConfirmBtn').onclick = () => {
  close();
  let delay = 0;
  files.forEach(filePath => {
   const name = filePath.split('/').pop();
   setTimeout(() => {
    const link = document.createElement('a');
    link.href = `/api/download?path=${encodeURIComponent(filePath)}`;
    link.download = name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
   }, delay);
   delay += 400;
  });
  if(typeof showToast === 'function') showToast(`Mendownload ${files.length} file...`);
 };
};
function deleteSingle(filePath, fileName) { showDeleteModal([filePath]); }
function openRenameModal(filePath, currentName) { if(typeof closeAllDropdowns === 'function') closeAllDropdowns(); if(document.getElementById('renameOldPath')) document.getElementById('renameOldPath').value = filePath; if(document.getElementById('renameInput')) document.getElementById('renameInput').value = currentName; const rModal = document.getElementById('renameModal'); if(rModal) rModal.classList.remove('hidden'); const rInput = document.getElementById('renameInput'); if(rInput) rInput.focus(); }

async function executeRename() { 
 const oldPath = document.getElementById('renameOldPath').value; const newName = document.getElementById('renameInput').value; if(!newName) return; 
 document.getElementById('renameModal').classList.add('hidden'); 
 startProgress();
 try { 
 const res = await fetch('/api/rename', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ oldPath, newName }) }); 
 if (res.ok) { 
 delete folderCache[currentPath]; 
 await loadFiles(currentPath); 
 if(typeof showToast === 'function') showToast('Nama file diubah!');
 } 
 } catch(e) {} finally { finishProgress(); }
}

function showCreateModal(type) {
 if (type === 'file') {
 isNewFile = true;
 currentEditFile = '';
 const editNameEl = document.getElementById('editingFileName');
 if (editNameEl) editNameEl.innerText = 'File Baru (belum disimpan)';

 if (typeof showTab === 'function') showTab('edit', false);
 history.pushState({ tab: 'edit', file: 'new' }, '', ((typeof tabUrlPath === 'function') ? tabUrlPath('files') : window.location.pathname) + '#edit/new');

 // Tampilkan spinner sebentar saat persiapan editor
 const fileContentParent = document.getElementById('fileContent') && document.getElementById('fileContent').parentElement;
 let editorSpinner = document.getElementById('editor-spinner');
 if (fileContentParent && !editorSpinner) {
 editorSpinner = document.createElement('div');
 editorSpinner.id = 'editor-spinner';
 editorSpinner.className = 'absolute inset-0 bg-[#1a1d23] z-[60] flex flex-col items-center justify-center gap-3';
 editorSpinner.innerHTML = `
 <div class="w-8 h-8 border-4 border-slate-600 border-t-blue-500 rounded-full animate-spin"></div>
 <span class="text-slate-400 font-bold text-sm tracking-wide">Menyiapkan editor...</span>
 `;
 fileContentParent.appendChild(editorSpinner);
 }
 if (editorSpinner) editorSpinner.classList.remove('hidden');

 setTimeout(() => {
 if (editor) { editor.setValue(""); editor.clearHistory(); editorSavedContent = editor.getValue(); syncEditorSaveButton(); }
 setEditorLanguage(null, 'Plain Text');
 if (editorSpinner) editorSpinner.classList.add('hidden');
 if (editor) editor.focus();
 }, 350);
 return;
 }
 if(document.getElementById('createType')) document.getElementById('createType').value = type; 
 if(document.getElementById('createModalTitle')) document.getElementById('createModalTitle').innerText = 'Create Directory'; 
 const cInput = document.getElementById('createInput'); if(cInput) cInput.value = ''; 
 const cModal = document.getElementById('createModal'); if(cModal) cModal.classList.remove('hidden'); 
 if(cInput) cInput.focus(); 
}

async function executeCreate() { 
 const type = document.getElementById('createType').value; const name = document.getElementById('createInput').value.trim(); if (!name) return; 
 const targetPath = currentPath === '' ? name : `${currentPath}/${name}`; document.getElementById('createModal').classList.add('hidden'); 
 startProgress();
 try { 
 let res;
 if (type === 'file') { res = await fetch('/api/file', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ path: targetPath, content: '' }) }); } 
 else { res = await fetch('/api/folder', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ path: targetPath }) }); } 
 if (res && res.ok) {
 delete folderCache[currentPath]; 
 await loadFiles(currentPath);
 if(typeof showToast === 'function') showToast(`${type === 'file' ? 'File' : 'Folder'} berhasil dibuat!`);
 }
 } catch (e) {} finally { finishProgress(); }
}

function formatLocalTime(isoString) { if (!isoString || isoString === '-') return '-'; const date = new Date(isoString); return `${String(date.getDate()).padStart(2, '0')}/${String(date.getMonth() + 1).padStart(2, '0')}/${date.getFullYear()} ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`; }

window.downloadFile = function(filePath, fileName, fileSize) {
 if(typeof closeAllDropdowns === 'function') closeAllDropdowns();

 const existing = document.getElementById('downloadConfirmModal');
 if (existing) existing.remove();

 const ext = fileName.includes('.') ? fileName.split('.').pop().toLowerCase() : '';
 const iconMap = {
  jar: { icon: '📦', color: 'text-orange-400', bg: 'bg-orange-500/15', border: 'border-orange-500/40' },
  zip: { icon: '🗜️', color: 'text-yellow-400', bg: 'bg-yellow-500/15', border: 'border-yellow-500/40' },
  gz: { icon: '🗜️', color: 'text-yellow-400', bg: 'bg-yellow-500/15', border: 'border-yellow-500/40' },
  json: { icon: '📋', color: 'text-blue-400', bg: 'bg-blue-500/15', border: 'border-blue-500/40' },
  yml: { icon: '⚙️', color: 'text-purple-400', bg: 'bg-purple-500/15', border: 'border-purple-500/40' },
  yaml: { icon: '⚙️', color: 'text-purple-400', bg: 'bg-purple-500/15', border: 'border-purple-500/40' },
  properties: { icon: '⚙️', color: 'text-slate-300', bg: 'bg-slate-500/15', border: 'border-slate-500/40' },
  txt: { icon: '📄', color: 'text-slate-300', bg: 'bg-slate-500/15', border: 'border-slate-500/40' },
  log: { icon: '📜', color: 'text-green-400', bg: 'bg-green-500/15', border: 'border-green-500/40' },
  png: { icon: '🖼️', color: 'text-pink-400', bg: 'bg-pink-500/15', border: 'border-pink-500/40' },
  jpg: { icon: '🖼️', color: 'text-pink-400', bg: 'bg-pink-500/15', border: 'border-pink-500/40' },
  sh: { icon: '💻', color: 'text-green-400', bg: 'bg-green-500/15', border: 'border-green-500/40' },
 };
 const style = iconMap[ext] || { icon: '📁', color: 'text-slate-300', bg: 'bg-slate-500/15', border: 'border-slate-500/40' };

 const modal = document.createElement('div');
 modal.id = 'downloadConfirmModal';
 modal.className = 'fixed inset-0 z-[300] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm tab-fade-in';
 modal.innerHTML = `
  <div class="bg-[#1e293b] w-full max-w-sm rounded-2xl border ${style.border} shadow-2xl overflow-hidden" style="box-shadow:0 0 40px rgba(0,0,0,0.6)">
   <div class="px-6 pt-6 pb-5">
    <div class="flex flex-col items-center text-center gap-3 mb-5">
     <div class="w-16 h-16 rounded-2xl ${style.bg} border ${style.border} flex items-center justify-center text-3xl shadow-inner">
      ${style.icon}
     </div>
     <div>
      <h3 class="text-white font-black text-lg leading-tight">Download File</h3>
      <p class="text-slate-400 text-xs mt-1">Siap untuk diunduh ke perangkat kamu</p>
     </div>
    </div>
    <div class="bg-slate-900/70 rounded-xl px-4 py-3 border border-slate-700/60 mb-5">
     <div class="flex items-start justify-between gap-3">
      <div class="min-w-0 flex-1">
       <p class="text-xs text-slate-400 mb-1 font-semibold uppercase tracking-wider">Nama File</p>
       <p class="text-white font-mono text-sm break-all leading-snug">${fileName}</p>
      </div>
      ${fileSize ? `<div class="shrink-0 text-right">
       <p class="text-xs text-slate-400 mb-1 font-semibold uppercase tracking-wider">Ukuran</p>
       <p class="text-blue-400 font-mono font-bold text-sm">${fileSize}</p>
      </div>` : ''}
     </div>
    </div>
    <div class="flex gap-3">
     <button id="dlCancelBtn" class="flex-1 bg-slate-700 hover:bg-slate-600 active:scale-95 text-slate-200 font-bold py-3 rounded-xl transition text-sm">Batal</button>
     <button id="dlConfirmBtn" class="flex-1 bg-blue-600 hover:bg-blue-500 active:scale-95 text-white font-bold py-3 rounded-xl transition text-sm flex items-center justify-center gap-2 shadow-lg shadow-blue-900/40">
      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
      Download
     </button>
    </div>
   </div>
  </div>
 `;

 document.body.appendChild(modal);

 const close = () => { modal.style.opacity = '0'; modal.style.transition = 'opacity 0.15s'; setTimeout(() => modal.remove(), 150); };

 document.getElementById('dlCancelBtn').onclick = close;
 modal.addEventListener('click', (e) => { if (e.target === modal) close(); });

 document.getElementById('dlConfirmBtn').onclick = () => {
  close();
  if(typeof showToast === 'function') showToast('Mendownload: ' + fileName);
  const link = document.createElement('a');
  link.href = `/api/download?path=${encodeURIComponent(filePath)}`;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
 };
}

window.executeSingleAction = function(filePath, action) { 
 if(typeof closeAllDropdowns === 'function') closeAllDropdowns(); 
 selectedFiles.clear(); selectedFiles.add(filePath); 
 updateDeleteButton(); 
 if (action === 'move') showMoveModal(); 
 if (action === 'archive') showArchiveModal(); 
}

function formatFileDate(isoDate) {
 if (!isoDate) return '';
 try {
  const d = new Date(isoDate);
  const now = new Date();
  const diffMs = now - d;
  const diffSec = Math.floor(diffMs / 1000);
  const diffMin = Math.floor(diffSec / 60);
  const diffHr = Math.floor(diffMin / 60);
  const diffDay = Math.floor(diffHr / 24);

  if (diffSec < 60) return 'less than a minute ago';
  if (diffMin < 60) return diffMin === 1 ? '1 minute ago' : diffMin + ' minutes ago';
  if (diffHr < 24) return diffHr === 1 ? 'about 1 hour ago' : 'about ' + diffHr + ' hours ago';
  if (diffDay === 1) return '1 day ago';

  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const day = d.getDate();
  const ord = day === 1 || day === 21 || day === 31 ? 'st' : day === 2 || day === 22 ? 'nd' : day === 3 || day === 23 ? 'rd' : 'th';
  let hr = d.getHours();
  const ampm = hr >= 12 ? 'PM' : 'AM';
  hr = hr % 12 || 12;
  const min = String(d.getMinutes()).padStart(2, '0');
  return months[d.getMonth()] + ' ' + day + ord + ', ' + d.getFullYear() + ' ' + hr + ':' + min + ampm;
 } catch(e) { return ''; }
}

// SVG paths diambil dari FontAwesome Free Solid (sama persis seperti Pterodactyl)
const _FA_FOLDER    = `<svg class="w-4 h-4" fill="currentColor" viewBox="0 0 512 512"><path d="M464 128H272l-64-64H48C21.49 64 0 85.49 0 112v288c0 26.51 21.49 48 48 48h416c26.51 0 48-21.49 48-48V176c0-26.51-21.49-48-48-48z"/></svg>`;
const _FA_FILE_ALT  = `<svg class="w-4 h-4" fill="currentColor" viewBox="0 0 384 512"><path d="M224 136V0H24C10.7 0 0 10.7 0 24v464c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H248c-13.2 0-24-10.8-24-24zm64 236c0 6.6-5.4 12-12 12H108c-6.6 0-12-5.4-12-12v-8c0-6.6 5.4-12 12-12h168c6.6 0 12 5.4 12 12v8zm0-64c0 6.6-5.4 12-12 12H108c-6.6 0-12-5.4-12-12v-8c0-6.6 5.4-12 12-12h168c6.6 0 12 5.4 12 12v8zm0-72v8c0 6.6-5.4 12-12 12H108c-6.6 0-12-5.4-12-12v-8c0-6.6 5.4-12 12-12h168c6.6 0 12 5.4 12 12zm96-114.1v6.1H256V0h6.1c6.4 0 12.5 2.5 17 7l97.9 98c4.5 4.5 7 10.6 7 16.9z"/></svg>`;
const _FA_FILE_ARCH = `<svg class="w-4 h-4" fill="currentColor" viewBox="0 0 384 512"><path d="M377 105L279.1 7c-4.5-4.5-10.6-7-17-7H256v128h128v-6.1c0-6.3-2.5-12.4-7-16.9zm-153 31V0H24C10.7 0 0 10.7 0 24v464c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H248c-13.2 0-24-10.8-24-24zM96 72c0-4.4 3.6-8 8-8h48c4.4 0 8 3.6 8 8v8c0 4.4-3.6 8-8 8h-48c-4.4 0-8-3.6-8-8v-8zm0 64c0-4.4 3.6-8 8-8h48c4.4 0 8 3.6 8 8v8c0 4.4-3.6 8-8 8h-48c-4.4 0-8-3.6-8-8v-8zm160 268c0 17.7-14.3 32-32 32s-32-14.3-32-32v-16h-16c-8.8 0-16-7.2-16-16v-48c0-8.8 7.2-16 16-16h16v-16c0-17.7 14.3-32 32-32s32 14.3 32 32v16h16c8.8 0 16 7.2 16 16v48c0 8.8-7.2 16-16 16h-16v16zm16-332c0 4.4-3.6 8-8 8h-48c-4.4 0-8-3.6-8-8v-8c0-4.4 3.6-8 8-8h48c4.4 0 8 3.6 8 8v8zm0 64c0 4.4-3.6 8-8 8h-48c-4.4 0-8-3.6-8-8v-8c0-4.4 3.6-8 8-8h48c4.4 0 8 3.6 8 8v8z"/></svg>`;
const _FA_FILE_IMP  = `<svg class="w-4 h-4" fill="currentColor" viewBox="0 0 512 512"><path d="M16 288c-8.8 0-16 7.2-16 16v32c0 8.8 7.2 16 16 16h112v-64zm489-183L407.1 7c-4.5-4.5-10.6-7-17-7H384v128h128v-6.1c0-6.3-2.5-12.4-7-16.9zm-153 31V0H152c-13.3 0-24 10.7-24 24v264h128v-65.2c0-14.3 17.3-21.4 27.4-11.3L379 308c6.6 6.3 6.6 16.4 0 22.6l-95.7 96.4c-10.1 10.1-27.4 3-27.4-11.3V352H128v136c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H376c-13.2 0-24-10.8-24-24z"/></svg>`;

function getFileIconBadge(name, isDirectory) {
 const lname = (name || '').toLowerCase();
 const DEF = { bg: 'bg-slate-700/60 border-slate-600/50', color: 'text-slate-400' };

 if (isDirectory) return { ...DEF, svg: _FA_FOLDER };

 const isArchive = lname.endsWith('.zip') || lname.endsWith('.tar.gz') || lname.endsWith('.tgz') || lname.endsWith('.tar') || lname.endsWith('.gz') || lname.endsWith('.rar') || lname.endsWith('.7z');
 if (isArchive) return { ...DEF, svg: _FA_FILE_ARCH };

 if (lname.endsWith('.lnk')) return { ...DEF, svg: _FA_FILE_IMP };

 return { ...DEF, svg: _FA_FILE_ALT };
}

function getFileIcon(name, isDirectory) {
 const b = getFileIconBadge(name, isDirectory);
 return `<div class="w-8 h-8 rounded-lg ${b.bg} border ${b.color} flex items-center justify-center shrink-0">${b.svg}</div>`;
}

const _VS_ROW_H = 48;
const _VS_THRESH = 80;
let _vsScrollCb = null;
let _vsScrollEl = null;

function _applyVirtualScroll(htmlBuffer, listElement) {
 if (!listElement) return;
 if (_vsScrollCb && _vsScrollEl) { _vsScrollEl.removeEventListener('scroll', _vsScrollCb); _vsScrollCb = null; }
 // Render every row into the page flow. The previous fixed-height virtual
 // scroller could hide rows when mobile row heights wrapped, and its capped
 // container made the file panel look like it stopped at the first entries.
 // The file manager already scrolls at page level, so the complete list must
 // be allowed to grow naturally down the page.
 _vsScrollEl = null;
 listElement.innerHTML = htmlBuffer;
}

function renderFileListHTML(files, dir, listElement) {
 if(!listElement) return;
 let htmlBuffer = ""; 
 
 if (dir !== '') { 
  const parentPath = dir.split('/').slice(0, -1).join('/'); 
  htmlBuffer += `
  <li onclick="loadFiles('${parentPath}')" class="flex items-center gap-3 px-4 py-2.5 cursor-pointer hover:bg-slate-700/40 border-b border-slate-700/40 transition-all duration-150 group" style="border-left:3px solid transparent" onmouseenter="this.style.borderLeftColor='#3b82f6'" onmouseleave="this.style.borderLeftColor='transparent'">
   <span class="w-4 h-4 shrink-0"></span>
   <div class="w-8 h-8 rounded-lg bg-slate-700/50 border border-slate-600/40 flex items-center justify-center shrink-0">
    <svg class="w-4 h-4 text-slate-400 group-hover:text-blue-400 transition" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
   </div>
   <span class="text-slate-400 group-hover:text-slate-200 text-sm font-medium transition select-none">..</span>
  </li>`; 
 } 

 // Tampilkan state khusus ketika folder tidak memiliki file maupun subfolder.
 // Pada subfolder, tombol '..' tetap ditampilkan agar pengguna bisa kembali.
 if (!files || files.length === 0) {
  htmlBuffer += `
  <li class="w-full min-h-[260px] flex flex-col items-center justify-center gap-3 text-center select-none">
   <div class="w-14 h-14 rounded-2xl bg-slate-800/80 border border-slate-700/70 flex items-center justify-center text-slate-500">
    <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.6" aria-hidden="true">
     <path stroke-linecap="round" stroke-linejoin="round" d="M3.75 7.5A1.75 1.75 0 0 1 5.5 5.75h4.086c.464 0 .91.184 1.238.512l1.164 1.164c.328.328.773.512 1.238.512H18.5a1.75 1.75 0 0 1 1.75 1.75v7.062A2.25 2.25 0 0 1 18 19H6a2.25 2.25 0 0 1-2.25-2.25V7.5Z" />
     <path stroke-linecap="round" stroke-linejoin="round" d="M4 10h16" />
    </svg>
   </div>
   <span class="text-sm font-semibold tracking-wide text-slate-400">Empty Folder</span>
  </li>`;
  _applyVirtualScroll(htmlBuffer, listElement);
  return;
 }
 
 files.forEach((file, index) => { 
  const iconSvg = getFileIcon(file.name, file.isDirectory);
  const action = file.isDirectory ? `loadFiles('${file.path}')` : `openFile('${file.path}', '${file.name}')`; 
  const menuId = `menu-${index}`; 
  const lname = file.name.toLowerCase();
  // Cek apakah file sudah berformat archive — kalau iya, tombol Archive disembunyikan
  const isAlreadyArchive = !file.isDirectory && (
    lname.endsWith('.zip') || lname.endsWith('.tar.gz') || lname.endsWith('.tgz') ||
    lname.endsWith('.tar') || lname.endsWith('.gz') || lname.endsWith('.rar') || lname.endsWith('.7z')
  );

  let unarchiveBtn = ''; 
  if (!file.isDirectory && (
    lname.endsWith('.zip') || lname.endsWith('.tar.gz') || lname.endsWith('.tgz') ||
    lname.endsWith('.tar') || lname.endsWith('.tar.bz2') || lname.endsWith('.tbz2') ||
    lname.endsWith('.tar.xz') || lname.endsWith('.txz')
  )) { 
   unarchiveBtn = `
   <div onclick="event.stopPropagation(); executeExtract('${file.path}')" class="px-4 py-2.5 hover:bg-white/10 text-slate-300 text-sm cursor-pointer flex items-center gap-3 transition">
    <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"/></svg>
    Extract
   </div>`; 
  } 
 
  let downloadBtn = '';
  if (!file.isDirectory) {
   downloadBtn = `
   <div onclick="event.stopPropagation(); downloadFile('${file.path}', '${file.name}', '${file.size || ''}')" class="px-4 py-2.5 hover:bg-white/10 text-slate-300 text-sm cursor-pointer flex items-center gap-3 transition">
    <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
    Download
   </div>`;
  }

  const fileDateStr = formatFileDate(file.date);
  const sizeHtml = file.size ? `<span class="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-slate-700/70 text-slate-300 font-mono border border-slate-600/40 whitespace-nowrap">${file.size}</span>` : '';
  htmlBuffer += `
  <li onclick="${action}" class="flex items-center gap-3 px-4 py-2.5 cursor-pointer hover:bg-slate-700/40 border-b border-slate-700/40 last:border-0 transition-all duration-150 group relative" style="border-left:3px solid transparent" onmouseenter="this.style.borderLeftColor='#3b82f6'" onmouseleave="this.style.borderLeftColor=selectedFiles.has('${file.path}')?'#3b82f6':'transparent'">
   <input type="checkbox" value="${file.path}" class="file-checkbox w-4 h-4 rounded cursor-pointer accent-blue-500 shrink-0 opacity-100 sm:opacity-40 sm:group-hover:opacity-100 transition-opacity" onclick="event.stopPropagation(); toggleSelect(this.value)">
   ${iconSvg}
   <span class="flex-grow text-slate-100 text-sm truncate min-w-0 font-medium">${file.name}</span>
   <div class="flex items-center shrink-0 gap-2.5">
    ${sizeHtml}
    <span class="text-[10px] text-slate-500 whitespace-nowrap">${fileDateStr || ''}</span>
   </div>
   <div class="relative shrink-0">
    <button onclick="toggleMenu(event, '${menuId}')" class="w-8 h-8 flex items-center justify-center text-slate-500 hover:text-slate-200 hover:bg-blue-500/20 rounded-lg transition opacity-100 sm:opacity-0 sm:group-hover:opacity-100">
     <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path d="M6 10a2 2 0 11-4 0 2 2 0 014 0zM12 10a2 2 0 11-4 0 2 2 0 014 0zM16 12a2 2 0 100-4 2 2 0 000 4z"/></svg>
    </button>
    <div id="${menuId}" class="dropdown-menu hidden w-48 bg-[#1e293b] border border-slate-600/80 rounded-lg shadow-2xl py-1 origin-top-right">
     ${unarchiveBtn}
     ${downloadBtn}
     <div onclick="event.stopPropagation(); openRenameModal('${file.path}', '${file.name}')" class="px-4 py-2.5 hover:bg-white/10 text-slate-300 text-sm cursor-pointer flex items-center gap-3 transition">
      <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
      Rename
     </div>
     <div onclick="event.stopPropagation(); executeSingleAction('${file.path}', 'move')" class="px-4 py-2.5 hover:bg-white/10 text-slate-300 text-sm cursor-pointer flex items-center gap-3 transition">
      <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4"/></svg>
      Move
     </div>
     ${!isAlreadyArchive ? `<div onclick="event.stopPropagation(); executeSingleAction('${file.path}', 'archive')" class="px-4 py-2.5 hover:bg-white/10 text-slate-300 text-sm cursor-pointer flex items-center gap-3 transition">
      <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"/></svg>
      Archive
     </div>` : ''}
     <div class="h-px bg-slate-600/50 my-1"></div>
     <div onclick="event.stopPropagation(); deleteSingle('${file.path}', '${file.name}')" class="px-4 py-2.5 hover:bg-red-500/10 text-red-400 text-sm font-medium cursor-pointer flex items-center gap-3 transition">
      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
      Delete
     </div>
    </div>
   </div>
  </li>`; 
 });
 
 _applyVirtualScroll(htmlBuffer, listElement);
}

async function loadFiles(dir = '', addToHistory = true) {
 const gen = ++_loadFilesGen;
 startProgress();
 currentPath = dir;

 const pathEl = document.getElementById('currentDirPath');
 if (pathEl) {
  let breadcrumbHTML = `
  <span class="text-slate-500 cursor-not-allowed select-none">/ home</span>
  <span class="text-slate-600 mx-1.5">/</span>
  <span onclick="loadFiles('')" class="cursor-pointer hover:text-blue-400 transition text-slate-300 font-bold">container</span>
  `;
  if (dir !== '') {
   const parts = dir.replace(/^\/+/, '').split('/').filter(Boolean);
   let buildPath = '';
   parts.forEach((part, idx) => {
    buildPath += (idx === 0 ? part : '/' + part);
    breadcrumbHTML += `<span class="text-slate-600 mx-1.5">/</span>`;
    if (idx === parts.length - 1) {
     breadcrumbHTML += `<span class="font-black text-slate-100">${part}</span>`;
    } else {
     breadcrumbHTML += `<span onclick="loadFiles('${buildPath}')" class="cursor-pointer hover:text-blue-400 transition text-slate-300">${part}</span>`;
    }
   });
  }
  pathEl.innerHTML = breadcrumbHTML;
 }

 selectedFiles.clear();
 updateDeleteButton();

 const list = document.getElementById('fileList');
 if (addToHistory) {
  const newHash = dir === '' ? '' : `#${dir}`;
  const basePath = (typeof tabUrlPath === 'function') ? tabUrlPath('files') : window.location.pathname;
  const newUrl = basePath + newHash;
  if (window.location.pathname + window.location.hash !== newUrl) history.pushState({ tab: 'files', path: dir }, '', newUrl);
 }

 if (folderCache[dir]) {
  const _cachedFiles = folderCache[dir];
  setTimeout(() => {
   if (gen !== _loadFilesGen) return;
   renderFileListHTML(_cachedFiles, dir, list);
   finishProgress();
  }, 10);
  return;
 }

 if (list) {
  list.innerHTML = `
  <li class="p-8 bg-[#1e293b] rounded-xl text-center text-slate-400 font-bold flex flex-col items-center justify-center gap-3 w-full h-full min-h-[200px] border border-slate-700/50 shadow-sm">
  <div class="w-8 h-8 border-4 border-slate-600 border-t-blue-500 rounded-full animate-spin"></div>
  <span class="text-sm tracking-wide">Memuat folder...</span>
  </li>
  `;
 }

 try {
  const res = await fetch(`/api/files?path=${encodeURIComponent(dir)}`);
  if (gen !== _loadFilesGen) return;
  if (res.status === 401) return window.location.href = '/';
  const files = await res.json();
  if (gen !== _loadFilesGen) return;
  folderCache[dir] = files;
  renderFileListHTML(files, dir, list);
 } catch(e) {
 } finally {
  if (gen === _loadFilesGen) finishProgress();
 }
}

const BINARY_EXTENSIONS = new Set(['jar','zip','tar','gz','tgz','war','ear','rar','7z','bz2','xz','zst','whl','egg','apk','ipa','exe','dll','so','dylib','bin','dat','db','sqlite','sqlite3','class','pyc','pyd','pyo','pdf','png','jpg','jpeg','gif','webp','bmp','ico','tiff','svg','mp3','mp4','wav','ogg','webm','mov','avi','mkv','flac','aac','woff','woff2','ttf','eot','otf']);

async function openFile(filePath, fileName, addToHistory = true) {
 isNewFile = false;
 // Tutup popup aksi File Manager saat berpindah ke Editor Text.
 // Bersihkan timer juga agar callback lama tidak memunculkannya lagi.
 if (floatingBarShowTimer) { clearTimeout(floatingBarShowTimer); floatingBarShowTimer = null; }
 if (floatingBarHideTimer) { clearTimeout(floatingBarHideTimer); floatingBarHideTimer = null; }
 const fileManagerActionPopup = document.getElementById('pteroFloatingBar');
 if (fileManagerActionPopup) {
  fileManagerActionPopup.classList.add('hidden', 'opacity-0', 'scale-90', '-translate-y-4');
  fileManagerActionPopup.classList.remove('opacity-100', 'scale-100', 'translate-y-0');
 }
 selectedFiles.clear();
 const selectAllFilesCheckbox = document.getElementById('selectAll');
 if (selectAllFilesCheckbox) selectAllFilesCheckbox.checked = false;

 if(!fileName) fileName = filePath.split('/').pop();

 const ext = fileName.includes('.') ? fileName.split('.').pop().toLowerCase() : '';
 const base = fileName.toLowerCase();
 const isBinary = BINARY_EXTENSIONS.has(ext) || base.endsWith('.tar.gz') || base.endsWith('.tar.bz2') || base.endsWith('.tar.xz');

 if (isBinary) {
 return;
 }

 startProgress(); 
 currentEditFile = filePath;
 // Build Pterodactyl-style breadcrumb: / home / container / server.properties
 (function buildBreadcrumb(fp) {
  const el = document.getElementById('editorBreadcrumb');
  if (!el) return;
  const parts = fp.replace(/^\/+/, '').split('/').filter(Boolean);
  if (!parts.length) { el.innerHTML = '<span class="text-slate-500">Edit File</span>'; return; }
  let html = '<span class="text-slate-500 cursor-not-allowed select-none">/ home</span>'
    + '<span class="text-slate-600 mx-1.5">/</span>'
    + '<span class="cursor-pointer hover:text-blue-400 transition text-slate-300 font-bold" role="button" tabindex="0" title="Buka folder utama container" onclick="closeEditor();loadFiles(&#39;&#39;)">container</span>'
    + '<span class="text-slate-600 mx-1.5">/</span>';
  let accPath = '';
  parts.forEach(function(part, i) {
   accPath += '/' + part;
   const isLast = i === parts.length - 1;
   const esc = accPath.replace(/\\/g,'\\\\').replace(/'/g,"\\'");
   if (isLast) {
    html += '<span class="font-black text-slate-100">' + part + '</span>';
   } else {
    html += '<span class="cursor-pointer hover:text-blue-400 transition text-slate-300" onclick="closeEditor();loadFiles(\'' + esc + '\')">' + part + '</span>';
    html += '<span class="text-slate-600 mx-1.5">/</span>';
   }
  });
  el.innerHTML = html;
 })(filePath);

 lastQuery = '';
 searchCursor = null;
 clearAllSearchMarks();
 
 const searchInput = document.getElementById('editorSearchInput');
 if(searchInput) searchInput.value = '';
 
 const searchBar = document.getElementById('customSearchBar');
 if(searchBar) searchBar.classList.add('hidden');

 const [mode, langLabel] = detectLanguage(filePath);

 const fileContentParent = document.getElementById('fileContent').parentElement;
 let editorSpinner = document.getElementById('editor-spinner');
 if (!editorSpinner) {
 editorSpinner = document.createElement('div');
 editorSpinner.id = 'editor-spinner';
 editorSpinner.className = 'absolute inset-0 bg-[#1d1f21] z-[60] flex flex-col items-center justify-center gap-3';
 editorSpinner.innerHTML = `
 <div class="w-8 h-8 border-4 border-slate-600 border-t-blue-500 rounded-full animate-spin"></div>
 <span class="text-slate-400 font-bold text-sm tracking-wide">Memuat teks...</span>
 `;
 fileContentParent.appendChild(editorSpinner);
 }
 editorSpinner.classList.remove('hidden');

 setEditorLanguage(null, 'Plain Text');
 if (editor) { editor.setValue(""); editorSavedContent = ''; syncEditorSaveButton(); }

 if(typeof showTab === 'function') showTab('edit', false);
 if (addToHistory) history.pushState({ tab: 'edit', file: filePath }, '', ((typeof tabUrlPath === 'function') ? tabUrlPath('files') : window.location.pathname) + '#edit/' + filePath);

 try {
 const res = await fetch(`/api/file?path=${encodeURIComponent(filePath)}`); 
 if (res.status === 401) return window.location.href = "/"; 
 const content = await res.text(); 
 if (editor) { editor.setValue(content); editor.clearHistory(); editorSavedContent = content; syncEditorSaveButton(); }
 setEditorLanguage(mode, langLabel);
 } catch(e) {
 if (editor) { editor.setValue("// Gagal memuat isi file. Coba lagi."); editorSavedContent = editor.getValue(); syncEditorSaveButton(); }
 setEditorLanguage(null, 'Plain Text');
 } finally { 
 finishProgress(); 
 if (editorSpinner) editorSpinner.classList.add('hidden'); 
 }
}

function closeEditor() {
 const savedPath = currentPath;
 window._skipFileReset = true;
 if(typeof showTab === 'function') showTab('files', false);
 currentPath = savedPath;
 const newHash = savedPath === '' ? '' : `#${savedPath}`;
 history.pushState({ tab: 'files', path: savedPath }, '', ((typeof tabUrlPath === 'function') ? tabUrlPath('files') : window.location.pathname) + newHash);
 delete folderCache[savedPath];
 loadFiles(savedPath, false);
}

async function saveFile() { 
 if (!editor || editor.getValue() === editorSavedContent) { syncEditorSaveButton(); return; }
 if (isNewFile || !currentEditFile) {
 const modal = document.getElementById('saveAsModal');
 if (modal) {
 document.getElementById('saveAsInput').value = '';
 modal.classList.remove('hidden');
 setTimeout(() => document.getElementById('saveAsInput').focus(), 100);
 }
 return;
 }
 startProgress(); 
 try { 
 const contentToSave = editor.getValue();
 const res = await fetch('/api/file', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ path: currentEditFile, content: contentToSave }) });
 if (res.ok) { editorSavedContent = contentToSave; syncEditorSaveButton(); if(typeof showToast === 'function') showToast('File Tersimpan!'); }
 else if (typeof showToast === 'function') showToast('Gagal menyimpan file', 'error');
 } catch(e) { if (typeof showToast === 'function') showToast('Error jaringan saat menyimpan', 'error'); } finally { finishProgress(); }
}

async function executeSaveAs() {
 const nameInput = document.getElementById('saveAsInput');
 const name = nameInput ? nameInput.value.trim() : '';
 if (!name) { if (typeof showToast === 'function') showToast('Nama file wajib diisi!', 'error'); return; }
 const targetPath = currentPath === '' ? name : `${currentPath}/${name}`;
 document.getElementById('saveAsModal').classList.add('hidden');
 startProgress();
 try {
 const res = await fetch('/api/file', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ path: targetPath, content: editor.getValue() }) });
 if (res.ok) {
 isNewFile = false;
 currentEditFile = targetPath;
 editorSavedContent = editor.getValue();
 syncEditorSaveButton();
 const editNameEl = document.getElementById('editingFileName');
 if (editNameEl) editNameEl.innerText = name;
 history.replaceState({ tab: 'edit', file: targetPath }, '', ((typeof tabUrlPath === 'function') ? tabUrlPath('files') : window.location.pathname) + '#edit/' + targetPath);
 delete folderCache[currentPath];
 const [detectedMode, detectedLabel] = detectLanguage(name);
 setEditorLanguage(detectedMode, detectedLabel);
 if (typeof showToast === 'function') showToast('File berhasil disimpan!');
 } else {
 if (typeof showToast === 'function') showToast('Gagal menyimpan file', 'error');
 }
 } catch(e) { if (typeof showToast === 'function') showToast('Error jaringan', 'error'); } 
 finally { finishProgress(); }
}

// === UPLOAD: Sistem baru akan ditambahkan di sini ===

async function executeExtract(filePath) { 
 if(typeof closeAllDropdowns === 'function') closeAllDropdowns(); 
 try { 
  const res = await fetch('/api/extract', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ filePath: filePath, destination: currentPath }) }); 
  if (res.status === 202) {
   let jobId = null;
   try { const d = await res.json(); jobId = d.jobId; } catch(e) {}
   showZipProgressModal('extract', filePath ? filePath.split('/').pop() : undefined, jobId);
   // progress dan selesai akan datang via socket extract_progress / extract_done
  } else if (res.ok) {
   delete folderCache[currentPath];
   await loadFiles(currentPath); 
   if(typeof showToast === 'function') showToast('Ekstrak berhasil!');
  } else {
   if(typeof showToast === 'function') showToast('Gagal mengekstrak', 'error');
  }
 } catch(e) {
  if(typeof showToast === 'function') showToast('Gagal mengekstrak', 'error');
 }
}

// ── Progress Toast (Archive & Extract) ──────────────────────────────
function _fmtBytes(bytes) {
 if (!bytes || bytes <= 0) return '0 B';
 const units = ['B','KB','MB','GB'];
 let i = 0, v = bytes;
 while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
 return v.toFixed(i === 0 ? 0 : 1) + ' ' + units[i];
}

// Tiap operasi (archive / extract) punya card sendiri dengan jobId unik → bisa jalan bersamaan
function showZipProgressModal(type, filename, jobId) {
 const oldToast = document.getElementById('zipProgressToast');
 if (oldToast) oldToast.remove();

 const isExtract = type === 'extract';
 const containerId = isExtract ? 'extractOnlyContainer' : 'archiveOnlyContainer';
 const listId      = isExtract ? 'extractOnlyList'      : 'archiveOnlyList';
 const container   = document.getElementById(containerId);
 const list        = document.getElementById(listId);
 if (!container || !list) return;

 const cardId  = 'archiveCard_' + (jobId || type);
 const oldCard = document.getElementById(cardId);
 if (oldCard) oldCard.remove();

 const safeName = (filename || 'Memproses...').replace(/</g, '&lt;').replace(/>/g, '&gt;');
 const card = document.createElement('div');
 card.id = cardId;
 card.className = 'bg-slate-800/60 rounded-xl p-3 transition-opacity duration-300';
 card.innerHTML = `
  <div class="flex items-center gap-1.5 mb-1.5">
   <p class="aop-name text-white text-xs font-bold truncate flex-1 min-w-0">${safeName}</p>
  </div>
  <div class="flex items-center justify-between text-[10px] text-slate-400 mb-1.5">
   <span class="aop-size font-mono">Menghitung...</span>
   <span class="aop-pct ${isExtract ? 'text-emerald-400' : 'text-blue-300'} font-bold font-mono">0%</span>
  </div>
  <div class="w-full bg-slate-700/60 rounded-full h-1.5 overflow-hidden">
   <div class="aop-bar h-full ${isExtract ? 'bg-emerald-500' : 'bg-blue-500'} rounded-full transition-all duration-300" style="width:0%"></div>
  </div>`;
 list.appendChild(card);
 container.classList.remove('hidden');
 if (typeof showUploadPanel === 'function') showUploadPanel();
}

window.updateZipProgress = function(jobId, percent, processed, total) {
 const card = document.getElementById('archiveCard_' + jobId);
 if (!card) return;
 const bar    = card.querySelector('.aop-bar');
 const pctEl  = card.querySelector('.aop-pct');
 const sizeEl = card.querySelector('.aop-size');
 if (bar)    bar.style.width = percent + '%';
 if (pctEl)  pctEl.textContent = percent + '%';
 if (sizeEl && total > 0) sizeEl.textContent = _fmtBytes(processed) + ' / ' + _fmtBytes(total);
};

window.closeZipProgressModal = function(jobId) {
 const card = document.getElementById('archiveCard_' + jobId);
 if (!card) return;
 card.style.opacity = '0';
 setTimeout(() => {
  if (card.parentNode) card.parentNode.removeChild(card);
  // Cek & sembunyikan container kalau list kosong
  const archiveList = document.getElementById('archiveOnlyList');
  const archiveCont = document.getElementById('archiveOnlyContainer');
  if (archiveList && archiveCont && archiveList.children.length === 0) archiveCont.classList.add('hidden');
  const extractList = document.getElementById('extractOnlyList');
  const extractCont = document.getElementById('extractOnlyContainer');
  if (extractList && extractCont && extractList.children.length === 0) extractCont.classList.add('hidden');
  // Tutup panel transfer kalau semua operasi selesai
  const noArchive = !archiveList || archiveList.children.length === 0;
  const noExtract = !extractList || extractList.children.length === 0;
  if (noArchive && noExtract) {
   const noUpload = typeof _uploadActive === 'undefined' || !_uploadActive;
   const noDl     = typeof _activeRemoteDownloadJobs === 'undefined' || _activeRemoteDownloadJobs.size === 0;
   if (noUpload && noDl) setTimeout(() => { if (typeof closeUploadPanel === 'function') closeUploadPanel(); }, 1500);
  }
 }, 300);
};
// ────────────────────────────────────────────────────────────────────

function showArchiveModal() {
 const regularItems = getSelectedFileEntries()
  .filter(entry => entry.isDirectory || !isArchivePath(entry.path))
  .map(entry => entry.path);
 if (regularItems.length === 0) {
  if (typeof showToast === 'function') showToast('File archive tidak bisa di-archive lagi. Gunakan Extract.', 'error');
  return;
 }
 // If a mixed selection contains an existing archive, do not put that archive
 // inside the new archive. Only the selected file/folder items are archived.
 selectedFiles = new Set(regularItems);
 const now = new Date();
 const pad = n => String(n).padStart(2, '0');
 const datePart = `${now.getFullYear()}-${pad(now.getMonth()+1)}-${pad(now.getDate())}`;
 const timePart = `${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;
 const archiveName = `archive-${datePart}T${timePart}Z.zip`;
 executeArchiveWithName(archiveName);
}

function executeSelectedExtract() {
 const archiveItems = getSelectedFileEntries()
  .filter(entry => !entry.isDirectory && isArchivePath(entry.path));
 if (archiveItems.length !== 1) {
  if (typeof showToast === 'function') showToast('Pilih satu file archive untuk Extract.', 'error');
  return;
 }
 executeExtract(archiveItems[0].path);
}

async function executeArchiveWithName(name) {
 try {
  const res = await fetch('/api/archive', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ items: Array.from(selectedFiles), archiveName: name, currentPath: currentPath }) });
  if (res.status === 202) {
   let jobId = null;
   try { const d = await res.json(); jobId = d.jobId; } catch(e) {}
   showZipProgressModal('archive', name, jobId);
   selectedFiles.clear(); if(typeof updateDeleteButton === 'function') updateDeleteButton();
   // progress dan selesai akan datang via socket archive_progress / archive_done
  } else if (res.ok) {
   delete folderCache[currentPath];
   selectedFiles.clear(); if(typeof updateDeleteButton === 'function') updateDeleteButton();
   await loadFiles(currentPath);
   if(typeof showToast === 'function') showToast('Arsip berhasil dibuat: ' + name);
  } else {
   if(typeof showToast === 'function') showToast('Gagal membuat arsip', 'error');
  }
 } catch(e) {
  if(typeof showToast === 'function') showToast('Gagal membuat arsip', 'error');
 }
}

async function executeArchive() { 
 const name = document.getElementById('archiveInput').value.trim(); if(!name) return; 
 document.getElementById('archiveModal').classList.add('hidden'); 
 await executeArchiveWithName(name);
}

window.showMoveModal = function() { 
 moveTargetPath = currentPath; 
 const mModal = document.getElementById('moveModal'); 
 if(mModal) mModal.classList.remove('hidden'); 
 
 const mInput = document.getElementById('moveNewDirInput'); 
 if(mInput) mInput.value = ''; 
 
 loadMoveFolders(moveTargetPath); 
}

window.loadMoveFolders = async function(targetDir) {
 moveTargetPath = targetDir;
 const listEl = document.getElementById('moveFolderList');
 const pathText = document.getElementById('moveCurrentPathText');
 
 if(pathText) { pathText.innerText = targetDir === '' ? '/home/container/' : `/home/container/${targetDir}/`; }
 if(listEl) { listEl.innerHTML = '<div class="flex justify-center py-6"><div class="w-6 h-6 border-4 border-slate-600 border-t-blue-500 rounded-full animate-spin"></div></div>'; }
 
 try {
 const res = await fetch(`/api/files?path=${encodeURIComponent(targetDir)}`);
 if (!res.ok) throw new Error('Failed');
 const files = await res.json();
 
 let htmlBuffer = '';
 
 if (targetDir !== '') {
 const parentPath = targetDir.split('/').slice(0, -1).join('/');
 htmlBuffer += `
 <button onclick="loadMoveFolders('${parentPath}')" class="w-full bg-slate-800/80 hover:bg-slate-700 border border-slate-700/80 p-3 rounded-xl flex items-center justify-center gap-2 text-slate-300 font-bold transition active:scale-95 shadow-sm mb-1">
 <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
 Go back
 </button>
 `;
 }
 
 const dirs = files.filter(f => f.isDirectory);
 if (dirs.length === 0) {
 htmlBuffer += '<p class="text-center text-slate-500 py-6 text-xs font-bold">Tidak ada sub-folder di sini.</p>';
 } else {
 dirs.forEach(dir => {
 htmlBuffer += `
 <div onclick="loadMoveFolders('${dir.path}')" class="w-full bg-slate-800 hover:bg-slate-700 border border-slate-700/80 p-3.5 rounded-xl flex items-center gap-3 text-slate-200 font-bold transition cursor-pointer active:scale-95 shadow-sm group">
 <svg class="w-4 h-4 text-blue-400 shrink-0" fill="currentColor" viewBox="0 0 24 24"><path d="M10 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z"/></svg>
 <span class="truncate">${dir.name}</span>
 </div>
 `;
 });
 }
 
 if(listEl) listEl.innerHTML = htmlBuffer;
 } catch (e) {
 if(listEl) listEl.innerHTML = '<p class="text-center text-red-400 py-4 text-xs font-bold">Gagal memuat direktori.</p>';
 }
}

window.createDirInMove = async function() {
 const input = document.getElementById('moveNewDirInput');
 if (!input) return;
 const name = input.value.trim();
 if (!name) return;
 
 const targetPath = moveTargetPath === '' ? name : `${moveTargetPath}/${name}`;
 input.disabled = true;
 
 try {
 const res = await fetch('/api/folder', { 
 method: 'POST', 
 headers: { 'Content-Type': 'application/json' }, 
 body: JSON.stringify({ path: targetPath }) 
 });
 
 if (res.ok) {
 input.value = '';
 delete folderCache[moveTargetPath]; 
 await loadMoveFolders(moveTargetPath); 
 if(typeof showToast === 'function') showToast('Folder ' + name + ' berhasil dibuat!');
 } else {
 if(typeof showToast === 'function') showToast('Nama sudah ada / gagal dibuat', 'error');
 }
 } catch(e) {
 if(typeof showToast === 'function') showToast('Error jaringan', 'error');
 } finally {
 input.disabled = false;
 input.focus();
 }
}

window.executeInteractiveMove = async function() { 
 document.getElementById('moveModal').classList.add('hidden'); 
 startProgress(); 
 try { 
 const res = await fetch('/api/move', { 
 method: 'POST', 
 headers: { 'Content-Type': 'application/json' }, 
 body: JSON.stringify({ items: Array.from(selectedFiles), destination: moveTargetPath }) 
 }); 
 
 if(res.ok) {
 delete folderCache[currentPath]; 
 delete folderCache[moveTargetPath]; 
 selectedFiles.clear(); 
 updateDeleteButton(); 
 await loadFiles(currentPath); 
 if(typeof showToast === 'function') showToast('File berhasil dipindah!');
 } else {
 if(typeof showToast === 'function') showToast('Gagal memindah file', 'error');
 }
 } catch(e) {
 if(typeof showToast === 'function') showToast('Error jaringan', 'error');
 } finally { 
 finishProgress(); 
 }
}

window.addEventListener('popstate', function(event) {
 const hash = window.location.hash;
 const pathTab = (typeof getTabFromPath === 'function') ? getTabFromPath() : null;
 if (hash.startsWith('#edit/')) {
  if(typeof showTab === 'function') showTab('edit', false);
  let file = hash.replace('#edit/', '');
  openFile(file, '', false);
 } else if (pathTab === 'files' || hash === '#files' || hash.startsWith('#files/')) {
  window._skipFileReset = true;
  if(typeof showTab === 'function') showTab('files', false);
  let dir = hash.replace(/^#files/, '');
  if (dir.startsWith('/')) dir = dir.substring(1);
  else if (dir.startsWith('#')) dir = dir.substring(1);
  loadFiles(dir, false);
 }
});

/* =========================================
 MODULE: CHUNKED UPLOAD MANAGER
 ========================================= */

const MAX_CONCURRENT_UPLOADS = 1; // maksimal 1 upload aktif, sisanya masuk antrean
let _activeUploadCount = 0;   // berapa upload sedang berjalan
let _activeUploadJobs = new Map(); // safeId → { cancelFn, fileName }

let _uploadQueue = [];        // antrian file yang mau diupload
let _uploadActive = false;    // lagi ada upload ga
let _uploadCancelled = false; // di-cancel (global — cancel semua)



// -- Tombol upload di toolbar --
function triggerUpload() {
 const input = document.getElementById('uploadFileInput');
 if (input) { input.value = ''; input.click(); }
}

function onUploadFilesSelected(event) {
 const files = Array.from(event.target.files);
 if (!files.length) return;
 queueUploadFiles(files);
}

function queueUploadFiles(files) {
 const destPath = (typeof currentPath !== 'undefined') ? currentPath : '';
 _uploadQueue.push(...files.map(f => ({ file: f, destPath })));
 showUploadPanel();
 _updateQueueListUI();
 _fillUploadSlots();
}

let _lastUploadSucceeded = true; // status hasil upload terakhir, dipakai buat nentuin auto-close panel

function _scheduleAutoClosePanel() {
 // Jangan tutup panel kalau URL download masih aktif
 setTimeout(() => { if (!_uploadActive && _activeRemoteDownloadJobs.size === 0) closeUploadPanel(); }, 2200);
}

// -- Isi slot upload sampai batas MAX_CONCURRENT_UPLOADS --
function _fillUploadSlots() {
 while (_uploadQueue.length > 0 && _activeUploadCount < MAX_CONCURRENT_UPLOADS) {
  const item = _uploadQueue.shift();
  _runSingleUpload(item);
 }
 _updateQueueListUI();
}

// -- Jalankan 1 file upload; setelah selesai, ambil slot berikutnya dari antrian --
async function _runSingleUpload(item) {
 _activeUploadCount++;
 _uploadActive = true;
 // Gunakan direct upload (tanpa chunk)
 await _startDirectUpload(item);
 const dp = (typeof currentPath !== 'undefined') ? currentPath : '';
 if (!_uploadCancelled && item.destPath === dp) {
  if (typeof folderCache !== 'undefined') delete folderCache[dp];
  if (typeof loadFiles === 'function') await loadFiles(dp);
 }
 _activeUploadCount--;
 if (_uploadCancelled) {
  if (_activeUploadCount === 0) {
   _uploadQueue = [];
   _uploadCancelled = false;
   _uploadActive = false;
   _setUploadDone();
   _updateQueueListUI();
  }
  return;
 }
 // Slot bebas — ambil file berikutnya dari antrian (jika ada)
 _fillUploadSlots();
 // Kalau benar-benar semua selesai (tidak ada yang aktif + antrian kosong)
 if (_activeUploadCount === 0 && _uploadQueue.length === 0) {
  _uploadActive = false;
  _setUploadDone();
  if (_lastUploadSucceeded) _scheduleAutoClosePanel();
 }
}

// -- Core: upload langsung tanpa chunk (progress via XHR) --
async function _startDirectUpload({ file, destPath }) {
 // Buat ID unik untuk kartu UI (bukan dari server, langsung di client)
 const cardId = 'dir_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
 const _safeCardId = cardId.replace(/[^a-zA-Z0-9_-]/g, '');

 _createUploadCard(_safeCardId, file.name, file.size);
 _updateUploadCard(_safeCardId, { size: file.size, progress: 0, speed: 0, done: 0, total: 1, status: 'uploading' });

 let _localCancelled = false;
 let _xhr = null;

 _activeUploadJobs.set(_safeCardId, {
  cancelFn: () => { _localCancelled = true; if (_xhr) _xhr.abort(); },
  fileName: file.name
 });

 // Sliding window untuk kecepatan realtime
 const SPEED_WINDOW_MS = 6000; // window 6 detik — lebih stabil dari burst awal
 let _speedSamples = []; // array of { t: ms, loaded: bytes }
 let _speed = 0;
 let _uploadStartTime = null; // waktu progress event pertama, untuk cumulative avg cap

 // State untuk smooth display via rAF
 let _anchorLoaded = 0;    // byte terakhir yang dikonfirmasi XHR
 let _anchorTime = performance.now();
 let _smoothLoaded = 0;    // byte yang sedang ditampilkan (selalu mulai dari 0, naik sesuai speed)
 let _lastRafTime = performance.now(); // untuk hitung dt antar frame
 let _rafId = null;
 let _uploadDone = false;

 return new Promise((resolve) => {
  const fd = new FormData();
  // Kirim destPath lebih dulu agar Multer sudah mengetahuinya saat menentukan folder tujuan.
  fd.append('destPath', destPath || '');
  fd.append('file', file, file.name);

  _xhr = new XMLHttpRequest();

  // rAF loop: naikkan _smoothLoaded sesuai kecepatan upload (speed × dt)
  // Mulai dari 0, counting up pelan-pelan — tidak pernah loncat ke anchor langsung
  function _rafLoop() {
   if (_uploadDone || _localCancelled) return;
   const now = performance.now();
   const dtSec = Math.min((now - _lastRafTime) / 1000, 0.1); // max 100ms per frame
   _lastRafTime = now;
   if (_speed > 0) {
    // Naik sesuai kecepatan real, tidak boleh melampaui anchor (data XHR konfirmasi)
    _smoothLoaded = Math.min(_anchorLoaded, _smoothLoaded + _speed * dtSec);
   }
   // Kalau speed belum ada (belum ada progress event), tampilkan 0 saja
   const pct = file.size > 0 ? Math.min(99.9, (_smoothLoaded / file.size) * 100) : 0;
   _updateUploadCard(_safeCardId, { size: file.size, progress: pct, speed: _speed, done: _smoothLoaded, total: file.size, status: 'uploading' });
   _rafId = requestAnimationFrame(_rafLoop);
  }
  _rafId = requestAnimationFrame(_rafLoop);

  // Progress real-time dari XHR — update anchor + hitung speed sliding window
  _xhr.upload.addEventListener('progress', (e) => {
   if (!e.lengthComputable) return;
   const now = performance.now();
   if (!_uploadStartTime) _uploadStartTime = now;

   // Update anchor dengan data real dari XHR
   _anchorLoaded = e.loaded;
   _anchorTime = now;

   // Tambah sample ke sliding window
   _speedSamples.push({ t: now, loaded: e.loaded });
   const cutoff = now - SPEED_WINDOW_MS;
   while (_speedSamples.length > 1 && _speedSamples[0].t < cutoff) _speedSamples.shift();

   // Hitung speed dari sliding window, lalu cap dengan cumulative average
   // agar tidak keliatan lebih cepat dari kecepatan internet sebenarnya
   if (_speedSamples.length >= 2) {
    const oldest = _speedSamples[0];
    const newest = _speedSamples[_speedSamples.length - 1];
    const dtSec = (newest.t - oldest.t) / 1000;
    if (dtSec > 0) {
     const windowSpeed = (newest.loaded - oldest.loaded) / dtSec;
     const elapsedSec = (now - _uploadStartTime) / 1000;
     // Cumulative average = bytes terkirim / total waktu sejak mulai (lebih jujur)
     const cumulativeAvg = elapsedSec > 1 ? e.loaded / elapsedSec : windowSpeed;
     _speed = Math.min(windowSpeed, cumulativeAvg);
    }
   }
  });

  function _stopRaf() { _uploadDone = true; if (_rafId) { cancelAnimationFrame(_rafId); _rafId = null; } }

  // Upload selesai (sukses atau error HTTP)
  _xhr.addEventListener('load', () => {
   _stopRaf();
   if (_localCancelled) { _removeUploadCard(_safeCardId); _activeUploadJobs.delete(_safeCardId); return resolve(); }
   if (_xhr.status >= 200 && _xhr.status < 300) {
    _lastUploadSucceeded = true;
    if (typeof showToast === 'function') showToast('Upload selesai: ' + file.name);
    _updateUploadCard(_safeCardId, { size: file.size, progress: 100, speed: 0, done: 1, total: 1, status: 'done' });
    setTimeout(() => _removeUploadCard(_safeCardId), 1500);
   } else {
    _lastUploadSucceeded = false;
    let errMsg = 'Error ' + _xhr.status;
    try { errMsg = JSON.parse(_xhr.responseText).error || errMsg; } catch(e) {}
    if (typeof showToast === 'function') showToast('Gagal upload: ' + errMsg, 'error');
    _updateUploadCard(_safeCardId, { size: file.size, progress: 0, speed: 0, done: 0, total: 1, status: 'error' });
   }
   _activeUploadJobs.delete(_safeCardId);
   resolve();
  });

  // Error jaringan
  _xhr.addEventListener('error', () => {
   _stopRaf();
   if (_localCancelled) { _removeUploadCard(_safeCardId); }
   else {
    _lastUploadSucceeded = false;
    if (typeof showToast === 'function') showToast('Koneksi error: ' + file.name, 'error');
    _updateUploadCard(_safeCardId, { size: file.size, progress: 0, speed: 0, done: 0, total: 1, status: 'error' });
   }
   _activeUploadJobs.delete(_safeCardId);
   resolve();
  });

  // Di-abort (tombol X atau cancel global)
  _xhr.addEventListener('abort', () => {
   _stopRaf();
   _removeUploadCard(_safeCardId);
   _activeUploadJobs.delete(_safeCardId);
   resolve();
  });

  _xhr.open('POST', '/api/upload/direct');
  _xhr.send(fd);
 });
}


// -- UI Upload Panel (Sidebar) --
// Tampilkan/sembunyikan floating toggle tab di tepi kanan
function _showToggleTab() {
 const tab = document.getElementById('uploadToggleTab');
 if (tab) tab.classList.remove('hidden');
}
function _hideToggleTab() {
 const tab = document.getElementById('uploadToggleTab');
 if (tab) tab.classList.add('hidden');
}
// Perbarui badge di toggle tab
function _updateToggleTabBadge() {
 const badge = document.getElementById('uploadToggleBadge');
 if (!badge) return;
 const q = _remoteDownloadQueue.length + (typeof _uploadQueue !== 'undefined' ? _uploadQueue.length : 0);
 if (q > 0) { badge.textContent = '+' + q; badge.classList.remove('hidden'); }
 else badge.classList.add('hidden');
}

function showUploadPanel() {
 const panel = document.getElementById('uploadProgressPanel');
 const backdrop = document.getElementById('uploadPanelBackdrop');
 if (!panel) return;
 // Sembunyikan toggle tab saat sidebar terbuka
 _hideToggleTab();
 // Tampilkan elemen lalu animate slide-in dari kanan
 panel.classList.remove('hidden');
 if (backdrop) { backdrop.classList.remove('hidden'); backdrop.style.opacity = '0'; requestAnimationFrame(() => { backdrop.style.transition = 'opacity 0.3s'; backdrop.style.opacity = '1'; }); }
 // rAF ganda supaya transition berjalan setelah display berubah
 requestAnimationFrame(() => requestAnimationFrame(() => { panel.style.transform = 'translateX(0)'; }));
 // BUG FIX: Kalau ada download URL yang masih aktif, pastikan section-nya terlihat lagi
 // (bisa tersembunyi oleh _hideUrlDlSection() saat panel pernah ditutup sebelumnya)
 if (typeof _activeRemoteDownloadJobs !== 'undefined' && _activeRemoteDownloadJobs.size > 0) {
  const dlContainer = document.getElementById('urlDlActiveContainer');
  if (dlContainer) dlContainer.classList.remove('hidden');
 }
 const doneBtn = document.getElementById('uploadDoneBtn');
 const cancelBtn = document.getElementById('uploadClosePanelBtnNoop');
 const resumeBtn = document.getElementById('uploadResumeBtn');
 const spinner = document.getElementById('uploadPanelSpinner');
 const fileSection = document.getElementById('uploadFileSection');
 if (doneBtn) doneBtn.classList.add('hidden');
 if (cancelBtn) cancelBtn.classList.remove('hidden');
 if (resumeBtn) resumeBtn.classList.add('hidden');
 if (spinner) spinner.classList.remove('hidden');
 // uploadFileSection hanya untuk restore mode — jangan auto-show di sini
}

function closeUploadPanel() {
 const panel = document.getElementById('uploadProgressPanel');
 const backdrop = document.getElementById('uploadPanelBackdrop');
 if (!panel) return;
 // Slide keluar ke kanan, tampilkan toggle tab kalau masih ada transfer
 panel.style.transform = 'translateX(100%)';
 if (backdrop) { backdrop.style.opacity = '0'; }
 setTimeout(() => {
  panel.classList.add('hidden');
  if (backdrop) { backdrop.classList.add('hidden'); backdrop.style.opacity = ''; backdrop.style.transition = ''; }
  _hideUrlDlSection();
  // Selalu tampilkan toggle tab setelah panel ditutup
  _updateToggleTabBadge();
  _showToggleTab();
 }, 310);
}

function _setUploadDone() {
 const spinner = document.getElementById('uploadPanelSpinner');
 const cancelBtn = document.getElementById('uploadClosePanelBtnNoop');
 const doneBtn = document.getElementById('uploadDoneBtn');
 if (spinner) spinner.classList.add('hidden');
 // Kalau URL download masih aktif, tetap tampilkan tombol cancel & sembunyikan "Selesai"
 // supaya user bisa batalkan download yang masih berjalan
 if (_activeRemoteDownloadJobs.size > 0) {
  if (cancelBtn) cancelBtn.classList.remove('hidden');
  if (doneBtn) doneBtn.classList.add('hidden');
 } else {
  if (cancelBtn) cancelBtn.classList.add('hidden');
  if (doneBtn) doneBtn.classList.remove('hidden');
 }
}

// --- URL download section: compat stub (diganti sistem multi-concurrent) ---
function _updateUrlDlUI() { /* digantikan _updateUrlDlCard per jobId */ }

function _hideUrlDlSection() {
 // Sembunyikan semua kartu download aktif (dipanggil saat panel ditutup)
 const container = document.getElementById('urlDlActiveContainer');
 if (container) container.classList.add('hidden');
}

// ===== UPLOAD CARD UI (multi-concurrent) =====

function _createUploadCard(uploadId, name, size) {
 const container = document.getElementById('uploadFileContainer');
 const list = document.getElementById('uploadActiveList');
 if (!container || !list) return;
 container.classList.remove('hidden');
 const safeName = String(name || '-').replace(/</g,'&lt;').replace(/>/g,'&gt;');
 const safeId = String(uploadId).replace(/[^a-zA-Z0-9_-]/g, '');
 const card = document.createElement('div');
 card.id = 'upCard_' + safeId;
 card.className = 'bg-slate-800/60 rounded-xl p-3 transition-opacity duration-300';
 card.innerHTML = `
  <div class="flex items-center gap-2 mb-2">
    <p class="up-name text-white text-xs font-bold truncate flex-1 min-w-0">${safeName}</p>
    <button onclick="cancelSingleUpload('${safeId}')" class="flex-shrink-0 w-5 h-5 flex items-center justify-center text-slate-500 hover:text-red-400 hover:bg-red-500/10 rounded transition active:scale-90" title="Batalkan upload ini">
      <svg xmlns='http://www.w3.org/2000/svg' class='w-3.5 h-3.5' fill='none' viewBox='0 0 24 24' stroke='currentColor' stroke-width='2.5'><path stroke-linecap='round' stroke-linejoin='round' d='M6 18L18 6M6 6l12 12'/></svg>
    </button>
  </div>
  <div class="w-full bg-slate-700/60 rounded-full h-1.5 overflow-hidden mb-2">
    <div class="up-bar h-full bg-blue-500 rounded-full transition-none" style="width:0%"></div>
  </div>
  <div class="flex items-center justify-between text-[10px] mb-0.5">
    <span class="up-size font-mono text-slate-300 truncate">...</span>
  </div>
  <div class="flex items-center justify-between text-[10px]">
    <span class="up-speed text-blue-300 font-medium">-</span>
    <span class="up-eta text-slate-400">-</span>
  </div>`;
 list.appendChild(card);
 _updateUploadCountLabel();
}

function _updateUploadCard(uploadId, { size, progress, speed, done, total, status, concurrency }) {
 const safeId = String(uploadId).replace(/[^a-zA-Z0-9_-]/g, '');
 const card = document.getElementById('upCard_' + safeId);
 if (!card) return;
 const sizeEl = card.querySelector('.up-size');
 const speedEl = card.querySelector('.up-speed');
 const etaEl = card.querySelector('.up-eta');
 const barEl = card.querySelector('.up-bar');
 const pct = Math.min(100, progress || 0);
 if (barEl) {
  barEl.style.width = pct.toFixed(1) + '%';
  barEl.classList.remove('bg-blue-500','bg-yellow-500','bg-green-500');
  if (status === 'done') barEl.classList.add('bg-green-500');
  else barEl.classList.add('bg-blue-500');
 }
 if (sizeEl) {
  const doneBytes = (size || 0) * (pct / 100);
  // Selalu pakai unit yang sama buat done dan total — tidak lompat-lompat ikut kecepatan
  sizeEl.textContent = _fmtBinary(doneBytes) + ' / ' + _fmtBinary(size || 0);
 }
 if (speedEl) {
  if (status === 'uploading' && speed > 0) speedEl.textContent = _fmtBytes(speed) + '/s';
  else if (status === 'finishing') speedEl.textContent = 'Menyimpan...';
  else if (status === 'done') speedEl.textContent = '✓';
  else speedEl.textContent = '-';
 }
 if (etaEl) {
  if (status === 'uploading' && speed > 0 && size > 0) { const rem = (size) * (1 - pct / 100); etaEl.textContent = 'ETA ' + _fmtEta(rem / speed); }
  else if (status === 'finishing') etaEl.textContent = '...';
  else if (status === 'done') etaEl.textContent = 'Selesai';
  else etaEl.textContent = '-';
 }
 _updateRemoteDlQueueBadge();
}

function _removeUploadCard(uploadId) {
 const safeId = String(uploadId).replace(/[^a-zA-Z0-9_-]/g, '');
 const card = document.getElementById('upCard_' + safeId);
 if (card) {
  card.style.opacity = '0';
  setTimeout(() => { if (card.parentNode) card.parentNode.removeChild(card); _updateUploadCountLabel(); _checkHideUploadContainer(); }, 300);
 } else { _updateUploadCountLabel(); _checkHideUploadContainer(); }
}

function _updateUploadCountLabel() {
 const label = document.getElementById('uploadActiveCount');
 const n = _activeUploadJobs.size;
 if (label) label.textContent = n > 0 ? '— ' + n + ' aktif' : '— selesai';
}

function _checkHideUploadContainer() {
 const list = document.getElementById('uploadActiveList');
 const container = document.getElementById('uploadFileContainer');
 if (container && list && list.children.length === 0) container.classList.add('hidden');
}

// Batalkan SATU upload berdasarkan uploadId
function cancelSingleUpload(uploadId) {
 const job = _activeUploadJobs.get(uploadId);
 if (job && job.cancelFn) job.cancelFn();
 // Kartu + Map entry dihapus otomatis saat _startChunkedUpload mendeteksi _localCancelled
}

function _fmtBytes(b) { if (!b || b < 0) return '0 B'; const k = 1024, u = ['B','KB','MB','GB']; const i = Math.floor(Math.log(b) / Math.log(k)); return (b / Math.pow(k,i)).toFixed(i?1:0) + ' ' + u[i]; }
function _fmtBinary(b) { if (!b || b < 0) return '0.00MiB'; const k = 1024, u = ['B','KiB','MiB','GiB']; let i = Math.floor(Math.log(b) / Math.log(k)); if (i < 0) i = 0; if (i > u.length - 1) i = u.length - 1; return (b / Math.pow(k,i)).toFixed(i === 0 ? 0 : 2) + u[i]; }
function _fmtEta(sec) {
 if (!isFinite(sec) || sec < 0) return '-';
 sec = Math.round(sec);
 if (sec < 1) return 'Hampir selesai';
 const m = Math.floor(sec / 60), s = sec % 60;
 return m > 0 ? `${m}m ${s}s lagi` : `${s}s lagi`;
}

function _updateUploadUI({ name, size, progress, speed, done, total, status, concurrency, sourceLabel, queueCount }) {
 const nameEl = document.getElementById('uploadFileName');
 const barEl = document.getElementById('uploadProgressBar');
 const pctEl = document.getElementById('uploadProgressText');
 const speedEl = document.getElementById('uploadSpeedText');
 const chunkEl = document.getElementById('uploadChunkText');
 const queueEl = document.getElementById('uploadQueueBadge');
 const spinner = document.getElementById('uploadPanelSpinner');
 const sizeEl = document.getElementById('uploadSizeText');
 const etaEl = document.getElementById('uploadEtaText');

 if (nameEl) nameEl.textContent = name || '-';
 if (barEl) barEl.style.width = Math.min(100, progress || 0).toFixed(1) + '%';
 if (pctEl) {
  const pct = Math.min(100, progress || 0).toFixed(0);
  if (status === 'finishing') pctEl.textContent = 'Menyimpan...';
  else if (status === 'done') pctEl.textContent = '100% ✓';
  else if (status === 'cancelled') pctEl.textContent = 'Dibatalkan';
  else pctEl.textContent = pct + '%';
 }
 if (speedEl) {
  if (status === 'uploading' && speed > 0) speedEl.textContent = _fmtBytes(speed) + '/s';
  else if (status === 'finishing') speedEl.textContent = '';
  else speedEl.textContent = '-';
 }
 if (sizeEl) {
  const doneBytes = Math.min(size || 0, (size || 0) * ((progress || 0) / 100));
  sizeEl.textContent = `${_fmtBinary(doneBytes)} / ${_fmtBinary(size || 0)}`;
 }
 if (etaEl) {
  if (status === 'uploading' && speed > 0) {
   const doneBytes = (size || 0) * ((progress || 0) / 100);
   const remaining = (size || 0) - doneBytes;
   etaEl.textContent = 'ETA ' + _fmtEta(remaining / speed);
  } else if (status === 'finishing') etaEl.textContent = 'Menyimpan...';
  else if (status === 'done') etaEl.textContent = 'Selesai';
  else etaEl.textContent = '-';
 }
 if (chunkEl) chunkEl.textContent = sourceLabel ? sourceLabel : (concurrency ? `${done}/${total} chunk • ${concurrency}x paralel` : `${done}/${total} chunk`);
 if (queueEl) {
  // Badge total: antrian upload biasa + antrian URL download
  const remoteQ = (typeof _remoteDownloadQueue !== 'undefined' ? _remoteDownloadQueue.length : 0);
  const uploadQ = (typeof queueCount === 'number') ? queueCount : _uploadQueue.length;
  const q = uploadQ + remoteQ;
  if (q > 0) { queueEl.textContent = '+' + q + ' antrian'; queueEl.classList.remove('hidden'); }
  else queueEl.classList.add('hidden');
 }
 if (spinner) {
  if (status === 'done' || status === 'cancelled') spinner.classList.add('hidden');
  else spinner.classList.remove('hidden');
 }
 // Warna progress bar
 if (barEl) {
  if (status === 'done') { barEl.classList.remove('bg-blue-500','bg-yellow-500'); barEl.classList.add('bg-green-500'); }
  else { barEl.classList.remove('bg-yellow-500','bg-green-500'); barEl.classList.add('bg-blue-500'); }
 }
 if (status === 'done') _setUploadDone();
 // Perbarui list file menunggu (upload biasa)
 _updateQueueListUI();
}


function cancelUpload() {
 _uploadCancelled = true;
 // Cancel semua upload aktif (per-job)
 for (const [, job] of _activeUploadJobs) { if (job.cancelFn) job.cancelFn(); }
}

// ===== IMPORT FILE DARI URL — max 4 download sekaligus =====
const MAX_CONCURRENT_REMOTE_DL = 4;
let _activeRemoteDownloadJobs = new Map(); // jobId → { pollTimer, lastBytes, lastTime, pollErrors }
let _remoteDownloadQueue = []; // antrian: { url, destPath, fileName }
let _queueListExpanded = false;
let _startingCount = 0; // berapa download sedang dalam proses awal (guard race condition)

// Helper: total slot yang sedang dipakai
function _activeSlots() { return _activeRemoteDownloadJobs.size + _startingCount; }

// --- Helpers: simpan/restore antrian ke localStorage ---
function _saveRemoteDlQueue() {
 try {
  if (_remoteDownloadQueue.length > 0) {
   localStorage.setItem(_LS('remote_dl_queue'), JSON.stringify(_remoteDownloadQueue));
  } else {
   localStorage.removeItem(_LS('remote_dl_queue'));
  }
 } catch(e) {}
}

function _loadRemoteDlQueue() {
 try {
  const raw = localStorage.getItem(_LS('remote_dl_queue'));
  if (!raw) return [];
  return JSON.parse(raw) || [];
 } catch(e) { return []; }
}

// --- UI: toggle expand/collapse list antrian (no-op — sidebar selalu tampil) ---
function _toggleQueueList() { /* sidebar: queue selalu visible */ }

// --- UI: render isi antrian di sidebar ---
function _updateQueueListUI() {
 const section = document.getElementById('remoteDlQueueSection');
 const label = document.getElementById('queueToggleLabel');
 const list = document.getElementById('queueFileList');
 if (!section) return;

 // Gabungkan antrian: upload biasa di atas, URL download di bawah
 const remoteItems = _remoteDownloadQueue.map((item, i) => {
  const name = item.fileName || (() => {
   try { return decodeURIComponent(item.url.split('/').pop().split('?')[0]) || ('file-' + (i + 1)); }
   catch(e) { return 'file-' + (i + 1); }
  })();
  return { name, type: 'url', origIdx: i };
 });
 const uploadItems = (typeof _uploadQueue !== 'undefined' ? _uploadQueue : []).map((item, i) => ({
  name: item.file ? item.file.name : 'file',
  type: 'upload',
  origIdx: i
 }));
 const allItems = [...uploadItems, ...remoteItems];
 const q = allItems.length;

 if (q === 0) {
  section.classList.add('hidden');
  return;
 }

 section.classList.remove('hidden');
 if (label) label.textContent = q + ' file menunggu';

 if (list) {
  list.innerHTML = allItems.map((item, idx) => {
   const isUrl = item.type === 'url';
   const icon = isUrl
    ? `<svg class="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M13.19 8.688a4.5 4.5 0 011.242 7.244l-4.5 4.5a4.5 4.5 0 01-6.364-6.364l1.757-1.757m13.35-.622l1.757-1.757a4.5 4.5 0 00-6.364-6.364l-4.5 4.5a4.5 4.5 0 001.242 7.244"/></svg>`
    : `<svg class="w-3.5 h-3.5 text-blue-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5m-13.5-9L12 3m0 0l4.5 4.5M12 3v13.5"/></svg>`;
   const badge = isUrl
    ? `<span class="text-[9px] bg-emerald-900/60 text-emerald-400 px-1.5 py-0.5 rounded font-bold">URL</span>`
    : `<span class="text-[9px] bg-blue-900/60 text-blue-400 px-1.5 py-0.5 rounded font-bold">FILE</span>`;
   const cancelBtn = `<button onclick="cancelQueueItem('${item.type}',${item.origIdx})" class="flex-shrink-0 ml-1 text-slate-500 hover:text-red-400 transition active:scale-90" title="Batalkan"><svg xmlns='http://www.w3.org/2000/svg' class='w-3.5 h-3.5' fill='none' viewBox='0 0 24 24' stroke='currentColor' stroke-width='2.5'><line x1='18' y1='6' x2='6' y2='18'/><line x1='6' y1='6' x2='18' y2='18'/></svg></button>`;
   return `<div class="flex items-center gap-2.5 bg-slate-800/70 rounded-xl px-3 py-2">
    <span class="text-[10px] text-slate-600 font-mono w-4 text-right flex-shrink-0">${idx + 1}</span>
    ${icon}
    <span class="truncate text-[12px] text-slate-200 font-medium flex-1 min-w-0">${item.name}</span>
    ${badge}
    ${cancelBtn}
   </div>`;
  }).join('');
 }
}

function cancelQueueItem(type, origIdx) {
 if (type === 'url') {
  if (origIdx >= 0 && origIdx < _remoteDownloadQueue.length) {
   const removed = _remoteDownloadQueue.splice(origIdx, 1);
   _saveRemoteDlQueue();
   if (typeof showToast === 'function' && removed.length) showToast('Dibatalkan: ' + (removed[0].fileName || 'file'), 'warning');
  }
 } else if (type === 'upload') {
  if (typeof _uploadQueue !== 'undefined' && origIdx >= 0 && origIdx < _uploadQueue.length) {
   const removed = _uploadQueue.splice(origIdx, 1);
   if (typeof showToast === 'function' && removed.length) showToast('Dibatalkan: ' + (removed[0].file ? removed[0].file.name : 'file'), 'warning');
  }
 }
 _updateRemoteDlQueueBadge();
 _updateQueueListUI();
}

function openRemoteDownloadModal() {
 const modal = document.getElementById('remoteDownloadModal');
 if (!modal) return;
 const urlInput = document.getElementById('remoteDownloadUrl');
 const nameInput = document.getElementById('remoteDownloadFileName');
 if (urlInput) urlInput.value = '';
 if (nameInput) nameInput.value = '';
 modal.classList.remove('hidden');
 if (urlInput) urlInput.focus();
}

function closeRemoteDownloadModal() {
 const modal = document.getElementById('remoteDownloadModal');
 if (modal) modal.classList.add('hidden');
}

async function startRemoteDownload() {
 const urlInput = document.getElementById('remoteDownloadUrl');
 const nameInput = document.getElementById('remoteDownloadFileName');
 const url = urlInput ? urlInput.value.trim() : '';
 const fileName = nameInput ? nameInput.value.trim() : '';
 if (!url) { if (typeof showToast === 'function') showToast('Tempel link file dulu bro!', 'error'); return; }
 closeRemoteDownloadModal();

 // Kalau slot penuh (4 aktif), masukkan ke antrian
 if (_activeSlots() >= MAX_CONCURRENT_REMOTE_DL) {
  _remoteDownloadQueue.push({ url, destPath: currentPath, fileName });
  _saveRemoteDlQueue();
  // BUG FIX: Pastikan panel terbuka & kartu download aktif terlihat saat tambah ke antrian
  showUploadPanel();
  if (typeof showToast === 'function') showToast('Ditambahkan ke antrian (' + _remoteDownloadQueue.length + ' menunggu)', 'warning');
  _updateRemoteDlQueueBadge();
  return;
 }

 await _executeRemoteDownload({ url, destPath: currentPath, fileName });
}

function _updateRemoteDlQueueBadge() {
 const queueEl = document.getElementById('uploadQueueBadge');
 const q = _remoteDownloadQueue.length + (typeof _uploadQueue !== 'undefined' ? _uploadQueue.length : 0);
 if (queueEl) {
  if (q > 0) { queueEl.textContent = '+' + q + ' antrian'; queueEl.classList.remove('hidden'); }
  else queueEl.classList.add('hidden');
 }
 _updateToggleTabBadge();
 _updateQueueListUI();
}

// --- Buat kartu UI untuk satu download aktif ---
function _createUrlDlCard(jobId, name) {
 const container = document.getElementById('urlDlActiveContainer');
 const list = document.getElementById('urlDlActiveList');
 if (!container || !list) return;
 container.classList.remove('hidden');
 const safeName = String(name || 'Mengunduh...').replace(/</g, '&lt;').replace(/>/g, '&gt;');
 const safeJobId = String(jobId).replace(/[^a-zA-Z0-9_-]/g, '');
 const card = document.createElement('div');
 card.id = 'urlDlCard_' + safeJobId;
 card.className = 'bg-slate-800/60 rounded-xl p-3 transition-opacity duration-300';
 card.innerHTML = `<div class="flex items-center gap-2 mb-1.5"><p class="url-dl-name text-white text-xs font-bold truncate flex-1 min-w-0">${safeName}</p><button onclick="cancelSingleRemoteDownload('${safeJobId}')" class="flex-shrink-0 w-5 h-5 flex items-center justify-center text-slate-500 hover:text-red-400 hover:bg-red-500/10 rounded transition active:scale-90" title="Batalkan"><svg xmlns='http://www.w3.org/2000/svg' class='w-3.5 h-3.5' fill='none' viewBox='0 0 24 24' stroke='currentColor' stroke-width='2.5'><path stroke-linecap='round' stroke-linejoin='round' d='M6 18L18 6M6 6l12 12'/></svg></button></div><div class="flex items-center justify-between text-[10px] text-slate-400 mb-1.5"><span class="url-dl-size font-mono">...</span><span class="url-dl-speed text-emerald-300">-</span><span class="url-dl-src text-slate-500">-</span></div><div class="w-full bg-slate-700/60 rounded-full h-1.5 overflow-hidden"><div class="url-dl-bar h-full bg-emerald-500 rounded-full transition-all duration-300" style="width:0%"></div></div>`;
 list.appendChild(card);
 _updateActiveCountLabel();
}

function _updateUrlDlCard(jobId, { name, size, progress, speed, status }) {
 const safeJobId = String(jobId).replace(/[^a-zA-Z0-9_-]/g, '');
 const card = document.getElementById('urlDlCard_' + safeJobId);
 if (!card) return;
 const nameEl = card.querySelector('.url-dl-name');
 const sizeEl = card.querySelector('.url-dl-size');
 const speedEl = card.querySelector('.url-dl-speed');
 const srcEl = card.querySelector('.url-dl-src');
 const barEl = card.querySelector('.url-dl-bar');
 if (nameEl && name) nameEl.textContent = name;
 if (barEl) {
  barEl.style.width = Math.min(100, progress || 0).toFixed(1) + '%';
  if (status === 'done') { barEl.classList.remove('bg-emerald-500'); barEl.classList.add('bg-green-400'); }
  else { barEl.classList.remove('bg-green-400'); barEl.classList.add('bg-emerald-500'); }
 }
 if (sizeEl) {
  if (size > 0) { const done = Math.min(size, size * ((progress || 0) / 100)); sizeEl.textContent = _fmtBinary(done) + ' / ' + _fmtBinary(size); }
  else sizeEl.textContent = status === 'done' ? '✓ Selesai' : '...';
 }
 if (speedEl) {
  if (status === 'uploading' && speed > 0) speedEl.textContent = _fmtBytes(speed) + '/s';
  else if (status === 'done') speedEl.textContent = '✓';
  else speedEl.textContent = '-';
 }
 if (srcEl) {
  if (status === 'done') srcEl.textContent = 'Selesai';
  else if (speed > 0 && size > 0 && status === 'uploading') { const rem = size - size * ((progress || 0) / 100); srcEl.textContent = 'ETA ' + _fmtEta(rem / speed); }
  else srcEl.textContent = '-';
 }
}

function _removeUrlDlCard(jobId) {
 const safeJobId = String(jobId).replace(/[^a-zA-Z0-9_-]/g, '');
 const card = document.getElementById('urlDlCard_' + safeJobId);
 if (card) { card.style.opacity = '0'; setTimeout(() => { if (card.parentNode) card.parentNode.removeChild(card); _updateActiveCountLabel(); _checkHideActiveContainer(); }, 300); }
 else { _updateActiveCountLabel(); _checkHideActiveContainer(); }
}

function _updateActiveCountLabel() {
 const label = document.getElementById('urlDlActiveCount');
 const n = _activeRemoteDownloadJobs.size;
 if (label) label.textContent = n > 0 ? '— ' + n + ' aktif' : '— selesai';
}

function _checkHideActiveContainer() {
 const list = document.getElementById('urlDlActiveList');
 const container = document.getElementById('urlDlActiveContainer');
 if (container && list && list.children.length === 0) container.classList.add('hidden');
}

// BUG FIX: Simpan SEMUA jobId aktif ke localStorage (bukan hanya 1 terakhir)
// agar saat page refresh semua download bisa di-restore, bukan cuma yang terakhir dimulai
function _saveAllActiveRemoteDlJobs() {
 try {
  if (_activeRemoteDownloadJobs.size === 0) {
   localStorage.removeItem(_LS('remote_dl_active'));
   return;
  }
  const allJobs = Array.from(_activeRemoteDownloadJobs.entries()).map(([jid, state]) => ({
   jobId: jid,
   destPath: state.destPath || '',
   startedAt: state.startedAt || Date.now()
  }));
  localStorage.setItem(_LS('remote_dl_active'), JSON.stringify(allJobs));
 } catch(e) {}
}

// --- Jalankan satu download ---
async function _executeRemoteDownload({ url, destPath, fileName }) {
 _startingCount++;
 _updateRemoteDlQueueBadge();
 try {
  const r = await fetch('/api/remote-download/start', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ url, destPath, fileName }) });
  const data = await r.json().catch(() => ({}));
  if (!r.ok || !data.jobId) {
   _startingCount--;
   if (typeof showToast === 'function') showToast(data.error || 'Gagal memulai download', 'error');
   _processNextRemoteDownload();
   return;
  }
  const jobId = data.jobId;
  _activeRemoteDownloadJobs.set(jobId, { pollTimer: null, lastBytes: 0, lastTime: Date.now(), pollErrors: 0, destPath, startedAt: Date.now() });
  _startingCount--;
  // BUG FIX: Simpan SEMUA jobId aktif, bukan hanya yang baru saja dimulai
  _saveAllActiveRemoteDlJobs();
  showUploadPanel();
  _createUrlDlCard(jobId, fileName || 'Mengambil info file...');
  _updateRemoteDlQueueBadge();
  _pollRemoteDownload(jobId);
 } catch(e) {
  _startingCount--;
  if (typeof showToast === 'function') showToast('Gagal memulai download: ' + e.message, 'error');
  _processNextRemoteDownload();
 }
}

// --- Mulai dari antrian sampai slot penuh (maks 4 concurrent) ---
function _processNextRemoteDownload() {
 while (_remoteDownloadQueue.length > 0 && _activeSlots() < MAX_CONCURRENT_REMOTE_DL) {
  const next = _remoteDownloadQueue.shift();
  _saveRemoteDlQueue();
  _executeRemoteDownload(next); // tanpa await — jalankan bersamaan
 }
 _updateQueueListUI();
}

function _pollRemoteDownload(jobId) {
 const state = _activeRemoteDownloadJobs.get(jobId);
 if (!state) return;
 const GIVE_UP_ERRORS = 300;
 if (state.pollTimer) clearInterval(state.pollTimer);
 state.pollTimer = setInterval(async () => {
  try {
   const r = await fetch('/api/remote-download/status?jobId=' + encodeURIComponent(jobId));
   if (!r.ok) throw new Error('status_' + r.status);
   state.pollErrors = 0;
   const job = await r.json();
   const now = Date.now();
   const dt = (now - state.lastTime) / 1000;
   const speed = dt > 0 ? Math.max(0, (job.downloaded - state.lastBytes) / dt) : 0;
   state.lastBytes = job.downloaded; state.lastTime = now;

   const _finishPoll = () => {
    clearInterval(state.pollTimer);
    _activeRemoteDownloadJobs.delete(jobId);
    // BUG FIX: Update localStorage setelah 1 job selesai, agar job lain tetap tersimpan
    _saveAllActiveRemoteDlJobs();
   };

   if (job.status === 'starting' || job.status === 'downloading') {
    const pct = job.total ? (job.downloaded / job.total * 100) : 0;
    _updateUrlDlCard(jobId, { name: job.fileName || 'Mengunduh dari internet...', size: job.total, progress: pct, speed, status: 'uploading' });
    _updateRemoteDlQueueBadge();

   } else if (job.status === 'done') {
    _finishPoll();
    _updateUrlDlCard(jobId, { name: job.fileName, size: job.total, progress: 100, speed: 0, status: 'done' });
    if (typeof showToast === 'function') showToast('Berhasil diunduh: ' + job.fileName);
    if (typeof folderCache !== 'undefined') delete folderCache[currentPath];
    if (typeof loadFiles === 'function') loadFiles(currentPath);
    setTimeout(() => {
     _removeUrlDlCard(jobId);
     _processNextRemoteDownload();
     if (_activeRemoteDownloadJobs.size === 0 && _remoteDownloadQueue.length === 0 && !_uploadActive) _scheduleAutoClosePanel();
    }, 1500);

   } else if (job.status === 'error') {
    _finishPoll();
    if (typeof showToast === 'function') showToast(job.error || 'Gagal mengunduh file', 'error');
    _removeUrlDlCard(jobId);
    _processNextRemoteDownload();
    if (_activeRemoteDownloadJobs.size === 0 && !_uploadActive) closeUploadPanel();

   } else if (job.status === 'cancelled') {
    _finishPoll();
    _removeUrlDlCard(jobId);
    _processNextRemoteDownload();
    if (_activeRemoteDownloadJobs.size === 0 && !_uploadActive) closeUploadPanel();
   }
  } catch(e) {
   state.pollErrors++;
   const card = document.getElementById('urlDlCard_' + jobId);
   if (card) { const srcEl = card.querySelector('.url-dl-src'); if (srcEl) srcEl.textContent = 'Menghubungkan...'; }
   if (state.pollErrors < GIVE_UP_ERRORS) return;
   clearInterval(state.pollTimer);
   _activeRemoteDownloadJobs.delete(jobId);
   if (typeof showToast === 'function') showToast('Koneksi terputus, download dihentikan', 'error');
   _removeUrlDlCard(jobId);
   _processNextRemoteDownload();
   if (_activeRemoteDownloadJobs.size === 0 && !_uploadActive) closeUploadPanel();
  }
 }, 1000);
}

// --- Batalkan SATU download aktif ---
function cancelSingleRemoteDownload(jobId) {
 const state = _activeRemoteDownloadJobs.get(jobId);
 if (!state) return;
 if (state.pollTimer) clearInterval(state.pollTimer);
 _activeRemoteDownloadJobs.delete(jobId);
 // BUG FIX: Update localStorage setelah cancel 1 job, agar job lain tetap tersimpan
 _saveAllActiveRemoteDlJobs();
 fetch('/api/remote-download/cancel', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ jobId }) }).catch(() => {});
 if (typeof showToast === 'function') showToast('Download dibatalkan', 'warning');
 _removeUrlDlCard(jobId);
 _updateRemoteDlQueueBadge();
 _processNextRemoteDownload();
 if (_activeRemoteDownloadJobs.size === 0) {
  if (!_uploadActive) _scheduleAutoClosePanel();
 }
}

// Alias untuk backward compat (dipanggil tombol lama tanpa jobId)
function cancelActiveRemoteDownload(jobId) {
 if (jobId) { cancelSingleRemoteDownload(jobId); return; }
 const firstId = _activeRemoteDownloadJobs.keys().next().value;
 if (firstId) cancelSingleRemoteDownload(firstId);
}

function cancelActiveUpload() {
 if (!_uploadActive) return;
 cancelUpload();
 if (typeof showToast === 'function') showToast('Upload dibatalkan', 'warning');
}

// --- Batalkan SEMUA download aktif + antrian ---
function cancelRemoteDownload() {
 const hadQueue = _remoteDownloadQueue.length > 0;
 _remoteDownloadQueue = [];
 _saveRemoteDlQueue();
 _updateQueueListUI();
 for (const [jid, state] of _activeRemoteDownloadJobs) {
  if (state.pollTimer) clearInterval(state.pollTimer);
  fetch('/api/remote-download/cancel', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ jobId: jid }) }).catch(() => {});
  _removeUrlDlCard(jid);
 }
 _activeRemoteDownloadJobs.clear();
 try { localStorage.removeItem(_LS('remote_dl_active')); } catch(e) {}
 closeUploadPanel();
 if (typeof showToast === 'function') showToast(hadQueue ? 'Download + antrian dibatalkan semua' : 'Download dibatalkan', 'warning');
}

// cancelUpload extended: handle remote download cancellation too
const _origCancelUpload = typeof cancelUpload !== 'undefined' ? cancelUpload : null;
function cancelUpload() {
 if (_activeRemoteDownloadJobs.size > 0) { cancelRemoteDownload(); return; }
 _uploadCancelled = true;
 for (const [, job] of _activeUploadJobs) { if (job.cancelFn) job.cancelFn(); }
}

// -- Drag & Drop ke area file manager --
(function _initUploadDragDrop() {
 let _dragCounter = 0;
 document.addEventListener('dragenter', e => {
  if (!e.dataTransfer || !e.dataTransfer.types.includes('Files')) return;
  _dragCounter++;
  const overlay = document.getElementById('uploadDropOverlay');
  const label = document.getElementById('uploadDropPathLabel');
  if (overlay) overlay.classList.remove('hidden');
  if (label) {
   const dp = (typeof currentPath !== 'undefined' && currentPath) ? currentPath : '/';
   label.textContent = 'ke /' + dp;
  }
 });
 document.addEventListener('dragleave', e => {
  _dragCounter--;
  if (_dragCounter <= 0) {
   _dragCounter = 0;
   const overlay = document.getElementById('uploadDropOverlay');
   if (overlay) overlay.classList.add('hidden');
  }
 });
 document.addEventListener('dragover', e => { e.preventDefault(); });
 document.addEventListener('drop', e => {
  e.preventDefault(); _dragCounter = 0;
  const overlay = document.getElementById('uploadDropOverlay');
  if (overlay) overlay.classList.add('hidden');
  const files = Array.from(e.dataTransfer?.files || []);
  if (!files.length) return;
  // Hanya aktif kalau lagi di tab files
  const activeTab = document.querySelector('[id$="-view"]:not(.hidden), #files-view:not(.hidden)');
  const filesView = document.getElementById('files-view');
  if (!filesView || filesView.classList.contains('hidden')) return;
  queueUploadFiles(files);
 });
})();


// -- Restore panel download URL yang masih jalan di background saat page di-refresh --
// BUG FIX: Sekarang support restore SEMUA jobId aktif (format baru: array),
// dengan fallback ke format lama (single object) untuk kompatibilitas
async function _checkInterruptedRemoteDownload() {
 try {
  // Restore antrian yang tersimpan di localStorage
  const savedQueue = _loadRemoteDlQueue();
  if (savedQueue.length > 0) _remoteDownloadQueue = savedQueue;

  const raw = localStorage.getItem(_LS('remote_dl_active'));
  if (!raw) {
   // Tidak ada yang aktif tapi ada antrian tersimpan? Mulai langsung
   if (_remoteDownloadQueue.length > 0) {
    _updateQueueListUI();
    showUploadPanel();
    _processNextRemoteDownload();
   }
   return;
  }

  const parsed = JSON.parse(raw);
  // Normalisasi: format baru = array, format lama = single object { jobId, ... }
  const activeList = Array.isArray(parsed)
   ? parsed
   : (parsed && parsed.jobId ? [parsed] : []);

  if (activeList.length === 0) {
   localStorage.removeItem(_LS('remote_dl_active'));
   if (_remoteDownloadQueue.length > 0) {
    _updateQueueListUI();
    showUploadPanel();
    _processNextRemoteDownload();
   }
   return;
  }

  let anyRestored = false;
  // Cek dan reconnect ke setiap job yang masih aktif di server
  await Promise.all(activeList.map(async (active) => {
   if (!active || !active.jobId) return;
   try {
    const r = await fetch('/api/remote-download/status?jobId=' + encodeURIComponent(active.jobId));
    if (!r.ok) return; // job tidak ditemukan di server, skip
    const job = await r.json();

    if (job.status === 'done') {
     if (typeof showToast === 'function') showToast('Download "' + (job.fileName || active.jobId) + '" sudah selesai di background', 'success');
     if (typeof currentPath !== 'undefined' && active.destPath === currentPath) {
      if (typeof folderCache !== 'undefined') delete folderCache[currentPath];
      if (typeof loadFiles === 'function') loadFiles(currentPath);
     }
     return;
    }
    if (job.status === 'error') {
     if (typeof showToast === 'function') showToast(job.error || 'Download dari URL gagal', 'error');
     return;
    }
    if (job.status === 'cancelled') return;

    // Masih downloading -> reconnect ke job ini
    _activeRemoteDownloadJobs.set(active.jobId, { pollTimer: null, lastBytes: job.downloaded || 0, lastTime: Date.now(), pollErrors: 0, destPath: active.destPath || '', startedAt: active.startedAt || Date.now() });
    anyRestored = true;
    const pct = job.total ? (job.downloaded / job.total * 100) : 0;
    _createUrlDlCard(active.jobId, job.fileName || 'Mengunduh dari internet...');
    _updateUrlDlCard(active.jobId, { name: job.fileName || 'Mengunduh...', size: job.total, progress: pct, speed: 0, status: 'uploading' });
    _pollRemoteDownload(active.jobId);
   } catch(e) { /* skip job ini kalau ada error */ }
  }));

  if (anyRestored) {
   showUploadPanel();
   _updateRemoteDlQueueBadge();
   _updateQueueListUI();
   // Simpan ulang hanya yang berhasil di-restore
   _saveAllActiveRemoteDlJobs();
  } else {
   localStorage.removeItem(_LS('remote_dl_active'));
  }

  // Proses sisa antrian kalau ada slot kosong
  if (_remoteDownloadQueue.length > 0) {
   if (!anyRestored) {
    _updateQueueListUI();
    showUploadPanel();
   }
   setTimeout(() => _processNextRemoteDownload(), anyRestored ? 400 : 0);
  }
 } catch (e) { try { localStorage.removeItem(_LS('remote_dl_active')); } catch(e2) {} }
}

// ===== PANEL PORTAL + SWIPE-TO-CLOSE =====
(function _initUploadPanelPortal() {
 function _setup() {
  // Teleport panel, backdrop, modal, dan resume input ke level <body>
  // Agar tidak ikut tersembunyi saat tab #files-view di-hide (display:none)
  const els = ['uploadPanelBackdrop', 'uploadToggleTab', 'uploadProgressPanel', 'remoteDownloadModal', 'uploadResumeFileInput'];
  els.forEach(id => {
   const el = document.getElementById(id);
   if (el && el.parentElement !== document.body) document.body.appendChild(el);
  });

  // Swipe-to-close: geser sidebar ke kanan untuk tutup (mobile-friendly)
  const panel = document.getElementById('uploadProgressPanel');
  if (!panel) return;
  let touchStartX = 0, touchCurX = 0, swiping = false;

  panel.addEventListener('touchstart', e => {
   touchStartX = e.touches[0].clientX;
   touchCurX = touchStartX;
   swiping = true;
   panel.style.transition = 'none';
  }, { passive: true });

  panel.addEventListener('touchmove', e => {
   if (!swiping) return;
   touchCurX = e.touches[0].clientX;
   const dx = Math.max(0, touchCurX - touchStartX); // hanya ke kanan
   panel.style.transform = 'translateX(' + dx + 'px)';
  }, { passive: true });

  panel.addEventListener('touchend', () => {
   if (!swiping) return;
   swiping = false;
   panel.style.transition = '';
   const dx = touchCurX - touchStartX;
   if (dx > 80) {
    closeUploadPanel(); // tutup kalau geser cukup jauh
   } else {
    panel.style.transform = 'translateX(0)'; // balik ke posisi terbuka
   }
  });

  // ── Drag atas-bawah untuk toggle tab ──────────────────────────────
  const tab = document.getElementById('uploadToggleTab');
  if (tab) {
   const _getTabTop = () => {
    const saved = sessionStorage.getItem('uploadTabTop');
    return saved ? parseFloat(saved) : window.innerHeight * 0.5;
   };
   const _setTabPosition = (y) => {
    const half = tab.offsetHeight / 2;
    const clamped = Math.min(Math.max(y, half + 8), window.innerHeight - half - 8);
    tab.style.top = clamped + 'px';
    tab.style.transform = 'translateY(-50%)';
    sessionStorage.setItem('uploadTabTop', clamped);
   };
   _setTabPosition(_getTabTop());

   let _tabDragging = false, _tabStartY = 0, _tabOriginTop = 0, _tabMoved = false;
   const _onTabStart = (clientY) => {
    _tabDragging = true; _tabMoved = false;
    _tabStartY = clientY;
    _tabOriginTop = parseFloat(tab.style.top) || _getTabTop();
    tab.style.transition = 'none';
   };
   const _onTabMove = (clientY) => {
    if (!_tabDragging) return;
    const dy = clientY - _tabStartY;
    if (Math.abs(dy) > 5) _tabMoved = true;
    if (_tabMoved) _setTabPosition(_tabOriginTop + dy);
   };
   const _onTabEnd = () => {
    if (!_tabDragging) return;
    _tabDragging = false;
    tab.style.transition = '';
    if (!_tabMoved) showUploadPanel();
   };
   // Tracking X juga supaya swipe kiri = buka sidebar
   let _tabStartX = 0;
   const _onTabStartXY = (cx, cy) => { _tabStartX = cx; _onTabStart(cy); };
   const _onTabMoveXY = (cx, cy) => { _onTabMove(cy); };
   const _onTabEndXY  = (cx) => {
    const dx = _tabStartX - cx; // positif = swipe ke kiri
    if (!_tabDragging) return;
    _tabDragging = false;
    tab.style.transition = '';
    if (_tabMoved) return; // geser vertikal — bukan tap/swipe horizontal
    if (dx > 30) { showUploadPanel(); return; } // swipe kiri ≥30px = buka
    showUploadPanel(); // tap biasa juga buka
   };

   tab.addEventListener('touchstart', e => _onTabStartXY(e.touches[0].clientX, e.touches[0].clientY), { passive: true });
   tab.addEventListener('touchmove',  e => { e.preventDefault(); _onTabMoveXY(e.touches[0].clientX, e.touches[0].clientY); }, { passive: false });
   tab.addEventListener('touchend',   e => { e.preventDefault(); _onTabEndXY(e.changedTouches[0].clientX); });
   tab.addEventListener('mousedown', e => {
    e.preventDefault(); _onTabStartXY(e.clientX, e.clientY);
    const _mm = ev => _onTabMoveXY(ev.clientX, ev.clientY);
    const _mu = ev => { _onTabEndXY(ev.clientX); window.removeEventListener('mousemove', _mm); window.removeEventListener('mouseup', _mu); };
    window.addEventListener('mousemove', _mm); window.addEventListener('mouseup', _mu);
   });
  }
 }

 if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', _setup);
 } else {
  _setup();
 }
})();

// Cek download-URL yang terjeda saat page load (setelah DOM siap)
if (document.readyState === 'loading') {
 document.addEventListener('DOMContentLoaded', () => setTimeout(_checkInterruptedRemoteDownload, 1200));
} else {
 setTimeout(_checkInterruptedRemoteDownload, 1200);
}

// Popup aksi File Manager dan Editor Text dapat dipindahkan dengan drag grip (mouse maupun touch).
(function initDraggableActionPopups() {
 function makePopupDraggable(popup) {
  if (!popup || popup.dataset.dragReady === '1') return;
  const handle = popup.querySelector('[data-drag-handle]');
  if (!handle) return;
  popup.dataset.dragReady = '1';
  handle.addEventListener('pointerdown', function (event) {
   if (event.button !== undefined && event.button !== 0) return;
   event.preventDefault();
   const rect = popup.getBoundingClientRect();
   const startX = event.clientX;
   const startY = event.clientY;
   const offsetX = startX - rect.left;
   const offsetY = startY - rect.top;
   popup.style.left = rect.left + 'px';
   popup.style.top = rect.top + 'px';
   popup.style.right = 'auto';
   popup.style.bottom = 'auto';
   popup.style.transform = 'none';
   popup.style.transition = 'opacity 180ms ease';
   handle.setPointerCapture(event.pointerId);
   handle.classList.add('cursor-grabbing');

   const move = (e) => {
    const width = popup.offsetWidth;
    const height = popup.offsetHeight;
    const maxLeft = Math.max(0, window.innerWidth - width);
    const maxTop = Math.max(0, window.innerHeight - height);
    const left = Math.min(maxLeft, Math.max(0, e.clientX - offsetX));
    const top = Math.min(maxTop, Math.max(0, e.clientY - offsetY));
    popup.style.left = left + 'px';
    popup.style.top = top + 'px';
   };
   const finish = () => {
    handle.classList.remove('cursor-grabbing');
    handle.removeEventListener('pointermove', move);
    handle.removeEventListener('pointerup', finish);
    handle.removeEventListener('pointercancel', finish);
   };
   handle.addEventListener('pointermove', move);
   handle.addEventListener('pointerup', finish);
   handle.addEventListener('pointercancel', finish);
  });
 }
 const setup = () => {
  makePopupDraggable(document.getElementById('pteroFloatingBar'));
  makePopupDraggable(document.getElementById('editorFloatingBar'));
 };
 if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', setup, { once: true });
 else setup();
})();
