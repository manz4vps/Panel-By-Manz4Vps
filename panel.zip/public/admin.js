let allUsers = [];


    function showToast(message, type = 'success') {
      const container = document.getElementById('toast-container');
      if (container.children.length >= 5) container.removeChild(container.lastChild);
      const isSuccess = type === 'success', isWarning = type === 'warning';
      const borderColor = isSuccess ? 'border-green-500/40' : isWarning ? 'border-yellow-500/40' : 'border-red-500/40';
      const iconBg = isSuccess ? 'bg-green-500/20 text-green-400' : isWarning ? 'bg-yellow-500/20 text-yellow-400' : 'bg-red-500/20 text-red-400';
      const barColor = isSuccess ? 'bg-green-500' : isWarning ? 'bg-yellow-500' : 'bg-red-500';
      const icon = isSuccess ? '<svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"/></svg>' : '<svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v4m0 4h.01M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/></svg>';
      const toast = document.createElement('div');
      toast.className = `relative bg-[#1e293b] border ${borderColor} text-white px-4 py-3 rounded-2xl flex items-center gap-3 shadow-2xl shadow-black/40 overflow-hidden`;
      toast.style.animation = 'toastIn 0.3s cubic-bezier(0.34,1.56,0.64,1)';
      toast.innerHTML = `<div class="w-7 h-7 rounded-full ${iconBg} flex items-center justify-center font-black text-sm flex-shrink-0">${icon}</div><span class="text-[13px] font-semibold leading-snug flex-1">${message}</span><button class="text-slate-500 hover:text-white transition text-xl leading-none flex-shrink-0 ml-1">×</button><div class="absolute bottom-0 left-0 h-[2px] ${barColor} toast-bar rounded-full" style="width:100%;transition:width 4s linear;"></div>`;
      container.insertBefore(toast, container.firstChild);
      requestAnimationFrame(() => { requestAnimationFrame(() => { const bar = toast.querySelector('.toast-bar'); if (bar) bar.style.width = '0%'; }); });
      const autoRemove = setTimeout(() => { toast.style.animation = 'toastOut 0.3s ease-in forwards'; setTimeout(() => toast.remove(), 300); }, 4200);
      toast.querySelector('button').addEventListener('click', () => { clearTimeout(autoRemove); toast.style.animation = 'toastOut 0.3s ease-in forwards'; setTimeout(() => toast.remove(), 300); });
    }

    function toggleAdminDrawer(force) {
      const open = typeof force === 'boolean' ? force : !document.body.classList.contains('drawer-open');
      document.body.classList.toggle('drawer-open', open);
      const drawer = document.getElementById('admin-drawer');
      if (drawer) drawer.setAttribute('aria-hidden', String(!open));
    }
    const ADMIN_SECTION_ROUTES = {
      'section-resource': '/admin/resourcevps',
      'section-overview': '/admin/ringkasan',
      'section-users': '/admin/manajemenuser',
      'section-settings': '/admin/pengaturan'
    };
    function adminNavigate(id) {
      const route = ADMIN_SECTION_ROUTES[id];
      if (route) window.location.href = route;
      toggleAdminDrawer(false);
    }

    // Setiap menu admin memiliki URL sendiri. Hanya section aktif yang ditampilkan.
    (function initAdminRouteView() {
      const routeToSection = {
        '/admin/resourcevps': 'section-resource',
        '/admin/ringkasan': 'section-overview',
        '/admin/manajemenuser': 'section-users',
        '/admin/pengaturan': 'section-settings'
      };
      const activeSection = routeToSection[window.location.pathname] || 'section-resource';
      document.querySelectorAll('.adm-section').forEach(section => {
        section.style.display = section.id === activeSection ? '' : 'none';
      });
      document.querySelectorAll('.adm-nav-link[data-target]').forEach(link => {
        link.classList.toggle('active', link.dataset.target === activeSection);
      });
    })();
    document.addEventListener('keydown', e => { if (e.key === 'Escape') toggleAdminDrawer(false); });

    function escapeAdminHTML(value) {
      return String(value == null ? '' : value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
    }

    function renderDashboardOverview(users) {
      const totalUsers = users.length;
      let totalServers = 0, online = 0;
      const activities = [];
      users.forEach(user => {
        const username = user.username || 'User';
        if (user.createdAt) {
          const date = new Date(user.createdAt);
          if (Number.isFinite(date.getTime())) activities.push({type:'user', title:'User baru terdaftar', detail:username, date});
        }
        (Array.isArray(user.servers) ? user.servers : []).forEach(server => {
          totalServers++;
          if (server.isOnline) online++;
          const created = server.createdAt || server.created_at;
          if (created) {
            const date = new Date(created);
            if (Number.isFinite(date.getTime())) activities.push({type:'server', title:'Server dibuat', detail:(server.name || 'Server') + ' · ' + username, date});
          }
        });
      });
      const offline = Math.max(0, totalServers - online);
      const percent = totalServers ? Math.round(online / totalServers * 100) : 0;
      const setText = (id, value) => { const el = document.getElementById(id); if (el) el.textContent = value; };
      setText('server-status-percent', percent + '%');
      setText('overview-online-count', online);
      setText('overview-offline-count', offline);
      setText('overview-server-total', `Total ${totalServers} server · ${totalUsers} user`);
      const onlineBar = document.getElementById('overview-online-bar');
      const offlineBar = document.getElementById('overview-offline-bar');
      if (onlineBar) onlineBar.style.width = percent + '%';
      if (offlineBar) offlineBar.style.width = (totalServers ? 100 - percent : 0) + '%';
      const donut = document.getElementById('server-status-donut');
      if (donut) donut.style.background = `conic-gradient(#34d399 0deg ${percent * 3.6}deg,#475569 ${percent * 3.6}deg 360deg)`;

      const activityEl = document.getElementById('overview-activity');
      if (activityEl) {
        activities.sort((a,b) => b.date - a.date);
        const recent = activities.slice(0,5);
        activityEl.innerHTML = recent.length ? recent.map(item => {
          const isUser = item.type === 'user';
          const dateLabel = item.date.toLocaleString('id-ID',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'});
          return `<div class="adm-activity-item"><span class="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${isUser?'bg-blue-500/10 text-blue-300':'bg-violet-500/10 text-violet-300'}"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">${isUser?'<path stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" d="M16 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2m8-10a4 4 0 100-8 4 4 0 000 8z"/>':'<rect x="3" y="4" width="18" height="16" rx="2" stroke-width="1.8"/><path stroke-width="1.8" d="M7 8h10M7 12h6"/>'}</svg></span><div class="min-w-0 flex-1"><p class="text-[10px] font-bold text-slate-300">${item.title}</p><p class="text-[10px] text-slate-500 truncate">${escapeAdminHTML(item.detail)}</p></div><time class="text-[9px] text-slate-600 whitespace-nowrap">${dateLabel}</time></div>`;
        }).join('') : '<p class="text-[10px] text-slate-600 text-center py-6">Belum ada data aktivitas bertanggal.</p>';
      }
      const dataDot = document.getElementById('overview-data-dot');
      if (dataDot) dataDot.className = 'w-2 h-2 rounded-full bg-emerald-400';
      setText('overview-data-status', `${totalUsers} user dan ${totalServers} server berhasil dimuat`);
    }

    function renderMonthlyUserStats(users) {
      const now = new Date();
      const months = [];
      for (let i = 5; i >= 0; i--) {
        const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
        months.push({ key: d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0'), label: d.toLocaleDateString('id-ID',{month:'short'}), count: 0 });
      }
      let known = 0;
      users.forEach(u => {
        if (!u.createdAt) return;
        const d = new Date(u.createdAt);
        if (!Number.isFinite(d.getTime())) return;
        known++;
        const key = d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0');
        const item = months.find(m => m.key === key);
        if (item) item.count++;
      });
      const currentKey = now.getFullYear() + '-' + String(now.getMonth()+1).padStart(2,'0');
      const current = months.find(m => m.key === currentKey);
      const monthEl = document.getElementById('stat-users-month');
      if (monthEl) monthEl.textContent = current ? current.count : 0;
      const weekEl = document.getElementById('stat-users-week');
      const weekCutoff = now.getTime() - 7 * 24 * 60 * 60 * 1000;
      if (weekEl) weekEl.textContent = users.filter(u => u.createdAt && Number.isFinite(new Date(u.createdAt).getTime()) && new Date(u.createdAt).getTime() >= weekCutoff).length;
      const max = Math.max(1, ...months.map(m => m.count));
      const chart = document.getElementById('monthly-user-chart');
      if (chart) chart.innerHTML = months.map(m => `<div class="grid grid-cols-[42px_1fr_28px] items-center gap-3"><span class="text-[10px] text-slate-500 font-bold">${m.label}</span><div class="adm-month-bar"><span style="width:${(m.count/max)*100}%"></span></div><span class="text-[10px] text-slate-400 text-right font-mono">${m.count}</span></div>`).join('') + (known < users.length ? `<p class="text-[9px] text-slate-700 pt-1">${users.length-known} akun lama belum memiliki tanggal pendaftaran, sehingga tidak masuk grafik historis.</p>` : '');
    }

    /* ========== RESOURCE HISTORY CHART ========== */
    let resourceHistory = [];
    let resourcePeriod = '24h';
    let resourceSystemInfo = { cores: 1, ramTotal: 0, diskTotal: 0 };
    const bytesToGiB = bytes => bytes / (1024 * 1024 * 1024);
    const formatGiB = bytes => `${bytesToGiB(Math.max(0, Number(bytes) || 0)).toLocaleString('id-ID', { minimumFractionDigits: 1, maximumFractionDigits: 1 })} GB`;
    const formatDiskCapacity = bytes => {
      const gib = bytesToGiB(Math.max(0, Number(bytes) || 0));
      const value = gib >= 1024 ? gib / 1024 : gib;
      const unit = gib >= 1024 ? 'TB' : 'GB';
      return `${value.toLocaleString('id-ID', { minimumFractionDigits: 1, maximumFractionDigits: 1 })} ${unit}`;
    };
    const formatCpuPercent = value => {
      const n = Math.max(0, Number(value) || 0);
      return n < 10
        ? n.toLocaleString('id-ID', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + '%'
        : Math.round(n).toLocaleString('id-ID') + '%';
    };
    const formatCpuDual = value => {
      const normalized = Math.max(0, Number(value) || 0);
      const cores = Math.max(1, Number(resourceSystemInfo.cores) || 1);
      return `${formatCpuPercent(normalized)} = ${formatCpuPercent(normalized * cores)}`;
    };
    function resourceChartValue(point, metric) {
      if (metric === 'cpu') return Number(point.cpu);
      if (metric === 'ram') return Number.isFinite(Number(point.ramUsed)) ? bytesToGiB(point.ramUsed) : (Number(point.ram) / 100) * bytesToGiB(resourceSystemInfo.ramTotal);
      return Number.isFinite(Number(point.diskUsed)) ? bytesToGiB(point.diskUsed) : (Number(point.disk) / 100) * bytesToGiB(resourceSystemInfo.diskTotal);
    }
    function resourceChartMaximum(metric) {
      if (metric === 'cpu') return 100;
      if (metric === 'ram') return Math.max(1, bytesToGiB(resourceSystemInfo.ramTotal));
      return Math.max(1, bytesToGiB(resourceSystemInfo.diskTotal));
    }
    function formatResourceChartValue(value, metric) {
      return metric === 'cpu' ? formatCpuDual(value) : `${Number(value).toLocaleString('id-ID', { minimumFractionDigits: 1, maximumFractionDigits: 1 })} GB`;
    }
    const resourceChartSelection = Object.create(null);
    const resourcePeriodLabels = {'24h':'24H','7d':'7D','14d':'14D','28d':'28D'};
    async function loadResourceHistory() {
      try {
        const r = await fetch('/api/admin/resource-history?period=' + encodeURIComponent(resourcePeriod), { cache: 'no-store' });
        if (!r.ok) return;
        const data = await r.json();
        resourceHistory = Array.isArray(data.points) ? data.points : [];
        drawResourceChart();

        // UptimeRobot status, uptime percentage, dan downtime terpisah dari chart resource lokal.
        await loadUptimeRobotMetrics();
        const note=document.getElementById('resource-history-note');
        if(note) note.textContent='CPU, RAM, dan Disk memakai monitoring lokal. Uptime, status ONLINE/OFFLINE, dan downtime berasal dari UptimeRobot.';
      } catch(e) {}
    }
    async function loadUptimeRobotMetrics() {
      const period = ({ '24h':'1d', '7d':'7d', '14d':'14d', '28d':'28d' })[resourcePeriod] || '1d';
      const uptimeValue = document.getElementById('sys-uptime-value');
      const uptimeSub = document.getElementById('sys-uptime-sub');
      const uptimeTitle = document.getElementById('sys-uptime-title');
      const uptimeBadge = document.getElementById('sys-uptime-badge');
      const uptimeStatus = document.getElementById('sys-uptime-status');
      const label = ({'1d':'24H','7d':'7D','14d':'14D','28d':'28D'})[period] || '24H';
      if (uptimeTitle) uptimeTitle.textContent = `Uptime ${label}`;
      if (uptimeBadge) uptimeBadge.textContent = label;
      try {
        const res = await fetch('/api/admin/uptimerobot?period=' + encodeURIComponent(period), { cache:'no-store' });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'API UptimeRobot tidak tersedia');
        if (uptimeValue) uptimeValue.textContent = data.uptimePercent != null && Number.isFinite(Number(data.uptimePercent)) ? Number(data.uptimePercent).toFixed(2) + '%' : '—';
        if (uptimeStatus) { uptimeStatus.textContent = 'STATUS: ' + (data.status || 'UNKNOWN'); uptimeStatus.className = 'text-[10px] font-bold mt-1 ' + (data.status === 'ONLINE' ? 'text-emerald-400' : data.status === 'OFFLINE' ? 'text-red-400' : 'text-amber-400'); }
        if (uptimeSub) uptimeSub.textContent = `Downtime ${label}: ${data.downtimeText || '—'}`;
      } catch (e) {
        if (uptimeValue) uptimeValue.textContent = 'Tidak tersedia';
        if (uptimeStatus) { uptimeStatus.textContent = 'STATUS: GAGAL MEMUAT'; uptimeStatus.className = 'text-[10px] font-bold mt-1 text-amber-400'; }
        if (uptimeSub) uptimeSub.textContent = e.message || 'Periksa config/uptimerobot.json';
      }
    }

    const periodMs = { '24h':86400000, '7d':604800000, '14d':1209600000, '28d':2419200000 };
    // Interval navigasi crosshair berubah mengikuti periode grafik.
    const resourceCursorStepMs = { '24h':5*60*1000, '7d':30*60*1000, '14d':2*60*60*1000, '28d':24*60*60*1000 };
    function snapResourceCursorTime(timestamp, period) {
      const step = resourceCursorStepMs[period] || resourceCursorStepMs['24h'];
      if (period === '28d') { const d = new Date(timestamp); d.setHours(0,0,0,0); return d.getTime(); }
      return Math.round(timestamp / step) * step;
    }
    // Kurangi titik yang digambar sesuai lebar layar, tetapi pertahankan titik min/max
    // di setiap bucket agar lonjakan CPU tidak hilang. Data mentah tidak disentuh.
    function decimateResourcePoints(points, values, cutoff, windowMs, plotWidth) {
      if (points.length <= Math.max(300, plotWidth * 2.5)) return points.map((point, i) => ({ point, value: values[i] }));
      const bucketCount = Math.max(120, Math.floor(plotWidth * 1.5));
      const buckets = Array.from({ length: bucketCount }, () => ({ min: -1, max: -1 }));
      points.forEach((point, i) => {
        const ratio = Math.max(0, Math.min(0.999999, (point.at - cutoff) / windowMs));
        const bucket = buckets[Math.floor(ratio * bucketCount)];
        if (bucket.min < 0 || values[i] < values[bucket.min]) bucket.min = i;
        if (bucket.max < 0 || values[i] > values[bucket.max]) bucket.max = i;
      });
      const indices = new Set([0, points.length - 1]);
      buckets.forEach(bucket => { if (bucket.min >= 0) indices.add(bucket.min); if (bucket.max >= 0) indices.add(bucket.max); });
      return Array.from(indices).sort((a, b) => a - b).map(i => ({ point: points[i], value: values[i] }));
    }
    // Monotone cubic Hermite: kurva halus, melewati titik data, dan tidak membuat
    // overshoot buatan di antara sampel (penting untuk spike CPU).
    function traceMonotoneCurve(ctx, coords, closeToBaseline, baselineY) {
      ctx.beginPath();
      if (!coords.length) return;
      ctx.moveTo(coords[0].x, coords[0].y);
      if (coords.length === 1) ctx.lineTo(coords[0].x, coords[0].y);
      else {
        const slopes = [];
        for (let i = 0; i < coords.length - 1; i++) {
          const dx = Math.max(0.0001, coords[i + 1].x - coords[i].x);
          slopes.push((coords[i + 1].y - coords[i].y) / dx);
        }
        const tangents = new Array(coords.length);
        tangents[0] = slopes[0]; tangents[coords.length - 1] = slopes[slopes.length - 1];
        for (let i = 1; i < coords.length - 1; i++) {
          const a = slopes[i - 1], b = slopes[i];
          tangents[i] = a * b <= 0 ? 0 : (2 * a * b) / (a + b);
        }
        for (let i = 0; i < coords.length - 1; i++) {
          const a = coords[i], b = coords[i + 1], dx = b.x - a.x;
          ctx.bezierCurveTo(a.x + dx / 3, a.y + tangents[i] * dx / 3,
            b.x - dx / 3, b.y - tangents[i + 1] * dx / 3, b.x, b.y);
        }
      }
      if (closeToBaseline) {
        ctx.lineTo(coords[coords.length - 1].x, baselineY);
        ctx.lineTo(coords[0].x, baselineY);
        ctx.closePath();
      }
    }
    function drawOneResourceChart(metric, color, canvasId, valueId, trendId) {
      const canvas = document.getElementById(canvasId); if (!canvas) return;
      const now = Date.now(), cutoff = now - (periodMs[resourcePeriod] || periodMs['24h']);
      const points = resourceHistory.filter(p => p.at >= cutoff && Number.isFinite(Number(p[metric])));
      const selectedAt = resourceChartSelection[canvasId];
      const rect = canvas.getBoundingClientRect(), w = Math.max(260, Math.floor(rect.width || 600)), h = Math.max(240, Math.floor(rect.height || 360)), dpr = window.devicePixelRatio || 1;
      canvas.width = w * dpr; canvas.height = h * dpr;
      const ctx = canvas.getContext('2d'); ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, w, h);
      const pad = { l: 48, r: 8, t: 8, b: 19 }, cw = w - pad.l - pad.r, ch = h - pad.t - pad.b;
      const windowMsForAxis = periodMs[resourcePeriod] || periodMs['24h'];
      const maxValue = resourceChartMaximum(metric);
      const yFor = value => pad.t + ch - (Math.max(0, Math.min(maxValue, value)) / maxValue) * ch;
      const formatAxis = value => metric === 'cpu' ? `${Math.round(value)}%` : `${Number(value).toLocaleString('id-ID', { maximumFractionDigits: 2 })} GB`;
      ctx.font = '9px system-ui'; ctx.fillStyle = '#64748b'; ctx.strokeStyle = 'rgba(51,65,85,.45)'; ctx.lineWidth = 1;
      [0, 0.5, 1].forEach(fraction => {
        const value = maxValue * fraction, y = yFor(value);
        ctx.beginPath(); ctx.moveTo(pad.l, y); ctx.lineTo(w - pad.r, y); ctx.stroke();
        ctx.fillText(formatAxis(value), 1, y + 3);
      });
      if (points.length) {
        const windowMs = periodMs[resourcePeriod] || periodMs['24h'];
        const values = points.map(p => resourceChartValue(p, metric));
        // Garis memakai nilai asli. Rentang panjang hanya mengurangi jumlah titik
        // yang dirender berdasarkan lebar canvas, dengan min/max tiap bucket tetap dipertahankan.
        const displayPoints = decimateResourcePoints(points, values, cutoff, windowMs, cw);
        const coords = displayPoints.map(item => ({
          x: pad.l + Math.max(0, Math.min(1, (item.point.at - cutoff) / windowMs)) * cw,
          y: yFor(item.value)
        }));
        const rawCoords = points.map((p, i) => ({
          x: pad.l + Math.max(0, Math.min(1, (p.at - cutoff) / windowMs)) * cw,
          y: yFor(values[i])
        }));
        // Semua metrik memakai monotone cubic Hermite agar kurva halus seperti
        // grafik status provider, tetapi tetap melewati setiap sampel asli.
        // Tidak ada moving average atau perubahan pada nilai data.
        const traceResourceLine = (closeToBaseline = false) => {
          traceMonotoneCurve(ctx, coords, closeToBaseline, pad.t + ch);
        };
        traceResourceLine(true);
        ctx.fillStyle = color + '22'; ctx.fill();
        traceResourceLine(false);
        ctx.strokeStyle = color; ctx.lineWidth = 2.4; ctx.lineJoin = 'round'; ctx.lineCap = 'round'; ctx.stroke();

        const latest = values[values.length - 1], previous = values.length > 1 ? values[values.length - 2] : latest, delta = latest - previous;
        const selectedIndex = selectedAt == null ? -1 : points.findIndex(p => p.at === selectedAt);
        const valuePoint = selectedIndex >= 0 ? points[selectedIndex] : points[points.length - 1];
        const value = selectedIndex >= 0 ? values[selectedIndex] : latest;
        const valueEl = document.getElementById(valueId); if (valueEl) valueEl.textContent = formatResourceChartValue(value, metric);
        const trendEl = document.getElementById(trendId);
        if (trendEl) {
          trendEl.textContent = selectedIndex >= 0
            ? new Date(valuePoint.at).toLocaleString('id-ID', { dateStyle: 'medium', timeStyle: 'short' })
            : `${delta > 0 ? '+' : ''}${formatResourceChartValue(delta, metric)} dibanding sampel sebelumnya`;
          trendEl.style.color = selectedIndex >= 0 ? '#cbd5e1' : delta < 0 ? '#34d399' : delta > 0 ? '#f87171' : '#94a3b8';
        }
        if (selectedIndex >= 0) {
          const q = rawCoords[selectedIndex], label = new Date(valuePoint.at).toLocaleString('id-ID', { dateStyle: 'medium', timeStyle: 'short' });
          const val = formatResourceChartValue(value, metric);
          ctx.save(); ctx.strokeStyle = 'rgba(226,232,240,.65)'; ctx.lineWidth = 1; ctx.setLineDash([3, 3]);
          ctx.beginPath(); ctx.moveTo(q.x, pad.t); ctx.lineTo(q.x, pad.t + ch); ctx.stroke(); ctx.setLineDash([]);
          ctx.beginPath(); ctx.arc(q.x, q.y, 4, 0, Math.PI * 2); ctx.fillStyle = color; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = '#e2e8f0'; ctx.stroke();
          ctx.font = 'bold 10px system-ui'; const boxW = Math.min(250, Math.max(150, ctx.measureText(val).width + 16)), boxH = 37;
          const bx = Math.max(4, Math.min(w - boxW - 4, q.x - boxW / 2)), by = q.y < pad.t + 48 ? q.y + 10 : q.y - boxH - 10;
          ctx.fillStyle = 'rgba(15,23,42,.96)'; ctx.strokeStyle = color; ctx.lineWidth = 1; ctx.beginPath(); ctx.roundRect(bx, by, boxW, boxH, 7); ctx.fill(); ctx.stroke();
          ctx.fillStyle = '#cbd5e1'; ctx.font = '9px system-ui'; ctx.textAlign = 'left'; ctx.fillText(label, bx + 8, by + 13);
          ctx.fillStyle = '#fff'; ctx.font = 'bold 11px system-ui'; ctx.fillText(val, bx + 8, by + 28); ctx.restore();
        }
      } else {
        ctx.fillStyle = '#64748b'; ctx.textAlign = 'center'; ctx.fillText('Mengumpulkan data untuk periode ini…', w / 2, h / 2);
      }
      // Label waktu mengikuti rentang berjalan (rolling window), bukan batas pergantian tanggal.
      // 24H selalu memetakan 24 jam terakhir sampai saat ini; 7D/14D/28D menampilkan tanggal historis.
      ctx.fillStyle = '#64748b';
      const tickFractions = [0, 0.25, 0.5, 0.75, 1];
      tickFractions.forEach((fraction, index) => {
        const tickTime = cutoff + windowMsForAxis * fraction;
        const tickDate = new Date(tickTime);
        const label = resourcePeriod === '24h'
          ? tickDate.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
          : tickDate.toLocaleDateString('id-ID', { day: '2-digit', month: 'short' });
        const x = pad.l + cw * fraction;
        ctx.textAlign = index === 0 ? 'left' : index === tickFractions.length - 1 ? 'right' : 'center';
        ctx.fillText(label, x, h - 3);
      });
    }
    function drawResourceChart(){drawOneResourceChart('cpu','#60a5fa','cpu-history-chart','cpu-chart-value','cpu-trend');drawOneResourceChart('ram','#a78bfa','ram-history-chart','ram-chart-value','ram-trend');drawOneResourceChart('disk','#34d399','disk-history-chart','disk-chart-value','disk-trend');}
    const periodContainer = document.getElementById('resource-periods');
    if (periodContainer) periodContainer.addEventListener('click', async (event) => {
      const btn = event.target.closest('button.resource-period');
      if (!btn || !periodMs[btn.dataset.period]) return;
      event.preventDefault();
      resourcePeriod = btn.dataset.period;
      Object.keys(resourceChartSelection).forEach(key => delete resourceChartSelection[key]);
      periodContainer.querySelectorAll('button.resource-period').forEach(b => {
        const active = b === btn;
        b.classList.toggle('active', active);
        b.setAttribute('aria-pressed', String(active));
      });
      btn.disabled = true;
      try { await loadResourceHistory(); }
      finally { btn.disabled = false; }
    });
    ['cpu-history-chart','ram-history-chart','disk-history-chart'].forEach(canvasId=>{
      const canvas=document.getElementById(canvasId);if(!canvas)return;
      canvas.style.cursor='crosshair';canvas.style.touchAction='pan-y';
      const inspectPoint=(event)=>{
        const rect=canvas.getBoundingClientRect(), x=event.clientX-rect.left;
        const now=Date.now(), cutoff=now-(periodMs[resourcePeriod]||periodMs['24h']);
        const metric=canvasId.startsWith('cpu')?'cpu':canvasId.startsWith('ram')?'ram':'disk';
        const points=resourceHistory.filter(p=>p.at>=cutoff&&Number.isFinite(p[metric]));if(!points.length)return;
        const pad={l:48,r:8}, usable=Math.max(1,rect.width-pad.l-pad.r);
        const windowMs=periodMs[resourcePeriod]||periodMs['24h'];
        const rawTargetTime=cutoff+Math.max(0,Math.min(1,(x-pad.l)/usable))*windowMs;
        const targetTime=snapResourceCursorTime(rawTargetTime,resourcePeriod);
        let nearest=points[0];for(const point of points){if(Math.abs(point.at-targetTime)<Math.abs(nearest.at-targetTime))nearest=point;}
        resourceChartSelection[canvasId]=nearest.at;drawResourceChart();
      };
      canvas.addEventListener('pointerdown',event=>{if(event.pointerType==='touch')event.preventDefault();inspectPoint(event);});
      canvas.addEventListener('pointermove',event=>{if(event.pointerType==='mouse'||event.buttons||event.pointerType==='touch')inspectPoint(event);});
      canvas.addEventListener('pointerleave',event=>{if(event.pointerType==='mouse'){delete resourceChartSelection[canvasId];drawResourceChart();}});
      canvas.addEventListener('pointerup',()=>{if(window.matchMedia('(pointer: coarse)').matches){setTimeout(()=>{delete resourceChartSelection[canvasId];drawResourceChart();},3500);}});
    });
    window.addEventListener('resize',drawResourceChart);

    /* ========== LOAD DATA ========== */
    async function loadData() {
      document.getElementById('loading-indicator').classList.remove('hidden');
      try {
        const res = await fetch('/api/admin/users');
        if (res.status === 403) return window.location.href = '/';
        allUsers = await res.json();
        renderUsers(allUsers);
        const offlineEl = document.getElementById('stat-panel-offline'); if (offlineEl) offlineEl.textContent = allUsers.length;
        renderMonthlyUserStats(allUsers);
        renderDashboardOverview(allUsers);
        const dataDot = document.getElementById('overview-data-dot');
        if (dataDot) dataDot.className = 'w-2 h-2 rounded-full bg-emerald-400';
      } catch(e) { const status = document.getElementById('overview-data-status'); if(status) status.textContent = 'Gagal mengambil data administrasi'; const dot = document.getElementById('overview-data-dot'); if(dot) dot.className = 'w-2 h-2 rounded-full bg-red-500'; showToast('Gagal memuat data', 'error'); }
      document.getElementById('loading-indicator').classList.add('hidden');
    }

    async function refreshPanelPresence() {
      try { const r = await fetch('/api/admin/presence', {cache:'no-store'}); if (!r.ok) return; const data = await r.json(); const el=document.getElementById('stat-panel-online'); const onlineCount=Number(data.count)||0; if(el) el.textContent=onlineCount; const offlineEl=document.getElementById('stat-panel-offline'); if(offlineEl) offlineEl.textContent=Math.max(0,allUsers.length-onlineCount); const onlineNames=new Set(data.online||[]); allUsers.forEach(u=>u.isPanelOnline=onlineNames.has(u.username)); const q=(document.getElementById('search-input')?.value||'').trim().toLowerCase(); const visible=q?allUsers.filter(u=>u.username.toLowerCase().includes(q)||u.email.toLowerCase().includes(q)||u.servers.some(s=>s.name.toLowerCase().includes(q))):allUsers; renderUsers(visible); } catch (_) {}
    }
    refreshPanelPresence();
    setInterval(refreshPanelPresence, 30000);

    function filterUsers() {
      const q = document.getElementById('search-input').value.toLowerCase();
      if (!q) { renderUsers(allUsers); return; }
      const filtered = allUsers.filter(u =>
        u.username.toLowerCase().includes(q) ||
        u.email.toLowerCase().includes(q) ||
        u.servers.some(s => s.name.toLowerCase().includes(q))
      );
      renderUsers(filtered);
    }

    /* ========== RENDER USERS (ringkas — kelola server di halaman terpisah) ========== */
    function renderUsers(users) {
      document.querySelectorAll('.user-row').forEach(el => el.remove());
      let totalServers = 0, totalOnline = 0;

      if (users.length === 0) {
        document.getElementById('user-list').insertAdjacentHTML('beforeend', `<div class="user-row text-center py-16"><p class="text-slate-600 font-bold text-sm">Tidak ada user ditemukan</p><p class="text-slate-700 text-xs mt-1">Coba ubah kata kunci pencarian</p></div>`);
        if (users === allUsers) {
          document.getElementById('stat-users').textContent = '0';
          if (document.getElementById('stat-servers')) document.getElementById('stat-servers').textContent = '0';
          if (document.getElementById('stat-online')) document.getElementById('stat-online').textContent = '0';
          if (document.getElementById('stat-offline')) document.getElementById('stat-offline').textContent = '0';
          const activeEl = document.getElementById('stat-active-servers');
          if (activeEl) activeEl.textContent = '0';
        }
        return;
      }

      users.forEach(user => {
        const onlineCount = user.servers.filter(s => s.isOnline).length;
        totalServers += user.servers.length;
        totalOnline += onlineCount;

        const card = document.createElement('div');
        card.className = 'user-row fade-in cursor-pointer';
        card.title = 'Klik untuk kelola user & server';
        card.onclick = () => { window.location.href = '/admin/manageuser?user=' + encodeURIComponent(user.username); };
        card.innerHTML = `
          <div class="px-5 py-4 flex items-center gap-3">
            <div class="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-600/20 to-indigo-600/10 border border-blue-500/20 flex items-center justify-center font-black text-blue-300 text-sm flex-shrink-0 select-none">
              ${user.username.charAt(0).toUpperCase()}
            </div>
            <div class="min-w-0 flex-1">
              <div class="flex items-center gap-2 flex-wrap">
                <span class="font-black text-white text-sm">${user.username}</span>
                ${user.isAdmin ? '<span class="text-[9px] font-black px-1.5 py-0.5 rounded bg-red-500/15 text-red-400 border border-red-500/25">ADMIN</span>' : ''}
                <span class="inline-flex items-center gap-1 text-[9px] font-bold px-1.5 py-0.5 rounded border ${user.isPanelOnline ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-slate-800 text-slate-500 border-slate-700/50'}">
                  <span class="w-1.5 h-1.5 rounded-full ${user.isPanelOnline ? 'bg-emerald-400' : 'bg-slate-600'}"></span>
                  ${user.isPanelOnline ? 'Panel Online' : 'Offline'}
                </span>
              </div>
              <p class="text-[10px] text-slate-600 mt-0.5 truncate">${user.email} <span class="text-slate-700">·</span> ${user.servers.length} server</p>
            </div>
            <svg class="w-4 h-4 text-slate-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
          </div>`;
        document.getElementById('user-list').appendChild(card);
      });

      if (users === allUsers) {
        document.getElementById('stat-users').textContent = allUsers.length;
        if (document.getElementById('stat-servers')) document.getElementById('stat-servers').textContent = totalServers;
        if (document.getElementById('stat-online')) document.getElementById('stat-online').textContent = totalOnline;
        if (document.getElementById('stat-offline')) document.getElementById('stat-offline').textContent = totalServers - totalOnline;
        const activeEl = document.getElementById('stat-active-servers');
        if (activeEl) activeEl.textContent = totalOnline;
      }
    }

    /* ========== TOGGLE REGISTRASI ========== */
    let regEnabled = true;

    function setToggleUI(enabled) {
      regEnabled = enabled;
      const track = document.getElementById('toggle-reg-track');
      const thumb = document.getElementById('toggle-reg-thumb');
      if (enabled) {
        track.classList.remove('bg-slate-700');
        track.classList.add('bg-emerald-500');
        thumb.style.transform = 'translateX(28px)';
      } else {
        track.classList.add('bg-slate-700');
        track.classList.remove('bg-emerald-500');
        thumb.style.transform = 'translateX(0px)';
      }
      const btn = document.getElementById('toggle-reg-btn');
      const statusText = document.getElementById('registration-status-text');
      const statusDot = document.getElementById('registration-status-dot');
      if (btn) btn.setAttribute('aria-pressed', String(enabled));
      if (statusText) { statusText.textContent = enabled ? 'Registrasi sedang dibuka' : 'Registrasi sedang ditutup'; statusText.className = 'text-[11px] font-bold ' + (enabled ? 'text-emerald-400' : 'text-slate-400'); }
      if (statusDot) statusDot.className = 'w-2 h-2 rounded-full ' + (enabled ? 'bg-emerald-400' : 'bg-slate-500');
    }

    async function loadConfig() {
      try {
        const res = await fetch('/api/admin/config');
        const data = await res.json();
        setToggleUI(data.registrationEnabled !== false);
      } catch(e) {}
    }

    async function toggleRegistration() {
      const newVal = !regEnabled;
      try {
        const res = await fetch('/api/admin/config', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ registrationEnabled: newVal })
        });
        const data = await res.json();
        if (data.success) {
          setToggleUI(newVal);
          showToast(newVal ? 'Registrasi dibuka!' : 'Registrasi ditutup!', newVal ? 'success' : 'warning');
        }
      } catch(e) { showToast('Gagal mengubah pengaturan', 'error'); }
    }

    /* ========== SYSTEM STATS ========== */
    function fmtBytes(b) {
      if (b >= 1099511627776) return (b / 1099511627776).toFixed(2) + ' TiB';
      if (b >= 1073741824) return (b / 1073741824).toFixed(2) + ' GiB';
      if (b >= 1048576) return (b / 1048576).toFixed(1) + ' MiB';
      if (b >= 1024) return (b / 1024).toFixed(0) + ' KiB';
      return b + ' B';
    }
    function fmtUptime(s) {
      const d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60);
      if (d > 0) return `${d}d ${h}h ${m}m`;
      if (h > 0) return `${h}h ${m}m`;
      return `${m}m`;
    }
    function getBarColor(pct, colors) {
      if (pct >= 90) return colors[2];
      if (pct >= 70) return colors[1];
      return colors[0];
    }

    async function loadSystemStats() {
      try {
        const res = await fetch('/api/admin/system-stats', { cache: 'no-store' });
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const d = await res.json();
        const badge = document.getElementById('overview-system-badge');
        if (badge) { badge.textContent = 'NORMAL'; badge.className = 'text-[9px] font-bold px-2 py-1 rounded-full bg-emerald-500/10 text-emerald-300'; }
        const apiStatus = document.getElementById('overview-api-status');
        if (apiStatus) apiStatus.textContent = 'Endpoint resource merespons dengan normal';
        const apiDot = document.getElementById('overview-api-dot');
        if (apiDot) apiDot.className = 'w-2 h-2 rounded-full bg-emerald-400';

        const cores = d.cores || 1;
        resourceSystemInfo = { cores, ramTotal: Number(d.ramTotal) || 0, diskTotal: Number(d.diskTotal) || 0 };
        const cpuUsagePct = Math.max(0, Math.min(100, Number(d.cpu) || 0));
        const cpuBarPct = cpuUsagePct;
        const ramPct = Math.round((d.ramUsed / d.ramTotal) * 100);
        const diskPct = d.diskTotal > 0 ? Math.min((d.diskUsed / d.diskTotal) * 100, 100) : 0;
        // Riwayat berasal dari collector backend agar tetap berjalan saat browser ditutup.
        drawResourceChart();

        const setText = (id, value) => { const el = document.getElementById(id); if (el) el.textContent = value; };
        setText('resource-info-cores', `${cores} vCPU`);
        setText('resource-info-uptime', fmtUptime(d.uptime));
        setText('resource-info-cpu', `${formatCpuPercent(cpuUsagePct * cores)} / ${formatCpuPercent(cores * 100)}`);
        const liveLabel = document.getElementById('resource-live-label'); if (liveLabel) liveLabel.textContent = 'LIVE';
        document.getElementById('sys-cpu-pct').textContent = `${formatCpuPercent(cpuUsagePct * cores)} / ${formatCpuPercent(cores * 100)}`;
        document.getElementById('sys-cpu-bar').style.width = cpuBarPct + '%';
        document.getElementById('sys-cpu-bar').style.background = cpuBarPct >= 90
          ? 'linear-gradient(to right,#dc2626,#ef4444)'
          : cpuBarPct >= 70 ? 'linear-gradient(to right,#d97706,#f59e0b)'
          : 'linear-gradient(to right,#2563eb,#60a5fa)';
        document.getElementById('sys-cpu-sub').textContent = `${cores} core · kapasitas total CPU`;

        document.getElementById('sys-ram-pct').textContent = `${formatGiB(d.ramUsed)} / ${formatGiB(d.ramTotal)}`;
        document.getElementById('sys-ram-bar').style.width = ramPct + '%';
        document.getElementById('sys-ram-bar').style.background = ramPct >= 90
          ? 'linear-gradient(to right,#dc2626,#ef4444)'
          : ramPct >= 70 ? 'linear-gradient(to right,#d97706,#f59e0b)'
          : 'linear-gradient(to right,#7c3aed,#a78bfa)';
        document.getElementById('sys-ram-sub').textContent = `${ramPct}% terpakai`;

        document.getElementById('sys-disk-val').textContent = d.diskTotal > 0
          ? `${formatDiskCapacity(d.diskUsed)} / ${formatDiskCapacity(d.diskTotal)}`
          : formatDiskCapacity(d.diskUsed);
        document.getElementById('sys-disk-bar').style.width = diskPct + '%';
        document.getElementById('sys-disk-bar').style.background = diskPct >= 90
          ? 'linear-gradient(to right,#dc2626,#ef4444)'
          : diskPct >= 70 ? 'linear-gradient(to right,#d97706,#f59e0b)'
          : 'linear-gradient(to right,#059669,#34d399)';
        document.getElementById('sys-disk-sub').textContent = `${diskPct.toFixed(1)}% terpakai · folder server`;

        const coresEl = document.getElementById('sys-cores-label');
        const uptimeEl = document.getElementById('sys-uptime-label');
        const uptimeValue = document.getElementById('sys-uptime-value');
        const uptimeSub = document.getElementById('sys-uptime-sub');
        const dot = document.getElementById('sys-dot');
        const statusText = document.getElementById('sys-status-text');
        const statusIndicator = document.getElementById('sys-status-indicator');
        const lastUpdate = document.getElementById('sys-last-update');
        if (statusText) statusText.textContent = 'VPS ONLINE';
        if (statusIndicator) statusIndicator.className = 'w-1.5 h-1.5 rounded-full bg-emerald-400 live-dot';
        if (lastUpdate) lastUpdate.textContent = new Date(Number(d.sampledAt) || Date.now()).toLocaleTimeString('id-ID');
        dot.className = 'w-2 h-2 rounded-full bg-green-400 shadow shadow-green-500/50';
      } catch(e) {
        const sysDot = document.getElementById('sys-dot'); if (sysDot) sysDot.className = 'w-2 h-2 rounded-full bg-red-500';
        const statusText = document.getElementById('sys-status-text'); if (statusText) statusText.textContent = 'KONEKSI TERGANGGU';
        const statusIndicator = document.getElementById('sys-status-indicator'); if (statusIndicator) statusIndicator.className = 'w-1.5 h-1.5 rounded-full bg-red-400';
        const badge = document.getElementById('overview-system-badge'); if (badge) { badge.textContent = 'GANGGUAN'; badge.className = 'text-[9px] font-bold px-2 py-1 rounded-full bg-red-500/10 text-red-300'; }
        const apiStatus = document.getElementById('overview-api-status'); if (apiStatus) apiStatus.textContent = 'Endpoint resource tidak merespons';
        const apiDot = document.getElementById('overview-api-dot'); if (apiDot) apiDot.className = 'w-2 h-2 rounded-full bg-red-500';
      }
    }

    // Refresh angka resource dan grafik setiap 5 detik mengikuti interval sampel server.
    let systemStatsTimer = null;
    let resourceHistoryTimer = null;
    let systemStatsLoading = false;
    let resourceHistoryLoading = false;

    async function refreshSystemStatsSafely() {
      if (systemStatsLoading || document.hidden) return;
      systemStatsLoading = true;
      try { await loadSystemStats(); }
      finally { systemStatsLoading = false; }
    }

    async function refreshResourceHistorySafely() {
      if (resourceHistoryLoading || document.hidden) return;
      resourceHistoryLoading = true;
      try { await loadResourceHistory(); }
      finally { resourceHistoryLoading = false; }
    }

    function startResourceAutoRefresh() {
      clearInterval(systemStatsTimer);
      clearInterval(resourceHistoryTimer);
      refreshSystemStatsSafely();
      refreshResourceHistorySafely();
      systemStatsTimer = setInterval(refreshSystemStatsSafely, 5 * 60 * 1000);
      resourceHistoryTimer = setInterval(refreshResourceHistorySafely, 5 * 60 * 1000);
    }

    startResourceAutoRefresh();
    document.addEventListener('visibilitychange', () => {
      // Refresh resource mengikuti interval 5 menit.
    });
    window.addEventListener('online', () => {
      refreshSystemStatsSafely();
      refreshResourceHistorySafely();
    });

    loadConfig();
    loadData();

    /* ========== CREATE USER ========== */
    function openCreateUserModal() {
      document.getElementById('cu-username').value = '';
      document.getElementById('cu-email').value = '';
      document.getElementById('cu-password').value = '';
      document.getElementById('cu-password').type = 'password';
      const err = document.getElementById('cu-error');
      err.classList.add('hidden'); err.textContent = '';
      document.getElementById('modal-create-user').classList.remove('hidden');
      setTimeout(() => document.getElementById('cu-username').focus(), 100);
    }

    function closeCreateUserModal() {
      document.getElementById('modal-create-user').classList.add('hidden');
    }

    async function executeCreateUser() {
      const username = document.getElementById('cu-username').value.trim();
      const email = document.getElementById('cu-email').value.trim();
      const password = document.getElementById('cu-password').value;
      const errEl = document.getElementById('cu-error');
      const btn = document.getElementById('cu-btn');
      errEl.classList.add('hidden');
      if (!username || !email || !password) { errEl.textContent = 'Semua field wajib diisi.'; errEl.classList.remove('hidden'); return; }
      btn.textContent = 'Membuat...'; btn.disabled = true;
      try {
        const res = await fetch('/api/admin/create-user', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username, email, password })
        });
        const data = await res.json();
        if (res.ok) {
          showToast(`User "${username}" berhasil dibuat!`, 'success');
          closeCreateUserModal();
          loadData();
        } else {
          errEl.textContent = data.error || 'Gagal membuat user.';
          errEl.classList.remove('hidden');
        }
      } catch(e) { errEl.textContent = 'Error jaringan.'; errEl.classList.remove('hidden'); }
      btn.textContent = 'Buat User'; btn.disabled = false;
    }

    document.getElementById('modal-create-user').addEventListener('click', function(e) { if (e.target === this) closeCreateUserModal(); });

    /* ========== CREATE SERVER FOR USERS ========== */
    let csSelectedUsers = new Set();

    function openCreateServerModal() {
      document.getElementById('cs-server-name').value = '';
      document.getElementById('cs-engine').value = 'java';
      document.getElementById('cs-ram').value = '3072';
      document.getElementById('cs-cpu').value = '200';
      document.getElementById('cs-disk').value = '10240';
      const errEl = document.getElementById('cs-error');
      const resEl = document.getElementById('cs-result');
      errEl.classList.add('hidden'); errEl.textContent = '';
      resEl.classList.add('hidden'); resEl.innerHTML = '';
      csSelectedUsers = new Set();
      document.getElementById('cs-selected-count').textContent = '0';
      const btn = document.getElementById('cs-btn');
      btn.textContent = 'Buat Server'; btn.disabled = false;
      csRenderUserList();
      document.getElementById('modal-create-server').classList.remove('hidden');
      setTimeout(() => document.getElementById('cs-server-name').focus(), 100);
    }

    function closeCreateServerModal() {
      document.getElementById('modal-create-server').classList.add('hidden');
    }

    function csRenderUserList() {
      const listEl = document.getElementById('cs-user-list');
      if (!allUsers || allUsers.length === 0) {
        listEl.innerHTML = '<p class="text-slate-500 text-xs text-center py-4">Tidak ada user tersedia.</p>';
        return;
      }
      listEl.innerHTML = allUsers.map(u => `
        <label class="flex items-center gap-3 p-2 rounded-lg hover:bg-slate-800 cursor-pointer transition group">
          <input type="checkbox" class="cs-user-cb w-4 h-4 accent-blue-500 cursor-pointer flex-shrink-0" value="${u.username}" onchange="csToggleUser('${u.username}', this.checked)">
          <div class="min-w-0">
            <span class="text-sm font-bold text-white">${u.username}</span>
            <span class="text-xs text-slate-500 ml-1.5">${u.email || ''}</span>
          </div>
          <span class="ml-auto text-[10px] text-slate-600 font-mono flex-shrink-0">${u.servers.length} server</span>
        </label>
      `).join('');
    }

    function csToggleUser(username, checked) {
      if (checked) csSelectedUsers.add(username);
      else csSelectedUsers.delete(username);
      document.getElementById('cs-selected-count').textContent = csSelectedUsers.size;
    }

    function csSelectAll() {
      csSelectedUsers = new Set(allUsers.map(u => u.username));
      document.querySelectorAll('.cs-user-cb').forEach(cb => { cb.checked = true; });
      document.getElementById('cs-selected-count').textContent = csSelectedUsers.size;
    }

    function csSelectNone() {
      csSelectedUsers = new Set();
      document.querySelectorAll('.cs-user-cb').forEach(cb => { cb.checked = false; });
      document.getElementById('cs-selected-count').textContent = '0';
    }

    async function executeCreateServer() {
      const serverName = document.getElementById('cs-server-name').value.trim();
      const errEl = document.getElementById('cs-error');
      const resEl = document.getElementById('cs-result');
      const btn = document.getElementById('cs-btn');
      errEl.classList.add('hidden');
      resEl.classList.add('hidden');
      if (!serverName) { errEl.textContent = 'Nama server wajib diisi.'; errEl.classList.remove('hidden'); return; }
      if (!/^[a-zA-Z0-9_-]+$/.test(serverName)) { errEl.textContent = 'Nama hanya boleh huruf, angka, strip (-), underscore (_).'; errEl.classList.remove('hidden'); return; }
      if (csSelectedUsers.size === 0) { errEl.textContent = 'Pilih minimal satu user.'; errEl.classList.remove('hidden'); return; }
      const engine = document.getElementById('cs-engine').value;
      const ram = document.getElementById('cs-ram').value;
      const cpu = document.getElementById('cs-cpu').value;
      const disk = document.getElementById('cs-disk').value;
      btn.textContent = 'Membuat...'; btn.disabled = true;
      try {
        const res = await fetch('/api/admin/create-server-for-users', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ serverName, usernames: Array.from(csSelectedUsers), engine, ram, cpu, disk })
        });
        const data = await res.json();
        if (res.ok) {
          const successList = data.results.filter(r => r.success);
          const failList = data.results.filter(r => !r.success);
          resEl.innerHTML = [
            ...successList.map(r => `<div class="text-green-400">✓ ${r.username} — server "${serverName}" dibuat</div>`),
            ...failList.map(r => `<div class="text-red-400">✗ ${r.username} — ${r.error}</div>`)
          ].join('');
          resEl.classList.remove('hidden');
          if (successList.length > 0) {
            showToast(`${successList.length} server berhasil dibuat!`, 'success');
            loadData();
          }
        } else {
          errEl.textContent = data.error || 'Gagal membuat server.';
          errEl.classList.remove('hidden');
        }
      } catch(e) { errEl.textContent = 'Error jaringan.'; errEl.classList.remove('hidden'); }
      btn.textContent = 'Buat Server'; btn.disabled = false;
    }



    document.getElementById('modal-create-server').addEventListener('click', function(e) { if (e.target === this) closeCreateServerModal(); });
