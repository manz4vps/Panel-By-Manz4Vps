// Service worker minimal — cuma buat bisa manggil registration.showNotification(),
// karena di Chrome Android, `new Notification()` langsung dari halaman itu DIBLOKIR;
// notif WAJIB lewat Service Worker biar bisa muncul + bunyi walau tab udah di-refresh.
self.addEventListener('install', (e) => { self.skipWaiting(); });
self.addEventListener('activate', (e) => { e.waitUntil(self.clients.claim()); });
