// Manz4VPS PWA Service Worker — v21
// Cache aset statis agar kunjungan berikutnya dan perpindahan halaman lebih cepat.
// Halaman HTML, API, autentikasi, dan Socket.IO TIDAK disimpan agar data akun selalu fresh.

const CACHE_NAME = 'manz4vps-static-v23';
const PRECACHE = [
  '/panel.css',
  '/panel.js',
  '/console.js',
  '/filemanager.js',
  '/panel-common.js',
  '/admin.js',
  '/serverport.js',
  '/manifest.json',
  '/login',
  '/logo.png'
];

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    // Cache aset satu per satu; satu file yang gagal tidak menggagalkan instalasi SW.
    await Promise.all(PRECACHE.map(async path => {
      try {
        const response = await fetch(path, { cache: 'reload' });
        if (response.ok) await cache.put(path, response);
      } catch (_) {}
    }));
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(key => key.startsWith('manz4vps-') && key !== CACHE_NAME)
      .map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);

  // Jangan cache API, endpoint autentikasi, data server, atau koneksi realtime.
  if (url.origin === self.location.origin &&
      (url.pathname.startsWith('/api/') || url.pathname.startsWith('/socket.io/'))) return;

  // Halaman login: network-first agar tetap terbaru, cache sebagai fallback saat offline.
  // Login HTML hanya shell tampilan; endpoint POST /login dan seluruh API tetap tidak di-cache.
  if (request.mode === 'navigate' || request.destination === 'document') {
    if (url.origin === self.location.origin &&
        (url.pathname === '/' || url.pathname === '/login' || url.pathname === '/login/')) {
      event.respondWith((async () => {
        const cache = await caches.open(CACHE_NAME);
        try {
          const response = await fetch(request);
          if (response.ok) {
            try {
              await cache.put('/login', response.clone());
              await cache.put('/', response.clone());
            } catch (_) {}
          }
          return response;
        } catch (_) {
          const cached = await cache.match('/login') || await cache.match('/');
          return cached || new Response('Halaman login belum tersimpan. Sambungkan internet lalu buka kembali.', {
            status: 503, headers: { 'Content-Type': 'text/plain; charset=utf-8' }
          });
        }
      })());
    }
    // Dashboard/admin tetap dari server agar data dan hak akses selalu terbaru.
    return;
  }

  const isStaticAsset =
    ['script', 'style', 'image', 'font', 'worker'].includes(request.destination) ||
    /\.(?:js|css|png|jpe?g|gif|svg|ico|woff2?|ttf|otf|webp)(?:\?.*)?$/i.test(url.href);

  if (!isStaticAsset) return;

  event.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);
    const cached = await cache.match(request);
    if (cached) return cached;

    try {
      const response = await fetch(request);
      // Cache respons sukses, termasuk CDN cross-origin bertipe opaque.
      if (response.ok || response.type === 'opaque') {
        try { await cache.put(request, response.clone()); } catch (_) {}
      }
      return response;
    } catch (error) {
      if (cached) return cached;
      return new Response('', { status: 503, statusText: 'Asset unavailable offline' });
    }
  })());
});
