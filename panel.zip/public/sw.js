// ─────────────────────────────────────────────────────────────
// Manz4VPS Service Worker — v2
// Strategi:
//   • Static assets (JS/CSS/font/image) → Cache-First
//   • HTML pages                        → Network-First + cache fallback
//   • /api/* dan /socket.io/*           → Network only (jangan di-cache)
// ─────────────────────────────────────────────────────────────

const CACHE = 'manz4vps-v2';

const PRECACHE = [
  '/login',
  '/dashboard',
  '/panel.css',
  '/panel.js',
  '/console.js',
  '/filemanager.js',
  '/panel-common.js',
  '/manifest.json',
];

// ── Install: cache aset penting ──
self.addEventListener('install', e => {
  self.skipWaiting();
  e.waitUntil(
    caches.open(CACHE)
      .then(c => c.addAll(PRECACHE).catch(() => {})) // abaikan error per-item
  );
});

// ── Activate: hapus cache lama ──
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(
        keys.filter(k => k !== CACHE).map(k => caches.delete(k))
      ))
      .then(() => self.clients.claim())
  );
});

// ── Fetch ──
self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return; // hanya GET

  const url = new URL(req.url);

  // 1. API & Socket.IO → network only, jangan sentuh cache
  if (url.pathname.startsWith('/api/') || url.pathname.startsWith('/socket.io/')) return;

  // 2. Static assets (JS, CSS, font, gambar, dll) → Cache-First
  const isStatic = /\.(js|css|png|jpg|jpeg|gif|svg|ico|woff2?|ttf|otf|webp)(\?.*)?$/.test(url.pathname)
                || url.hostname !== self.location.hostname; // CDN / external
  if (isStatic) {
    e.respondWith(
      caches.match(req).then(cached => {
        if (cached) return cached;
        return fetch(req).then(res => {
          if (res.ok) {
            const clone = res.clone();
            caches.open(CACHE).then(c => c.put(req, clone));
          }
          return res;
        }).catch(() => cached || new Response('', { status: 503 }));
      })
    );
    return;
  }

  // 3. HTML pages → Network-First, fallback ke cache
  e.respondWith(
    fetch(req).then(res => {
      if (res.ok) {
        const clone = res.clone();
        caches.open(CACHE).then(c => c.put(req, clone));
      }
      return res;
    }).catch(() =>
      caches.match(req).then(cached =>
        cached || new Response(
          '<!DOCTYPE html><html><body style="background:#0f172a;color:#94a3b8;font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0"><div style="text-align:center"><p style="font-size:2rem;margin-bottom:8px">📡</p><p style="font-weight:700">Tidak ada koneksi internet</p><p style="font-size:0.8rem;margin-top:4px">Buka kembali setelah ada koneksi</p></div></body></html>',
          { status: 503, headers: { 'Content-Type': 'text/html' } }
        )
      )
    )
  );
});
