/* =========================================
 MODULE: PANEL CORE & SETTINGS (FRONTEND)
 ========================================= */

// Resolve server ID from URL FIRST — needed for socket query & fetch interceptor
function getPanelServerId() {
 const m = window.location.pathname.match(/^\/server\/([^\/]+)/);
 return m ? m[1] : null;
}
const PANEL_SERVER_ID = getPanelServerId();

// Patch global fetch to auto-inject X-Panel-Server-Id header for all internal /api/ calls.
// This isolates each browser tab to its own server regardless of what the session says.
(function _patchFetch() {
 const _orig = window.fetch.bind(window);
 window.fetch = function(resource, opts) {
  try {
   const urlStr = typeof resource === 'string' ? resource
    : (resource instanceof URL ? resource.href : (resource && resource.url) ? resource.url : '');
   if (PANEL_SERVER_ID && urlStr && /^\/api\//.test(urlStr)) {
    opts = opts ? Object.assign({}, opts) : {};
    opts.headers = Object.assign({}, opts.headers || {}, { 'X-Panel-Server-Id': PANEL_SERVER_ID });
   }
  } catch(e) {}
  return _orig(resource, opts);
 };
})();

const socket = io({
 reconnection: true,
 reconnectionAttempts: Infinity,
 reconnectionDelay: 2000,
 reconnectionDelayMax: 10000,
 timeout: 60000,
 transports: ['websocket', 'polling'],
 query: { panelServerId: PANEL_SERVER_ID || '' }
});

const URL_TO_TAB = { console: 'console', files: 'files', filemanager: 'files', network: 'network', startup: 'startup', plugins: 'plugins', plugin: 'plugins', mods: 'mods', mod: 'mods', settings: 'settings', versions: 'versions' };
const TAB_TO_URL = { console: 'console', files: 'files', network: 'network', startup: 'startup', plugins: 'plugin', mods: 'mod', settings: 'settings', versions: 'versions', edit: 'files' };
function tabUrlPath(tab) {
 const seg = TAB_TO_URL[tab] || 'console';
 return PANEL_SERVER_ID ? `/server/${PANEL_SERVER_ID}/${seg}` : '/dashboard';
}
function getTabFromPath() {
 const m = window.location.pathname.match(/^\/server\/[^\/]+\/([^\/]+)/);
 const urlTab = m ? m[1] : 'console';
 return URL_TO_TAB[urlTab] || 'console';
}

let globalStartTime = null;
let isServerOnline = false;
let serverStatus = 'offline';
let currentDiskUsedMB = 0;
let isStoppingServer = false;
let settingsCache = null;
let _allVmVersions = [];
let currentServerRamMB = 2048;
let currentServerCpuLimit = 100;
let currentServerDiskLimitMB = 32768;

// ── Connection Manager ──────────────────────────────────────────
const _conn = {
 hasConnected: false,
 leaving: false,
 isDisconnected: false,
 bannerTimer: null,
 attempt: 0
};

['beforeunload', 'pagehide'].forEach(ev =>
 window.addEventListener(ev, () => { _conn.leaving = true; })
);
window.addEventListener('pageshow', () => { _conn.leaving = false; });
document.addEventListener('visibilitychange', () => {
 if (!document.hidden) _conn.leaving = false;
});

(function _initBanner() {
 const s = document.createElement('style');
 s.textContent = [
  '@keyframes _rc_spin{to{transform:rotate(360deg)}}',
  '#rc-banner{position:fixed;top:0;left:0;right:0;z-index:99999;background:#dc2626;',
  'color:#fff;display:none;align-items:center;justify-content:center;gap:10px;',
  'padding:10px 16px;font-size:13px;font-weight:700;',
  'box-shadow:0 2px 12px rgba(0,0,0,.5);}',
  '.rc-spinner{width:14px;height:14px;border:2px solid rgba(255,255,255,.35);',
  'border-top-color:#fff;border-radius:50%;',
  'animation:_rc_spin .8s linear infinite;flex-shrink:0}'
 ].join('');
 document.head.appendChild(s);
 const el = document.createElement('div');
 el.id = 'rc-banner';
 el.innerHTML = '<div class="rc-spinner"></div><span id="rc-banner-text">Koneksi terputus — mencoba menghubungkan kembali...</span>';
 document.body.appendChild(el);
})();

function _setControlsDisabled(disabled) {
 ['startBtn', 'restartBtn', 'stopBtn', 'cmdInput'].forEach(id => {
  const el = document.getElementById(id);
  if (!el) return;
  el.disabled = disabled;
  if (disabled) el.classList.add('opacity-40', 'cursor-not-allowed');
  else el.classList.remove('opacity-40', 'cursor-not-allowed');
 });
}

function _showBanner(attempt) {
 const el = document.getElementById('rc-banner');
 if (el) {
  const txt = document.getElementById('rc-banner-text');
  if (txt) {
   txt.textContent = (attempt && attempt > 1)
    ? 'Koneksi terputus — percobaan ke-' + attempt + '...'
    : 'Koneksi terputus — mencoba menghubungkan kembali...';
  }
  el.style.display = 'flex';
 }
 const overlay = document.getElementById('term-reconnect-overlay');
 if (overlay) overlay.classList.remove('hidden');
 _setControlsDisabled(true);
}

function _hideBanner() {
 clearTimeout(_conn.bannerTimer);
 _conn.bannerTimer = null;
 const el = document.getElementById('rc-banner');
 if (el) el.style.display = 'none';
 const overlay = document.getElementById('term-reconnect-overlay');
 if (overlay) overlay.classList.add('hidden');
 _setControlsDisabled(false);
}

function _triggerDisconnect() {
 if (_conn.leaving) return;
 _conn.isDisconnected = true;
 clearTimeout(_conn.bannerTimer);
 _showBanner(_conn.attempt);
}

socket.on('connect', () => {
 _conn.hasConnected = true;
 _conn.isDisconnected = false;
 _conn.attempt = 0;
 _hideBanner();
});

socket.on('panel_error', (data) => {
 if (typeof showToast === 'function') showToast(data.message || 'Terjadi error pada panel.', 'error');
});

socket.on('disconnect', (reason) => {
 if (_conn.leaving) return;
 if (reason === 'io server disconnect') setTimeout(() => socket.connect(), 1000);
 _triggerDisconnect();
});

socket.on('connect_error', () => {
 if (_conn.leaving) return;
 _triggerDisconnect();
});

socket.on('reconnect_attempt', (attempt) => {
 _conn.attempt = attempt;
 if (_conn.isDisconnected && !_conn.leaving) _showBanner(attempt);
});

socket.on('reconnect_failed', () => {
 if (_conn.leaving) return;
 const txt = document.getElementById('rc-banner-text');
 if (txt) txt.textContent = 'Koneksi gagal — coba refresh halaman ini.';
 _showBanner();
});

socket.on('server_ready', () => {
 serverStatus = 'running';
 setStartButtonEnabled(false);
 setStopButtonEnabled(true);
 _applyUptimeState('online');
 // sound notifikasi dihapus
});

function updateJvmVisibility(engine) {
 const isJava = (engine !== 'node' && engine !== 'python');
 const jvmSection = document.getElementById('jvm-flags-section');
 const dockerSection = document.getElementById('docker-image-section');
 if (dockerSection) dockerSection.style.display = '';
 if (jvmSection) jvmSection.style.display = isJava ? '' : 'none';
}

// Hanya tampilkan rilis Minecraft stabil (contoh: 1.21.11).
// Prerelease seperti pre, rc, snapshot, beta, dan alpha disembunyikan.
function _isStableGameVersion(version) {
 return /^\d+(?:\.\d+){1,2}$/.test(String(version || '').trim());
}

function _parseMcVer(v) { return v.split('.').map(part => { const m = part.match(/^\d+/); return m ? parseInt(m[0]) : 0; }); }
function _cmpMcVer(a,b) { const pa=_parseMcVer(a),pb=_parseMcVer(b); for(let i=0;i<3;i++){const d=(pa[i]||0)-(pb[i]||0);if(d!==0)return d;} return 0; }
function _requiredJavaForMc(v) {
 if(_cmpMcVer(v,'1.16.99')<=0) return 8;
 if(_cmpMcVer(v,'1.17.0')>=0 && _cmpMcVer(v,'1.20.4')<=0) return 17;
 if(_cmpMcVer(v,'1.20.5')>=0 && _cmpMcVer(v,'1.21.99')<=0) return 21;
 if(_cmpMcVer(v,'1.22.0')>=0) return 25;
 return 21;
}

function filterVersionsByJava() {
 const versionSelect = document.getElementById('vm-version');
 if (!versionSelect || _allVmVersions.length === 0) return;
 const cat = document.getElementById('vm-category')?.value;
 if (cat !== 'mc-java') return;
 const jvEl = document.getElementById('set-java-version');
 const jv = jvEl ? parseInt(jvEl.value) : 21;
 const filtered = _allVmVersions.filter(v => _requiredJavaForMc(v) === jv);
 if (filtered.length === 0) {
  versionSelect.innerHTML = `<option value="">Tidak ada versi MC untuk Java ${jv}</option>`;
 } else {
  versionSelect.innerHTML = filtered.map(v => `<option value="${v}">${v}</option>`).join('');
 }
}
// ───────────────────────────────────────────────────────────────

function parseRamToMB(ramStr) {
 if (ramStr === undefined || ramStr === null || String(ramStr).trim() === '') return 2048;
 let val = parseFloat(ramStr.replace(/[^0-9.]/g, ''));
 let str = ramStr.toUpperCase();
 if (str.includes('G')) return Math.round(val * 1024);
 if (str.includes('M')) return Math.round(val);
 return Math.round(val);
}

function showToast(message, type = 'success') {
 // Panel hanya menampilkan error; toast sukses/proses/peringatan disembunyikan agar UI tetap bersih.
 if (type !== 'error') return;
 const overlay = document.getElementById('running-installer-overlay');
 if (overlay && !overlay.classList.contains('hidden')) return;
 const container = document.getElementById('toast-container');
 if (!container) return;
 if (container.children.length >= 3) container.removeChild(container.lastChild);
 let cleanMsg = message.replace(/^[^\x20-\x7E\xA0-\uD7FF\uE000-\uFFFD]+\s*/u, '').trim();
 const isSuccess = type === 'success';
 const isWarning = type === 'warning';
 const borderColor = isSuccess ? 'border-green-500/40' : isWarning ? 'border-yellow-500/40' : 'border-red-500/40';
 const iconBg = isSuccess ? 'bg-green-500/20 text-green-400' : isWarning ? 'bg-yellow-500/20 text-yellow-400' : 'bg-red-500/20 text-red-400';
 const barColor = isSuccess ? 'bg-green-500' : isWarning ? 'bg-yellow-500' : 'bg-red-500';
 const icon = isSuccess ? '<svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"/></svg>' : '<svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v4m0 4h.01M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/></svg>';
 const toast = document.createElement('div');
 toast.className = `relative bg-[#1e293b] border ${borderColor} text-white px-3 py-2.5 rounded-xl flex items-center gap-2.5 shadow-2xl shadow-black/40 backdrop-blur-sm overflow-hidden`;
 toast.style.cssText = 'animation:toastIn 0.3s cubic-bezier(0.34,1.56,0.64,1);';
 toast.innerHTML = `<div class="w-6 h-6 rounded-full ${iconBg} flex items-center justify-center font-black text-sm flex-shrink-0">${icon}</div><span class="text-[12px] font-semibold leading-snug flex-1">${cleanMsg}</span><button onclick="this.closest('.toast-item') ? this.closest('.toast-item').remove() : this.parentElement.remove()" class="text-slate-500 hover:text-white transition text-base leading-none flex-shrink-0 ml-0.5">×</button><div class="absolute bottom-0 left-0 h-[2px] ${barColor} toast-bar rounded-full" style="width:100%;transition:width 4s linear;"></div>`;
 container.insertBefore(toast, container.firstChild);
 requestAnimationFrame(() => { requestAnimationFrame(() => { const bar = toast.querySelector('.toast-bar'); if (bar) bar.style.width = '0%'; }); });
 const autoRemove = setTimeout(() => { toast.style.animation = 'toastOut 0.3s ease-in forwards'; setTimeout(() => toast.remove(), 300); }, 4200);
 toast.querySelector('button').addEventListener('click', () => { clearTimeout(autoRemove); toast.style.animation = 'toastOut 0.3s ease-in forwards'; setTimeout(() => toast.remove(), 300); });
}
function copyIp() { const ipEl = document.getElementById('stat-ip-text'); if(!ipEl) return; const ipText = ipEl.innerText; if (!ipText || ipText === 'Memuat...' || ipText === 'Offline') return; if (navigator.clipboard && window.isSecureContext) { navigator.clipboard.writeText(ipText).then(() => showToast(' IP disalin', 'success')).catch(err => {}); } else { let textArea = document.createElement("textarea"); textArea.value = ipText; textArea.style.position = "fixed"; textArea.style.opacity = "0"; document.body.appendChild(textArea); textArea.focus(); textArea.select(); try { if (document.execCommand('copy')) showToast(' IP disalin', 'success'); } catch (err) {} document.body.removeChild(textArea); } }
let _dropdownScrollHandler = null;
function toggleMenu(event, menuId) {
  event.stopPropagation();
  closeAllDropdowns();
  const menu = document.getElementById(menuId);
  if (menu) {
    const btn = event.currentTarget || event.target.closest('button') || event.target;
    const rect = btn.getBoundingClientRect();

    // Tampilkan dulu agar ukuran menu (termasuk tombol Delete) bisa diukur.
    menu.style.position = 'fixed';
    menu.style.visibility = 'hidden';
    menu.style.top = '0px';
    menu.style.right = 'auto';
    menu.style.left = '0px';
    menu.style.zIndex = '9999';
    menu.classList.remove('hidden');

    const menuRect = menu.getBoundingClientRect();
    const margin = 10;
    const gap = 6;
    const viewportHeight = window.innerHeight;
    const viewportWidth = window.innerWidth;

    // Jika ruang di bawah tombol tidak cukup, buka ke atas.
    const spaceBelow = viewportHeight - rect.bottom - margin;
    const spaceAbove = rect.top - margin;
    const openAbove = menuRect.height > spaceBelow && spaceAbove > spaceBelow;
    let top = openAbove
      ? rect.top - menuRect.height - gap
      : rect.bottom + gap;

    // Batasi posisi agar seluruh menu tetap berada di dalam layar.
    top = Math.max(margin, Math.min(top, viewportHeight - menuRect.height - margin));

    // Rata kanan dengan tombol, tetapi jangan sampai keluar dari sisi layar.
    let left = rect.right - menuRect.width;
    left = Math.max(margin, Math.min(left, viewportWidth - menuRect.width - margin));

    menu.style.top = top + 'px';
    menu.style.left = left + 'px';
    menu.style.right = 'auto';
    menu.style.visibility = 'visible';

    // Auto-close saat user scroll agar popup tidak tertinggal di posisi lama.
    if (_dropdownScrollHandler) window.removeEventListener('scroll', _dropdownScrollHandler, true);
    _dropdownScrollHandler = () => closeAllDropdowns();
    window.addEventListener('scroll', _dropdownScrollHandler, { capture: true, passive: true });
  }
}
function closeAllDropdowns() {
  document.querySelectorAll('.dropdown-menu').forEach(el => {
    el.classList.add('hidden');
    el.style.position = '';
    el.style.top = '';
    el.style.right = '';
    el.style.left = '';
    el.style.zIndex = '';
  });
  if (_dropdownScrollHandler) {
    window.removeEventListener('scroll', _dropdownScrollHandler, true);
    _dropdownScrollHandler = null;
  }
}

const _defaultTermVh = () => (window.innerWidth >= 768) ? 38 : 42;
let termZoomLevel = parseInt(localStorage.getItem('termZoomVh')) || _defaultTermVh();
function termZoom(delta) {
 termZoomLevel = Math.min(90, Math.max(15, termZoomLevel + delta));
 const wrapper = document.getElementById('terminal-wrapper');
 const label = document.getElementById('termZoomLabel');
 if (wrapper) wrapper.style.height = termZoomLevel + 'vh';
 if (label) label.textContent = termZoomLevel + 'vh';
 localStorage.setItem('termZoomVh', termZoomLevel);
}
function initTermZoom() {
 const wrapper = document.getElementById('terminal-wrapper');
 const label = document.getElementById('termZoomLabel');
 if (wrapper) wrapper.style.height = termZoomLevel + 'vh';
 if (label) label.textContent = termZoomLevel + 'vh';
}
function resetStopButton() { isStoppingServer = false; const stopBtn = document.getElementById('stopBtn'); if(stopBtn) { stopBtn.innerText = "Stop"; stopBtn.classList.remove('bg-red-800', 'hover:bg-red-700'); stopBtn.classList.add('bg-red-600', 'hover:bg-red-500'); } }
function setStopButtonKillMode() { isStoppingServer = true; const stopBtn = document.getElementById('stopBtn'); if(stopBtn) { stopBtn.innerText = "Kill"; stopBtn.classList.remove('bg-red-600', 'hover:bg-red-500'); stopBtn.classList.add('bg-red-800', 'hover:bg-red-700'); } }
function setStopButtonEnabled(enabled) {
 const stopBtn = document.getElementById('stopBtn');
 if (!stopBtn) return;
 if (enabled) {
  stopBtn.disabled = false;
  stopBtn.classList.remove('opacity-40', 'cursor-not-allowed', 'pointer-events-none');
 } else {
  stopBtn.disabled = true;
  stopBtn.classList.add('opacity-40', 'cursor-not-allowed', 'pointer-events-none');
  if (typeof resetStopButton === 'function') resetStopButton();
 }
}

// Tombol Start hanya aktif saat server benar-benar offline.
function setStartButtonEnabled(enabled) {
 const startBtn = document.getElementById('startBtn');
 if (!startBtn) return;
 startBtn.disabled = !enabled;
 if (enabled) startBtn.classList.remove('opacity-40', 'cursor-not-allowed', 'pointer-events-none');
 else startBtn.classList.add('opacity-40', 'cursor-not-allowed', 'pointer-events-none');
}

function syncPowerButtons(status, startTime) {
 const active = (status && status !== 'offline' && status !== 'stopped') || startTime != null;
 setStartButtonEnabled(!active);
 setStopButtonEnabled(active);
}

const formatMB = (mb) => { if (!mb || mb === 0) return '0 Bytes'; if (mb >= 1024) return parseFloat((mb / 1024).toFixed(2)) + ' GiB'; return parseFloat(mb.toFixed(2)) + ' MiB'; };
window.ramLimitMB = 2048; 

Chart.defaults.color = '#9ca3af'; Chart.defaults.font.family = 'Inter, sans-serif';
const MAX_DATA_POINTS = 32; 
let chartLabels = Array(MAX_DATA_POINTS).fill(''); let cpuData = Array(MAX_DATA_POINTS).fill(0); let ramData = Array(MAX_DATA_POINTS).fill(0);
let netInSpeedData = Array(MAX_DATA_POINTS).fill(0); let netOutSpeedData = Array(MAX_DATA_POINTS).fill(0);

// CONFIG GRAFIK: 120FPS + TEMBUS DINDING + ANGKA KIRI 
const commonChartOptions = { 
 responsive: true, 
 maintainAspectRatio: false, 
 animation: { duration: 1000, easing: 'linear' }, 
 events: [], 
 layout: { padding: { left: 0, right: 0, top: 10, bottom: 0 } }, 
 elements: { 
 point: { radius: 0, hitRadius: 0, hoverRadius: 0 }, 
 line: { tension: 0.4, borderWidth: 2 } 
 }, 
 scales: { 
 x: { display: false, min: 1, max: MAX_DATA_POINTS - 2 }, 
 y: { 
 beginAtZero: true, min: 0, border: { display: false }, 
 grid: { color: 'rgba(255, 255, 255, 0.05)', drawTicks: false }, 
 ticks: { count: 3, color: '#9ca3af', mirror: false, z: 10, padding: 10, font: { size: 11, weight: 'bold' } } 
 } 
 }, 
 plugins: { legend: { display: false }, tooltip: { enabled: false } }, 
 interaction: { mode: 'none' } 
};

let cpuChart, ramChart, networkChart;
const ctxCpu = document.getElementById('cpuChart'); if(ctxCpu) { cpuChart = new Chart(ctxCpu.getContext('2d'), { type: 'line', data: { labels: chartLabels, datasets: [{ data: cpuData, borderColor: '#06b6d4', backgroundColor: 'rgba(6, 182, 212, 0.15)', fill: true }] }, options: JSON.parse(JSON.stringify(commonChartOptions)) }); cpuChart.options.scales.y.max = 100; cpuChart.options.scales.y.ticks.callback = function(value) { return parseFloat(value).toFixed(2) + '%'; }; }
const ctxRam = document.getElementById('ramChart'); if(ctxRam) { ramChart = new Chart(ctxRam.getContext('2d'), { type: 'line', data: { labels: chartLabels, datasets: [{ data: ramData, borderColor: '#0ea5e9', backgroundColor: 'rgba(14, 165, 233, 0.2)', fill: true }] }, options: JSON.parse(JSON.stringify(commonChartOptions)) }); ramChart.options.scales.y.max = currentServerRamMB; ramChart.options.scales.y.ticks.callback = function(value) { return value + 'MiB'; }; }
const ctxNetwork = document.getElementById('networkChart');
if (ctxNetwork) {
 const networkOptions = JSON.parse(JSON.stringify(commonChartOptions));
 networkOptions.plugins.legend = { display: true, position: 'top', align: 'end', labels: { color: '#cbd5e1', boxWidth: 10, boxHeight: 10, usePointStyle: true, padding: 14, font: { size: 10, weight: 'bold' } } };
 // Mulai dari rentang minimum 1 Byte/s (data internal tetap MiB/s).
 networkOptions.scales.y.max = 1 / (1024 * 1024);
 networkOptions.scales.y.ticks.callback = value => formatNetworkSpeed(value);
 networkChart = new Chart(ctxNetwork.getContext('2d'), { type: 'line', data: { labels: chartLabels, datasets: [
  { label: 'Inbound / Download', data: netInSpeedData, borderColor: '#38bdf8', backgroundColor: 'rgba(56, 189, 248, 0.10)', fill: true },
  { label: 'Outbound / Upload', data: netOutSpeedData, borderColor: '#facc15', backgroundColor: 'rgba(250, 204, 21, 0.08)', fill: true }
 ] }, options: networkOptions });
}
function formatNetworkSpeed(mibPerSec) {
 // Data grafik tetap dalam MiB/s; tampilan dikonversi ke B/s, KB/s, MB/s, GB/s.
 const bytesPerSec = Math.max(0, Number(mibPerSec) || 0) * 1024 * 1024;
 const units = ['B/s', 'KB/s', 'MB/s', 'GB/s', 'TB/s'];
 let value = bytesPerSec, unitIndex = 0;
 while (value >= 1000 && unitIndex < units.length - 1) { value /= 1000; unitIndex++; }
 const decimals = unitIndex === 0 ? 0 : 2;
 // Label sumbu dibulatkan ke bawah agar skala awal terbaca 1 B/s, 0 B/s, 0 B/s.
 if (unitIndex === 0) return `${Math.floor(value)} ${units[unitIndex]}`;
 return `${value.toFixed(decimals)} ${units[unitIndex]}`;
}


function getCleanMax(dataArray, minDefault, step) { let maxVal = Math.max(...dataArray); if (maxVal <= minDefault) return minDefault; return Math.ceil(maxVal / step) * step; }
// CPU chart: keep the configured limit normally, but add 5% headroom
// when historical/current CPU usage rises above that limit.
function getCpuChartMax() {
 const baseLimit = currentServerCpuLimit > 0 ? currentServerCpuLimit : 100;
 const peakCpu = Math.max(latestStats.cpu || 0, ...cpuData);
 return peakCpu > baseLimit ? peakCpu * 1.05 : baseLimit;
}
const CARD_BASE_G = 'bg-[#1e293b] p-3.5 md:p-4 rounded-xl shadow-lg relative overflow-hidden flex items-center gap-3 md:gap-4 select-none';
const ICON_NORMAL_G   = 'w-10 h-10 md:w-12 md:h-12 rounded-xl flex items-center justify-center text-slate-400 flex-shrink-0 bg-slate-700/40 border border-slate-600/60';
const ICON_WARN_G     = 'w-10 h-10 md:w-12 md:h-12 rounded-xl flex items-center justify-center text-yellow-300 flex-shrink-0 bg-yellow-500/25 border border-yellow-500/40';
const ICON_DANGER_G   = 'w-10 h-10 md:w-12 md:h-12 rounded-xl flex items-center justify-center text-red-300 flex-shrink-0 bg-red-500/25 border border-red-500/40';
function applyDiskState(cardId, iconId, pct) {
  const card = document.getElementById(cardId);
  const icon = document.getElementById(iconId);
  if (pct >= 0.95) {
    if(card) { card.className = `${CARD_BASE_G} border border-slate-700`; card.style.boxShadow = 'inset 4px 0 0 #ef4444'; }
    if(icon) icon.className = ICON_DANGER_G;
  } else if (pct >= 0.85) {
    if(card) { card.className = `${CARD_BASE_G} border border-slate-700`; card.style.boxShadow = 'inset 4px 0 0 #facc15'; }
    if(icon) icon.className = ICON_WARN_G;
  } else {
    if(card) { card.className = `${CARD_BASE_G} border border-slate-700`; card.style.boxShadow = ''; }
    if(icon) icon.className = ICON_NORMAL_G;
  }
}
function renderDiskUsage() {
  const diskText = document.getElementById('stat-disk-text');
  const diskPct = currentServerDiskLimitMB > 0 ? currentDiskUsedMB / currentServerDiskLimitMB : 0;
  if (diskText) {
    diskText.innerHTML = `<span class="text-white">${formatMB(currentDiskUsedMB)}</span><span style="color:#747B8B" class="text-xs font-semibold"> / ${currentServerDiskLimitMB > 0 ? formatMB(currentServerDiskLimitMB) : '∞'}</span>`;
  }
  applyDiskState('stat-disk-card', 'stat-disk-icon', diskPct);
}
async function syncDiskAndLimits() {
  try {
    const [statsRes, settingsRes] = await Promise.all([
      fetch('/api/dashboard-stats?t=' + Date.now()),
      fetch('/api/settings?t=' + Date.now())
    ]);
    if (statsRes.ok) {
      const data = await statsRes.json();
      window.ramLimitMB = data.ramTotal / (1024 * 1024);
      currentDiskUsedMB = data.diskUsed / (1024 * 1024);
      if (data.diskTotal !== undefined) currentServerDiskLimitMB = data.diskTotal > 0 ? data.diskTotal / (1024 * 1024) : 0;
    }
    if (settingsRes && settingsRes.ok) {
      const sData = await settingsRes.json();
      if (sData) {
        settingsCache = Object.assign(settingsCache || {}, sData);
        if (sData.srvLimits && sData.srvLimits.ram !== undefined) {
          window.ramLimitMB = Number(sData.srvLimits.ram);
          currentServerRamMB = Number(sData.srvLimits.ram);
        }
        if (sData.srvLimits && sData.srvLimits.disk !== undefined) {
          currentServerDiskLimitMB = Number(sData.srvLimits.disk);
        }
        const ramEl = document.getElementById('set-ram');
        if (sData.ram !== undefined && sData.ram !== null && ramEl && document.activeElement !== ramEl) {
          ramEl.value = sData.ram;
          if (!(sData.srvLimits && sData.srvLimits.ram !== undefined)) currentServerRamMB = parseRamToMB(sData.ram);
        }
      }
    }
    renderDiskUsage();
    
    updateCommandPreview();
  } catch(e) {}
}
syncDiskAndLimits(); setInterval(syncDiskAndLimits, 10000); 

const UPTIME_CARD_BASE = 'bg-[#1e293b] p-3.5 md:p-4 rounded-xl shadow-lg relative overflow-hidden flex items-center gap-3 md:gap-4 select-none border border-slate-700';
function _applyUptimeState(state) {
 const card = document.getElementById('stat-uptime-card');
 const icon = document.getElementById('stat-uptime-icon');
 const ICON_NORMAL  = 'w-10 h-10 md:w-12 md:h-12 rounded-xl flex items-center justify-center text-slate-400 flex-shrink-0 bg-slate-700/40 border border-slate-600/60';
 const ICON_WARN    = 'w-10 h-10 md:w-12 md:h-12 rounded-xl flex items-center justify-center text-yellow-300 flex-shrink-0 bg-yellow-500/25 border border-yellow-500/40';
 const ICON_SUCCESS = 'w-10 h-10 md:w-12 md:h-12 rounded-xl flex items-center justify-center text-green-300 flex-shrink-0 bg-green-500/25 border border-green-500/40';
 if (state === 'starting') {
  if (card) { card.className = UPTIME_CARD_BASE; card.style.boxShadow = 'inset 4px 0 0 #facc15'; }
  if (icon) icon.className = ICON_WARN;
 } else if (state === 'online') {
  if (card) { card.className = UPTIME_CARD_BASE; card.style.boxShadow = 'inset 4px 0 0 #22c55e'; }
  if (icon) icon.className = ICON_SUCCESS;
 } else {
  if (card) { card.className = UPTIME_CARD_BASE; card.style.boxShadow = ''; }
  if (icon) icon.className = ICON_NORMAL;
 }
}

setInterval(() => {
 const uptimeEl = document.getElementById('stat-uptime-text');
 if (!uptimeEl) return;
 if (_conn.isDisconnected) {
  uptimeEl.className = 'text-sm md:text-base font-black text-slate-500 truncate';
  uptimeEl.innerText = 'Offline';
  _applyUptimeState('offline');
  return;
 }
 if (globalStartTime) {
  let totalSeconds = Math.max(0, Math.floor((Date.now() - globalStartTime) / 1000));
  let totalDays = Math.floor(totalSeconds / (3600 * 24));
  let hours = Math.floor((totalSeconds % (3600 * 24)) / 3600);
  let minutes = Math.floor((totalSeconds % 3600) / 60);
  let seconds = totalSeconds % 60;
  const uptimeStr = totalDays > 0 ? `${totalDays}d ${hours}h ${minutes}m` : `${hours}h ${minutes}m ${seconds}s`;
  if (serverStatus === 'starting') {
   uptimeEl.className = 'text-sm md:text-base font-black text-white truncate';
   uptimeEl.innerText = uptimeStr;
   _applyUptimeState('starting');
   return;
  }
  uptimeEl.className = 'text-sm md:text-base font-black text-white truncate';
  uptimeEl.innerText = uptimeStr;
  _applyUptimeState('online');
 } else {
  uptimeEl.className = 'text-sm md:text-base font-black text-slate-500 truncate';
  uptimeEl.innerText = 'Offline';
  _applyUptimeState('offline');
 }
}, 1000);

let lastStatsTick = Date.now();
let latestStats = { cpu: 0, ram: 0, netIn: 0, netOut: 0 };
let latestNetworkSpeed = { in: 0, out: 0 };
let previousNetworkCounters = null;
let previousNetworkSampleAt = 0;
let isTabActive = true;

document.addEventListener("visibilitychange", () => { isTabActive = !document.hidden; });

function formatNetBytes(bytes) {
 if (bytes >= 1073741824) return (bytes / 1073741824).toFixed(2) + ' GB';
 if (bytes >= 1048576) return (bytes / 1048576).toFixed(2) + ' MB';
 if (bytes >= 1024) return (bytes / 1024).toFixed(1) + ' KB';
 return bytes + ' B';
}


// Simpan alamat allocation terakhir yang valid supaya event offline (yang kadang
// membawa 0.0.0.0 dari bind address) tidak menimpa IP publik/alias yang sudah benar.
const SERVER_ADDRESS_CACHE_KEY = 'manz4vps:last-address:' + (new URLSearchParams(location.search).get('panelServerId') || location.pathname);
function isUsableServerAddress(address) {
 const value = String(address || '').trim();
 if (!value || value === 'undefined:undefined') return false;
 return true;
}
function updateServerAddress(address) {
 const ipText = document.getElementById('stat-ip-text');
 if (!ipText) return;
 let value = String(address || '').trim();
 if (isUsableServerAddress(value)) {
   try { localStorage.setItem(SERVER_ADDRESS_CACHE_KEY, value); } catch (e) {}
 } else {
   try { value = localStorage.getItem(SERVER_ADDRESS_CACHE_KEY) || ''; } catch (e) {}
 }
 if (!value) value = 'IP belum tersedia';
 ipText.innerText = value;
 ipText.title = value;
}

socket.on('stats', (data) => {
 lastStatsTick = Date.now();
 updateServerAddress(data.address);
 globalStartTime = data.startTime;
 serverStatus = data.status || (data.startTime ? 'running' : 'offline');
 const currentlyOnline = data.startTime !== null || (serverStatus !== 'offline' && serverStatus !== 'stopped');
 syncPowerButtons(serverStatus, data.startTime);
 if (data.cpuLimit !== undefined && Number.isFinite(Number(data.cpuLimit))) {
   currentServerCpuLimit = Number(data.cpuLimit);
   if (cpuChart) cpuChart.options.scales.y.max = getCpuChartMax();
 }

 if (currentlyOnline) {
 latestStats.cpu = parseFloat(data.cpu) || 0; latestStats.ram = parseFloat(data.ramMB) || 0;
 if (data.cpuLimit !== undefined) currentServerCpuLimit = Number(data.cpuLimit);
 if (data.ramLimit !== undefined) currentServerRamMB = Number(data.ramLimit);
  if (data.diskLimit !== undefined) {
    currentServerDiskLimitMB = parseFloat(data.diskLimit);
    renderDiskUsage();
  }
 latestStats.netIn = parseFloat(data.netIn) || 0; latestStats.netOut = parseFloat(data.netOut) || 0;
 const sampleAt = Date.now();
 if (previousNetworkCounters && previousNetworkSampleAt) {
  const elapsedSeconds = Math.max(0.1, (sampleAt - previousNetworkSampleAt) / 1000);
  const rxDelta = Math.max(0, latestStats.netIn - previousNetworkCounters.in);
  const txDelta = Math.max(0, latestStats.netOut - previousNetworkCounters.out);
  latestNetworkSpeed.in = (rxDelta / elapsedSeconds) / (1024 * 1024);
  latestNetworkSpeed.out = (txDelta / elapsedSeconds) / (1024 * 1024);
 } else {
  latestNetworkSpeed.in = 0; latestNetworkSpeed.out = 0;
 }
 previousNetworkCounters = { in: latestStats.netIn, out: latestStats.netOut };
 previousNetworkSampleAt = sampleAt;
 isServerOnline = true;
 setStopButtonEnabled(true);
 } else {
 latestStats.cpu = 0; latestStats.ram = 0; latestStats.netIn = 0; latestStats.netOut = 0;
 setStopButtonEnabled(false);
 resetStopButton();
 isServerOnline = false;
 }
});

// ENGINE PENGGERAK UTAMA (BIAR TETEP MULUS & SINKRON) 
setInterval(() => {
 if (!isTabActive) return;

 const cpuText = document.getElementById('stat-cpu-text'); 
 const ramText = document.getElementById('stat-ram-text');
 const netInText = document.getElementById('stat-netin-text');
 const netOutText = document.getElementById('stat-netout-text');

 const CARD_BASE = 'bg-[#1e293b] p-3.5 md:p-4 rounded-xl shadow-lg relative overflow-hidden flex items-center gap-3 md:gap-4 select-none';
 const ICON_NORMAL   = 'w-10 h-10 md:w-12 md:h-12 rounded-xl flex items-center justify-center text-slate-400 flex-shrink-0 bg-slate-700/40 border border-slate-600/60';
 const ICON_WARN     = 'w-10 h-10 md:w-12 md:h-12 rounded-xl flex items-center justify-center text-yellow-300 flex-shrink-0 bg-yellow-500/25 border border-yellow-500/40';
 const ICON_DANGER   = 'w-10 h-10 md:w-12 md:h-12 rounded-xl flex items-center justify-center text-red-300 flex-shrink-0 bg-red-500/25 border border-red-500/40';
 const ICON_SUCCESS  = 'w-10 h-10 md:w-12 md:h-12 rounded-xl flex items-center justify-center text-green-300 flex-shrink-0 bg-green-500/25 border border-green-500/40';

 function applyStatState(cardId, iconId, pct) {
  const card = document.getElementById(cardId);
  const icon = document.getElementById(iconId);
  if (pct >= 0.95) {
   if(card) { card.className = `${CARD_BASE} border border-slate-700`; card.style.boxShadow = 'inset 4px 0 0 #ef4444'; }
   if(icon) icon.className = ICON_DANGER;
  } else if (pct >= 0.85) {
   if(card) { card.className = `${CARD_BASE} border border-slate-700`; card.style.boxShadow = 'inset 4px 0 0 #facc15'; }
   if(icon) icon.className = ICON_WARN;
  } else {
   if(card) { card.className = `${CARD_BASE} border border-slate-700`; card.style.boxShadow = ''; }
   if(icon) icon.className = ICON_NORMAL;
  }
 }
 // CPU khusus: kuning >= 96% limit, merah >= 100% limit
 function applyCpuState(cardId, iconId, ratio) {
  const card = document.getElementById(cardId);
  const icon = document.getElementById(iconId);
  if (ratio >= 1.0) {
   if(card) { card.className = `${CARD_BASE} border border-slate-700`; card.style.boxShadow = 'inset 4px 0 0 #ef4444'; }
   if(icon) icon.className = ICON_DANGER;
  } else if (ratio >= 0.97) {
   if(card) { card.className = `${CARD_BASE} border border-slate-700`; card.style.boxShadow = 'inset 4px 0 0 #eab308'; }
   if(icon) icon.className = ICON_WARN;
  } else {
   if(card) { card.className = `${CARD_BASE} border border-slate-700`; card.style.boxShadow = ''; }
   if(icon) icon.className = ICON_NORMAL;
  }
 }

 if (Date.now() - lastStatsTick > 20000 || !isServerOnline) {
  latestStats.cpu = 0; latestStats.ram = 0; latestStats.netIn = 0; latestStats.netOut = 0;
  latestNetworkSpeed.in = 0; latestNetworkSpeed.out = 0; previousNetworkCounters = null; previousNetworkSampleAt = 0;
  if(cpuText) { cpuText.className = 'text-sm font-black text-slate-500 truncate'; cpuText.innerText = 'Offline'; }
  if(ramText) { ramText.className = 'text-sm font-black text-slate-500 truncate'; ramText.innerText = 'Offline'; }
  if(netInText) netInText.innerHTML = `<span class="text-slate-500">Offline</span>`;
  if(netOutText) netOutText.innerHTML = `<span class="text-slate-500">Offline</span>`;
  applyStatState('stat-cpu-card', 'stat-cpu-icon', 0);
  applyStatState('stat-ram-card', 'stat-ram-icon', 0);
 } else {
  const cpuRatio = currentServerCpuLimit > 0 ? latestStats.cpu / currentServerCpuLimit : 0;
  const ramPct = currentServerRamMB > 0 ? latestStats.ram / currentServerRamMB : 0;
  const cpuLimitStr = currentServerCpuLimit > 0 ? `${currentServerCpuLimit % 1 === 0 ? currentServerCpuLimit.toFixed(0) : currentServerCpuLimit.toFixed(1)}%` : '∞';
  if(cpuText) { cpuText.className = 'text-sm font-black truncate'; cpuText.innerHTML = `<span class="text-white">${latestStats.cpu.toFixed(2)}%</span><span style="color:#747B8B" class="text-xs font-semibold"> / ${cpuLimitStr}</span>`; }
  if(ramText) { ramText.className = 'text-sm font-black truncate'; ramText.innerHTML = `<span class="text-white">${formatMB(latestStats.ram)}</span><span style="color:#747B8B" class="text-xs font-semibold"> / ${currentServerRamMB > 0 ? formatMB(currentServerRamMB) : '∞'}</span>`; }
  if(netInText) netInText.innerHTML = formatNetBytes(latestStats.netIn);
  if(netOutText) netOutText.innerHTML = formatNetBytes(latestStats.netOut);
  applyCpuState('stat-cpu-card', 'stat-cpu-icon', cpuRatio);
  applyStatState('stat-ram-card', 'stat-ram-icon', ramPct);
 }

 cpuData.shift(); cpuData.push(latestStats.cpu); 
 ramData.shift(); ramData.push(latestStats.ram); 
 netInSpeedData.shift(); netInSpeedData.push(latestNetworkSpeed.in);
 netOutSpeedData.shift(); netOutSpeedData.push(latestNetworkSpeed.out);
 const netInSpeedEl = document.getElementById('chart-netin-speed');
 const netOutSpeedEl = document.getElementById('chart-netout-speed');
 if (netInSpeedEl) netInSpeedEl.textContent = formatNetworkSpeed(latestNetworkSpeed.in);
 if (netOutSpeedEl) netOutSpeedEl.textContent = formatNetworkSpeed(latestNetworkSpeed.out); 
 
 // FIX FINAL: Paksa durasi 1000ms biar jalannya ngalir mulus tanpa henti 
 if(cpuChart) { cpuChart.options.scales.y.max = getCpuChartMax(); cpuChart.update({duration: 250, easing: 'easeOutQuart'}); }
 if(ramChart) {
 let maxRamInChart = Math.max(...ramData);
 if (currentServerRamMB <= 0 || maxRamInChart > currentServerRamMB) { ramChart.options.scales.y.max = Math.max(100, Math.ceil(maxRamInChart + 100)); } 
 else { ramChart.options.scales.y.max = currentServerRamMB; }
 ramChart.update({duration: 300, easing: 'easeOutQuart'});
 }
 if(networkChart) { const minimumRange = 1 / (1024 * 1024); const peak = Math.max(0, ...netInSpeedData, ...netOutSpeedData); networkChart.options.scales.y.max = peak > 0 ? Math.max(minimumRange, peak * 1.15) : minimumRange; networkChart.update({duration: 300, easing: 'easeOutQuart'}); }
}, 1000);

let _javaCatalogReady = false;
let _javaCatalogPromise = null;
function fallbackMinecraftJavaRequirement(version) {
 const m = String(version || '').match(/^(\d+)\.(\d+)(?:\.(\d+))?/);
 if (!m) return 21;
 const major = Number(m[1]), minor = Number(m[2]), patch = Number(m[3] || 0);
 if (major >= 26) return 25;
 if (major === 1 && minor >= 20 && (minor > 20 || patch >= 5)) return 21;
 if (major === 1 && minor >= 17) return 17;
 return 8;
}
async function loadDynamicVersionCatalog() {
 if (_javaCatalogPromise) return _javaCatalogPromise;
 _javaCatalogPromise = (async () => {
  const select = document.getElementById('set-java-version');
  try {
   const res = await fetch('/api/version-catalog', { cache: 'no-store' });
   const data = await res.json();
   if (!res.ok || !Array.isArray(data.javaLts) || !data.javaLts.length) throw new Error(data.error || 'Katalog Java tidak tersedia.');
   if (select) {
    const previous = String(select.value || settingsCache?.javaVersion || '21');
    select.innerHTML = data.javaLts.map(v => `<option value="${Number(v)}">Temurin JDK ${Number(v)} (LTS)</option>`).join('');
    select.value = data.javaLts.map(String).includes(previous) ? previous : String(data.javaLts[0]);
   }
   _javaCatalogReady = true;
  } catch (e) {
   // Opsi bawaan HTML tetap tersedia bila API offline; izinkan percobaan ulang.
   _javaCatalogPromise = null;
  }
  return _javaCatalogReady;
 })();
 return _javaCatalogPromise;
}

async function fetchVersions() {
 const software = document.getElementById('vm-software')?.value;
 const category = document.getElementById('vm-category')?.value;
 const isMinecraftServer = category === 'mc-java' && ['paper', 'purpur', 'fabric'].includes(software);
 const input = document.getElementById('vm-version');
 const list = document.getElementById('vm-version-suggestions');
 if (!input || !list) return;
 list.innerHTML = '';
 try {
  let versions = [];
  if (software === 'paper' || software === 'velocity' || software === 'waterfall') {
   const res = await fetch(`https://fill.papermc.io/v3/projects/${software}`);
   if (!res.ok) throw new Error('Gagal mengambil versi software.');
   const data = await res.json();
   versions = Array.isArray(data.versions) ? data.versions : Object.values(data.versions || {}).flat();
  } else if (software === 'purpur') {
   const res = await fetch('https://api.purpurmc.org/v2/purpur'); if (!res.ok) throw new Error('Gagal mengambil versi Purpur.'); const data = await res.json(); versions = data.versions || [];
  } else if (software === 'fabric') {
   const res = await fetch('https://meta.fabricmc.net/v2/versions/game'); if (!res.ok) throw new Error('Gagal mengambil versi Fabric.'); const data = await res.json(); versions = (data || []).filter(v => v.stable).map(v => v.version);
  }
  versions = versions.filter(_isStableGameVersion).sort((a,b) => _cmpMcVer(b,a));
  await loadDynamicVersionCatalog();
  // Minecraft version remains a manual setting. Suggestions never overwrite the
  // value the user saved (including 'latest') and are not filtered by Java here.
  list.innerHTML = versions.map(v => `<option value="${String(v).replace(/&/g,'&amp;').replace(/"/g,'&quot;')}"></option>`).join('');
  if (!input.value.trim()) input.value = String(settingsCache?.softwareVersion || 'latest');
 } catch (_) {
  // Input manual tetap bisa digunakan walaupun API saran versi tidak tersedia.
 }
}

const tabVisited = new Set();


let pendingInstallConfig = null;
let _pendingEngineChange = null;

async function prepareInstall() {
 // Reinstall always targets the last saved configuration, not unsaved dropdown drafts.
 // Reload persisted settings first so the button works consistently from Settings.
 try {
  await loadSettings(true);
  const saved = settingsCache || {};
  const category = saved.softwareCategory || ((saved.engine === 'node' || saved.engine === 'python') ? 'bot' : 'mc-java');
  const software = String(saved.softwareId || ((saved.engine === 'node' || saved.engine === 'python') ? saved.engine : (String(saved.installedVersion || 'paper').split(' ')[0].toLowerCase())) || 'paper').toLowerCase();
  let version = 'latest';
  if (category === 'bot') {
   if (software === 'node') version = String(saved.nodeVersion || '24');
   else if (software === 'python') version = String(saved.pythonVersion || '3.15');
   else { showToast('Runtime tidak didukung.', 'error'); return; }
  } else {
   version = String(saved.softwareVersion || 'latest').trim() || 'latest';
  }
  // Synchronize the hidden Startup controls with the persisted values used by reinstall.
  const catEl = document.getElementById('vm-category');
  const softEl = document.getElementById('vm-software');
  if (catEl) catEl.value = category;
  if (softEl && [...softEl.options].some(o => o.value === software)) softEl.value = software;
  const versionEl = document.getElementById('vm-version');
  if (versionEl && category !== 'bot') versionEl.value = version;
  const javaEl = document.getElementById('set-java-version');
  if (javaEl && saved.javaVersion) javaEl.value = String(saved.javaVersion);
  const nodeEl = document.getElementById('set-node-version');
  if (nodeEl && saved.nodeVersion) nodeEl.value = String(saved.nodeVersion);
  const pyEl = document.getElementById('set-python-version');
  if (pyEl && saved.pythonVersion) pyEl.value = String(saved.pythonVersion);
  pendingInstallConfig = { software, version, category };
  const name = document.getElementById('installVersionName');
  if (name) name.innerText = `${software.toUpperCase()} ${version}`;
  const modal = document.getElementById('installConfirmModal');
  if (!modal) throw new Error('Dialog Reinstall Server tidak ditemukan.');
  modal.classList.remove('hidden');
 } catch (e) {
  showToast(e.message || 'Gagal membuka Reinstall Server.', 'error');
 }
}

function requestCleanInstallConfirm() {
 const choice = document.getElementById('installConfirmModal');
 if (choice) choice.classList.add('hidden');
 const confirm = document.getElementById('installWipeConfirmModal');
 if (confirm) confirm.classList.remove('hidden');
}

async function executeInstall(type) {
 document.getElementById('installConfirmModal').classList.add('hidden');
 const wipeConfirm = document.getElementById('installWipeConfirmModal');
 if (wipeConfirm) wipeConfirm.classList.add('hidden');
 if (!pendingInstallConfig) return;
 const { software, version, category } = pendingInstallConfig;
 const startBtn = document.getElementById('startBtn'); if (startBtn) startBtn.disabled = true;
 if (window.startProgress) window.startProgress();
 try {
  if (category === 'bot' && software === 'node') {
   if (isServerOnline) { socket.emit('stop_aman'); await new Promise(r => setTimeout(r, 1800)); }
   document.getElementById('set-engine').value = 'node';
   const nodeVer = document.getElementById('set-node-version')?.value || version;
   if (!(await saveSettings(true))) throw new Error('Pengaturan Node.js gagal disimpan.');
   if (type === 'clean') {
    const wipeRes = await fetch('/api/wipe-server-files', { method: 'POST' });
    if (!wipeRes.ok) throw new Error('Gagal menghapus file server. Runtime tidak jadi dipasang.');
   }
   const result = await new Promise(resolve => socket.emit('install_node_runtime', nodeVer, resolve));
   if (!result?.ok) throw new Error(result?.error || 'Gagal memasang Node.js.');
   if (settingsCache) { settingsCache.engine = 'node'; settingsCache.nodeVersion = String(nodeVer); settingsCache.jarFile = 'index.js'; }
   showToast(`Node.js ${nodeVer} berhasil dipasang.`, 'success');
   updateJvmVisibility('node');
   return;
  }
  if (category === 'bot' && software === 'python') {
   if (isServerOnline) { socket.emit('stop_aman'); await new Promise(r => setTimeout(r, 1800)); }
   document.getElementById('set-engine').value = 'python';
   const pyVer = document.getElementById('set-python-version')?.value || version || '3.15';
   if (!(await saveSettings(true))) throw new Error('Pengaturan Python gagal disimpan.');
   if (type === 'clean') {
    const wipeRes = await fetch('/api/wipe-server-files', { method: 'POST' });
    if (!wipeRes.ok) throw new Error('Gagal menghapus file server. Runtime tidak jadi dipasang.');
   }
   const result = await new Promise(resolve => socket.emit('install_python_runtime', pyVer, resolve));
   if (!result?.ok) throw new Error(result?.error || 'Gagal memasang Python.');
   if (settingsCache) { settingsCache.engine = 'python'; settingsCache.pythonVersion = String(pyVer); settingsCache.jarFile = settingsCache.jarFile || 'main.py'; }
   showToast(`Python ${pyVer} berhasil dipasang.`, 'success');
   updateJvmVisibility('node');
   return;
  }
  let resolvedVersion = version;
  if (version.toLowerCase() === 'latest') {
   if (software === 'paper' || software === 'velocity' || software === 'waterfall') {
    const r = await fetch(`https://fill.papermc.io/v3/projects/${software}?t=${Date.now()}`); const d = await r.json();
    const all = Array.isArray(d.versions) ? d.versions : Object.values(d.versions || {}).flat();
    resolvedVersion = all.filter(_isStableGameVersion).sort((a,b) => _cmpMcVer(b,a))[0];
   } else if (software === 'purpur') {
    const r = await fetch(`https://api.purpurmc.org/v2/purpur?t=${Date.now()}`); const d = await r.json();
    resolvedVersion = (d.versions || []).filter(_isStableGameVersion).sort((a,b) => _cmpMcVer(b,a))[0];
   } else if (software === 'fabric') {
    const r = await fetch(`https://meta.fabricmc.net/v2/versions/game?t=${Date.now()}`); const d = await r.json();
    resolvedVersion = (d || []).filter(v => v.stable).map(v => v.version).filter(_isStableGameVersion).sort((a,b) => _cmpMcVer(b,a))[0];
   }
   if (!resolvedVersion) throw new Error('Tidak dapat menentukan versi latest dari sumber resmi.');
  }
  let downloadUrl = '';
  const versionName = `${software.toUpperCase()} ${resolvedVersion}`;
  if (software === 'paper' || software === 'velocity' || software === 'waterfall') {
   const res = await fetch(`https://fill.papermc.io/v3/projects/${software}/versions/${resolvedVersion}/builds?t=${Date.now()}`);
   const data = await res.json(); const builds = Array.isArray(data) ? data : data.builds;
   if (!builds?.length) throw new Error(`Build ${software} ${resolvedVersion} tidak ditemukan.`);
   const latestBuild = builds.reduce((a,b) => (b.build > a.build ? b : a), builds[0]);
   const key = latestBuild.downloads['server:default'] ? 'server:default' : Object.keys(latestBuild.downloads)[0];
   downloadUrl = latestBuild.downloads[key].url;
  } else if (software === 'purpur') downloadUrl = `https://api.purpurmc.org/v2/purpur/${resolvedVersion}/latest/download`;
  else if (software === 'fabric') {
   const lr = await fetch(`https://meta.fabricmc.net/v2/versions/loader/${resolvedVersion}?t=${Date.now()}`); const ld = await lr.json();
   const loader = ld.find(v => v.loader?.stable) || ld[0];
   const ir = await fetch(`https://meta.fabricmc.net/v2/versions/installer?t=${Date.now()}`); const idata = await ir.json();
   const installer = idata.find(v => v.stable) || idata[0];
   downloadUrl = `https://meta.fabricmc.net/v2/versions/loader/${resolvedVersion}/${loader.loader.version}/${installer.version}/server/jar`;
  }
  if (!downloadUrl) throw new Error('URL download server tidak ditemukan.');
  if (isServerOnline) { socket.emit('stop_aman'); await new Promise(r => setTimeout(r, 1800)); }
  document.getElementById('set-engine').value = 'java';
  if (!(await saveSettings(true))) throw new Error('Pengaturan server gagal disimpan.');
  socket.emit('download_jar', downloadUrl, versionName, type === 'clean');
  if (settingsCache) settingsCache.installedVersion = versionName;
  const jvm = document.getElementById('jvm-flags-section'); if (jvm) jvm.style.display = '';
  showToast(`Reinstall ${versionName} dimulai.`, 'info');
 } catch (e) {
  showToast(e.message || 'Gagal memproses Reinstall Server.', 'error');
  if (startBtn) startBtn.disabled = false;
 } finally { if (window.finishProgress) window.finishProgress(); }
}

async function loadAllocations() {
 const list = document.getElementById('alloc-list');
 const hint = document.getElementById('alloc-free-hint');
 const btn  = document.getElementById('btn-add-alloc');
 const usageBanner = document.getElementById('alloc-usage-text');
 if (!list) return;
 list.innerHTML = '<div class="text-slate-500 text-sm text-center py-6">Memuat...</div>';
 try {
  const res = await fetch('/api/allocations');
  if (res.status === 401) return window.location.href = '/';
  const data = await res.json();
  const portLimit = data.portLimit || 2;
  const usedCount = data.usedCount || data.allocations.length;
  // Usage banner
  if (usageBanner) {
   const atLimit = usedCount >= portLimit;
   usageBanner.innerHTML = `You are currently using <strong class="${atLimit ? 'text-red-400' : 'text-blue-300'}">${usedCount}</strong> of <strong>${portLimit}</strong> allowed allocations for this server.`;
  }
  list.innerHTML = '';
  if (data.allocations.length === 0) {
   list.innerHTML = '<div class="text-slate-500 text-sm text-center py-6">Belum ada allocation. Klik tombol di bawah untuk menambah.</div>';
  }
  data.allocations.forEach(a => {
   const card = document.createElement('div');
   card.className = `rounded-lg border ${a.primary ? 'border-blue-500/60 bg-blue-500/8' : 'border-slate-700 bg-slate-900/70'} overflow-hidden`;
   card.innerHTML = `
    <!-- Baris atas: hostname + port -->
    <div class="flex items-center gap-3 px-4 py-3 border-b ${a.primary ? 'border-blue-500/30' : 'border-slate-700/60'}">
     <svg class="w-5 h-5 text-slate-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><rect x="2" y="2" width="20" height="8" rx="2" ry="2"/><rect x="2" y="14" width="20" height="8" rx="2" ry="2"/><line x1="6" y1="6" x2="6.01" y2="6"/><line x1="6" y1="18" x2="6.01" y2="18"/></svg>
     <div class="flex-1 min-w-0">
      <p class="text-[10px] text-slate-500 font-bold uppercase tracking-wider mb-0.5">Hostname</p>
      <p class="font-mono text-sm text-white truncate">${a.alias || a.ip}</p>
     </div>
     <div class="text-right flex-shrink-0">
      <p class="text-[10px] text-slate-500 font-bold uppercase tracking-wider mb-0.5">Port</p>
      <span class="font-mono font-black text-white text-base">${a.port}</span>
     </div>
    </div>
    <!-- Baris bawah: ⭐Primary + trash -->
    <div class="flex items-center justify-between px-4 py-2.5">
     <div>
      ${a.primary
        ? `<span class="inline-flex items-center gap-1 text-xs font-black text-blue-300 bg-blue-600/20 border border-blue-500/40 px-2.5 py-1 rounded-full">
            <svg class="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
            Primary
           </span>`
        : `<button onclick="setPrimaryAllocation('${a.id}')" class="inline-flex items-center gap-1 text-xs font-bold text-slate-400 hover:text-blue-300 transition px-2.5 py-1 rounded-full border border-slate-600/50 hover:border-blue-500/50">
            <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"/></svg>
            Set as Primary
           </button>`
      }
     </div>
     ${!a.primary
       ? `<button onclick="removeAllocation('${a.id}')" title="Lepas allocation" class="w-8 h-8 flex items-center justify-center rounded-lg text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition">
           <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
          </button>`
       : `<div class="w-8 h-8"></div>`
     }
    </div>`;
   list.appendChild(card);
  });
  const atLimit = usedCount >= portLimit;
  if (hint) hint.textContent = '';
  if (btn) {
   const dis = data.freeCount <= 0 || atLimit;
   btn.disabled = dis;
   btn.classList.toggle('opacity-40', dis);
   btn.classList.toggle('cursor-not-allowed', dis);
   btn.title = atLimit ? `Batas ${portLimit} port per server sudah tercapai.` : '';
  }
 } catch(e) { list.innerHTML = '<div class="text-red-400 text-sm text-center py-4">Gagal memuat allocations.</div>'; }
}
async function addAllocation() {
 if (window.startProgress) window.startProgress();
 try {
  const res = await fetch('/api/allocations/add', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
  const data = await res.json();
  if (res.ok) { showToast('Port ditambahkan!'); loadAllocations(); loadSettings(true); }
  else showToast(data.error || 'Gagal menambah port.', 'error');
 } catch(e) { showToast('Error jaringan.', 'error'); } finally { if (window.finishProgress) window.finishProgress(); }
}
async function setPrimaryAllocation(id) {
 if (window.startProgress) window.startProgress();
 try {
  const res = await fetch('/api/allocations/set-primary', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) });
  const data = await res.json();
  if (res.ok) { showToast('Port utama diperbarui! Restart server untuk efek.'); loadAllocations(); loadSettings(true); }
  else showToast(data.error || 'Gagal.', 'error');
 } catch(e) { showToast('Error jaringan.', 'error'); } finally { if (window.finishProgress) window.finishProgress(); }
}
async function removeAllocation(id) {
 if (window.startProgress) window.startProgress();
 try {
  const res = await fetch('/api/allocations/remove', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) });
  const data = await res.json();
  if (res.ok) { showToast('Port dilepas.'); loadAllocations(); }
  else showToast(data.error || 'Gagal.', 'error');
 } catch(e) { showToast('Error jaringan.', 'error'); } finally { if (window.finishProgress) window.finishProgress(); }
}

async function loadSettings(forceRefresh = false) { 
 if (window.startProgress) window.startProgress();
 try { 
 if (!settingsCache || forceRefresh) { const res = await fetch('/api/settings', { cache: 'no-store' }); if (res.status === 401) return window.location.href = "/"; if (!res.ok) throw new Error(`API settings HTTP ${res.status}`); settingsCache = await res.json(); }
 const data = settingsCache;
 await loadDynamicVersionCatalog();
 if (document.getElementById('set-java-version')) {
  const savedJava = String(data.javaVersion || '21');
  const javaSelect = document.getElementById('set-java-version');
  if ([...javaSelect.options].some(o => o.value === savedJava)) javaSelect.value = savedJava;
 }
 if(data.ram && document.getElementById('set-ram')) {
 document.getElementById('set-ram').value = data.ram; currentServerRamMB = parseRamToMB(data.ram);
 if (ramChart) { let maxRamInChart = Math.max(...ramData); if (currentServerRamMB <= 0 || maxRamInChart > currentServerRamMB) { ramChart.options.scales.y.max = Math.max(100, Math.ceil(maxRamInChart + 100)); } else { ramChart.options.scales.y.max = currentServerRamMB; } ramChart.update({duration: 300, easing: 'easeOutQuart'}); }
 }
 if(data.jarFile && document.getElementById('set-jar')) document.getElementById('set-jar').value = data.jarFile; 
 const activeJarEl = document.getElementById('current-active-jar'); if(activeJarEl) { const _isJavaEng = data.engine !== 'node' && data.engine !== 'python'; activeJarEl.innerText = (_isJavaEng && data.installedVersion) ? data.installedVersion : (data.jarFile || 'Unknown'); } 
 if(data.engine) { 
 if(document.getElementById('set-engine')) document.getElementById('set-engine').value = data.engine; 
 const activeEngEl = document.getElementById('current-active-engine'); if(activeEngEl) activeEngEl.innerText = data.engine.toUpperCase(); 
 const catEl = document.getElementById('vm-category'); const softEl = document.getElementById('vm-software'); 
 if(catEl && softEl) {
 const savedCategory = data.softwareCategory || ((data.engine === 'node' || data.engine === 'python') ? 'bot' : 'mc-java');
 const detectedSw = String(data.softwareId || (data.engine === 'node' || data.engine === 'python' ? data.engine : (data.installedVersion || '').split(' ')[0].toLowerCase()) || 'paper').toLowerCase();
 catEl.value = ['mc-java','proxy','bot'].includes(savedCategory) ? savedCategory : 'mc-java';
 updateSubCategory(false);
 if ([...softEl.options].some(o => o.value === detectedSw)) softEl.value = detectedSw;
 updateRuntimeVersionType();
 if (document.getElementById('vm-version')) {
  const savedMcVersion = String(data.softwareVersion || '').trim();
  document.getElementById('vm-version').value = savedMcVersion || 'latest';
  if (!savedMcVersion && !data.installedVersion && catEl.value !== 'bot') {
   const javaSelect = document.getElementById('set-java-version');
   if (javaSelect && javaSelect.options.length) javaSelect.value = javaSelect.options[0].value;
  }
 }
 if (catEl.value !== 'bot') fetchVersions();
 onSoftwareSelectionChanged(false);
 } 
 updateJvmVisibility(data.engine);
 }
 if(document.getElementById('set-node-version')) document.getElementById('set-node-version').value = String(data.nodeVersion || '24');
 if(document.getElementById('set-python-version')) document.getElementById('set-python-version').value = String(data.pythonVersion || '3.15');
 if(document.getElementById('set-java-version')) {
  await loadDynamicVersionCatalog();
  const javaSelect = document.getElementById('set-java-version');
  const firstMinecraftSetup = (data.softwareCategory !== 'bot' && data.engine !== 'node' && data.engine !== 'python')
   && !String(data.softwareVersion || '').trim() && !String(data.installedVersion || '').trim();
  const jv = firstMinecraftSetup && javaSelect.options.length
   ? javaSelect.options[0].value
   : (data.javaVersion || '21');
  javaSelect.value = (jv === 'auto') ? (javaSelect.options[0]?.value || '21') : String(jv);
 }
 setAutoStartUI(data.autoStart === true);
 updateCustomStartupUI(data.useCustomStartup || false, data.customStartupCmd || '');
 updateCommandPreview(); 
 } catch(e) {
  console.error('[Startup] Gagal memuat pengaturan:', e);
  const preview = document.getElementById('cmd-preview');
  if (preview) preview.textContent = `Gagal memuat pengaturan: ${e.message || 'Kesalahan tidak diketahui'}`;
  showToast(`Gagal memuat pengaturan: ${e.message || 'Periksa koneksi/API'}`, 'error');
 } finally {
  const preview = document.getElementById('cmd-preview');
  if (preview && preview.textContent === 'Memuat...') {
   try { updateCommandPreview(); }
   catch (e) { console.error('[Startup] Preview gagal dibuat:', e); preview.textContent = `Preview gagal: ${e.message || 'Kesalahan JavaScript'}`; }
  }
  if (window.finishProgress) window.finishProgress();
 }
}

let _autoStartValue = false;
function setAutoStartUI(enabled) {
 _autoStartValue = enabled;
 const btn = document.getElementById('autoStartToggle');
 const knob = document.getElementById('autoStartKnob');
 if (!btn || !knob) return;
 if (enabled) {
 btn.classList.replace('bg-slate-600', 'bg-blue-600');
 knob.classList.replace('translate-x-1', 'translate-x-8');
 btn.setAttribute('aria-pressed', 'true');
 } else {
 btn.classList.replace('bg-blue-600', 'bg-slate-600');
 knob.classList.replace('translate-x-8', 'translate-x-1');
 btn.setAttribute('aria-pressed', 'false');
 }
}
function toggleAutoStart() {
 setAutoStartUI(!_autoStartValue);
}

async function saveSettings(silent = false, saveRuntimeConfig = true) { 
 if (window.startProgress) window.startProgress();
 try { 
 const ramInput = document.getElementById('set-ram') ? document.getElementById('set-ram').value : (settingsCache ? settingsCache.ram : '2G');
 const selectedCategory = saveRuntimeConfig ? (document.getElementById('vm-category')?.value || (settingsCache?.softwareCategory || 'mc-java')) : (settingsCache?.softwareCategory || ((settingsCache?.engine === 'node' || settingsCache?.engine === 'python') ? 'bot' : 'mc-java'));
 const selectedSoftware = saveRuntimeConfig ? (document.getElementById('vm-software')?.value || settingsCache?.softwareId || 'paper') : (settingsCache?.softwareId || settingsCache?.engine || 'paper');
 const newEngine = saveRuntimeConfig ? (selectedCategory === 'bot' ? selectedSoftware : 'java') : (settingsCache?.engine || 'java');
 const newJar = (saveRuntimeConfig ? (document.getElementById('set-jar')?.value || (newEngine === 'node' ? 'index.js' : newEngine === 'python' ? 'main.py' : 'server.jar')) : (settingsCache?.jarFile || 'server.jar')).trim();
 if (!newJar || !/^[A-Za-z0-9._-]+$/.test(newJar) || newJar === '.' || newJar === '..') throw new Error('Nama file startup tidak valid. Gunakan nama file tanpa folder.');
 const newJavaVer = saveRuntimeConfig && document.getElementById('set-java-version') ? document.getElementById('set-java-version').value : (settingsCache ? (settingsCache.javaVersion || '21') : '21');
 const newNodeVer = saveRuntimeConfig && document.getElementById('set-node-version') ? document.getElementById('set-node-version').value : (settingsCache ? (settingsCache.nodeVersion || '24') : '24');
 const newPythonVer = saveRuntimeConfig && document.getElementById('set-python-version') ? document.getElementById('set-python-version').value : (settingsCache ? (settingsCache.pythonVersion || '3.15') : '3.14');
 const softwareVersion = saveRuntimeConfig ? (selectedCategory === 'bot' ? '' : (document.getElementById('vm-version')?.value || 'latest').trim()) : (settingsCache?.softwareVersion || '');
 if (saveRuntimeConfig && selectedCategory !== 'bot' && !softwareVersion) throw new Error('Masukkan versi software atau latest.');
 const useCustom = settingsCache ? (settingsCache.useCustomStartup || false) : false;
 const customCmd = settingsCache ? (settingsCache.customStartupCmd || '') : '';
 const saveRes = await fetch('/api/settings', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ engine: newEngine, ram: ramInput, jarFile: newJar, autoStart: _autoStartValue, javaVersion: newJavaVer, nodeVersion: newNodeVer, pythonVersion: newPythonVer, softwareCategory: selectedCategory, softwareId: selectedSoftware, softwareVersion, useCustomStartup: useCustom, customStartupCmd: customCmd }) });
 if (!saveRes.ok) throw new Error(`Gagal menyimpan pengaturan (HTTP ${saveRes.status})`); 
 settingsCache = { ...settingsCache, engine: newEngine, ram: ramInput, jarFile: newJar, autoStart: _autoStartValue, javaVersion: newJavaVer, nodeVersion: newNodeVer, pythonVersion: newPythonVer, softwareCategory: selectedCategory, softwareId: selectedSoftware, softwareVersion, useCustomStartup: useCustom, customStartupCmd: customCmd };
 const engineInput = document.getElementById('set-engine'); if (engineInput) engineInput.value = newEngine;
 updateJvmVisibility(newEngine);
 currentServerRamMB = parseRamToMB(ramInput);
 if (ramChart) { let maxRamInChart = Math.max(...ramData); if (currentServerRamMB <= 0 || maxRamInChart > currentServerRamMB) { ramChart.options.scales.y.max = Math.max(100, Math.ceil(maxRamInChart + 100)); } else { ramChart.options.scales.y.max = currentServerRamMB; } ramChart.update({duration: 300, easing: 'easeOutQuart'}); }
 if (!silent) showToast('Tersimpan!'); updateCommandPreview();
 return true;
 } catch(e) { if (!silent) showToast(e.message || 'Gagal menyimpan pengaturan.', 'error'); return false; } finally { if (window.finishProgress) window.finishProgress(); }
}

let _useCustomStartup = false;

function autoResizeStartupInput(el) {
 el.style.height = 'auto';
 el.style.height = Math.max(80, el.scrollHeight) + 'px';
}

function updateStartupValidationUI() {
 const input = document.getElementById('custom-startup-input');
 const errorBox = document.getElementById('startup-validation-error');
 const saveButton = document.querySelector('button[onclick=\"saveCustomStartup()\"]');
 if (errorBox) { errorBox.textContent = ''; errorBox.classList.add('hidden'); }
 if (input) input.classList.remove('border-red-500', 'focus:border-red-500');
 if (saveButton) {
  saveButton.disabled = false;
  saveButton.classList.remove('opacity-50', 'cursor-not-allowed');
  saveButton.setAttribute('aria-disabled', 'false');
 }
 return true;
}

function updateCustomStartupUI(enabled, cmd) {
 _useCustomStartup = enabled;
 const badge = document.getElementById('custom-startup-badge');
 const input = document.getElementById('custom-startup-input');
 if (badge) badge.classList.toggle('hidden', !enabled);
 if (input) {
  if (cmd) {
   // Bersihkan flag heap lama dari konfigurasi yang pernah tersimpan.
   input.value = cmd.trim().split(/\s+/).filter(token => !/^-Xmx/i.test(token)).join(' ');
  } else {
   // Default aman tanpa pengaturan heap otomatis.
   input.value = `-Xms128M -Dterminal.jline=false -Dterminal.ansi=true`;
  }
  setTimeout(() => {
   autoResizeStartupInput(input);
   // Pasang listener sekali saja biar startup command preview update live saat user ketik
   if (!input._previewListenerAdded) {
    input.addEventListener('input', () => { input.value = input.value.split(/\s+/).filter(token => !/^-Xmx/i.test(token)).join(' '); autoResizeStartupInput(input); updateCommandPreview(); updateStartupValidationUI(); });
    input._previewListenerAdded = true;
   }
   updateStartupValidationUI();
  }, 50);
 }
}

async function saveCustomStartup() {
 const input = document.getElementById('custom-startup-input');
 const newCmd = input ? input.value.trim() : '';
 if (!updateStartupValidationUI()) {
  showToast('Startup tidak disimpan. Perbaiki bagian yang ditandai.', 'error');
  input?.focus();
  return;
 }
 const useCustom = newCmd.length > 0;
 if (window.startProgress) window.startProgress();
 try {
  const response = await fetch('/api/settings', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ useCustomStartup: useCustom, customStartupCmd: newCmd }) });
  if (!response.ok) { const raw = await response.text().catch(() => ''); let message = raw; try { message = JSON.parse(raw).error || raw; } catch (_) {} throw new Error(message || `HTTP ${response.status} saat menyimpan.`); }
  if (settingsCache) { settingsCache.useCustomStartup = useCustom; settingsCache.customStartupCmd = newCmd; }
  const badge = document.getElementById('custom-startup-badge');
  if (badge) badge.classList.toggle('hidden', !useCustom);
  _useCustomStartup = useCustom;
  updateCommandPreview();
  showToast(useCustom ? 'Custom startup disimpan!' : 'Kembali ke command default!', 'success');
 } catch(e) { showToast(e.message || 'Gagal menyimpan.', 'error'); } finally { if (window.finishProgress) window.finishProgress(); }
}

async function resetCustomStartup() {
 if (window.startProgress) window.startProgress();
 const DEFAULT_FLAGS = `-Xms128M -Dterminal.jline=false -Dterminal.ansi=true`;
 try {
  const response = await fetch('/api/settings', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ useCustomStartup: true, customStartupCmd: DEFAULT_FLAGS }) });
  if (!response.ok) { const raw = await response.text().catch(() => ''); let message = raw; try { message = JSON.parse(raw).error || raw; } catch (_) {} throw new Error(message || `HTTP ${response.status} saat reset.`); }
  if (settingsCache) { settingsCache.useCustomStartup = true; settingsCache.customStartupCmd = DEFAULT_FLAGS; }
  const input = document.getElementById('custom-startup-input');
  if (input) { input.value = DEFAULT_FLAGS; autoResizeStartupInput(input); }
  updateStartupValidationUI();
  const badge = document.getElementById('custom-startup-badge');
  if (badge) badge.classList.remove('hidden');
  _useCustomStartup = true;
  updateCommandPreview();
  showToast('Command direset ke default!', 'success');
 } catch(e) { showToast(e.message || 'Gagal reset.', 'error'); } finally { if (window.finishProgress) window.finishProgress(); }
}

function showTab(tab, addToHistory = true, forceRefresh = false) {
 if (window.startProgress) window.startProgress();

 // Tutup semua modal saat ganti tab supaya ga ngikut ke tab lain
 ['pluginInstallModal','modInstallModal','genericModal'].forEach(id => {
  document.getElementById(id)?.classList.add('hidden');
 });

 const tabContainer = document.getElementById('main-tab-container');
 if (tabContainer) {
  if (tab === 'files' || tab === 'edit') {
   tabContainer.classList.remove('max-w-2xl', 'mx-auto', 'md:px-12', 'md:pt-6');
  } else {
   tabContainer.classList.add('max-w-2xl', 'mx-auto', 'md:px-12', 'md:pt-6');
  }
 }

 ['console', 'files', 'versions', 'plugins', 'mods', 'network', 'startup', 'settings', 'edit'].forEach(t => { 
 const view = document.getElementById(t === 'edit' ? 'fileEditor' : `${t}-view`); const tabBtns = document.querySelectorAll(`.tab-btn-${t}`); 
 if(view) { if (t === tab) { view.style.display = 'block'; } else { view.style.display = 'none'; } } 
 tabBtns.forEach(btn => {
 if (t === tab || (tab === 'edit' && t === 'files')) {
 btn.className = `tab-btn-${t} w-full text-left px-3 py-2.5 rounded-lg bg-blue-600/15 text-blue-400 font-semibold flex items-center gap-3 transition-all duration-150 text-sm border border-blue-500/20`;
 const svg = btn.querySelector('svg'); if (svg) { svg.classList.remove('opacity-70'); svg.classList.add('text-blue-400'); }
 } else {
 btn.className = `tab-btn-${t} w-full text-left px-3 py-2.5 rounded-lg text-slate-400 font-semibold hover:bg-slate-800/70 hover:text-slate-100 flex items-center gap-3 transition-all duration-150 text-sm group`;
 const svg = btn.querySelector('svg'); if (svg) { svg.classList.remove('text-blue-400'); svg.classList.add('opacity-70'); }
 }
 });
 });
 const isFirstVisit = !tabVisited.has(tab) || forceRefresh;
 if (tab !== 'edit') tabVisited.add(tab);
  const _uploadToggleTab = document.getElementById('uploadToggleTab');
  if (tab !== 'files' && tab !== 'edit') {
    const bar = document.getElementById('pteroFloatingBar');
    if(bar) { bar.classList.add('translate-y-20', 'opacity-0'); setTimeout(() => { if(bar) bar.classList.add('hidden'); }, 300); }
    if(_uploadToggleTab) _uploadToggleTab.classList.add('hidden');
    // Tutup panel Transfer saat pindah ke tab lain (download tetap jalan di background)
    const _upPanel = document.getElementById('uploadProgressPanel');
    if (_upPanel && !_upPanel.classList.contains('hidden') && typeof closeUploadPanel === 'function') {
      closeUploadPanel();
      setTimeout(() => { const _t = document.getElementById('uploadToggleTab'); if(_t) _t.classList.add('hidden'); }, 350);
    }
  } else {
    if(_uploadToggleTab) _uploadToggleTab.classList.remove('hidden');
    if (tab === 'files' && typeof loadFiles === 'function') { if (!window._skipFileReset) { if (typeof currentPath !== 'undefined') currentPath = ''; if (typeof folderCache !== 'undefined') { Object.keys(folderCache).forEach(k => delete folderCache[k]); } loadFiles('', true); } window._skipFileReset = false; }
  }
 if((tab === 'startup' || tab === 'network' || tab === 'settings') && isFirstVisit) loadSettings();
 if(tab === 'network') loadAllocations();
 if(tab === 'plugins') {
  pmInitMcVersions(); pmFetchPlugins(1);
 if(_pmShowingInstalled) {
  _pmShowingInstalled = false;
  document.getElementById('pm-browse-section')?.classList.remove('hidden');
  document.getElementById('pm-installed-results')?.classList.add('hidden');
  const _b = document.getElementById('pm-installed-btn');
  if(_b) { _b.textContent = 'Installed Plugins'; _b.className = 'bg-blue-600 hover:bg-blue-500 px-5 py-2 rounded-lg font-black text-sm text-white shadow transition active:scale-95'; }
 }
}
 if(tab === 'mods') {
 if(isFirstVisit) { mmInitMcVersions(); mmFetchMods(1); }
 if(_mmShowingInstalled) {
  mmSetTab('browse');
 }
}
 if(tab === 'versions') { const vmCat = document.getElementById('vm-category'); if(document.getElementById('vm-software') && document.getElementById('vm-software').options.length === 0) updateSubCategory(); }
 if (addToHistory && tab !== 'files' && tab !== 'edit') { const newPath = tabUrlPath(tab); if (window.location.pathname !== newPath) history.pushState({ tab: tab }, '', newPath); }
 if (tab === 'edit' && typeof editor !== 'undefined' && editor) setTimeout(() => { editor.refresh(); }, 150);
 if (tab === 'console' && typeof smoothScrollToBottom === 'function') setTimeout(() => smoothScrollToBottom(true), 80);
 setTimeout(() => { if (window.finishProgress) window.finishProgress(); }, 150);
}

window.addEventListener('popstate', (event) => {
 const tab = getTabFromPath();
 if (tab === 'files' || tab === 'edit') window._skipFileReset = true;
 showTab(tab, false);
});
window.onload = async () => {
 let initialTab = getTabFromPath();
 let restoredFilesPath = '';
 const hashFull = window.location.hash.replace('#', '');
 if (initialTab === 'files' && hashFull.startsWith('edit/')) initialTab = 'edit';
 if (initialTab === 'files' && !hashFull.startsWith('edit/')) {
  let p = hashFull;
  if (p.startsWith('files')) { p = p.replace('files', ''); if (p.startsWith('/')) p = p.substring(1); }
  restoredFilesPath = p;
  if (typeof currentPath !== 'undefined') currentPath = p;
 }
 if (initialTab === 'files') window._skipFileReset = true;
 showTab(initialTab, false);
 if (initialTab === 'files' && typeof currentPath !== 'undefined') currentPath = restoredFilesPath;
 initTermZoom();
 // Hide loader immediately — don't wait for API calls
 const loader = document.getElementById('page-loader');
 if (loader) { loader.style.transition = 'opacity 0.15s'; loader.style.opacity = '0'; setTimeout(() => loader.classList.add('hidden'), 150); }
 // Load settings in background after UI is visible
 try {
 await loadSettings();
 if (initialTab === 'files' && typeof loadFiles === 'function') loadFiles(typeof currentPath !== 'undefined' ? currentPath : '', false);
 if (initialTab === 'edit' && hashFull.startsWith('edit/') && typeof openFile === 'function') { let filePath = hashFull.replace('edit/', ''); if (typeof currentPath !== 'undefined') currentPath = filePath.substring(0, filePath.lastIndexOf('/')) || ''; openFile(filePath, filePath.split('/').pop(), false); }
 } catch(e) {}
};

const _defaultJvmFlags = `-Dterminal.jline=false -Dterminal.ansi=true`;

function updateCommandPreview() {
 const engineEl = document.getElementById('set-engine');
 const jarEl = document.getElementById('set-jar');
 const previewEl = document.getElementById('cmd-preview');
 if (!engineEl || !previewEl) return;
 const engine = engineEl.value || 'java';
 const jar = jarEl ? (jarEl.value || 'server.jar') : 'server.jar';
 const ramEl = document.getElementById('set-ram');
 const ramRaw = ramEl ? ramEl.value : (settingsCache && settingsCache.ram) || '';
 const ramFromSetting = ramRaw ? parseRamToMB(ramRaw) : 0;
 const configuredLimit = Number(settingsCache?.srvLimits?.ram ?? window.ramLimitMB ?? 0);
 const ramMB = configuredLimit > 0 ? Math.min(ramFromSetting, configuredLimit) : 0;
 let cmd = '';
 if (engine === 'node') {
  cmd = `node ${jar}`;
 } else if (engine === 'python') {
  const pyVer = String(settingsCache?.pythonVersion || document.getElementById('set-python-version')?.value || '3.15');
  cmd = `python${pyVer} ${jar}`;
 } else {
  // Baca langsung dari textarea biar preview update live (bukan dari settingsCache)
  const inputEl = document.getElementById('custom-startup-input');
  const liveFlags = inputEl ? inputEl.value.trim() : '';
  const customFlags = liveFlags || (settingsCache && settingsCache.customStartupCmd && settingsCache.customStartupCmd.trim()) || '';
  const jvmPreviewFlags = customFlags ? customFlags.split(/\s+/).filter(token => token && !/^-Xmx/i.test(token) && !/^-XX:MaxRAMPercentage=/i.test(token)) : ['-Xms128M', '-Dterminal.jline=false', '-Dterminal.ansi=true'];
  const xmsIndex = jvmPreviewFlags.findIndex(token => /^-Xms/i.test(token));
  const xms = xmsIndex >= 0 ? jvmPreviewFlags.splice(xmsIndex, 1)[0] : '-Xms128M';
  const generatedHeapFlag = ramMB > 0 ? `-Xmx${Math.floor(ramMB)}M` : '-XX:MaxRAMPercentage=95.0';
  cmd = `java ${[xms, generatedHeapFlag, ...jvmPreviewFlags].join(' ')} -jar ${jar}`;
 }
 previewEl.textContent = cmd;
}
const softwareData = { 'mc-java': [ {id: 'paper', name: 'PaperMC (Ringan)'}, {id: 'purpur', name: 'Purpur'}, {id: 'fabric', name: 'Fabric (Mod Loader)'} ], 'proxy': [ {id: 'velocity', name: 'Velocity'}, {id: 'waterfall', name: 'Waterfall'} ], 'bot': [ {id: 'node', name: 'Node.js'}, {id: 'python', name: 'Python 3'} ] };
function updateRuntimeVersionType() {
 const cat = document.getElementById('vm-category')?.value;
 const software = document.getElementById('vm-software')?.value;
 const isNode = cat === 'bot' && software === 'node';
 const isPython = cat === 'bot' && software === 'python';
 const javaSection = document.getElementById('java-version-section');
 const nodeSection = document.getElementById('node-version-section');
 const pythonSection = document.getElementById('python-version-section');
 const label = document.getElementById('runtime-version-label');
 const help = document.getElementById('runtime-version-help');
 if (javaSection) javaSection.classList.toggle('hidden', cat === 'bot');
 if (nodeSection) nodeSection.classList.toggle('hidden', !isNode);
 if (pythonSection) pythonSection.classList.toggle('hidden', !isPython);
 if (label) label.textContent = isNode ? 'NodeJS Version' : (isPython ? 'Python Version' : 'Java Version');
 if (help) help.textContent = isNode ? 'Pilih versi Node.js. Runtime dipasang saat Reinstall Server, bukan saat Start.' : (isPython ? 'Pilih versi Python. Runtime dipasang saat Reinstall Server, bukan saat Start.' : 'Pilih versi Temurin JDK. Runtime dipasang saat Reinstall Server, bukan saat Start.');
 const versionContainer = document.getElementById('vm-version-container');
 if (versionContainer) versionContainer.classList.toggle('hidden', cat === 'bot');
 updateJvmVisibility(isNode || isPython ? 'node' : 'java');
}

function onSoftwareSelectionChanged(applyDefaultFile = true) {
 const cat = document.getElementById('vm-category')?.value || 'mc-java';
 const software = document.getElementById('vm-software')?.value || 'paper';
 const engine = cat === 'bot' ? software : 'java';
 const jar = document.getElementById('set-jar');
 const fileLabel = document.getElementById('startup-file-label');
 const fileHelp = document.getElementById('startup-file-help');
 if (jar && applyDefaultFile) {
  const defaultFile = engine === 'node' ? 'index.js' : engine === 'python' ? 'main.py' : 'server.jar';
  jar.value = defaultFile;
  if (typeof updateCommandPreview === 'function') updateCommandPreview();
 }
 if (fileLabel) fileLabel.textContent = engine === 'node' || engine === 'python' ? 'Startup File' : 'Server Jar File';
 if (fileHelp) fileHelp.textContent = engine === 'node' ? 'File JavaScript yang dijalankan, default index.js.' : engine === 'python' ? 'File Python yang dijalankan, default main.py.' : 'File JAR server yang dijalankan, default server.jar.';
}

function resetMinecraftDefaults() {
 // When the user switches to a different software egg, start from newest LTS + latest.
 loadDynamicVersionCatalog().then(() => {
  const java = document.getElementById('set-java-version');
  if (java && java.options.length) java.value = java.options[0].value;
  const version = document.getElementById('vm-version');
  if (version) version.value = 'latest';
  fetchVersions();
 });
}
function onSoftwareChanged() {
 updateRuntimeVersionType();
 onSoftwareSelectionChanged(true);
 const cat = document.getElementById('vm-category')?.value || 'mc-java';
 if (cat !== 'bot') resetMinecraftDefaults();
}
function updateSubCategory(applyDefaultFile = true) {
 const cat = document.getElementById('vm-category')?.value || 'mc-java';
 const softSelect = document.getElementById('vm-software');
 if (softSelect) softSelect.innerHTML = (softwareData[cat] || softwareData['mc-java']).map(s => `<option value="${s.id}">${s.name}</option>`).join('');
 updateRuntimeVersionType();
 onSoftwareSelectionChanged(applyDefaultFile);
 if (cat !== 'bot' && applyDefaultFile) resetMinecraftDefaults();
 else if (cat !== 'bot') fetchVersions();
}

/* =========================================
 PLUGIN MANAGER (Pterodactyl-style)
 ========================================= */
let _pmSearchTimeout;
let _pmCurrentPage = 1;
let _pmInstallMeta = null;
let _pmInstallVersions = [];
let _pmShowingInstalled = false;

function pmDebounceSearch() { clearTimeout(_pmSearchTimeout); _pmSearchTimeout = setTimeout(() => pmFetchPlugins(1), 500); }
function pmOnFilterChange() { pmFetchPlugins(1); }

function pmSetProvider(prov) {
 const sel = document.getElementById('pm-provider');
 if (sel) { sel.value = prov; }
 document.querySelectorAll('.pm-prov-btn').forEach(btn => {
  btn.className = 'pm-prov-btn px-3.5 py-1.5 rounded-lg text-xs font-black border bg-slate-700/60 text-slate-400 border-slate-600 hover:border-slate-400 hover:text-slate-200 transition active:scale-95';
 });
 const active = document.getElementById('pm-prov-' + prov);
 if (active) {
  if (prov === 'modrinth') active.className = 'pm-prov-btn px-3.5 py-1.5 rounded-lg text-xs font-black border bg-green-500/15 text-green-400 border-green-500/40 transition active:scale-95';
  else if (prov === 'spigotmc') active.className = 'pm-prov-btn px-3.5 py-1.5 rounded-lg text-xs font-black border bg-orange-500/15 text-orange-400 border-orange-500/40 transition active:scale-95';
  else if (prov === 'hangar') active.className = 'pm-prov-btn px-3.5 py-1.5 rounded-lg text-xs font-black border bg-blue-500/15 text-blue-400 border-blue-500/40 transition active:scale-95';
 }
 pmFetchPlugins(1);
}

function pmSetTab(tab) {
 const browseSection = document.getElementById('pm-browse-section');
 const ins = document.getElementById('pm-installed-results');
 const tabBrowse = document.getElementById('pm-tab-browse');
 const tabInstalled = document.getElementById('pm-tab-installed');
 const activeClass = 'flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl font-black text-sm bg-blue-600 text-white shadow transition active:scale-95';
 const inactiveClass = 'flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl font-black text-sm bg-slate-700/60 border border-slate-600/60 text-slate-300 hover:bg-slate-700 transition active:scale-95';
 if (tab === 'browse') {
  _pmShowingInstalled = false;
  if (browseSection) browseSection.classList.remove('hidden');
  if (ins) ins.classList.add('hidden');
  if (tabBrowse) tabBrowse.className = activeClass;
  if (tabInstalled) tabInstalled.className = inactiveClass;
 } else {
  _pmShowingInstalled = true;
  if (browseSection) browseSection.classList.add('hidden');
  if (ins) ins.classList.remove('hidden');
  if (tabBrowse) tabBrowse.className = inactiveClass;
  if (tabInstalled) tabInstalled.className = activeClass;
  pmLoadInstalled();
 }
}

async function pmInitMcVersions() {
 const sel = document.getElementById('pm-mcversion');
 if (!sel || sel.options.length > 1) return;
 try {
  const res = await fetch('https://api.modrinth.com/v2/tag/game_version');
  const tags = await res.json();
  const releaseVersions = tags.filter(t => t.version_type === 'release' && /^\d+\.\d+/.test(t.version));
  releaseVersions.forEach(t => {
   const opt = document.createElement('option');
   opt.value = t.version; opt.textContent = t.version;
   sel.appendChild(opt);
  });
 } catch(e) {}
}

async function pmFetchPlugins(page) {
 const provider = document.getElementById('pm-provider')?.value || 'modrinth';
 if (provider === 'curseforge' || provider === 'polymart') {
  const res = document.getElementById('pm-results');
  const pag = document.getElementById('pm-pagination');
  if(res) res.innerHTML = `<div class="text-center py-16"><p class="text-slate-300 font-bold text-base mb-2">${provider === 'curseforge' ? 'CurseForge' : 'Polymart'} membutuhkan API Key</p><p class="text-slate-500 text-sm">Provider ini tidak memiliki akses publik gratis.<br>Gunakan <span class="text-green-400 font-bold">Modrinth</span>, <span class="text-blue-400 font-bold">SpigotMC</span>, atau <span class="text-orange-400 font-bold">Hangar</span>.</p></div>`;
  if(pag) pag.innerHTML = '';
  return;
 }
 _pmCurrentPage = page || 1;
 const pageSize = parseInt(document.getElementById('pm-pagesize')?.value || '50');
 const loader = document.getElementById('pm-loader')?.value || '';
 const mcVersion = document.getElementById('pm-mcversion')?.value || '';
 const query = document.getElementById('pm-search')?.value.trim() || '';
 const offset = (_pmCurrentPage - 1) * pageSize;
 const resultsDiv = document.getElementById('pm-results');
 const paginationDiv = document.getElementById('pm-pagination');
 if (resultsDiv) resultsDiv.innerHTML = '<div class="text-center py-10 text-slate-400 text-sm animate-pulse">Memuat plugin...</div>';
 if (paginationDiv) paginationDiv.innerHTML = '';
 if (window.startProgress) window.startProgress();
 try {
  if (provider === 'modrinth') {
   let facets = [['project_type:plugin']];
   if (loader) facets.push([`categories:${loader}`]);
   if (mcVersion) facets.push([`versions:${mcVersion}`]);
   const facetsStr = encodeURIComponent(JSON.stringify(facets));
   const index = query ? 'relevance' : 'downloads';
   const url = `https://api.modrinth.com/v2/search?query=${encodeURIComponent(query)}&facets=${facetsStr}&index=${index}&limit=${pageSize}&offset=${offset}`;
   const res = await fetch(url);
   const data = await res.json();
   const normalized = (data.hits || []).map(p => ({ project_id: p.project_id, title: p.title, description: p.description, icon_url: p.icon_url, ext_url: `https://modrinth.com/plugin/${p.slug || p.project_id}`, _provider: 'modrinth' }));
   pmRenderList(normalized, data.total_hits || 0, _pmCurrentPage, pageSize);
  } else if (provider === 'spigotmc') {
   const pageNum = _pmCurrentPage - 1;
   let url;
   if (query) {
    url = `https://api.spiget.org/v2/search/resources/${encodeURIComponent(query)}?size=${pageSize}&page=${pageNum}&sort=-downloads&fields=id,name,tag,author,icon,file,premium`;
   } else {
    url = `https://api.spiget.org/v2/resources/free?size=${pageSize}&page=${pageNum}&sort=-downloads&fields=id,name,tag,author,icon,file,premium`;
   }
   const res = await fetch(url, { headers: { 'User-Agent': 'Manz4VPS-Panel' } });
   const data = await res.json();
   const list = Array.isArray(data) ? data : (data.resources || []);
   const totalRes = await fetch(`https://api.spiget.org/v2/${query ? `search/resources/${encodeURIComponent(query)}/` : 'resources/free/'}count`, { headers: { 'User-Agent': 'Manz4VPS-Panel' } }).then(r => r.json()).catch(() => list.length);
   const total = typeof totalRes === 'number' ? totalRes : list.length;
   const normalized = list.map(p => ({ project_id: String(p.id), title: p.name, description: p.tag || '', icon_url: p.icon && p.icon.url ? (p.icon.url.startsWith('http') ? p.icon.url : `https://www.spigotmc.org/${p.icon.url}`) : '', ext_url: `https://www.spigotmc.org/resources/${p.id}`, _provider: 'spigotmc', _premium: p.premium }));
   pmRenderList(normalized, total, _pmCurrentPage, pageSize);
  } else if (provider === 'hangar') {
   const url = `https://hangar.papermc.io/api/v1/projects?q=${encodeURIComponent(query)}&limit=${pageSize}&offset=${offset}`;
   const res = await fetch(url, { headers: { 'User-Agent': 'Manz4VPS-Panel' } });
   const data = await res.json();
   const normalized = (data.result || []).map(p => ({ project_id: `${p.namespace.owner}/${p.namespace.slug}`, title: p.name, description: p.description, icon_url: p.iconUrl || '', ext_url: `https://hangar.papermc.io/${p.namespace.owner}/${p.namespace.slug}`, _provider: 'hangar' }));
   pmRenderList(normalized, data.pagination?.count || normalized.length, _pmCurrentPage, pageSize);
  }
 } catch(e) {
  if(resultsDiv) resultsDiv.innerHTML = `<div class="text-center py-10 text-red-400 font-bold">Gagal mengambil data. Coba lagi.</div>`;
 } finally {
  if (window.finishProgress) window.finishProgress();
 }
}

function pmRenderList(hits, total, page, pageSize) {
 const resultsDiv = document.getElementById('pm-results');
 const paginationDiv = document.getElementById('pm-pagination');
 if (!resultsDiv) return;
 if (hits.length === 0) {
  resultsDiv.innerHTML = '<div class="text-center py-16 text-slate-500 font-bold">Plugin tidak ditemukan. Coba kata kunci atau filter lain.</div>';
  if(paginationDiv) paginationDiv.innerHTML = '';
  return;
 }
 resultsDiv.innerHTML = hits.map(p => {
  const icon = p.icon_url
   ? `<img src="${p.icon_url}" class="w-11 h-11 rounded-xl object-cover bg-slate-900 border border-slate-700/80 shrink-0" onerror="this.outerHTML='<div class=\\'w-11 h-11 rounded-xl bg-slate-800 border border-slate-700 shrink-0 flex items-center justify-center text-slate-500\\'><svg class=\\'w-5 h-5\\' fill=\\'none\\' stroke=\\'currentColor\\' viewBox=\\'0 0 24 24\\'><path stroke-linecap=\\'round\\' stroke-linejoin=\\'round\\' stroke-width=\\'2\\' d=\\'M17 14v6m-3-3h6M6 10h2a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v2a2 2 0 002 2zm10 0h2a2 2 0 002-2V6a2 2 0 00-2-2h-2a2 2 0 00-2 2v2a2 2 0 002 2zM6 20h2a2 2 0 002-2v-2a2 2 0 00-2-2H6a2 2 0 00-2 2v2a2 2 0 002 2z\\'/></svg></div>'">`
   : `<div class="w-11 h-11 rounded-xl bg-slate-800 border border-slate-700 shrink-0 flex items-center justify-center text-slate-500"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 14v6m-3-3h6M6 10h2a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v2a2 2 0 002 2zm10 0h2a2 2 0 002-2V6a2 2 0 00-2-2h-2a2 2 0 00-2 2v2a2 2 0 002 2zM6 20h2a2 2 0 002-2v-2a2 2 0 00-2-2H6a2 2 0 00-2 2v2a2 2 0 002 2z"/></svg></div>`;
  const safeTitle = p.title.replace(/'/g, "\\'").replace(/"/g, '&quot;');
  const safeId = p.project_id.replace(/'/g, "\\'");
  const safeIcon = encodeURIComponent(p.icon_url || '');
  const premium = p._premium ? `<span class="text-[9px] font-black px-1.5 py-0.5 rounded bg-yellow-500/20 text-yellow-400 border border-yellow-500/30 uppercase tracking-widest shrink-0">PREMIUM</span>` : '';
  const extLink = `<a href="${p.ext_url}" target="_blank" onclick="event.stopPropagation()" class="text-slate-600 hover:text-blue-400 transition shrink-0"><svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg></a>`;
  return `<div class="flex items-center gap-3 bg-[#1e293b] border border-slate-700/60 hover:border-slate-600/80 px-4 py-3.5 rounded-xl transition-all duration-150 group">
   ${icon}
   <div class="flex-1 min-w-0">
    <div class="flex items-center gap-1.5 flex-wrap mb-0.5">
     <span class="font-bold text-white text-sm">${p.title}</span>${premium}${extLink}
    </div>
    <p class="text-xs text-slate-400 line-clamp-1">${p.description || 'Tidak ada deskripsi.'}</p>
   </div>
   <button onclick="pmOpenInstallModal('${safeId}','${safeTitle}','${safeIcon}')"
    class="shrink-0 flex items-center gap-1.5 px-3 py-2 rounded-lg font-black text-xs bg-green-600/20 hover:bg-green-600 border border-green-600/40 hover:border-green-500 text-green-400 hover:text-white transition-all duration-150 active:scale-90 whitespace-nowrap">
    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
    Pasang
   </button>
  </div>`;
 }).join('');
 if (paginationDiv) {
  const totalPages = Math.ceil(total / pageSize);
  if (totalPages <= 1) { paginationDiv.innerHTML = ''; return; }
  const maxVisible = 6;
  const startPage = Math.max(1, page - 2);
  const endPage = Math.min(totalPages, startPage + maxVisible - 1);
  let pages = [];
  for (let i = startPage; i <= endPage; i++) pages.push(i);
  const btnClass = p => p === page ? 'w-9 h-9 rounded-lg font-black text-sm bg-blue-600 text-white shadow' : 'w-9 h-9 rounded-lg font-bold text-sm bg-slate-700 hover:bg-slate-600 text-slate-300 transition active:scale-95';
  paginationDiv.innerHTML =
   (page > 1 ? `<button onclick="pmFetchPlugins(${page-1})" class="w-9 h-9 rounded-lg font-bold text-sm bg-slate-700 hover:bg-slate-600 text-slate-300 transition active:scale-95">&lt;</button>` : '') +
   pages.map(p => `<button onclick="pmFetchPlugins(${p})" class="${btnClass(p)}">${p}</button>`).join('') +
   (page < totalPages ? `<button onclick="pmFetchPlugins(${page+1})" class="w-9 h-9 rounded-lg font-bold text-sm bg-slate-700 hover:bg-slate-600 text-slate-300 transition active:scale-95">&gt;</button>` : '');
 }
}

// Ambil MC version dari settingsCache, contoh "paper 1.21.1" → "1.21.1"
function _extractMcVersion() {
 const installed = (settingsCache && settingsCache.installedVersion) || '';
 const match = installed.match(/(\d+\.\d+(?:\.\d+)?)/);
 return match ? match[1] : '';
}
// Cek apakah server MC version cocok dengan list versi yang didukung
// Fuzzy: "1.21.1" cocok dengan ["1.21","1.21.1","1.21.4"]
function _mcVersionMatches(serverVer, gameVersions) {
 if (!serverVer || !gameVersions || !gameVersions.length) return true;
 if (gameVersions.includes(serverVer)) return true;
 const minor = serverVer.split('.').slice(0, 2).join('.');
 return gameVersions.some(v => v === minor || v.startsWith(minor + '.'));
}

async function pmOpenInstallModal(projectId, title, encodedIconUrl) {
 const provider = document.getElementById('pm-provider')?.value || 'modrinth';
 const iconUrl = encodedIconUrl ? decodeURIComponent(encodedIconUrl) : '';
 _pmInstallMeta = { project_id: projectId, title, provider, icon_url: iconUrl };
 _pmInstallVersions = [];
 const modal = document.getElementById('pluginInstallModal');
 const nameEl = document.getElementById('pim-name');
 const sel = document.getElementById('pim-version-select');
 const loadingEl = document.getElementById('pim-loading');
 if (!modal || !sel) return;
 if (nameEl) nameEl.textContent = title;
 const providerSpan = document.getElementById('pim-provider');
 if (providerSpan) providerSpan.textContent = provider;
 const iconWrap = document.getElementById('pim-icon-wrap');
 if (iconWrap) {
  if (iconUrl) {
   iconWrap.innerHTML = `<img src="${iconUrl}" class="w-full h-full object-cover" onerror="this.parentElement.innerHTML='<svg class=\\'w-6 h-6 text-slate-500\\' fill=\\'none\\' stroke=\\'currentColor\\' viewBox=\\'0 0 24 24\\'><path stroke-linecap=\\'round\\' stroke-linejoin=\\'round\\' stroke-width=\\'2\\' d=\\'M17 14v6m-3-3h6M6 10h2a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v2a2 2 0 002 2zm10 0h2a2 2 0 002-2V6a2 2 0 00-2-2h-2a2 2 0 00-2 2v2a2 2 0 002 2zM6 20h2a2 2 0 002-2v-2a2 2 0 00-2-2H6a2 2 0 00-2 2v2a2 2 0 002 2z\\'/>\\'/></svg>'">`;
  } else {
   iconWrap.innerHTML = `<svg class="w-6 h-6 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 14v6m-3-3h6M6 10h2a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v2a2 2 0 002 2zm10 0h2a2 2 0 002-2V6a2 2 0 00-2-2h-2a2 2 0 00-2 2v2a2 2 0 002 2zM6 20h2a2 2 0 002-2v-2a2 2 0 00-2-2H6a2 2 0 00-2 2v2a2 2 0 002 2z"/></svg>`;
  }
 }
 sel.innerHTML = '';
 sel.disabled = true;
 if (loadingEl) { loadingEl.style.display = 'flex'; sel.style.display = 'none'; }
 // Reset SpigotMC warning state setiap kali modal dibuka
 const _pimWarning = document.getElementById('pim-spigot-warning');
 const _pimNormal = document.getElementById('pim-info-normal');
 const _pimBtnLabel = document.getElementById('pim-btn-label');
 const _pimBtnIconDl = document.getElementById('pim-btn-icon-download');
 const _pimBtnIconOpen = document.getElementById('pim-btn-icon-open');
 const _pimVersionLabel = document.getElementById('pim-version-label');
 const _pimInstallBtn = document.getElementById('pim-install-btn');
 if (_pimWarning) _pimWarning.classList.add('hidden');
 if (_pimNormal) _pimNormal.classList.remove('hidden');
 if (_pimBtnLabel) _pimBtnLabel.textContent = 'Pasang Sekarang';
 if (_pimBtnIconDl) _pimBtnIconDl.classList.remove('hidden');
 if (_pimBtnIconOpen) _pimBtnIconOpen.classList.add('hidden');
 if (_pimVersionLabel) _pimVersionLabel.classList.remove('hidden');
 if (_pimInstallBtn) { _pimInstallBtn.classList.remove('bg-amber-600','hover:bg-amber-500'); _pimInstallBtn.classList.add('bg-green-600','hover:bg-green-500'); }
 modal.classList.remove('hidden');
 try {
  if (provider === 'modrinth') {
   const res = await fetch(`https://api.modrinth.com/v2/project/${projectId}/version`);
   const versions = await res.json();
   const modLoaders = ['fabric','neoforge','forge','quilt'];
   const filtered = versions.filter(v => { const ls = (v.loaders||[]).map(l=>l.toLowerCase()); return !ls.every(l=>modLoaders.includes(l)); });
   const stableOnly = filtered.filter(v => v.version_type === 'release');
   const releaseBase = stableOnly.length > 0 ? stableOnly : (filtered.length > 0 ? filtered : versions);
   const _serverMcVer = _extractMcVersion();
   const mcFiltered = _serverMcVer ? releaseBase.filter(v => _mcVersionMatches(_serverMcVer, v.game_versions || [])) : releaseBase;
   const list = mcFiltered.length > 0 ? mcFiltered : releaseBase;
   _pmInstallVersions = list.map(v => {
    const f = _pmGetBestFile(v.files);
    if (!f) return null;
    const gameVers = (v.game_versions || []);
    const minVer = gameVers[gameVers.length - 1];
    const maxVer = gameVers[0];
    const verRange = gameVers.length > 1 && minVer !== maxVer ? `${minVer}–${maxVer}` : (maxVer || '');
    const loaderInfo = (v.loaders || []).filter(l => !['fabric','neoforge','forge','quilt'].includes(l.toLowerCase())).map(l => l.charAt(0).toUpperCase()+l.slice(1)).join('/');
    const baseLabel = v.name && v.name !== v.version_number ? v.name : `${title} ${v.version_number}`;
    const suffix = (!baseLabel.toLowerCase().includes(verRange) && verRange) ? ` (${loaderInfo ? loaderInfo + ' ' : ''}${verRange})` : '';
    return { label: baseLabel + suffix + _fmtBytes(f.size), url: f.url, filename: f.filename, version_number: v.version_number };
   }).filter(Boolean);
  } else if (provider === 'spigotmc') {
   const safeName = title.replace(/[^a-zA-Z0-9\-_.]/g, '_').substring(0, 40);
   // Selalu pakai endpoint /resources/{id}/download dari Spiget → lewat Spiget CDN,
   // bukan /versions/{vid}/download yang redirect ke SpigotMC → kena Cloudflare 403.
   // Ambil daftar versi untuk label saja, tapi URL download tetap pakai resource-level.
   const versRes = await fetch(`https://api.spiget.org/v2/resources/${projectId}/versions?size=20&page=0&sort=-name`, { headers: { 'User-Agent': 'Manz4VPS-Panel' } });
   const versions = await versRes.json();
   const snapshotRe = /snapshot|alpha|beta|rc\d|\.dev|pre[-.\d]/i;
   // URL download = Spiget CDN (bukan version-specific agar tidak kena Cloudflare)
   const dlUrl = `https://api.spiget.org/v2/resources/${projectId}/download`;
   // Ambil ukuran file dari resource detail (size sama untuk semua versi karena URL sama)
   let spigotSizeLabel = '';
   try {
    const rInfo = await fetch(`https://api.spiget.org/v2/resources/${projectId}?fields=file`, { headers: { 'User-Agent': 'Manz4VPS-Panel' } });
    const rData = await rInfo.json();
    const sz = rData.file && rData.file.size != null ? Number(rData.file.size) : 0;
    if (sz > 0) spigotSizeLabel = ` (${sz} ${rData.file.sizeUnit || 'KB'})`;
   } catch(e) {}
   const allSpigot = (Array.isArray(versions) ? versions : []).map(v => ({
    label: (v.name || String(v.id)) + spigotSizeLabel,
    url: dlUrl,
    filename: `${safeName}-${(v.name||v.id).replace(/[^a-zA-Z0-9\-_.]/g,'_')}.jar`
   }));
   const stableSpigot = allSpigot.filter(v => !snapshotRe.test(v.label));
   _pmInstallVersions = stableSpigot.length > 0 ? stableSpigot : allSpigot;
   if (_pmInstallVersions.length === 0) {
    _pmInstallVersions = [{ label: 'Latest', url: dlUrl, filename: `${safeName}-latest.jar` }];
   }
  } else if (provider === 'hangar') {
   const [owner, slug] = projectId.split('/');
   const res = await fetch(`https://hangar.papermc.io/api/v1/projects/${owner}/${slug}/versions?limit=20&offset=0`, { headers: { 'User-Agent': 'Manz4VPS-Panel' } });
   const data = await res.json();
   const versions = data.result || [];
   const snapshotReH = /snapshot|alpha|beta|rc\d|\.dev|pre[-.\d]/i;
   const allHangar = versions.map(v => {
    const platform = v.downloads && (v.downloads.PAPER || v.downloads.VELOCITY || v.downloads.WATERFALL);
    const dlUrl = platform?.downloadUrl || `https://hangar.papermc.io/api/v1/projects/${owner}/${slug}/versions/${encodeURIComponent(v.name)}/PAPER/download`;
    const filename = (platform?.fileInfo?.name) || `${slug}-${v.name.replace(/[^a-zA-Z0-9\-_.]/g,'_')}.jar`;
    const channel = (typeof v.channel === 'string' ? v.channel : (v.channel?.name || '')).toLowerCase();
    const gameVersions = (v.platformDependencies?.PAPER || v.platformDependencies?.VELOCITY || v.platformDependencies?.WATERFALL || []);
    return { label: v.name, url: dlUrl, filename, _channel: channel, _gameVersions: gameVersions };
   });
   const stableHangar = allHangar.filter(v => v._channel === 'release' || (!snapshotReH.test(v.label) && v._channel !== 'snapshot'));
   const stableHangarBase = stableHangar.length > 0 ? stableHangar : allHangar;
   const _serverMcVerH = _extractMcVersion();
   const mcFilteredHangar = _serverMcVerH ? stableHangarBase.filter(v => _mcVersionMatches(_serverMcVerH, v._gameVersions)) : stableHangarBase;
   _pmInstallVersions = (mcFilteredHangar.length > 0 ? mcFilteredHangar : stableHangarBase).map(({label,url,filename}) => ({label,url,filename}));
  }
  if (_pmInstallVersions.length === 0) {
   sel.innerHTML = '<option disabled>Tidak ada versi tersedia</option>';
  } else {
   sel.innerHTML = _pmInstallVersions.map((v, i) => `<option value="${i}">${v.label}</option>`).join('');
  }
 } catch(e) {
  sel.innerHTML = '<option disabled>Gagal memuat versi</option>';
 } finally {
  sel.disabled = false;
  if (loadingEl) { loadingEl.style.display = 'none'; sel.style.display = ''; }
 }
}

async function pmInstallSelected() {
 const sel = document.getElementById('pim-version-select');
 if (!sel || !_pmInstallVersions.length) return;
 const idx = parseInt(sel.value) || 0;
 const version = _pmInstallVersions[idx];
 if (!version) return;
 // Kalau plugin ini SpigotMC-hosted (Cloudflare), buka halaman SpigotMC manual
 if (version._manualUrl) {
  window.open(version._manualUrl, '_blank');
  document.getElementById('pluginInstallModal').classList.add('hidden');
  showToast('Halaman SpigotMC dibuka. Download lalu upload lewat File Manager.', 'info');
  return;
 }
 document.getElementById('pluginInstallModal').classList.add('hidden');
 showToast(`Memproses ${version.filename}...`);
 socket.emit('download_plugin', version.url, version.filename);
 if (_pmInstallMeta) {
  try {
   await fetch('/api/plugin-meta', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ filename: version.filename, meta: { source: _pmInstallMeta.provider, project_id: _pmInstallMeta.project_id, title: _pmInstallMeta.title, icon_url: _pmInstallMeta.icon_url || '', version: version.version_number || version.label } }) });
  } catch(e) {}
  _pmInstallMeta = null;
 }
}

function _fmtBytes(bytes) {
 if (!bytes) return '';
 if (bytes >= 1048576) return ` (${(bytes/1048576).toFixed(1)} MB)`;
 return ` (${(bytes/1024).toFixed(0)} KB)`;
}
function _pmGetBestFile(files) {
 if (!files || files.length === 0) return null;
 const n = f => f.filename.toLowerCase();
 // Kategori buruk: mod loader lain, bundled/shaded, source jar, zip
 const isModLoader = f => n(f).includes('fabric') || n(f).includes('neoforge') || n(f).includes('-forge');
 const isBundled  = f => n(f).includes('-shaded') || n(f).includes('-all.') || n(f).includes('-fat.')
                      || n(f).includes('-with-dep') || n(f).includes('-sources') || n(f).endsWith('.zip');
 const isClean = f => !isModLoader(f) && !isBundled(f);
 // 1. primary + clean
 const p = files.find(f => isClean(f) && f.primary);
 if (p) return p;
 // 2. any clean
 const c = files.find(f => isClean(f));
 if (c) return c;
 // 3. primary non-loader (bundled boleh)
 const pb = files.find(f => !isModLoader(f) && f.primary);
 if (pb) return pb;
 // 4. any non-loader
 const ab = files.find(f => !isModLoader(f));
 return ab || files.find(f => f.primary) || files[0];
}

function pmToggleInstalled() {
 _pmShowingInstalled = !_pmShowingInstalled;
 const browseSection = document.getElementById('pm-browse-section');
 const ins = document.getElementById('pm-installed-results');
 const btn = document.getElementById('pm-installed-btn');
 if (_pmShowingInstalled) {
  if(browseSection) browseSection.classList.add('hidden');
  if(ins) ins.classList.remove('hidden');
  if(btn) { btn.textContent = 'Browse Plugins'; btn.className = 'bg-blue-600 hover:bg-blue-500 px-5 py-2 rounded-lg font-black text-sm text-white shadow transition active:scale-95'; }
  pmLoadInstalled();
 } else {
  if(browseSection) browseSection.classList.remove('hidden');
  if(ins) ins.classList.add('hidden');
  if(btn) { btn.textContent = 'Installed Plugins'; btn.className = 'bg-blue-600 hover:bg-blue-500 px-5 py-2 rounded-lg font-black text-sm text-white shadow transition active:scale-95'; }
 }
}

function pmDeletePlugin(filename) {
 const modal = document.getElementById('genericModal');
 if (!modal) return;
 const iconEl = document.getElementById('genericModalIcon');
 const titleEl = document.getElementById('genericModalTitle');
 const msgEl = document.getElementById('genericModalMsg');
 const confirmBtn = document.getElementById('genericConfirmBtn');
 if (iconEl) iconEl.textContent = '🗑️';
 if (titleEl) { titleEl.textContent = 'Remove Plugin'; titleEl.className = 'text-2xl font-black text-red-400 mb-1'; }
 if (msgEl) msgEl.innerHTML = `<code class="bg-slate-900 px-2 py-0.5 rounded text-red-300 text-sm font-mono">plugins/${filename}</code><span class="text-slate-300"> will be deleted.</span>`;
 if (confirmBtn) { confirmBtn.textContent = 'Remove Plugin'; confirmBtn.className = 'w-1/2 bg-red-600 hover:bg-red-500 text-white py-3 rounded-lg font-bold transition flex items-center justify-center gap-2 active:scale-95'; }
 modal.classList.remove('hidden');
 if (confirmBtn) {
  confirmBtn.onclick = async () => {
   modal.classList.add('hidden');
   try {
    await fetch('/api/delete', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ items: [`plugins/${filename}`] }) });
    await fetch('/api/plugin-meta', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ filename, meta: null }) });
    showToast(`Plugin ${filename.replace(/\.jar$/i,'')} dihapus.`);
    pmLoadInstalled();
   } catch(e) {
    showToast('Gagal menghapus plugin.', 'error');
   }
  };
 }
}

let _pmInstalledMeta = {};
let _pmInstalledJars = [];
let _pmUpdateMap = {};

async function pmLoadInstalled() {
 const ins = document.getElementById('pm-installed-results');
 if (!ins) return;
 ins.innerHTML = '<div class="text-center py-10 text-slate-400 text-sm animate-pulse">Membaca folder plugins/ ...</div>';
 await fetch('/api/folder', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({ path: 'plugins' }) }).catch(()=>{});
 try {
  const [filesRes, metaRes] = await Promise.all([
   fetch('/api/files?path=plugins'),
   fetch('/api/plugin-meta')
  ]);
  const files = await filesRes.json();
  _pmInstalledMeta = await metaRes.json().catch(() => ({}));
  _pmInstalledJars = files.filter(f => !f.isDirectory && f.name.endsWith('.jar'));
  pmRenderInstalled();
 } catch(e) {
  ins.innerHTML = '<div class="text-center py-10 text-red-400 font-bold">Gagal membaca folder plugins.</div>';
 }
}

function pmRenderInstalled(updateMap) {
 const ins = document.getElementById('pm-installed-results');
 if (!ins) return;
 const jars = _pmInstalledJars;
 const meta = _pmInstalledMeta;
 if (jars.length === 0) {
  ins.innerHTML = '<div class="text-center py-16 text-slate-500 font-bold">Belum ada plugin yang terpasang.</div>';
  return;
 }
 const modrinthCount = jars.filter(j => (meta[j.name]||{}).source === 'modrinth' && (meta[j.name]||{}).project_id).length;
 const header = `<div class="flex items-center justify-between mb-4">
  <h3 class="text-lg font-black text-white">Installed Plugins <span class="text-slate-400 font-bold">(${jars.length})</span></h3>
  ${modrinthCount > 0 ? `<button id="pm-check-updates-btn" onclick="pmCheckUpdates()" class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-slate-700 hover:bg-slate-600 text-slate-300 hover:text-white transition active:scale-95">
   <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
   Cek Update
  </button>` : ''}
 </div>`;
 const pluginIcon = `<svg class="w-5 h-5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 14v6m-3-3h6M6 10h2a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v2a2 2 0 002 2zm10 0h2a2 2 0 002-2V6a2 2 0 00-2-2h-2a2 2 0 00-2 2v2a2 2 0 002 2zM6 20h2a2 2 0 002-2v-2a2 2 0 00-2-2H6a2 2 0 00-2 2v2a2 2 0 002 2z"/></svg>`;
 const cards = jars.map(jar => {
  const m = meta[jar.name] || {};
  const title = m.title || jar.name.replace(/\.jar$/i, '').replace(/[-_]/g, ' ');
  const safeFile = jar.name.replace(/'/g, "\\'");
  const iconHtml = m.icon_url
   ? `<img src="${m.icon_url}" class="w-10 h-10 rounded-lg object-cover bg-slate-900 border border-slate-700 shrink-0" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">`
     + `<div class="w-10 h-10 rounded-lg bg-slate-800 border border-slate-700 shrink-0 items-center justify-center hidden">${pluginIcon}</div>`
   : `<div class="w-10 h-10 rounded-lg bg-slate-800 border border-slate-700 shrink-0 flex items-center justify-center">${pluginIcon}</div>`;
  const verBadge = m.version ? `<span class="text-[10px] font-bold text-slate-500 bg-slate-800 px-1.5 py-0.5 rounded shrink-0">v${m.version}</span>` : '';
  const upd = updateMap && updateMap[jar.name];
  const updateBtn = upd
   ? `<button onclick="pmUpdatePlugin('${safeFile}')" class="shrink-0 flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[11px] font-black bg-green-500/15 hover:bg-green-500/25 text-green-400 border border-green-500/30 transition active:scale-90" title="Update ke ${upd.version}">
       <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
       ${upd.version}
      </button>` : '';
  const upToDateBadge = updateMap && !upd && m.source === 'modrinth'
   ? `<span class="shrink-0 text-[10px] font-bold text-green-500/70 bg-green-500/10 px-1.5 py-0.5 rounded border border-green-500/20">✓ Up to date</span>` : '';
  return `<div class="flex items-center gap-3 bg-[#1e293b] border border-slate-700/60 px-4 py-3 rounded-xl hover:border-slate-600 transition" id="pm-jar-${jar.name.replace(/[^a-zA-Z0-9]/g,'_')}">
   ${iconHtml}
   <div class="flex-1 min-w-0">
    <div class="flex items-center gap-2 flex-wrap">
     <p class="font-bold text-white text-sm truncate">${title}</p>
     ${verBadge}${upToDateBadge}
    </div>
    <p class="text-xs text-slate-500 mt-0.5">${jar.size}</p>
   </div>
   <div class="flex items-center gap-1 shrink-0">
    ${updateBtn}
    <button onclick="pmDeletePlugin('${safeFile}')" class="text-slate-600 hover:text-red-400 transition p-1.5 rounded-lg hover:bg-red-500/10 active:scale-90" title="Hapus plugin">
     <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
    </button>
   </div>
  </div>`;
 }).join('');
 ins.innerHTML = header + `<div class="space-y-1.5">${cards}</div>`;
}

async function pmCheckUpdates() {
 const btn = document.getElementById('pm-check-updates-btn');
 if (btn) { btn.disabled = true; btn.innerHTML = '<svg class="w-3.5 h-3.5 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg> Mengecek...'; }
 const meta = _pmInstalledMeta;
 const jars = _pmInstalledJars;
 const modrinthPlugins = jars.filter(j => (meta[j.name]||{}).source === 'modrinth' && (meta[j.name]||{}).project_id);
 const updateMap = {};
 const modLoaders = ['fabric','neoforge','forge','quilt'];
 const snapshotRe = /snapshot|alpha|beta|rc\d|\.dev|pre[-.\d]/i;
 await Promise.all(modrinthPlugins.map(async jar => {
  const m = meta[jar.name];
  try {
   const res = await fetch(`https://api.modrinth.com/v2/project/${m.project_id}/version`);
   const versions = await res.json();
   const filtered = versions.filter(v => {
    if (v.version_type !== 'release') return false;
    const ls = (v.loaders||[]).map(l=>l.toLowerCase());
    return !ls.every(l=>modLoaders.includes(l));
   });
   const list = filtered.length > 0 ? filtered : versions.filter(v => v.version_type === 'release');
   if (!list.length) return;
   const latest = list[0];
   const latestVer = latest.version_number;
   const storedVer = m.version || '';
   if (latestVer && storedVer && latestVer !== storedVer) {
    const f = _pmGetBestFile(latest.files);
    if (f) updateMap[jar.name] = { version: latestVer, url: f.url, filename: f.filename, project_id: m.project_id, title: m.title, icon_url: m.icon_url || '' };
   }
  } catch(e) {}
 }));
 const count = Object.keys(updateMap).length;
 showToast(count > 0 ? `${count} plugin ada update!` : 'Semua plugin sudah up to date ✓');
 _pmUpdateMap = updateMap;
 pmRenderInstalled(updateMap);
}

async function pmUpdatePlugin(oldFilename) {
 const meta = _pmInstalledMeta;
 const m = meta[oldFilename] || {};
 const upd = _pmUpdateMap[oldFilename];
 if (!upd) { showToast('Klik "Cek Update" dulu.', 'error'); return; }
 showToast(`Mengupdate ${m.title || oldFilename}...`);
 try {
  socket.emit('download_plugin', upd.url, upd.filename);
  if (upd.filename !== oldFilename) {
   await fetch('/api/delete', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ items: [`plugins/${oldFilename}`] }) });
   await fetch('/api/plugin-meta', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ filename: oldFilename, meta: null }) });
  }
  await fetch('/api/plugin-meta', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ filename: upd.filename, meta: { source: 'modrinth', project_id: upd.project_id, title: upd.title, icon_url: upd.icon_url, version: upd.version } }) });
  delete _pmUpdateMap[oldFilename];
  await pmLoadInstalled();
 } catch(e) { showToast('Gagal update plugin.', 'error'); }
}
let _downloadWasActive = false;
let _overlayShownAt = 0;
socket.on('download_lock_state', (isDownloading, kind) => {
  if (kind && kind !== 'jar') return; // plugin/mod downloads use their own toast, never the fullscreen installer overlay
  const overlay = document.getElementById('running-installer-overlay');
  const startBtn = document.getElementById('startBtn');
  if (isDownloading) {
    _downloadWasActive = true;
    _overlayShownAt = Date.now();
    if(overlay) overlay.classList.remove('hidden');
    if(startBtn) { startBtn.disabled = true; startBtn.innerText = "..."; }
  } else {
    const elapsed = Date.now() - _overlayShownAt;
    const delay = Math.max(0, 5000 - elapsed);
    setTimeout(() => {
      if(overlay) overlay.classList.add('hidden');
      if(startBtn) { startBtn.disabled = false; startBtn.innerText = "Start"; }
      if (_downloadWasActive) { _downloadWasActive = false; if(typeof clearTerminal === 'function') clearTerminal(); }
    }, delay);
  }
});
socket.on('download_success_toast', () => {}); 
socket.on('plugin_success_toast', () => {});
socket.on('mod_success_toast', () => {});
socket.on('op_resume', (data) => {
 const t   = data.type  || 'archive';
 const jId = data.jobId || t;
 if (typeof showZipProgressModal === 'function') showZipProgressModal(t, undefined, jId);
 if (typeof updateZipProgress === 'function') updateZipProgress(jId, data.percent || 0, data.processed || 0, data.total || 0);
});
socket.on('extract_progress', (data) => {
 if (typeof updateZipProgress === 'function') updateZipProgress(data.jobId, data.percent || 0, data.processed || 0, data.total || 0);
});
socket.on('extract_done', (data) => {
 if (typeof closeZipProgressModal === 'function') closeZipProgressModal(data.jobId);
 if (data.success) {
  showToast('Ekstrak berhasil!');
  if (typeof loadFiles === 'function' && typeof currentPath !== 'undefined') {
   if (typeof folderCache !== 'undefined') delete folderCache[currentPath];
   loadFiles(currentPath);
  }
 } else {
  showToast(data.message || 'Gagal mengekstrak', 'error');
 }
});
socket.on('archive_progress', (data) => {
 if (typeof updateZipProgress === 'function') updateZipProgress(data.jobId, data.percent || 0, data.processed || 0, data.total || 0);
});
socket.on('archive_done', (data) => {
 if (typeof closeZipProgressModal === 'function') closeZipProgressModal(data.jobId);
 if (data.success) {
  showToast('Arsip berhasil dibuat: ' + (data.name || ''));
  if (typeof loadFiles === 'function' && typeof currentPath !== 'undefined') {
   if (typeof folderCache !== 'undefined') delete folderCache[currentPath];
   loadFiles(currentPath);
  }
 } else {
  showToast(data.message || 'Gagal membuat arsip', 'error');
 }
});

/* =========================================
 MODS MANAGER (Modrinth - Fabric/Forge/Quilt)
 ========================================= */
let _mmSearchTimeout;
let _mmCurrentPage = 1;
let _mmInstallMeta = null;
let _mmInstallVersions = [];
let _mmShowingInstalled = false;
let _mmInstalledMeta = {};
let _mmInstalledJars = [];

function mmDebounceSearch() { clearTimeout(_mmSearchTimeout); _mmSearchTimeout = setTimeout(() => mmFetchMods(1), 500); }
function mmOnFilterChange() { mmFetchMods(1); }

function mmSetTab(tab) {
 const browseSection = document.getElementById('mm-browse-section');
 const ins = document.getElementById('mm-installed-results');
 const tabBrowse = document.getElementById('mm-tab-browse');
 const tabInstalled = document.getElementById('mm-tab-installed');
 const activeClass = 'flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl font-black text-sm bg-blue-600 text-white shadow transition active:scale-95';
 const inactiveClass = 'flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl font-black text-sm bg-slate-700/60 border border-slate-600/60 text-slate-300 hover:bg-slate-700 transition active:scale-95';
 if (tab === 'browse') {
  _mmShowingInstalled = false;
  if (browseSection) browseSection.classList.remove('hidden');
  if (ins) ins.classList.add('hidden');
  if (tabBrowse) tabBrowse.className = activeClass;
  if (tabInstalled) tabInstalled.className = inactiveClass;
 } else {
  _mmShowingInstalled = true;
  if (browseSection) browseSection.classList.add('hidden');
  if (ins) ins.classList.remove('hidden');
  if (tabBrowse) tabBrowse.className = inactiveClass;
  if (tabInstalled) tabInstalled.className = activeClass;
  mmLoadInstalled();
 }
}

async function mmInitMcVersions() {
 const sel = document.getElementById('mm-mcversion');
 if (!sel || sel.options.length > 1) return;
 try {
  const res = await fetch('https://api.modrinth.com/v2/tag/game_version');
  const tags = await res.json();
  const releaseVersions = tags.filter(t => t.version_type === 'release' && /^\d+\.\d+/.test(t.version));
  releaseVersions.forEach(t => {
   const opt = document.createElement('option');
   opt.value = t.version; opt.textContent = t.version;
   sel.appendChild(opt);
  });
 } catch(e) {}
}

async function mmFetchMods(page) {
 _mmCurrentPage = page || 1;
 const pageSize = 30;
 const loader = document.getElementById('mm-loader')?.value || '';
 const mcVersion = document.getElementById('mm-mcversion')?.value || '';
 const query = document.getElementById('mm-search')?.value.trim() || '';
 const offset = (_mmCurrentPage - 1) * pageSize;
 const resultsDiv = document.getElementById('mm-results');
 const paginationDiv = document.getElementById('mm-pagination');
 if (resultsDiv) resultsDiv.innerHTML = '<div class="text-center py-10 text-slate-400 text-sm animate-pulse">Memuat mod...</div>';
 if (paginationDiv) paginationDiv.innerHTML = '';
 if (window.startProgress) window.startProgress();
 try {
  let facets = [['project_type:mod']];
  if (loader) facets.push([`categories:${loader}`]);
  if (mcVersion) facets.push([`versions:${mcVersion}`]);
  const facetsStr = encodeURIComponent(JSON.stringify(facets));
  const index = query ? 'relevance' : 'downloads';
  const url = `https://api.modrinth.com/v2/search?query=${encodeURIComponent(query)}&facets=${facetsStr}&index=${index}&limit=${pageSize}&offset=${offset}`;
  const res = await fetch(url);
  const data = await res.json();
  const normalized = (data.hits || []).map(p => ({ project_id: p.project_id, title: p.title, description: p.description, icon_url: p.icon_url, ext_url: `https://modrinth.com/mod/${p.slug || p.project_id}` }));
  mmRenderList(normalized, data.total_hits || 0, _mmCurrentPage, pageSize);
 } catch(e) {
  if(resultsDiv) resultsDiv.innerHTML = `<div class="text-center py-10 text-red-400 font-bold">Gagal mengambil data. Coba lagi.</div>`;
 } finally {
  if (window.finishProgress) window.finishProgress();
 }
}

function mmRenderList(hits, total, page, pageSize) {
 const resultsDiv = document.getElementById('mm-results');
 const paginationDiv = document.getElementById('mm-pagination');
 if (!resultsDiv) return;
 if (hits.length === 0) {
  resultsDiv.innerHTML = '<div class="text-center py-16 text-slate-500 font-bold">Mod tidak ditemukan. Coba kata kunci atau filter lain.</div>';
  if(paginationDiv) paginationDiv.innerHTML = '';
  return;
 }
 resultsDiv.innerHTML = hits.map(p => {
  const icon = p.icon_url
   ? `<img src="${p.icon_url}" class="w-11 h-11 rounded-xl object-cover bg-slate-900 border border-slate-700/80 shrink-0" onerror="this.style.display='none'">`
   : `<div class="w-11 h-11 rounded-xl bg-slate-800 border border-slate-700 shrink-0 flex items-center justify-center text-slate-500"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg></div>`;
  const safeTitle = p.title.replace(/'/g, "\\'").replace(/"/g, '&quot;');
  const safeId = p.project_id.replace(/'/g, "\\'");
  const safeIcon = encodeURIComponent(p.icon_url || '');
  const extLink = `<a href="${p.ext_url}" target="_blank" onclick="event.stopPropagation()" class="text-slate-600 hover:text-blue-400 transition shrink-0"><svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg></a>`;
  return `<div class="flex items-center gap-3 bg-[#1e293b] border border-slate-700/60 hover:border-slate-600/80 px-4 py-3.5 rounded-xl transition-all duration-150 group">
   ${icon}
   <div class="flex-1 min-w-0">
    <div class="flex items-center gap-1.5 flex-wrap mb-0.5">
     <span class="font-bold text-white text-sm">${p.title}</span>${extLink}
    </div>
    <p class="text-xs text-slate-400 line-clamp-1">${p.description || 'Tidak ada deskripsi.'}</p>
   </div>
   <button onclick="mmOpenInstallModal('${safeId}','${safeTitle}','${safeIcon}')"
    class="shrink-0 flex items-center gap-1.5 px-3 py-2 rounded-lg font-black text-xs bg-green-600/20 hover:bg-green-600 border border-green-600/40 hover:border-green-500 text-green-400 hover:text-white transition-all duration-150 active:scale-90 whitespace-nowrap">
    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
    Pasang
   </button>
  </div>`;
 }).join('');
 if (paginationDiv) {
  const totalPages = Math.ceil(total / pageSize);
  if (totalPages <= 1) { paginationDiv.innerHTML = ''; return; }
  const maxVisible = 6;
  const startPage = Math.max(1, page - 2);
  const endPage = Math.min(totalPages, startPage + maxVisible - 1);
  let pages = [];
  for (let i = startPage; i <= endPage; i++) pages.push(i);
  const btnClass = p => p === page ? 'w-9 h-9 rounded-lg font-black text-sm bg-blue-600 text-white shadow' : 'w-9 h-9 rounded-lg font-bold text-sm bg-slate-700 hover:bg-slate-600 text-slate-300 transition active:scale-95';
  paginationDiv.innerHTML =
   (page > 1 ? `<button onclick="mmFetchMods(${page-1})" class="w-9 h-9 rounded-lg font-bold text-sm bg-slate-700 hover:bg-slate-600 text-slate-300 transition active:scale-95">&lt;</button>` : '') +
   pages.map(p => `<button onclick="mmFetchMods(${p})" class="${btnClass(p)}">${p}</button>`).join('') +
   (page < totalPages ? `<button onclick="mmFetchMods(${page+1})" class="w-9 h-9 rounded-lg font-bold text-sm bg-slate-700 hover:bg-slate-600 text-slate-300 transition active:scale-95">&gt;</button>` : '');
 }
}

function _mmGetBestFile(files) {
 if (!files || files.length === 0) return null;
 const n = f => f.filename.toLowerCase();
 const isBundled = f => n(f).includes('-shaded') || n(f).includes('-all.') || n(f).includes('-fat.')
                     || n(f).includes('-with-dep') || n(f).includes('-sources') || n(f).endsWith('.zip');
 const clean = files.find(f => !isBundled(f) && f.primary);
 if (clean) return clean;
 const anyClean = files.find(f => !isBundled(f));
 return anyClean || files.find(f => f.primary) || files[0];
}

async function mmOpenInstallModal(projectId, title, encodedIconUrl) {
 const iconUrl = encodedIconUrl ? decodeURIComponent(encodedIconUrl) : '';
 _mmInstallMeta = { project_id: projectId, title, icon_url: iconUrl };
 _mmInstallVersions = [];
 const modal = document.getElementById('modInstallModal');
 const nameEl = document.getElementById('mim-name');
 const sel = document.getElementById('mim-version-select');
 const loadingEl = document.getElementById('mim-loading');
 if (!modal || !sel) return;
 if (nameEl) nameEl.textContent = title;
 const iconWrap = document.getElementById('mim-icon-wrap');
 if (iconWrap) {
  iconWrap.innerHTML = iconUrl
   ? `<img src="${iconUrl}" class="w-full h-full object-cover" onerror="this.parentElement.innerHTML=''">`
   : '';
 }
 sel.innerHTML = '';
 sel.disabled = true;
 if (loadingEl) { loadingEl.style.display = 'flex'; sel.style.display = 'none'; }
 modal.classList.remove('hidden');
 try {
  const res = await fetch(`https://api.modrinth.com/v2/project/${projectId}/version`);
  const versions = await res.json();
  const stableOnly = versions.filter(v => v.version_type === 'release');
  const releaseBaseM = stableOnly.length > 0 ? stableOnly : versions;
  const _serverMcVerM = _extractMcVersion();
  const mcFilteredM = _serverMcVerM ? releaseBaseM.filter(v => _mcVersionMatches(_serverMcVerM, v.game_versions || [])) : releaseBaseM;
  const list = mcFilteredM.length > 0 ? mcFilteredM : releaseBaseM;
  _mmInstallVersions = list.map(v => {
   const f = _mmGetBestFile(v.files);
   if (!f) return null;
   const gameVers = (v.game_versions || []);
   const minVer = gameVers[gameVers.length - 1];
   const maxVer = gameVers[0];
   const verRange = gameVers.length > 1 && minVer !== maxVer ? `${minVer}–${maxVer}` : (maxVer || '');
   const loaderInfo = (v.loaders || []).map(l => l.charAt(0).toUpperCase()+l.slice(1)).join('/');
   const baseLabel = v.name && v.name !== v.version_number ? v.name : `${title} ${v.version_number}`;
   const suffix = ` (${loaderInfo ? loaderInfo + ' ' : ''}${verRange})`;
   return { label: baseLabel + suffix + _fmtBytes(f.size), url: f.url, filename: f.filename, version_number: v.version_number };
  }).filter(Boolean);
  if (_mmInstallVersions.length === 0) {
   sel.innerHTML = '<option disabled>Tidak ada versi tersedia</option>';
  } else {
   sel.innerHTML = _mmInstallVersions.map((v, i) => `<option value="${i}">${v.label}</option>`).join('');
  }
 } catch(e) {
  sel.innerHTML = '<option disabled>Gagal memuat versi</option>';
 } finally {
  sel.disabled = false;
  if (loadingEl) { loadingEl.style.display = 'none'; sel.style.display = ''; }
 }
}

async function mmInstallSelected() {
 const sel = document.getElementById('mim-version-select');
 if (!sel || !_mmInstallVersions.length) return;
 const idx = parseInt(sel.value) || 0;
 const version = _mmInstallVersions[idx];
 if (!version) return;
 document.getElementById('modInstallModal').classList.add('hidden');
 showToast(`Memproses ${version.filename}...`);
 socket.emit('download_mod', version.url, version.filename);
 if (_mmInstallMeta) {
  try {
   await fetch('/api/mod-meta', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ filename: version.filename, meta: { source: 'modrinth', project_id: _mmInstallMeta.project_id, title: _mmInstallMeta.title, icon_url: _mmInstallMeta.icon_url || '', version: version.version_number || version.label } }) });
  } catch(e) {}
  _mmInstallMeta = null;
 }
}

async function mmLoadInstalled() {
 const ins = document.getElementById('mm-installed-results');
 if (!ins) return;
 ins.innerHTML = '<div class="text-center py-10 text-slate-400 text-sm animate-pulse">Membaca folder mods/ ...</div>';
 await fetch('/api/folder', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({ path: 'mods' }) }).catch(()=>{});
 try {
  const [filesRes, metaRes] = await Promise.all([
   fetch('/api/files?path=mods'),
   fetch('/api/mod-meta')
  ]);
  const files = await filesRes.json();
  _mmInstalledMeta = await metaRes.json().catch(() => ({}));
  _mmInstalledJars = files.filter(f => !f.isDirectory && f.name.endsWith('.jar'));
  mmRenderInstalled();
 } catch(e) {
  ins.innerHTML = '<div class="text-center py-10 text-red-400 font-bold">Gagal membaca folder mods.</div>';
 }
}

function mmRenderInstalled() {
 const ins = document.getElementById('mm-installed-results');
 if (!ins) return;
 const jars = _mmInstalledJars;
 const meta = _mmInstalledMeta;
 if (jars.length === 0) {
  ins.innerHTML = '<div class="text-center py-16 text-slate-500 font-bold">Belum ada mod yang terpasang.</div>';
  return;
 }
 const header = `<div class="flex items-center justify-between mb-4">
  <h3 class="text-lg font-black text-white">Installed Mods <span class="text-slate-400 font-bold">(${jars.length})</span></h3>
 </div>`;
 const modIcon = `<svg class="w-5 h-5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>`;
 const cards = jars.map(jar => {
  const m = meta[jar.name] || {};
  const title = m.title || jar.name.replace(/\.jar$/i, '').replace(/[-_]/g, ' ');
  const safeFile = jar.name.replace(/'/g, "\\'");
  const iconHtml = m.icon_url
   ? `<img src="${m.icon_url}" class="w-10 h-10 rounded-lg object-cover bg-slate-900 border border-slate-700 shrink-0" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">`
     + `<div class="w-10 h-10 rounded-lg bg-slate-800 border border-slate-700 shrink-0 items-center justify-center hidden">${modIcon}</div>`
   : `<div class="w-10 h-10 rounded-lg bg-slate-800 border border-slate-700 shrink-0 flex items-center justify-center">${modIcon}</div>`;
  const verBadge = m.version ? `<span class="text-[10px] font-bold text-slate-500 bg-slate-800 px-1.5 py-0.5 rounded shrink-0">v${m.version}</span>` : '';
  return `<div class="flex items-center gap-3 bg-[#1e293b] border border-slate-700/60 px-4 py-3 rounded-xl hover:border-slate-600 transition">
   ${iconHtml}
   <div class="flex-1 min-w-0">
    <div class="flex items-center gap-2 flex-wrap">
     <p class="font-bold text-white text-sm truncate">${title}</p>
     ${verBadge}
    </div>
    <p class="text-xs text-slate-500 mt-0.5">${jar.size}</p>
   </div>
   <div class="flex items-center gap-1 shrink-0">
    <button onclick="mmDeleteMod('${safeFile}')" class="text-slate-600 hover:text-red-400 transition p-1.5 rounded-lg hover:bg-red-500/10 active:scale-90" title="Hapus mod">
     <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
    </button>
   </div>
  </div>`;
 }).join('');
 ins.innerHTML = header + `<div class="space-y-1.5">${cards}</div>`;
}

function mmDeleteMod(filename) {
 const modal = document.getElementById('genericModal');
 if (!modal) return;
 const iconEl = document.getElementById('genericModalIcon');
 const titleEl = document.getElementById('genericModalTitle');
 const msgEl = document.getElementById('genericModalMsg');
 const confirmBtn = document.getElementById('genericConfirmBtn');
 if (iconEl) iconEl.textContent = '🗑️';
 if (titleEl) { titleEl.textContent = 'Remove Mod'; titleEl.className = 'text-2xl font-black text-red-400 mb-1'; }
 if (msgEl) msgEl.innerHTML = `<code class="bg-slate-900 px-2 py-0.5 rounded text-red-300 text-sm font-mono">mods/${filename}</code><span class="text-slate-300"> will be deleted.</span>`;
 if (confirmBtn) { confirmBtn.textContent = 'Remove Mod'; confirmBtn.className = 'w-1/2 bg-red-600 hover:bg-red-500 text-white py-3 rounded-lg font-bold transition flex items-center justify-center gap-2 active:scale-95'; }
 modal.classList.remove('hidden');
 if (confirmBtn) {
  confirmBtn.onclick = async () => {
   modal.classList.add('hidden');
   try {
    await fetch('/api/delete', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ items: [`mods/${filename}`] }) });
    await fetch('/api/mod-meta', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ filename, meta: null }) });
    showToast(`Mod ${filename.replace(/\.jar$/i,'')} dihapus.`);
    mmLoadInstalled();
   } catch(e) {
    showToast('Gagal menghapus mod.', 'error');
   }
  };
 }
}
function deleteAccount() { document.getElementById('genericModalTitle').innerText = 'Hapus Akun Permanen?'; document.getElementById('genericModalMsg').innerHTML = 'Semua server, file, dan akun kamu akan <b>Dihapus Tanpa Sisa</b>. Yakin?'; const modal = document.getElementById('genericModal'); modal.classList.remove('hidden'); document.getElementById('genericConfirmBtn').onclick = async () => { modal.classList.add('hidden'); showToast('Sedang menghapus akun...', 'error'); try { const res = await fetch('/api/delete-account', { method: 'POST' }); if(res.ok) { window.location.href = '/'; } else { showToast('Gagal menghapus', 'error'); } } catch(e) { showToast('Koneksi Error', 'error'); } }; }

function deleteCurrentServer() { document.getElementById('genericModalTitle').innerText = 'Hapus Server Ini?'; document.getElementById('genericModalMsg').innerHTML = 'Semua file dan data game server ini akan <b>Dihapus Permanen</b>. Yakin?'; const modal = document.getElementById('genericModal'); modal.classList.remove('hidden'); document.getElementById('genericConfirmBtn').onclick = async () => { modal.classList.add('hidden'); showToast('Sedang menghapus server...', 'error'); try { const res = await fetch('/api/delete-current-server', { method: 'POST' }); if(res.ok) { window.location.href = '/dashboard'; } else { showToast('Gagal menghapus server', 'error'); } } catch(e) { showToast('Koneksi Error', 'error'); } }; }
document.addEventListener('DOMContentLoaded', () => { const cmdInput = document.getElementById('cmdInput'); if (cmdInput) { cmdInput.addEventListener('focus', function() { setTimeout(() => { window.scrollTo({ top: document.body.scrollHeight, behavior: "smooth" }); }, 300); }); } const javaSelect = document.getElementById('set-java-version'); if (javaSelect) javaSelect.addEventListener('change', () => updateCommandPreview()); loadDynamicVersionCatalog(); setStopButtonEnabled(false); });
