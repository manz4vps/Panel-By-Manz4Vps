const express = require('express');
const http = require('http');
const https = require('https'); 
const { Server } = require('socket.io');
const { spawn, exec, execSync } = require('child_process');
const session = require('express-session');
const FileStore = require('session-file-store')(session);
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const pidusage = require('pidusage');
const os = require('os');
const compression = require('compression');
// PlayIt tunnel dihapus

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
 pingTimeout: 60000,
 pingInterval: 25000,
 upgradeTimeout: 30000,
 transports: ['websocket', 'polling'],
});

// ================= AUTO JAVA MANAGER =================
function getRequiredJavaVersion(mcVersion) {
 if (!mcVersion) return 21; // Default standar
 const v = mcVersion.toLowerCase();
 
 // 1. Minecraft Klasik (Lama) - Udah aku tambahin 1.13 & 1.14 dkk biar aman!
 if (v.includes('1.7') || v.includes('1.8') || v.includes('1.9') || v.includes('1.10') || v.includes('1.11') || v.includes('1.12') || v.includes('1.13') || v.includes('1.14') || v.includes('1.15') || v.includes('1.16')) return 8;
 
 // 2. Era Minecraft 1.17 sampai 1.20.4
 if (v.includes('1.17') || v.includes('1.18') || v.includes('1.19') || v.includes('1.20.1') || v.includes('1.20.2') || v.includes('1.20.3') || v.includes('1.20.4')) return 17;
 
 // 3. Era Minecraft Modern 1.20.5, 1.21, 1.21.11 (Standard sekarang)
 if (v.includes('1.20.5') || v.includes('1.20.6') || v.includes('1.21')) return 21;

 // 4. Khusus buat Engine/Build versi "26.x" atau "26.2"
 if (v.startsWith('26.') || v.includes('26.2') || v.includes('1.22')) return 25;

 // Kalo versinya gak masuk kriteria di atas, pake 21
 return 21;
}

function fetchJsonHttps(url) {
 return new Promise((resolve, reject) => {
  https.get(url, { headers: { 'User-Agent': 'Manz4VPS-Panel/1.0' } }, (res) => {
   let data = '';
   res.on('data', chunk => data += chunk);
   res.on('end', () => { try { resolve(JSON.parse(data)); } catch(e) { reject(e); } });
  }).on('error', reject);
 });
}

function getSystemArch() {
 const a = os.arch();
 if (a === 'arm64' || a === 'aarch64') return { zulu: 'aarch64', temurin: 'aarch64' };
 if (a === 'arm') return { zulu: 'aarch32', temurin: 'arm' };
 return { zulu: 'x86_64', temurin: 'x64' };
}

async function getTemurinDownloadUrl(version) {
 const arch = getSystemArch().temurin;
 const url = `https://api.adoptium.net/v3/assets/latest/${version}/hotspot?architecture=${arch}&image_type=jdk&jvm_impl=hotspot&os=linux&vendor=eclipse`;
 const data = await fetchJsonHttps(url);
 if (data && data.length > 0) {
  const pkg = data[0].binary?.package;
  if (pkg && pkg.link) return pkg.link;
 }
 throw new Error(`Tidak ada Temurin JDK ${version} tersedia`);
}

async function getZuluDownloadUrl(version) {
 const arch = getSystemArch().zulu;
 const isAlpine = fs.existsSync('/etc/alpine-release');
 const zuluOs = isAlpine ? 'linux_musl' : 'linux';
 for (const status of ['ga', 'ea']) {
  try {
   const url = `https://api.azul.com/metadata/v1/zulu/packages/?java_version=${version}&os=${zuluOs}&arch=${arch}&archive_type=tar.gz&java_package_type=jdk&release_status=${status}&page=1&page_size=1`;
   const data = await fetchJsonHttps(url);
   if (data && data.length > 0 && data[0].download_url) return data[0].download_url;
  } catch(e) {}
 }
 throw new Error(`Tidak ada Zulu JDK ${version} tersedia untuk ${arch}`);
}

function checkSystemJava(version, callback) {
 const staticPaths = [
  `/usr/lib/jvm/java-${version}-openjdk-amd64/bin/java`,
  `/usr/lib/jvm/java-${version}-openjdk-arm64/bin/java`,
  `/usr/lib/jvm/java-${version}-openjdk-armhf/bin/java`,
  `/usr/lib/jvm/java-${version}-openjdk/bin/java`,
  `/usr/lib/jvm/java-${version}/bin/java`,
  `/usr/lib/jvm/temurin-${version}/bin/java`,
  `/usr/lib/jvm/zulu-${version}/bin/java`,
  `/usr/lib/jvm/zulu${version}/bin/java`,
  `/usr/lib/jvm/zulu${version}-amd64/bin/java`,
  `/usr/lib/jvm/zulu${version}-arm64/bin/java`,
  `/usr/local/lib/jvm/java-${version}/bin/java`,
  `/opt/java/${version}/bin/java`,
 ];
 for (const p of staticPaths) {
  if (fs.existsSync(p)) return callback(null, p);
 }
 try {
  const jvmBase = '/usr/lib/jvm';
  if (fs.existsSync(jvmBase)) {
   const dirs = fs.readdirSync(jvmBase);
   for (const dir of dirs) {
    const lower = dir.toLowerCase();
    const hasVersion = lower.includes(String(version));
    const isJdk = lower.includes('zulu') || lower.includes('temurin') || lower.includes('java') || lower.includes('jdk') || lower.includes('openjdk');
    if (hasVersion && isJdk) {
     const candidate = path.join(jvmBase, dir, 'bin', 'java');
     if (fs.existsSync(candidate)) return callback(null, candidate);
    }
   }
  }
 } catch(e) {}
 exec(`java -version 2>&1`, (err, stdout, stderr) => {
  const output = (stdout + stderr).toLowerCase();
  const match = output.match(/version\s+"?(\d+)/);
  if (!err && match) {
   const sysVer = parseInt(match[1]);
   if (sysVer >= version) {
    exec(`which java`, (e2, out2) => {
     const sysPath = out2 && out2.trim();
     if (!e2 && sysPath && fs.existsSync(sysPath)) return callback(null, sysPath);
     callback(null, null);
    });
    return;
   }
  }
  callback(null, null);
 });
}

function findJavaBinary(javaDir) {
 try {
  const binJava = path.join(javaDir, 'bin', 'java');
  if (fs.existsSync(binJava)) return binJava;
  const entries = fs.readdirSync(javaDir);
  for (const entry of entries) {
   const sub = path.join(javaDir, entry, 'bin', 'java');
   if (fs.existsSync(sub)) return sub;
  }
 } catch(e) {}
 return null;
}

function ensureJava(version, logCallback, callback) {
 const javaDir = path.join(__dirname, `java-runtime-${version}`);

 const existingBin = findJavaBinary(javaDir);
 if (existingBin) {
  try { fs.chmodSync(existingBin, '755'); } catch(e) {}
  return callback(null, existingBin);
 }

 checkSystemJava(version, (err, sysJava) => {
  if (sysJava) {
   return callback(null, sysJava);
  }

  function doInstall(apiUrl, label) {
   logCallback(`\x1b[33m⏳ Mendownload & Instalasi ${label} JDK ${version}... (Hanya sekali)\x1b[0m\n`);
   const tmpDir = path.join(__dirname, `tmp-java-${version}`);
   exec(
    `rm -rf "${tmpDir}" "${javaDir}" && mkdir -p "${tmpDir}" "${javaDir}" && curl -fsSL -o "${tmpDir}/java.tar.gz" "${apiUrl}" && tar -xzf "${tmpDir}/java.tar.gz" -C "${javaDir}" --strip-components=1 && rm -rf "${tmpDir}"`,
    { maxBuffer: 1024 * 1024 * 50 },
    (dlErr) => {
     if (dlErr) return callback(new Error(`Download ${label} JDK ${version} gagal: ${dlErr.message}`), null);
     const actualBin = findJavaBinary(javaDir);
     if (!actualBin) return callback(new Error(`${label} JDK ${version} terdownload tapi binary tidak ditemukan`), null);
     try { fs.chmodSync(actualBin, '755'); } catch(e) {}
     callback(null, actualBin);
    }
   );
  }

  getTemurinDownloadUrl(version)
   .then(apiUrl => doInstall(apiUrl, 'Temurin'))
   .catch(() => {
    getZuluDownloadUrl(version)
     .then(apiUrl => doInstall(apiUrl, 'Zulu'))
     .catch(err => callback(new Error(`Semua sumber JDK ${version} gagal: ${err.message}`), null));
   });
 });
}
// ===========================================================

// Mirip Pterodactyl: jalanin `java -version` beneran & tampilin outputnya sebelum
// eksekusi proses server, biar konsisten sama isi "process log" yang direplay saat refresh.
function logJavaVersion(javaPath, procLog, callback) {
 procLog(`\x1b[38;2;234;179;8m\x1b[1mcontainer@manz4vps~\x1b[0m java -version\n`);
 exec(`"${javaPath}" -version`, { timeout: 8000 }, (err, stdout, stderr) => {
 const out = ((stderr || '') + (stdout || '')).trim();
 if (out) procLog(out.split('\n').map(l => l + '\n').join(''));
 callback();
 });
}

const sessionMiddleware = session({ 
 store: new FileStore({ path: './sessions', retries: 0, logFn: () => {} }),
 secret: 'rahasia-v29-ultimate', 
 resave: false, 
 saveUninitialized: false,
 cookie: { maxAge: 30 * 24 * 60 * 60 * 1000 }
});
app.use(compression({ level: 6, threshold: 1024 }));
app.use(sessionMiddleware);
io.engine.use(sessionMiddleware);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use((req, res, next) => {
 res.setHeader('Permissions-Policy', 'autoplay=*');
 next();
});

// Request Timeout — batalin request yang nyangkut > 30 detik
// (upload routes dilewati, karena butuh waktu lebih lama)
app.use((req, res, next) => {
 if (req.path.startsWith('/api/upload/')) return next();
 const timeout = setTimeout(() => {
  if (!res.headersSent) {
   res.status(503).json({ error: 'Request timeout.' });
  }
 }, 30000);
 res.on('finish', () => clearTimeout(timeout));
 res.on('close', () => clearTimeout(timeout));
 next();
});

const baseServersDir = path.join(__dirname, 'servers');
const usersFile = path.join(__dirname, 'users.json');
const configFile = path.join(__dirname, 'panel_config.json');
const serverIdsFile = path.join(__dirname, 'server_ids.json');

if (!fs.existsSync(baseServersDir)) fs.mkdirSync(baseServersDir, { recursive: true });
if (!fs.existsSync(usersFile)) fs.writeFileSync(usersFile, JSON.stringify({}));
if (!fs.existsSync(configFile)) fs.writeFileSync(configFile, JSON.stringify({ registrationEnabled: true }));
if (!fs.existsSync(serverIdsFile)) fs.writeFileSync(serverIdsFile, JSON.stringify({}));

function readServerIds() {
 try { return JSON.parse(fs.readFileSync(serverIdsFile, 'utf8')); } catch(e) { return {}; }
}
function saveServerIds(map) {
 fs.writeFileSync(serverIdsFile, JSON.stringify(map));
}
function generateServerId() {
 return crypto.randomBytes(5).toString('hex');
}
function getOrCreateServerId(serverName, ownerHint) {
 if (!serverName) return null;
 const owner = getOwner(serverName, ownerHint) || ownerHint || serverName;
 const map = readServerIds();
 for (const id in map) {
  if (map[id].serverName === serverName && map[id].username === owner) return id;
 }
 let id;
 do { id = generateServerId(); } while (map[id]);
 map[id] = { serverName, username: owner };
 saveServerIds(map);
 return id;
}
function resolveServerId(id) {
 if (!id) return null;
 const map = readServerIds();
 return map[id] || null;
}
function renameServerId(oldServerName, oldOwner, newServerName, newOwner) {
 const map = readServerIds();
 for (const id in map) {
  if (map[id].serverName === oldServerName && map[id].username === oldOwner) {
   map[id] = { serverName: newServerName, username: newOwner };
   saveServerIds(map);
   return id;
  }
 }
 return null;
}
function removeServerId(serverName, owner) {
 const map = readServerIds();
 for (const id in map) {
  if (map[id].serverName === serverName && map[id].username === owner) { delete map[id]; saveServerIds(map); return; }
 }
}

function readConfig() {
 try { return JSON.parse(fs.readFileSync(configFile, 'utf8')); } catch(e) { return { registrationEnabled: true }; }
}
function saveConfig(cfg) {
 fs.writeFileSync(configFile, JSON.stringify(cfg, null, 2));
}

// ── Allocation pool (Pterodactyl-style IP/Port management) ──
function getAllocations() {
 const cfg = readConfig();
 if (!Array.isArray(cfg.allocations)) cfg.allocations = [];
 return cfg.allocations;
}
function saveAllocations(allocs) {
 const cfg = readConfig();
 cfg.allocations = allocs;
 saveConfig(cfg);
}
function allocOwnerKey(owner, serverName) { return owner + '::' + serverName; }
function getServerAllocations(owner, serverName) {
 const key = allocOwnerKey(owner, serverName);
 return getAllocations().filter(a => a.owner === key);
}
function getPrimaryAllocation(owner, serverName) {
 const list = getServerAllocations(owner, serverName);
 return list.find(a => a.primary) || list[0] || null;
}
function hasFreeAllocation() {
 return getAllocations().some(a => !a.owner);
}
function ensureServerAllocation(serverName, ownerHint) {
 const realOwner = getOwner(serverName, ownerHint) || ownerHint || serverName;
 const key = allocOwnerKey(realOwner, serverName);
 const allocs = getAllocations();
 if (allocs.some(a => a.owner === key)) return;
 // Jalur normal: ambil satu port kosong dari pool global.
 const free = allocs.find(a => !a.owner);
 if (free) {
  free.owner = key; free.primary = true;
  saveAllocations(allocs);
  return;
 }
 // Fallback migrasi: HANYA untuk server lama yang sudah punya ip/port asli di panel_settings.json
 // dari sebelum sistem pool ada. Server baru tidak akan pernah punya nilai ini karena
 // getUserSettings() tidak lagi mengarang port acak untuk file settings yang baru dibuat —
 // pembuatan server baru sudah diblokir lebih dulu di endpoint create-server kalau pool kosong.
 try {
  const dir = getUserDir(serverName, realOwner);
  const file = dir ? path.join(dir, 'panel_settings.json') : null;
  if (file && fs.existsSync(file)) {
   const s = JSON.parse(fs.readFileSync(file));
   if (s.port) {
    allocs.push({ id: crypto.randomUUID(), ip: s.ip || '127.0.0.1', port: parseInt(s.port), owner: key, primary: true });
    saveAllocations(allocs);
   }
  }
 } catch(e) {}
}
function releaseServerAllocations(owner, serverName) {
 const key = allocOwnerKey(owner, serverName);
 const allocs = getAllocations();
 let changed = false;
 allocs.forEach(a => { if (a.owner === key) { a.owner = null; a.primary = false; changed = true; } });
 if (changed) saveAllocations(allocs);
}

function readUsers() {
 try {
 const data = fs.readFileSync(usersFile, 'utf8');
 return data ? JSON.parse(data) : {};
 } catch(e) {
 return {}; 
 }
}

function hashPassword(password) { return crypto.createHash('sha256').update(password).digest('hex'); }

// ── Password Encryption (AES-256-CBC) ──
function getEncKey() {
  const secret = process.env.SESSION_SECRET || 'manz4vps-default-secret-key-2024';
  return crypto.createHash('sha256').update(secret).digest(); // 32 bytes
}
function encryptPassword(plain) {
  if (!plain) return '';
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv('aes-256-cbc', getEncKey(), iv);
  const enc = Buffer.concat([cipher.update(plain, 'utf8'), cipher.final()]);
  return iv.toString('hex') + ':' + enc.toString('hex');
}
function decryptPassword(enc) {
  if (!enc) return null;
  // Jika masih plain text lama (tidak ada ':' atau bukan format iv:hex), kembalikan apa adanya
  if (!enc.includes(':')) return enc;
  try {
    const [ivHex, encHex] = enc.split(':');
    const iv = Buffer.from(ivHex, 'hex');
    const encBuf = Buffer.from(encHex, 'hex');
    const decipher = crypto.createDecipheriv('aes-256-cbc', getEncKey(), iv);
    return Buffer.concat([decipher.update(encBuf), decipher.final()]).toString('utf8');
  } catch(e) { return null; }
}

// ── Migrasi passwordPlain → passwordEnc saat startup ──
function migratePasswords() {
  try {
    const users = readUsers();
    let changed = false;
    for (const u in users) {
      if (typeof users[u] !== 'object') continue;
      if (users[u].passwordPlain && !users[u].passwordEnc) {
        users[u].passwordEnc = encryptPassword(users[u].passwordPlain);
        delete users[u].passwordPlain;
        changed = true;
      }
    }
    if (changed) fs.writeFileSync(usersFile, JSON.stringify(users));
  } catch(e) { /* abaikan error migrasi */ }
}

function getOwner(serverName, preferUser) {
 const users = readUsers();
 if (preferUser && users[preferUser] && users[preferUser].servers && users[preferUser].servers.includes(serverName)) return preferUser;
 for (let u in users) {
 if (users[u].servers && users[u].servers.includes(serverName)) return u;
 }
 return null;
}

function getUserDir(serverName, ownerHint) {
 if (!serverName) return null;

 let owner = getOwner(serverName, ownerHint);
 const users = readUsers();
 if (!owner && users[serverName]) return null;
 if (!owner) owner = ownerHint || serverName;

 const userFolder = path.join(baseServersDir, owner);
 if (!fs.existsSync(userFolder)) fs.mkdirSync(userFolder, { recursive: true });
 try { fs.chmodSync(userFolder, 0o755); } catch(e) {}

 const serverDir = path.join(userFolder, serverName);
 if (!fs.existsSync(serverDir)) fs.mkdirSync(serverDir, { recursive: true });
 try { fs.chmodSync(serverDir, 0o755); } catch(e) {}
 return serverDir;
}

function generateRandomPort() {
 let port; do { port = Math.floor(Math.random() * 55535) + 10000; } while (port > 65535); return port.toString();
}

function getUserSettings(serverName, ownerHint) {
 const owner = getOwner(serverName, ownerHint);
 const ownerLimits = owner ? (readUsers()[owner]?.limits || { ram: 3072, cpu: 200, disk: 10240 }) : { ram: 3072, cpu: 200, disk: 10240 };
 const defaultRam = ownerLimits.ram % 1024 === 0 ? `${ownerLimits.ram / 1024}G` : `${ownerLimits.ram}M`;
 let def = { ram: defaultRam, jarFile: 'server.jar', ip: '127.0.0.1', port: '25565', engine: 'java', installedVersion: '', autoStart: true, javaVersion: '21', useCustomStartup: false, customStartupCmd: '', srvLimits: { ram: ownerLimits.ram || 3072, cpu: ownerLimits.cpu || 200, disk: ownerLimits.disk || 10240, portLimit: ownerLimits.portLimit || 2 } };
 const dir = getUserDir(serverName, ownerHint);
 if (!dir) return def;
 const file = path.join(dir, 'panel_settings.json');
 let result;
 if (fs.existsSync(file)) {
 try { result = { ...def, ...JSON.parse(fs.readFileSync(file)) }; } catch(e){ result = def; }
 } else {
 // Jangan mengarang port acak di sini — port baru hanya boleh berasal dari pool global
 // (lihat ensureServerAllocation di bawah). Kalau pool kosong, endpoint pembuatan server
 // sudah menolak request ini sebelum sampai ke sini.
 delete def.port;
 fs.writeFileSync(file, JSON.stringify(def));
 result = def;
 }
 // IP & Port sekarang dikelola lewat pool alokasi global (bukan diketik bebas lagi).
 // Migrasi ke pool HANYA sekali (ditandai flag allocationMigrated) — supaya server yang
 // sengaja "dilepas" dari pool oleh admin tidak otomatis dibuatkan alokasi baru lagi
 // setiap kali settings-nya dibaca (ini penyebab port duplikat muncul lagi di pool).
 const realOwner = owner || ownerHint || serverName;
 if (!result.allocationMigrated) {
 ensureServerAllocation(serverName, realOwner);
 result.allocationMigrated = true;
 try { fs.writeFileSync(file, JSON.stringify(result)); } catch(e) {}
 }
 const primary = getPrimaryAllocation(realOwner, serverName);
 if (primary) { result.ip = primary.ip; result.port = String(primary.port); result.alias = primary.alias || ''; }
 return result;
}

const activeServers = {};
// Track operasi archive/extract yang sedang berjalan (untuk restore popup setelah refresh)
const activeOps = {}; // roomKey → { type, percent, processed, total }

function getStateKey(srvName, ownerHint) {
 const o = ownerHint || getOwner(srvName) || srvName;
 return o + '::' + srvName;
}

function getUserState(serverName, owner) {
 const ownerStr = owner || getOwner(serverName) || serverName;
 const key = ownerStr + '::' + serverName;
 if (!activeServers[key]) activeServers[key] = { process: null, logs: [], processLog: [], isRestarting: false, isDownloading: false, startTime: null, isStarting: false, netBaseRx: 0, netBaseTx: 0, netAccumRx: 0, netAccumTx: 0, _lastSsRx: 0, _lastSsTx: 0, _restartKillTimer: null, _owner: ownerStr, _srvName: serverName };
 return activeServers[key];
}

const getServerName = (req) => {
 // Prefer tab-specific server ID header — isolates concurrent tabs from each other
 const panelServerId = req.headers && req.headers['x-panel-server-id'];
 if (panelServerId) {
  const info = resolveServerId(panelServerId);
  if (info) {
   const users = readUsers();
   const reqUser = req.session.username;
   const isOwner = reqUser === info.username;
   const isAdmin = !!(users[reqUser] && users[reqUser].isAdmin);
   if (isOwner || isAdmin) return info.serverName;
  }
 }
 // Fallback to session (for requests without the header)
 if (req.session.currentServer) return req.session.currentServer;
 const users = readUsers();
 const u = users[req.session.username];
 if (u && u.servers && u.servers.length > 0) return u.servers[0];
 return null;
};

app.get('/api/can-register', (req, res) => {
 const cfg = readConfig();
 res.json({ allowed: cfg.registrationEnabled !== false });
});

app.post('/register', (req, res) => {
 const cfg = readConfig();
 if (cfg.registrationEnabled === false) {
  const users = readUsers();
  const isFirstUser = Object.keys(users).length === 0;
  if (!isFirstUser) return res.status(403).json({ error: "Registrasi sedang ditutup oleh admin." });
 }
 const { username, email, password } = req.body;
 if (!username || !email || !password) return res.status(400).json({ error: "Data tidak boleh kosong!" });
 if (!/^[a-zA-Z0-9_]+$/.test(username)) return res.status(400).json({ error: "Username hanya huruf & angka!" });

 let users = readUsers();
 if (users[username]) return res.status(400).json({ error: "Username sudah terdaftar!" });
 for (let u in users) { if (typeof users[u] === 'object' && users[u].email === email) return res.status(400).json({ error: "Email sudah digunakan!" }); }

 const isFirstUser = Object.keys(users).length === 0;
 users[username] = { password: hashPassword(password), passwordEnc: encryptPassword(password), email: email, limits: { ram: 3072, cpu: 200, disk: 10240 }, servers: [], isAdmin: isFirstUser };
 fs.writeFileSync(usersFile, JSON.stringify(users));
 res.json({ success: true, message: "Akun berhasil dibuat! Silakan Login." });
});

app.post('/login', (req, res) => {
 const { username, password } = req.body; 
 let users = readUsers();
 let foundUsername = null;

 for (let userKey in users) { let u = users[userKey]; if (typeof u === 'object' && (userKey === username || u.email === username) && u.password === hashPassword(password)) { foundUsername = userKey; break; } }
 if (!foundUsername) return res.status(401).json({ error: "Username/Email atau password salah!" });

 req.session.loggedIn = true; req.session.username = foundUsername;
 res.json({ success: true });
});

app.get('/logout', (req, res) => { req.session.destroy(); res.redirect('/'); });
const checkAuth = (req, res, next) => { 
 res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
 res.header('Expires', '-1');
 res.header('Pragma', 'no-cache');

 if (req.session && req.session.loggedIn && req.session.username) return next(); 
 if (req.path.startsWith('/api/')) return res.status(401).json({ error: 'Sesi berakhir.' }); 
 res.redirect('/'); 
};

const checkAdmin = (req, res, next) => {
 res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
 res.header('Expires', '-1');
 res.header('Pragma', 'no-cache');
 if (req.session && req.session.loggedIn && req.session.username) {
 const users = readUsers();
 if (users[req.session.username] && users[req.session.username].isAdmin) return next();
 }
 if (req.path.startsWith('/api/')) return res.status(403).json({ error: 'Akses ditolak.' });
 res.redirect('/');
};

app.get(/\.html$/, (req, res) => {
 const clean = req.path.replace(/\.html$/, '').replace(/\/index$/, '') || '/';
 const qs = req.originalUrl.slice(req.path.length);
 res.redirect(301, clean + qs);
});

app.use(express.static('public', {
 maxAge: '1h',
 index: false,
 setHeaders: (res, filePath) => {
  if (filePath.endsWith('.html')) {
   res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
  }
 }
}));
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public', 'login.html')));
app.get('/login', (req, res) => res.sendFile(path.join(__dirname, 'public', 'login.html')));
app.get('/dashboard', checkAuth, (req, res) => { req.session.currentServer = null; req.session.viewAsUser = null; res.sendFile(path.join(__dirname, 'public', 'dashboard.html')) });
app.get('/panel', checkAuth, (req, res) => {
 if(!req.session.currentServer) return res.redirect('/dashboard');
 const id = getOrCreateServerId(req.session.currentServer, req.session.viewAsUser || req.session.username);
 return res.redirect('/server/' + id + '/console');
});
app.get('/admin', checkAdmin, (req, res) => res.sendFile(path.join(__dirname, 'public', 'admin.html')));
app.get('/admin/serverport', checkAdmin, (req, res) => res.sendFile(path.join(__dirname, 'public', 'serverport.html')));
app.get('/admin/manageuser', checkAdmin, (req, res) => res.sendFile(path.join(__dirname, 'public', 'manageuser.html')));

const TAB_URL_MAP = { console: 'console', files: 'files', filemanager: 'files', network: 'network', startup: 'startup', plugins: 'plugins', plugin: 'plugins', settings: 'settings', versions: 'versions' };
app.get('/server/:id/:tab?', checkAuth, (req, res) => {
 const info = resolveServerId(req.params.id);
 if (!info) return res.redirect('/dashboard');
 const users = readUsers();
 const isOwner = req.session.username === info.username;
 const isAdmin = !!(users[req.session.username] && users[req.session.username].isAdmin);
 if (!isOwner && !isAdmin) return res.status(403).send('Akses ditolak.');
 req.session.currentServer = info.serverName;
 req.session.viewAsUser = isOwner ? null : info.username;
 const tabParam = (req.params.tab || 'console').toLowerCase();
 if (req.params.tab && !TAB_URL_MAP[tabParam]) return res.redirect('/server/' + req.params.id + '/console');
 res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
 res.setHeader('Pragma', 'no-cache');
 res.setHeader('Expires', '0');
 res.sendFile(path.join(__dirname, 'public', 'panel.html'));
});

app.get('/api/admin/system-stats', checkAdmin, (req, res) => {
 const t1 = os.cpus();
 setTimeout(() => {
  const t2 = os.cpus();
  let idle = 0, total = 0;
  for (let i = 0; i < t1.length; i++) {
   const s = Object.values(t1[i].times).reduce((a, b) => a + b, 0);
   const e = Object.values(t2[i].times).reduce((a, b) => a + b, 0);
   idle += t2[i].times.idle - t1[i].times.idle;
   total += e - s;
  }
  const cpuPct = total > 0 ? parseFloat(((1 - idle / total) * 100).toFixed(1)) : 0;
  const ramTotal = os.totalmem();
  const ramUsed = ramTotal - os.freemem();
  function getDirSz(p) { let s = 0; try { fs.readdirSync(p).forEach(f => { const fp = path.join(p, f); const st = fs.statSync(fp); s += st.isDirectory() ? getDirSz(fp) : st.size; }); } catch(e) {} return s; }
  let diskUsed = 0, diskTotal = 0;
  try { const df = execSync('df -B1 /').toString().trim().split('\n')[1].split(/\s+/); diskTotal = parseInt(df[1]) || 0; diskUsed = parseInt(df[2]) || 0; } catch(e) {}
  const users = readUsers();
  let totalSrv = 0, onlineSrv = 0;
  for (const u in users) { const srvs = users[u].servers || []; totalSrv += srvs.length; for (const sv of srvs) { if (activeServers[u + '::' + sv] && activeServers[u + '::' + sv].process) onlineSrv++; } }
  res.json({ cpu: cpuPct, ramUsed, ramTotal, diskUsed, diskTotal, totalSrv, onlineSrv, cores: t1.length, uptime: os.uptime() });
 }, 250);
});

app.get('/api/admin/config', checkAdmin, (req, res) => {
 res.json(readConfig());
});

app.post('/api/admin/config', checkAdmin, (req, res) => {
 const cfg = readConfig();
 if (typeof req.body.registrationEnabled === 'boolean') cfg.registrationEnabled = req.body.registrationEnabled;
 saveConfig(cfg);
 res.json({ success: true, config: cfg });
});

app.get('/api/admin/users', checkAdmin, (req, res) => {
 const users = readUsers();
 const result = [];
 for (const username in users) {
 const u = users[username];
 const servers = (u.servers || []).map(srvName => {
 const stateKey = username + '::' + srvName;
 const state = activeServers[stateKey];
 const srvSettings = getUserSettings(srvName, username);
 const isOnline = !!(state && state.startTime);
 return {
  id: getOrCreateServerId(srvName, username),
  name: srvName,
  owner: username,
  isOnline,
  cpu: isOnline ? parseFloat((state._lastCpu || 0).toFixed(2)) : 0,
  ramMB: isOnline ? Math.round(state._lastRamMB || 0) : 0,
  srvLimits: srvSettings.srvLimits || { ram: u.limits?.ram || 2048, cpu: u.limits?.cpu || 100, disk: u.limits?.disk || 32768, portLimit: u.limits?.portLimit || 2 }
 };
 });
 result.push({ username, email: u.email || '', limits: u.limits || { ram: 3072, cpu: 200, disk: 10240 }, servers, balance: u.balance || 0, freePackageUsed: u.freePackageUsed || false });
 }
 res.json(result);
});

app.post('/api/admin/view-server', checkAdmin, (req, res) => {
 const { serverName, ownerUsername } = req.body;
 if (!serverName || !ownerUsername) return res.status(400).json({ error: 'serverName dan ownerUsername wajib diisi' });
 req.session.currentServer = serverName;
 req.session.viewAsUser = ownerUsername;
 const id = getOrCreateServerId(serverName, ownerUsername);
 res.json({ success: true, id });
});

app.post('/api/admin/start-server', checkAdmin, (req, res) => {
 const { serverName, ownerUsername } = req.body;
 if (!serverName) return res.status(400).json({ error: 'Nama server tidak valid.' });
 const owner = ownerUsername || getOwner(serverName) || serverName;
 const state = getUserState(serverName, owner);
 if (state.process || state.isStarting) return res.status(400).json({ error: 'Server sudah berjalan.' });
 globalSpawn(serverName, owner);
 res.json({ success: true });
});

app.post('/api/admin/restart-server', checkAdmin, (req, res) => {
 const { serverName, ownerUsername } = req.body;
 if (!serverName) return res.status(400).json({ error: 'Nama server tidak valid.' });
 const owner = ownerUsername || getOwner(serverName) || serverName;
 const stateKey = owner + '::' + serverName;
 const state = activeServers[stateKey];
 if (!state || !state.process) return res.status(400).json({ error: 'Server tidak berjalan.' });
 try {
 state.isRestarting = true;
 const settings = getUserSettings(serverName, owner);
 if (settings.engine === 'node' || settings.engine === 'python') {
 try { state.process.kill('SIGTERM'); } catch(e) {}
 } else {
 try { state.process.stdin.write('stop\n'); } catch(e) {}
 }
 if (state._restartKillTimer) clearTimeout(state._restartKillTimer);
 state._restartKillTimer = setTimeout(() => {
 if (state.process && state.isRestarting) {
 try { state.process.kill('SIGTERM'); } catch(e) {}
 setTimeout(() => { if (state.process && state.isRestarting) { try { state.process.kill('SIGKILL'); } catch(e) {} } }, 5000);
 }
 }, 45000);
 res.json({ success: true });
 } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/admin/stop-server', checkAdmin, (req, res) => {
 const { serverName, force, ownerUsername } = req.body;
 const owner = ownerUsername || getOwner(serverName) || serverName;
 const stateKey = owner + '::' + serverName;
 const state = activeServers[stateKey];
 if (!state || !state.process) return res.status(400).json({ error: 'Server tidak berjalan.' });
 try {
 state.process.kill(force ? 'SIGKILL' : 'SIGTERM');
 res.json({ success: true });
 } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/admin/delete-user', checkAdmin, (req, res) => {
 const { username } = req.body;
 if (!username) return res.status(400).json({ error: 'Tidak valid.' });
 const users2 = readUsers();
 if (users2[username] && users2[username].isAdmin) return res.status(400).json({ error: 'Tidak bisa menghapus admin.' });
 let users = readUsers();
 if (!users[username]) return res.status(404).json({ error: 'User tidak ditemukan.' });
 (users[username].servers || []).forEach(srvName => {
 const _key = username + '::' + srvName;
 const state = activeServers[_key];
 if (state && state.process) { try { state.process.kill('SIGKILL'); } catch(e){} delete activeServers[_key]; }
 releaseServerAllocations(username, srvName);
 });
 const userDirPath = path.join(baseServersDir, username);
 if (fs.existsSync(userDirPath)) { try { fs.rmSync(userDirPath, { recursive: true, force: true }); } catch(e){} }
 delete users[username];
 fs.writeFileSync(usersFile, JSON.stringify(users));
 res.json({ success: true });
});

app.post('/api/admin/create-user', checkAdmin, (req, res) => {
 const { username, email, password } = req.body;
 if (!username || !email || !password) return res.status(400).json({ error: 'Username, email, dan password wajib diisi.' });
 if (!/^[a-zA-Z0-9_]+$/.test(username)) return res.status(400).json({ error: 'Username hanya huruf, angka, dan underscore.' });
 if (!password) return res.status(400).json({ error: 'Password tidak boleh kosong.' });
 let users = readUsers();
 if (users[username]) return res.status(400).json({ error: 'Username sudah terdaftar.' });
 for (let u in users) { if (typeof users[u] === 'object' && users[u].email === email) return res.status(400).json({ error: 'Email sudah digunakan.' }); }
 users[username] = { password: hashPassword(password), passwordEnc: encryptPassword(password), email, limits: { ram: 3072, cpu: 200, disk: 10240 }, servers: [], isAdmin: false };
 fs.writeFileSync(usersFile, JSON.stringify(users));
 res.json({ success: true });
});

app.post('/api/admin/create-server-for-users', checkAdmin, (req, res) => {
 const { usernames, serverName, engine, ram, cpu, disk } = req.body;
 if (!serverName || !/^[a-zA-Z0-9_-]+$/.test(serverName)) return res.status(400).json({ error: 'Nama server hanya boleh huruf, angka, strip, dan underscore.' });
 if (!Array.isArray(usernames) || usernames.length === 0) return res.status(400).json({ error: 'Pilih minimal satu user.' });
 let users = readUsers();
 const newOnes = usernames.filter(u => users[u] && !(users[u].servers || []).includes(serverName));
 const freeCount = getAllocations().filter(a => !a.owner).length;
 if (newOnes.length > 0 && freeCount < newOnes.length) {
  return res.status(400).json({ error: `Port kosong tidak cukup. Butuh ${newOnes.length} port tapi cuma ada ${freeCount} port kosong di pool. Tambah port dulu di menu Server Port.` });
 }
 const results = [];
 for (const username of usernames) {
  if (!users[username]) { results.push({ username, success: false, error: 'User tidak ditemukan.' }); continue; }
  if (!users[username].servers) users[username].servers = [];
  if (users[username].servers.includes(serverName)) { results.push({ username, success: false, error: 'Server sudah ada.' }); continue; }
  users[username].servers.push(serverName);
  results.push({ username, success: true });
 }
 fs.writeFileSync(usersFile, JSON.stringify(users));
 for (const r of results.filter(r => r.success)) {
  getUserDir(serverName, r.username);
  getOrCreateServerId(serverName, r.username);
  const settings = getUserSettings(serverName, r.username);
  let changed = false;
  if (engine) { settings.engine = engine; changed = true; }
  if (engine === 'node') { settings.jarFile = 'index.js'; changed = true; }
  else if (engine === 'python') { settings.jarFile = 'main.py'; changed = true; }
  if (ram) { const ramMB = parseInt(ram); settings.ram = ramMB % 1024 === 0 ? `${ramMB/1024}G` : `${ramMB}M`; if (!settings.srvLimits) settings.srvLimits = {}; settings.srvLimits.ram = ramMB; changed = true; }
  if (cpu) { if (!settings.srvLimits) settings.srvLimits = {}; settings.srvLimits.cpu = parseInt(cpu); changed = true; }
  if (disk) { if (!settings.srvLimits) settings.srvLimits = {}; settings.srvLimits.disk = parseInt(disk); changed = true; }
  if (changed) {
   const srvDir = getUserDir(serverName, r.username);
   fs.writeFileSync(path.join(srvDir, 'panel_settings.json'), JSON.stringify(settings));
  }
 }
 res.json({ success: true, results });
});

app.post('/api/admin/update-limits', checkAdmin, (req, res) => {
 const { username, ram, cpu, disk } = req.body;
 if (!username) return res.status(400).json({ error: 'Tidak valid.' });
 let users = readUsers();
 if (!users[username]) return res.status(404).json({ error: 'User tidak ditemukan.' });
 if (!users[username].limits) users[username].limits = {};
 if (ram) {
 const ramMB = parseInt(ram);
 users[username].limits.ram = ramMB;
 const ramStr = ramMB % 1024 === 0 ? `${ramMB / 1024}G` : `${ramMB}M`;
 const userServers = users[username].servers || [];
 userServers.forEach(srvName => {
 const srvSettingsFile = path.join(baseServersDir, username, srvName, 'panel_settings.json');
 if (fs.existsSync(srvSettingsFile)) {
 try {
 const srvSettings = JSON.parse(fs.readFileSync(srvSettingsFile, 'utf8'));
 srvSettings.ram = ramStr;
 if (!srvSettings.srvLimits) srvSettings.srvLimits = {};
 srvSettings.srvLimits.ram = ramMB;
 fs.writeFileSync(srvSettingsFile, JSON.stringify(srvSettings));
 } catch(e) {}
 }
 });
 }
 if (cpu) users[username].limits.cpu = parseInt(cpu);
 if (disk) users[username].limits.disk = parseInt(disk);
 fs.writeFileSync(usersFile, JSON.stringify(users));
 res.json({ success: true });
});

app.post('/api/admin/update-server-limits', checkAdmin, (req, res) => {
 const { serverName, ram, cpu, disk, portLimit } = req.body;
 if (!serverName) return res.status(400).json({ error: 'Nama server wajib diisi.' });
 const settingsFile = path.join(getUserDir(serverName), 'panel_settings.json');
 const settings = getUserSettings(serverName);
 if (!settings.srvLimits) settings.srvLimits = {};
 if (ram) { settings.srvLimits.ram = parseInt(ram); const ramStr = parseInt(ram) % 1024 === 0 ? `${parseInt(ram)/1024}G` : `${parseInt(ram)}M`; settings.ram = ramStr; if (settings.customStartupCmd && /\-Xmx/i.test(settings.customStartupCmd)) { settings.customStartupCmd = settings.customStartupCmd.replace(/-Xmx\S+/gi, `-Xmx${ramStr}`); } }
 if (cpu) settings.srvLimits.cpu = parseInt(cpu);
 if (disk) settings.srvLimits.disk = parseInt(disk);
 if (portLimit !== undefined && portLimit !== '') { const pl = parseInt(portLimit); if (!isNaN(pl) && pl >= 1) settings.srvLimits.portLimit = pl; }
 fs.writeFileSync(settingsFile, JSON.stringify(settings));
 res.json({ success: true });
});

app.post('/api/admin/reset-password', checkAdmin, (req, res) => {
 const { username, newPassword } = req.body;
 if (!username) return res.status(400).json({ error: 'Tidak valid.' });
 if (!newPassword || newPassword.length < 6) return res.status(400).json({ error: 'Password minimal 6 karakter.' });
 let users = readUsers();
 if (!users[username]) return res.status(404).json({ error: 'User tidak ditemukan.' });
 users[username].password = hashPassword(newPassword);
 users[username].passwordEnc = encryptPassword(newPassword);
 delete users[username].passwordPlain;
 fs.writeFileSync(usersFile, JSON.stringify(users));
 res.json({ success: true });
});

app.post('/api/admin/view-password', checkAdmin, (req, res) => {
 const { username } = req.body;
 if (!username) return res.status(400).json({ error: 'Tidak valid.' });
 const users = readUsers();
 if (!users[username]) return res.status(404).json({ error: 'User tidak ditemukan.' });
 const plain = decryptPassword(users[username].passwordEnc) || null;
 res.json({ passwordPlain: plain });
});

app.post('/api/admin/copy-server', checkAdmin, (req, res) => {
 const { sourceServer, targetUser, newServerName } = req.body;
 if (!sourceServer || !targetUser || !newServerName) return res.status(400).json({ error: 'Data tidak lengkap.' });
 if (!/^[a-zA-Z0-9_-]+$/.test(newServerName)) return res.status(400).json({ error: 'Nama server hanya boleh huruf, angka, _ dan -' });
 const users = readUsers();
 if (!users[targetUser]) return res.status(404).json({ error: 'Target user tidak ditemukan.' });
 if (getOwner(newServerName)) return res.status(400).json({ error: `Nama server "${newServerName}" sudah digunakan.` });
 if (!hasFreeAllocation()) return res.status(400).json({ error: 'Tidak ada port kosong di pool. Tambah port dulu di menu Server Port sebelum menyalin server.' });
 const srcDir = getUserDir(sourceServer);
 if (!fs.existsSync(srcDir)) return res.status(404).json({ error: 'Server asal tidak ditemukan.' });
 const destDir = path.join(baseServersDir, targetUser, newServerName);
 if (fs.existsSync(destDir)) return res.status(400).json({ error: 'Folder server sudah ada.' });
 try {
 fs.cpSync(srcDir, destDir, { recursive: true });
 const destSettingsFile = path.join(destDir, 'panel_settings.json');
 let newSettings = {};
 if (fs.existsSync(destSettingsFile)) { try { newSettings = JSON.parse(fs.readFileSync(destSettingsFile, 'utf8')); } catch(e){} }
 // Jangan warisi ip/port/allocationMigrated dari server asal — server hasil copy harus
 // dapat port sendiri dari pool (lewat ensureServerAllocation), bukan duplikat port asalnya.
 delete newSettings.port; delete newSettings.ip; delete newSettings.allocationMigrated;
 fs.writeFileSync(destSettingsFile, JSON.stringify(newSettings));
 if (!users[targetUser].servers) users[targetUser].servers = [];
 users[targetUser].servers.push(newServerName);
 fs.writeFileSync(usersFile, JSON.stringify(users));
 getOrCreateServerId(newServerName, targetUser);
 getUserSettings(newServerName, targetUser);
 res.json({ success: true });
 } catch(e) { res.status(500).json({ error: `Gagal menyalin: ${e.message}` }); }
});

app.post('/api/admin/delete-server', checkAdmin, (req, res) => {
  const { serverName } = req.body;
  if (!serverName) return res.status(400).json({ error: 'Nama server wajib diisi.' });
  const users = readUsers();
  const owner = getOwner(serverName);
  if (!owner) return res.status(404).json({ error: 'Server tidak ditemukan.' });
  const _adminDelKey = owner + '::' + serverName;
  const state = activeServers[_adminDelKey];
  if (state && state.process) { try { state.process.kill('SIGKILL'); } catch(e){} }
  delete activeServers[_adminDelKey];
  const dirPath = getUserDir(serverName);
  if (fs.existsSync(dirPath)) { try { fs.rmSync(dirPath, { recursive: true, force: true }); } catch(e){} }
  users[owner].servers = (users[owner].servers || []).filter(s => s !== serverName);
  fs.writeFileSync(usersFile, JSON.stringify(users));
  removeServerId(serverName, owner);
  releaseServerAllocations(owner, serverName);
  res.json({ success: true });
});

// ── Global allocation pool (admin) ──
app.get('/api/admin/allocations', checkAdmin, (req, res) => {
  const allocs = getAllocations();
  const list = allocs.map(a => {
    let ownerUsername = null, ownerServer = null;
    if (a.owner) { const idx = a.owner.indexOf('::'); ownerUsername = a.owner.slice(0, idx); ownerServer = a.owner.slice(idx + 2); }
    return { id: a.id, ip: a.ip, port: a.port, alias: a.alias || '', primary: !!a.primary, ownerUsername, ownerServer };
  }).sort((a, b) => a.ip === b.ip ? a.port - b.port : a.ip.localeCompare(b.ip));
  res.json(list);
});

app.post('/api/admin/allocations/set-alias', checkAdmin, (req, res) => {
  const { id, alias } = req.body;
  const allocs = getAllocations();
  const target = allocs.find(a => a.id === id);
  if (!target) return res.status(404).json({ error: 'Alokasi tidak ditemukan.' });
  target.alias = String(alias || '').trim().slice(0, 100);
  saveAllocations(allocs);
  res.json({ success: true, alias: target.alias });
});

app.post('/api/admin/allocations/add', checkAdmin, (req, res) => {
  const { ip, portStart, portEnd } = req.body;
  const cleanIp = String(ip || '').trim();
  const start = parseInt(portStart), end = parseInt(portEnd || portStart);
  if (!cleanIp) return res.status(400).json({ error: 'IP wajib diisi.' });
  if (isNaN(start) || isNaN(end) || start < 1 || end > 65535 || start > end) return res.status(400).json({ error: 'Range port tidak valid (1-65535).' });
  if (end - start > 500) return res.status(400).json({ error: 'Maksimal 500 port sekaligus.' });
  const allocs = getAllocations();
  const existing = new Set(allocs.filter(a => a.ip === cleanIp).map(a => a.port));
  let added = 0;
  const cleanAlias = String(req.body.defaultAlias || '').trim().slice(0, 100);
  for (let p = start; p <= end; p++) {
    if (existing.has(p)) continue;
    allocs.push({ id: crypto.randomUUID(), ip: cleanIp, port: p, owner: null, primary: false, alias: cleanAlias });
    added++;
  }
  saveAllocations(allocs);
  res.json({ success: true, added });
});

app.post('/api/admin/allocations/delete', checkAdmin, (req, res) => {
  const { id } = req.body;
  const allocs = getAllocations();
  const target = allocs.find(a => a.id === id);
  if (!target) return res.status(404).json({ error: 'Alokasi tidak ditemukan.' });
  if (target.owner) return res.status(400).json({ error: 'Alokasi masih dipakai server, lepas dulu.' });
  saveAllocations(allocs.filter(a => a.id !== id));
  res.json({ success: true });
});

// Hapus semua alokasi yang tidak dipakai (owner === null) sekaligus
app.post('/api/admin/allocations/delete-all-free', checkAdmin, (req, res) => {
  const allocs = getAllocations();
  const kept = allocs.filter(a => !!a.owner);
  const deleted = allocs.length - kept.length;
  saveAllocations(kept);
  res.json({ success: true, deleted });
});

// Hapus banyak alokasi berdasarkan array id — hanya yang tidak dipakai
app.post('/api/admin/allocations/delete-bulk', checkAdmin, (req, res) => {
  const { ids } = req.body;
  if (!Array.isArray(ids) || ids.length === 0) return res.status(400).json({ error: 'Tidak ada id yang dikirim.' });
  const allocs = getAllocations();
  const idSet = new Set(ids);
  let deleted = 0, skipped = 0;
  const kept = allocs.filter(a => {
    if (!idSet.has(a.id)) return true;
    if (a.owner) { skipped++; return true; }
    deleted++;
    return false;
  });
  saveAllocations(kept);
  res.json({ success: true, deleted, skipped });
});

app.post('/api/admin/allocations/assign', checkAdmin, (req, res) => {
  const { id, serverName } = req.body;
  const owner = getOwner(serverName);
  if (!owner) return res.status(404).json({ error: 'Server tidak ditemukan.' });
  const allocs = getAllocations();
  const target = allocs.find(a => a.id === id);
  if (!target) return res.status(404).json({ error: 'Alokasi tidak ditemukan.' });
  if (target.owner) return res.status(400).json({ error: 'Alokasi sudah dipakai.' });
  const key = allocOwnerKey(owner, serverName);
  const hasAny = allocs.some(a => a.owner === key);
  target.owner = key; target.primary = !hasAny;
  saveAllocations(allocs);
  res.json({ success: true });
});

// Fitur "Lepas" (unassign manual dari admin) sengaja dihapus — ini penyebab bug port
// duplikat sebelumnya. Allocation sekarang hanya dilepas otomatis saat server dihapus
// (lihat releaseServerAllocations), bukan lewat aksi manual admin.

app.get('/api/admin/server-settings/:serverName', checkAdmin, (req, res) => {
  const { serverName } = req.params;
  const settings = getUserSettings(serverName);
  res.json({
    ip: settings.ip || '127.0.0.1',
    port: settings.port || '',
    engine: settings.engine || 'java',
    ram: settings.ram || '2G',
    jarFile: settings.jarFile || '',
    javaVersion: settings.javaVersion || '',
    autoStart: settings.autoStart !== undefined ? settings.autoStart : true,
    srvLimits: settings.srvLimits || { ram: 3072, cpu: 200, disk: 10240 }
  });
});

app.post('/api/reset-password', (req, res) => {
 const { username, email, newPassword } = req.body;
 if (!username || !email || !newPassword) return res.status(400).json({ error: 'Data tidak lengkap.' });
 if (newPassword.length < 6) return res.status(400).json({ error: 'Password minimal 6 karakter.' });
 const users = readUsers();
 const user = users[username];
 if (!user || user.email !== email) return res.status(400).json({ error: 'Username atau email tidak cocok.' });
 users[username].password = hashPassword(newPassword);
 users[username].passwordEnc = encryptPassword(newPassword);
 delete users[username].passwordPlain;
 fs.writeFileSync(usersFile, JSON.stringify(users));
 res.json({ success: true, message: 'Password berhasil direset! Silakan login.' });
});

app.post('/api/delete-account', checkAuth, (req, res) => {
 const username = req.session.username; 
 let users = readUsers();
 
 if (!users[username]) return res.status(400).json({ error: "Akun tidak ditemukan." });

 if (users[username].servers && Array.isArray(users[username].servers)) {
 users[username].servers.forEach(serverName => {
 const _key = username + '::' + serverName;
 const state = activeServers[_key];
 if (state && state.process) { 
 try { state.process.kill('SIGKILL'); } catch (e) {} 
 delete activeServers[_key]; 
 }
 removeServerId(serverName, username);
 releaseServerAllocations(username, serverName);
 });
 }

 const userDirPath = path.join(baseServersDir, username);
 if (fs.existsSync(userDirPath)) { 
 try { fs.rmSync(userDirPath, { recursive: true, force: true }); } catch (e) {} 
 }

 delete users[username];
 fs.writeFileSync(usersFile, JSON.stringify(users));
 
 req.session.destroy();
 res.json({ success: true });
});

app.post('/api/change-password', checkAuth, (req, res) => {
 const { oldPassword, newPassword } = req.body;
 if (!oldPassword || !newPassword) return res.status(400).json({ error: 'Data tidak lengkap.' });
 if (newPassword.length < 6) return res.status(400).json({ error: 'Password baru minimal 6 karakter.' });
 let users = readUsers();
 const username = req.session.username;
 if (!users[username]) return res.status(404).json({ error: 'User tidak ditemukan.' });
 if (users[username].password !== hashPassword(oldPassword)) return res.status(400).json({ error: 'Password lama salah.' });
 users[username].password = hashPassword(newPassword);
 users[username].passwordEnc = encryptPassword(newPassword);
 delete users[username].passwordPlain;
 fs.writeFileSync(usersFile, JSON.stringify(users));
 res.json({ success: true });
});

app.post('/api/delete-current-server', checkAuth, (req, res) => {
 const username = req.session.username;
 const serverName = req.session.currentServer;
 if (!serverName) return res.status(400).json({ error: 'Tidak ada server yang dipilih.' });
 let users = readUsers();
 if (!users[username]) return res.status(404).json({ error: 'User tidak ditemukan.' });
 const _curDelKey = username + '::' + serverName;
 const state = activeServers[_curDelKey];
 if (state && state.process) { try { state.process.kill('SIGKILL'); } catch(e) {} }
 delete activeServers[_curDelKey];
 const srvDir = path.join(baseServersDir, username, serverName);
 if (fs.existsSync(srvDir)) { try { fs.rmSync(srvDir, { recursive: true, force: true }); } catch(e) {} }
 users[username].servers = (users[username].servers || []).filter(s => s !== serverName);
 fs.writeFileSync(usersFile, JSON.stringify(users));
 removeServerId(serverName, username);
 releaseServerAllocations(username, serverName);
 req.session.currentServer = null;
 res.json({ success: true });
});

app.get('/api/servers-list', checkAuth, async (req, res) => {
 const username = req.session.username; let users = readUsers();
 if (!users[username]) return res.json([]);
 if (!users[username].servers) { users[username].servers = [username]; fs.writeFileSync(usersFile, JSON.stringify(users)); }
 const servers = users[username].servers;

 const results = await Promise.all(servers.map(async srv => {
  const state = getUserState(srv, username); const mcDir = getUserDir(srv, username);
  const srvSettings = getUserSettings(srv, username);
  const srvLimits = srvSettings.srvLimits || users[username]?.limits || { ram: 3072, cpu: 200, disk: 10240 };
  const diskUsed = await getDirSizeAsync(mcDir);
  return { id: getOrCreateServerId(srv, username), name: srv, isOnline: state.startTime !== null, diskUsed, srvLimits };
 }));
 res.json(results);
});

app.post('/api/delete-server', checkAuth, (req, res) => {
 const { serverName } = req.body; const username = req.session.username; let users = readUsers();
 if (!users[username] || !users[username].servers || !users[username].servers.includes(serverName)) return res.status(403).json({ error: "Akses ditolak / Server tidak ditemukan." });
 const _delKey = username + '::' + serverName;
 const state = activeServers[_delKey];
 if (state && state.process) { try { state.process.kill('SIGKILL'); } catch (e) {} }
 delete activeServers[_delKey];
 
 const dirPath = getUserDir(serverName);
 if (fs.existsSync(dirPath)) { try { fs.rmSync(dirPath, { recursive: true, force: true }); } catch (e) { } }
 
 users[username].servers = users[username].servers.filter(s => s !== serverName); fs.writeFileSync(usersFile, JSON.stringify(users));
 removeServerId(serverName, username);
 releaseServerAllocations(username, serverName);
 res.json({ success: true });
});

app.post('/api/create-server', checkAuth, (req, res) => {
 const { serverName } = req.body;
 if (!serverName || !/^[a-zA-Z0-9_-]+$/.test(serverName)) return res.status(400).json({error: "Nama hanya boleh huruf, angka, strip, dan underscore."});
 let users = readUsers(); const username = req.session.username;
 if (!users[username]) return res.status(403).json({ error: 'Akun tidak ditemukan.' });
 if (!users[username].servers) users[username].servers = [];
 if (users[username].servers.includes(serverName)) return res.status(400).json({error: "Kamu sudah punya server dengan nama ini, coba nama lain!"});
 if (!hasFreeAllocation()) return res.status(400).json({error: "Tidak ada port yang tersedia untuk dipasang. Hubungi admin untuk menambahkan port."});
 users[username].servers.push(serverName); fs.writeFileSync(usersFile, JSON.stringify(users));
 const newSrvDir = getUserDir(serverName, username); getUserSettings(serverName, username);
 const id = getOrCreateServerId(serverName, username);
 res.json({success: true, id});
});

app.post('/api/select-server', checkAuth, (req, res) => { req.session.currentServer = req.body.serverName; const id = getOrCreateServerId(req.body.serverName, req.session.username); res.json({success: true, id}); });
app.get('/api/whoami', checkAuth, (req, res) => { const users = readUsers(); const u = users[req.session.username]; res.json({ username: req.session.username, email: u?.email || '', isAdmin: !!(u && u.isAdmin) }); });

app.get('/api/settings', checkAuth, (req, res) => { res.json(getUserSettings(getServerName(req), req.session.username)); });

// ── Allocation pool (self-service, per server) ──
app.get('/api/allocations', checkAuth, (req, res) => {
  const srv = getServerName(req); const owner = getOwner(srv, req.session.username) || req.session.username;
  // Migrasi pool sudah ditangani sekali di getUserSettings() (via flag allocationMigrated).
  // Jangan panggil ensureServerAllocation() di sini, kalau tidak server yang sengaja
  // dilepas dari pool akan otomatis dibuatkan alokasi baru lagi setiap request.
  getUserSettings(srv, owner);
  const mine = getServerAllocations(owner, srv).map(a => ({ id: a.id, ip: a.ip, port: a.port, primary: !!a.primary }))
   .sort((a, b) => (b.primary - a.primary) || a.port - b.port);
  const freeCount = getAllocations().filter(a => !a.owner).length;
  const settings2 = getUserSettings(srv, owner);
  const portLimit = (settings2.srvLimits && settings2.srvLimits.portLimit) || 2;
  res.json({ allocations: mine, freeCount, portLimit, usedCount: mine.length });
});

app.post('/api/allocations/add', checkAuth, (req, res) => {
  const srv = getServerName(req); const owner = getOwner(srv, req.session.username) || req.session.username;
  const settings = getUserSettings(srv, owner);
  const portLimit = (settings.srvLimits && settings.srvLimits.portLimit) || 2;
  const key = allocOwnerKey(owner, srv);
  const allocs = getAllocations();
  const mineCount = allocs.filter(a => a.owner === key).length;
  if (mineCount >= portLimit) return res.status(400).json({ error: `Batas port tercapai (maks ${portLimit} port per server). Hubungi admin untuk menambah limit.` });
  const free = allocs.find(a => !a.owner);
  if (!free) return res.status(400).json({ error: 'Tidak ada port kosong tersisa di pool. Hubungi admin.' });
  const hasAny = mineCount > 0;
  free.owner = key; free.primary = !hasAny;
  saveAllocations(allocs);
  res.json({ success: true, allocation: { id: free.id, ip: free.ip, port: free.port, primary: free.primary } });
});

app.post('/api/allocations/set-primary', checkAuth, (req, res) => {
  const { id } = req.body;
  const srv = getServerName(req); const owner = getOwner(srv, req.session.username) || req.session.username;
  const key = allocOwnerKey(owner, srv);
  const allocs = getAllocations();
  const target = allocs.find(a => a.id === id && a.owner === key);
  if (!target) return res.status(404).json({ error: 'Alokasi tidak ditemukan.' });
  allocs.filter(a => a.owner === key).forEach(a => { a.primary = (a.id === id); });
  saveAllocations(allocs);
  res.json({ success: true });
});

app.post('/api/allocations/remove', checkAuth, (req, res) => {
  const { id } = req.body;
  const srv = getServerName(req); const owner = getOwner(srv, req.session.username) || req.session.username;
  const key = allocOwnerKey(owner, srv);
  const allocs = getAllocations();
  const target = allocs.find(a => a.id === id && a.owner === key);
  if (!target) return res.status(404).json({ error: 'Alokasi tidak ditemukan.' });
  const mine = allocs.filter(a => a.owner === key);
  if (mine.length <= 1) return res.status(400).json({ error: 'Server harus punya minimal 1 port.' });
  if (target.primary) return res.status(400).json({ error: 'Jadikan port lain sebagai utama dulu sebelum melepas ini.' });
  target.owner = null; target.primary = false;
  saveAllocations(allocs);
  res.json({ success: true });
});

app.post('/api/settings', checkAuth, (req, res) => { const srv = getServerName(req); const u = req.session.username; const srvDir = getUserDir(srv, u); const settings = getUserSettings(srv, u); if (req.body.ram) settings.ram = req.body.ram.trim(); if (req.body.jarFile) settings.jarFile = req.body.jarFile.trim(); if (req.body.engine) { const newEngine = String(req.body.engine).trim(); if ((newEngine === 'node' || newEngine === 'python') && (settings.engine !== 'node' && settings.engine !== 'python')) { try { const eulaPath = path.join(srvDir, 'eula.txt'); if (fs.existsSync(eulaPath)) fs.unlinkSync(eulaPath); } catch(e) {} } settings.engine = newEngine; } if (req.body.autoStart !== undefined) settings.autoStart = Boolean(req.body.autoStart); if (req.body.javaVersion !== undefined) settings.javaVersion = String(req.body.javaVersion).trim(); if (req.body.useCustomStartup !== undefined) settings.useCustomStartup = Boolean(req.body.useCustomStartup); if (req.body.customStartupCmd !== undefined) settings.customStartupCmd = String(req.body.customStartupCmd); fs.writeFileSync(path.join(srvDir, 'panel_settings.json'), JSON.stringify(settings)); res.send('Pengaturan disimpan'); });
app.get('/api/dashboard-stats', checkAuth, async (req, res) => {
 const srv = getServerName(req);
 const username = req.session.username;
 const users = readUsers();
 const userLimits = users[username]?.limits || { ram: 2048, cpu: 100, disk: 51200 };
 const serverLimits = getUserSettings(srv, username).srvLimits || {};
 const diskLimitMB = serverLimits.disk || userLimits.disk || 51200;
 const mcDir = getUserDir(srv, username);
 const state = getUserState(srv, username);
 const diskBytes = await getDirSizeAsync(mcDir);
 const responseBase = {
  name: srv,
  ramTotal: userLimits.ram * 1024 * 1024,
  diskUsed: diskBytes,
  diskTotal: diskLimitMB * 1024 * 1024
 };
 if (state.process) {
  pidusage(state.process.pid, (err, stats) => {
   if (!err && stats) {
    res.json({ ...responseBase, cpu: stats.cpu.toFixed(2), ramUsed: stats.memory });
   } else {
    res.json({ ...responseBase, cpu: "0.00", ramUsed: 0 });
   }
  });
 } else {
  res.json({ ...responseBase, cpu: "0.00", ramUsed: 0 });
 }
});
function getRawDate(filePath) { try { if (!fs.existsSync(filePath)) return null; return fs.statSync(filePath).mtime.toISOString(); } catch (e) { return null; } }
function formatBytes(bytes) { if (!+bytes) return '0 B'; const k = 1024, sizes = ['B', 'KB', 'MB', 'GB', 'TB'], i = Math.floor(Math.log(bytes) / Math.log(k)); return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`; }

app.get('/api/files', checkAuth, (req, res) => { try { const mcDir = getUserDir(getServerName(req), req.session.username); let subPath = req.query.path || ''; if (subPath.includes('..')) return res.status(403).json({ error: 'Akses ditolak!' }); let targetDir = path.join(mcDir, subPath); if (!fs.existsSync(targetDir)) targetDir = mcDir; const files = fs.readdirSync(targetDir, { withFileTypes: true }); const _roomKeyFiles = req.session.username + '::' + getServerName(req); const _archiveOp = Object.values(activeOps).find(op => op.roomKey === _roomKeyFiles && op.type === 'archive' && op.targetDir === targetDir && op.preExisting); const _isActiveArchiveDir = !!_archiveOp; let fileList = files.filter(dirent => !(subPath === '' && dirent.name === 'panel_settings.json') && dirent.name !== '.plugin_meta.json' && dirent.name !== '.mod_meta.json' && dirent.name !== '.upload_temp' && dirent.name !== '.remote_dl_temp' && !(_isActiveArchiveDir && !_archiveOp.preExisting.has(dirent.name) && dirent.name !== _archiveOp.finalName)).map(dirent => { const currentFilePath = path.join(targetDir, dirent.name); let size = ''; if (!dirent.isDirectory()) { try { size = formatBytes(fs.statSync(currentFilePath).size); } catch(e){} } return { name: dirent.name, isDirectory: dirent.isDirectory(), path: subPath === '' ? dirent.name : `${subPath}/${dirent.name}`, date: getRawDate(currentFilePath), size: size }; }); fileList.sort((a, b) => (a.isDirectory === b.isDirectory) ? a.name.localeCompare(b.name) : (a.isDirectory ? -1 : 1)); res.json(fileList); } catch (e) { res.status(500).json({ error: e.message }); } });
app.get('/api/file', checkAuth, (req, res) => { let subPath = req.query.path || ''; if (subPath.includes('..')) return res.status(403).send("Akses ditolak!"); fs.readFile(path.join(getUserDir(getServerName(req), req.session.username), subPath), 'utf8', (err, data) => res.send(err ? "Gagal membaca file" : data)); });

// FITUR DOWNLOAD FILE AMAN (DITAMBAHKAN DI SINI) 
app.get('/api/download', checkAuth, (req, res) => {
 let subPath = req.query.path || '';
 if (subPath.includes('..')) return res.status(403).send("Akses ditolak!");
 
 const fileTarget = path.join(getUserDir(getServerName(req), req.session.username), subPath);
 if (!fs.existsSync(fileTarget)) return res.status(404).send("File tidak ditemukan!");
 
 res.download(fileTarget);
});

app.post('/api/file', checkAuth, (req, res) => { let subPath = req.body.path || ''; if (subPath.includes('..')) return res.status(403).send("Akses ditolak!"); fs.writeFile(path.join(getUserDir(getServerName(req), req.session.username), subPath), req.body.content, (err) => res.send(err ? "Gagal menyimpan" : "Tersimpan")); });
app.post('/api/folder', checkAuth, (req, res) => { let subPath = req.body.path || ''; if (subPath.includes('..')) return res.status(403).send("Akses ditolak!"); try { fs.mkdirSync(path.join(getUserDir(getServerName(req), req.session.username), subPath), { recursive: true }); res.send("OK"); } catch(e) { res.status(500).send("Err"); } });

// ===== DIRECT UPLOAD SYSTEM =====
const multer = require('multer');

// Gunakan diskStorage agar file besar (100MB+) tidak dibuffer di RAM
const _directUpload = multer({
 storage: multer.diskStorage({
  destination: (req, file, cb) => cb(null, os.tmpdir()),
  filename: (req, file, cb) => cb(null, `upload_${Date.now()}_${Math.random().toString(36).slice(2)}`)
 }),
 // tanpa batas ukuran file
});

// Helper: validasi path aman (tidak bisa keluar dari baseDir)
function _safeInDir(baseDir, ...parts) {
 const resolved = path.resolve(path.join(baseDir, ...parts));
 const base = path.resolve(baseDir);
 // Tambah separator agar '/srv' tidak prefix-match '/srv2'
 return resolved === base || resolved.startsWith(base + path.sep);
}

// Helper: sanitasi nama file (hapus karakter berbahaya)
function _sanitizeFileName(name) {
 if (!name) return '';
 // Ambil hanya bagian terakhir (basename), hapus karakter null/slash/backslash
 return path.basename(name).replace(/[\x00\/\\]/g, '').trim();
}


// ===== DIRECT UPLOAD =====
app.post('/api/upload/direct', checkAuth, _directUpload.single('file'), (req, res) => {
 if (!req.file) return res.status(400).json({ error: 'Tidak ada file yang dikirim' });
 const mcDir = getUserDir(getServerName(req), req.session.username);
 if (!mcDir) {
  try { fs.unlinkSync(req.file.path); } catch(e) {}
  return res.status(403).json({ error: 'Server tidak ditemukan' });
 }

 const destPath = ((req.body && req.body.destPath) || '').replace(/\.\./g, '');
 const fileName = _sanitizeFileName(req.file.originalname);
 if (!fileName) {
  try { fs.unlinkSync(req.file.path); } catch(e) {}
  return res.status(400).json({ error: 'Nama file tidak valid' });
 }
 if (!_safeInDir(mcDir, destPath, fileName)) {
  try { fs.unlinkSync(req.file.path); } catch(e) {}
  return res.status(403).json({ error: 'Akses ditolak' });
 }

 const destDir = path.resolve(path.join(mcDir, destPath));
 try {
  if (!fs.existsSync(destDir)) fs.mkdirSync(destDir, { recursive: true });

  // Hindari overwrite: tambah suffix .1 .2 dst kalau sudah ada
  let actualFileName = fileName;
  let destFile = path.resolve(path.join(destDir, actualFileName));
  let counter = 1;
  while (fs.existsSync(destFile)) {
   actualFileName = fileName + '.' + counter;
   destFile = path.resolve(path.join(destDir, actualFileName));
   counter++;
  }

  // Pindahkan file dari temp multer ke tujuan (stream-safe untuk file besar)
  fs.rename(req.file.path, destFile, (err) => {
   if (err) {
    // Kalau rename lintas filesystem, fallback ke copy+delete
    try {
     fs.copyFileSync(req.file.path, destFile);
     try { fs.unlinkSync(req.file.path); } catch(e) {}
     res.json({ ok: true, fileName: actualFileName });
    } catch(e2) {
     try { fs.unlinkSync(req.file.path); } catch(e) {}
     if (!res.headersSent) res.status(500).json({ error: e2.message });
    }
   } else {
    res.json({ ok: true, fileName: actualFileName });
   }
  });
 } catch(e) {
  try { fs.unlinkSync(req.file.path); } catch(e2) {}
  if (!res.headersSent) res.status(500).json({ error: e.message });
 }
});


// ===== REMOTE DOWNLOAD (IMPORT FILE DARI LINK URL) =====
const remoteDownloadJobs = new Map();
const REMOTE_DL_TTL = 30 * 60 * 1000; // 30 menit, buat bersihin job yang sudah selesai/error dari memori
setInterval(() => {
 const now = Date.now();
 for (const [id, job] of remoteDownloadJobs) {
  if ((job.status === 'done' || job.status === 'error' || job.status === 'cancelled') && now - job.updatedAt > REMOTE_DL_TTL) {
   remoteDownloadJobs.delete(id);
  }
 }
}, 10 * 60 * 1000);

const _REMOTE_DL_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';

function _extractGDriveId(urlStr) {
 try {
  const u = new URL(urlStr);
  if (!/(^|\.)drive\.google\.com$/.test(u.hostname) && !/(^|\.)docs\.google\.com$/.test(u.hostname)) return null;
  let m = u.pathname.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
  if (m) return m[1];
  const idParam = u.searchParams.get('id');
  if (idParam) return idParam;
  return null;
 } catch (e) { return null; }
}

function _httpFollow(urlStr, headers, hops) {
 hops = hops || 0;
 return new Promise((resolve, reject) => {
  if (hops > 10) return reject(new Error('Terlalu banyak redirect, link kemungkinan tidak valid'));
  let u;
  try { u = new URL(urlStr); } catch (e) { return reject(new Error('URL tidak valid')); }
  const mod = u.protocol === 'http:' ? http : https;
  const req = mod.get(u, { headers }, (res) => {
   if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
    res.resume();
    let nextUrl;
    try { nextUrl = new URL(res.headers.location, u).toString(); } catch (e) { return reject(new Error('Redirect URL tidak valid')); }
    const newHeaders = Object.assign({}, headers);
    const setCookie = res.headers['set-cookie'];
    if (setCookie && setCookie.length) {
     const cookieStr = setCookie.map(c => c.split(';')[0]).join('; ');
     newHeaders.cookie = headers.cookie ? headers.cookie + '; ' + cookieStr : cookieStr;
    }
    return resolve(_httpFollow(nextUrl, newHeaders, hops + 1));
   }
   resolve(res);
  });
  req.on('error', reject);
  req.setTimeout(30000, () => req.destroy(new Error('Timeout koneksi ke server tujuan')));
 });
}

function _consumeBody(res, maxBytes) {
 return new Promise((resolve, reject) => {
  let chunks = [], size = 0;
  res.on('data', (c) => {
   size += c.length;
   if (size > maxBytes) { res.destroy(); return resolve(Buffer.concat(chunks).toString('utf8')); }
   chunks.push(c);
  });
  res.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
  res.on('error', reject);
 });
}

function _resolveGDriveConfirm(html, id) {
 const formMatch = html.match(/<form[^>]+action="([^"]+)"[^>]*>([\s\S]*?)<\/form>/i);
 if (formMatch) {
  const action = formMatch[1].replace(/&amp;/g, '&');
  const inputs = [...formMatch[2].matchAll(/<input[^>]+name="([^"]+)"[^>]+value="([^"]*)"/gi)];
  if (inputs.length) {
   const params = inputs.map(m => `${encodeURIComponent(m[1])}=${encodeURIComponent(m[2])}`).join('&');
   return action + (action.includes('?') ? '&' : '?') + params;
  }
 }
 const m = html.match(/confirm=([0-9A-Za-z_-]+)/);
 if (m) return `https://drive.google.com/uc?export=download&confirm=${m[1]}&id=${id}`;
 return null;
}

async function _resolveMediafireLink(pageUrl, headers) {
 try {
  const res = await _httpFollow(pageUrl, headers, 0);
  const html = await _consumeBody(res, 2 * 1024 * 1024);
  const m = html.match(/href="(https:\/\/download[0-9]*\.mediafire\.com\/[^"]+)"/i);
  if (m) return m[1].replace(/&amp;/g, '&');
  return null;
 } catch (e) { return null; }
}

async function _startRemoteDownload(job) {
 try {
  let targetUrl = job.url;
  const headers = { 'User-Agent': _REMOTE_DL_UA };
  const gdriveId = _extractGDriveId(targetUrl);

  if (gdriveId) {
   targetUrl = `https://drive.google.com/uc?export=download&id=${gdriveId}`;
  } else {
   try {
    const u = new URL(targetUrl);
    if (u.hostname === 'github.com' && u.pathname.includes('/blob/')) {
     targetUrl = targetUrl.replace('github.com', 'raw.githubusercontent.com').replace('/blob/', '/');
    } else if (u.hostname.includes('mediafire.com') && !u.hostname.startsWith('download')) {
     const resolved = await _resolveMediafireLink(targetUrl, headers);
     if (resolved) targetUrl = resolved;
    }
   } catch (e) {}
  }

  let res = await _httpFollow(targetUrl, headers, 0);
  let hops = 0;
  while (gdriveId && res.headers['content-type'] && res.headers['content-type'].includes('text/html') && hops < 3) {
   const html = await _consumeBody(res, 3 * 1024 * 1024);
   const setCookie = res.headers['set-cookie'];
   if (setCookie && setCookie.length) headers.cookie = (headers.cookie ? headers.cookie + '; ' : '') + setCookie.map(c => c.split(';')[0]).join('; ');
   const nextUrl = _resolveGDriveConfirm(html, gdriveId);
   if (!nextUrl) throw new Error('Google Drive menolak akses otomatis. Pastikan file di-share publik (Anyone with the link).');
   res = await _httpFollow(nextUrl, headers, 0);
   hops++;
  }

  if (job.cancelled) { res.destroy(); return; }
  if (res.statusCode !== 200) throw new Error('Gagal mengambil file dari link tersebut (HTTP ' + res.statusCode + ')');

  let fileName = job.fileNameHint;
  if (!fileName) {
   const cd = res.headers['content-disposition'];
   if (cd) {
    const m = /filename\*?=(?:UTF-8'')?"?([^";]+)"?/i.exec(cd);
    if (m) { try { fileName = decodeURIComponent(m[1]); } catch (e) { fileName = m[1]; } }
   }
  }
  if (!fileName) {
   try { fileName = path.basename(new URL(targetUrl).pathname); } catch (e) {}
  }
  if (!fileName) fileName = 'downloaded_file';
  fileName = _sanitizeFileName(fileName) || 'downloaded_file';

  const total = parseInt(res.headers['content-length'] || '0', 10) || 0;
  job.fileName = fileName; job.total = total; job.downloaded = 0; job.status = 'downloading'; job.updatedAt = Date.now();

  const tmpDir = path.join(job.mcDir, '.remote_dl_temp', job.id);
  fs.mkdirSync(tmpDir, { recursive: true });
  const tmpPath = path.join(tmpDir, fileName);
  const writeStream = fs.createWriteStream(tmpPath);
  job._res = res; job._writeStream = writeStream; job._tmpDir = tmpDir;

  res.on('data', (chunk) => { job.downloaded += chunk.length; job.updatedAt = Date.now(); });
  res.pipe(writeStream);

  await new Promise((resolve, reject) => {
   writeStream.on('finish', resolve);
   writeStream.on('error', reject);
   res.on('error', reject);
  });

  if (job.cancelled) { try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch (e) {} return; }

  if (!_safeInDir(job.mcDir, job.destSubPath)) throw new Error('Folder tujuan tidak valid');
  if (!fs.existsSync(job.destDir)) fs.mkdirSync(job.destDir, { recursive: true });

  let finalTarget = path.join(job.destDir, fileName);
  let counter = 1;
  while (fs.existsSync(finalTarget)) {
   finalTarget = path.join(job.destDir, fileName + '.' + counter);
   counter++;
  }
  fs.renameSync(tmpPath, finalTarget);
  try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch (e) {}
  job.fileName = path.basename(finalTarget);
  job.status = 'done';
 } catch (e) {
  if (job.cancelled) job.status = 'cancelled';
  else { job.status = 'error'; job.error = e.message || 'Gagal mengunduh file'; }
  try { if (job._tmpDir && fs.existsSync(job._tmpDir)) fs.rmSync(job._tmpDir, { recursive: true, force: true }); } catch (err) {}
 } finally {
  job.updatedAt = Date.now();
 }
}

app.post('/api/remote-download/start', checkAuth, (req, res) => {
 const mcDir = getUserDir(getServerName(req), req.session.username);
 const { url, destPath, fileName } = req.body;
 if (!url || typeof url !== 'string') return res.status(400).json({ error: 'URL wajib diisi' });
 let parsedUrl;
 try { parsedUrl = new URL(url); if (parsedUrl.protocol !== 'http:' && parsedUrl.protocol !== 'https:') throw new Error(); } catch (e) { return res.status(400).json({ error: 'URL tidak valid' }); }
 const subPath = destPath || '';
 if (subPath.includes('..') || !_safeInDir(mcDir, subPath)) return res.status(403).json({ error: 'Akses ditolak' });
 const destDir = path.join(mcDir, subPath);
 if (!fs.existsSync(destDir)) return res.status(404).json({ error: 'Folder tujuan tidak ditemukan' });

 const id = crypto.randomUUID();
 const job = {
  id, url, mcDir, destDir, destSubPath: subPath,
  fileNameHint: fileName ? _sanitizeFileName(fileName) : '',
  username: req.session.username,
  status: 'starting', downloaded: 0, total: 0, fileName: fileName || '', error: null,
  createdAt: Date.now(), updatedAt: Date.now(), cancelled: false,
 };
 remoteDownloadJobs.set(id, job);
 _startRemoteDownload(job);
 res.json({ ok: true, jobId: id });
});

app.get('/api/remote-download/status', checkAuth, (req, res) => {
 const job = remoteDownloadJobs.get(req.query.jobId);
 if (!job || job.username !== req.session.username) return res.status(404).json({ error: 'Job tidak ditemukan' });
 res.json({ status: job.status, downloaded: job.downloaded, total: job.total, fileName: job.fileName, error: job.error });
});

app.post('/api/remote-download/cancel', checkAuth, (req, res) => {
 const job = remoteDownloadJobs.get(req.body.jobId);
 if (!job || job.username !== req.session.username) return res.status(404).json({ error: 'Job tidak ditemukan' });
 job.cancelled = true;
 try { if (job._res) job._res.destroy(); } catch (e) {}
 try { if (job._writeStream) job._writeStream.destroy(); } catch (e) {}
 try { if (job._tmpDir && fs.existsSync(job._tmpDir)) fs.rmSync(job._tmpDir, { recursive: true, force: true }); } catch (e) {}
 job.status = 'cancelled'; job.updatedAt = Date.now();
 res.json({ ok: true });
});

app.post('/api/delete', checkAuth, (req, res) => { const mcDir = getUserDir(getServerName(req), req.session.username); const { items } = req.body; if (!items || !Array.isArray(items)) return res.status(400).send('Data tidak valid'); items.forEach(itemPath => { if (itemPath.includes('..')) return; const fullPath = path.join(mcDir, itemPath); if (fs.existsSync(fullPath)) { try { fs.rmSync(fullPath, { recursive: true, force: true }); } catch (err) {} } }); res.send('Berhasil dihapus'); });
app.post('/api/wipe-server-files', checkAuth, (req, res) => { const mcDir = getUserDir(getServerName(req), req.session.username); if (!fs.existsSync(mcDir)) return res.send('OK'); try { const files = fs.readdirSync(mcDir); files.forEach(file => { if (file === 'panel_settings.json' || file === '.upload_temp' || file === '.remote_dl_temp') return; try { fs.rmSync(path.join(mcDir, file), { recursive: true, force: true }); } catch(e) {} }); res.send('OK'); } catch(e) { res.status(500).send('Gagal menghapus file'); } });
app.post('/api/rename', checkAuth, (req, res) => { const mcDir = getUserDir(getServerName(req), req.session.username); const { oldPath, newName } = req.body; if (!oldPath || !newName || oldPath.includes('..') || newName.includes('..') || newName.includes('/')) return res.status(400).send("Format tidak valid"); const fullOldPath = path.join(mcDir, oldPath); const fullNewPath = path.join(path.dirname(fullOldPath), newName); if (!fs.existsSync(fullOldPath)) return res.status(404).send("File tidak ditemukan"); if (fs.existsSync(fullNewPath)) return res.status(400).send("Nama sudah digunakan"); try { fs.renameSync(fullOldPath, fullNewPath); res.send("Berhasil diubah"); } catch (err) { res.status(500).send("Gagal mengubah nama"); } });
// Hitung total ukuran bytes secara rekursif (untuk progress akurat)
function getTotalInputBytes(basePath, items) {
  let total = 0;
  function scanDir(dirPath) {
    try {
      const entries = fs.readdirSync(dirPath, { withFileTypes: true });
      for (const e of entries) {
        const full = path.join(dirPath, e.name);
        try { if (e.isDirectory()) scanDir(full); else total += fs.statSync(full).size; } catch(e) {}
      }
    } catch(e) {}
  }
  for (const item of items) {
    const full = path.join(basePath, item);
    if (!fs.existsSync(full)) continue;
    const stat = fs.statSync(full);
    if (stat.isDirectory()) scanDir(full); else total += stat.size;
  }
  return Math.max(total, 1);
}

// Hitung total ukuran sebuah direktori (SYNC — hanya untuk init, jangan di polling)
function getDirSizeSync(dirPath) {
  let size = 0;
  try {
    const entries = fs.readdirSync(dirPath, { withFileTypes: true });
    for (const e of entries) {
      const full = path.join(dirPath, e.name);
      try { if (e.isDirectory()) size += getDirSizeSync(full); else size += fs.statSync(full).size; } catch(e) {}
    }
  } catch(e) {}
  return size;
}

// Hitung ukuran direktori secara ASYNC tanpa cache (non-blocking, pakai du -sb)
// Khusus untuk polling extract/archive progress — JANGAN pakai getDirSizeAsync (ada cache 30s)
function getDirSizeForPolling(dirPath, callback) {
  exec(`du -sb "${dirPath.replace(/"/g, '\\"')}" 2>/dev/null`, { timeout: 15000 }, (err, stdout) => {
    if (err || !stdout) {
      // Fallback: Node.js async readdir+stat jika du gagal
      let total = 0;
      const queue = [dirPath];
      function next() {
        if (queue.length === 0) return callback(total);
        const dir = queue.shift();
        fs.readdir(dir, { withFileTypes: true }, (rErr, entries) => {
          if (rErr || !entries || entries.length === 0) return next();
          let pending = entries.length;
          for (const e of entries) {
            const full = path.join(dir, e.name);
            if (e.isDirectory()) { queue.push(full); if (--pending === 0) next(); }
            else fs.stat(full, (sErr, s) => { if (!sErr && s) total += s.size; if (--pending === 0) next(); });
          }
        });
      }
      next();
      return;
    }
    const size = parseInt((stdout || '').split('\t')[0]);
    callback(isNaN(size) ? 0 : size);
  });
}

app.post('/api/extract', checkAuth, (req, res) => {
  const srvName = getServerName(req);
  const username = req.session.username;
  const mcDir = getUserDir(srvName, username);
  const { filePath, destination } = req.body;
  if (!filePath || filePath.includes('..')) return res.status(403).send("Akses ditolak!");
  const fullPath = path.join(mcDir, filePath);
  const destPath = path.join(mcDir, destination || path.dirname(filePath));
  if (!fs.existsSync(fullPath)) return res.status(404).send("File tidak ditemukan");
  if (!fs.existsSync(destPath)) fs.mkdirSync(destPath, { recursive: true });

  const roomKey = username + '::' + srvName;
  const jobId = crypto.randomBytes(6).toString('hex');
  const opKey = roomKey + '::' + jobId;

  const lname = filePath.toLowerCase();
  const isZip = lname.endsWith('.zip');
  // Semua varian tar yang didukung
  const isTarVariant = lname.endsWith('.tar.gz') || lname.endsWith('.tgz') ||
                       lname.endsWith('.tar') || lname.endsWith('.tar.bz2') ||
                       lname.endsWith('.tbz2') || lname.endsWith('.tar.xz') ||
                       lname.endsWith('.txz');

  if (!isZip && !isTarVariant) {
    res.status(202).json({ jobId });
    return io.to('panel_' + roomKey).emit('extract_done', { jobId, success: false, message: 'Format tidak didukung. Didukung: .zip, .tar.gz, .tgz, .tar, .tar.bz2, .tar.xz' });
  }

  // Catat operasi aktif (untuk restore popup jika user refresh)
  activeOps[opKey] = { type: 'extract', percent: 0, processed: 0, total: 0, jobId, roomKey };
  res.status(202).json({ jobId });

  // Sistem progress: file-count based + heartbeat timer
  // Step 1: list semua entry -> totalFiles + totalBytes
  // Step 2: extract verbose -> hitung tiap file selesai
  // Progress = max(fileBased%, timeBased%) -> akurat untuk banyak file,
  // tetap bergerak untuk file tunggal besar (tidak ada stdout sampai selesai)
  function runExtract(totalFiles, totalBytes) {
    const displayTotal = Math.max(totalBytes, 1);
    let extractedFiles = 0;
    let lastPct = -1;
    let isClosed = false;
    let errOutput = '';
    const startTime = Date.now();

    if (activeOps[opKey]) activeOps[opKey].total = displayTotal;

    // Kirim progress awal langsung (mengganti "Menghitung..." ke "0 B / X GB")
    io.to('panel_' + roomKey).emit('extract_progress', { jobId, percent: 0, processed: 0, total: displayTotal });

    // Emit progress - ambil mana yang lebih besar antara file-count vs time-based
    // Ini memastikan progress bergerak meski zip hanya berisi 1 file besar
    function emitProgress(filesNow) {
      // File-count based (akurat, hanya naik saat file selesai di-extract)
      const filePct = totalFiles > 0 ? Math.round((filesNow / totalFiles) * 100) : 0;
      // Time-based fallback (bergerak pelan seiring waktu, cap 90%)
      // Estimasi kecepatan: ~80 MB/s read/write untuk storage Replit
      const elapsedSec = (Date.now() - startTime) / 1000;
      const estimatedSec = Math.max(3, displayTotal / (80 * 1024 * 1024));
      const timePct = Math.round((elapsedSec / estimatedSec) * 90);
      // Ambil yang tertinggi, cap 97% (100% hanya dari event close sukses)
      const pct = Math.min(97, Math.max(filePct, timePct));
      if (pct <= lastPct) return;
      lastPct = pct;
      const processedBytes = Math.round((pct / 100) * displayTotal);
      if (activeOps[opKey]) { activeOps[opKey].percent = pct; activeOps[opKey].processed = processedBytes; }
      io.to('panel_' + roomKey).emit('extract_progress', { jobId, percent: pct, processed: processedBytes, total: displayTotal });
    }

    // Heartbeat: update progress tiap 1.5 detik meski tidak ada stdout
    // Kritis untuk zip/tar yang berisi sedikit file besar - tanpa ini progress diam
    const heartbeat = setInterval(() => {
      if (isClosed) return clearInterval(heartbeat);
      emitProgress(extractedFiles);
    }, 1500);

    let proc;
    if (isZip) {
      // unzip tanpa -q -> stdout output per-file:
      // "  inflating: path/file.txt"
      // "  extracting: path/file.bin"
      // "   creating: path/dir/"
      proc = spawn('unzip', ['-o', fullPath, '-d', destPath]);
      let lineBuffer = '';
      proc.stdout.on('data', d => {
        lineBuffer += d.toString();
        let nl;
        while ((nl = lineBuffer.indexOf('\n')) !== -1) {
          const line = lineBuffer.slice(0, nl);
          lineBuffer = lineBuffer.slice(nl + 1);
          // Setiap baris entry = satu file/dir selesai di-extract
          if (/^\s+(inflating|extracting|creating|linking|skipping):/i.test(line)) {
            extractedFiles++;
            emitProgress(extractedFiles);
          }
        }
      });
    } else {
      // tar -xvf -> stdout: satu path per baris = satu entry selesai
      proc = spawn('tar', ['-xvf', fullPath, '-C', destPath]);
      let lineBuffer = '';
      proc.stdout.on('data', d => {
        lineBuffer += d.toString();
        let nl, newFiles = 0;
        while ((nl = lineBuffer.indexOf('\n')) !== -1) {
          const line = lineBuffer.slice(0, nl).trim();
          lineBuffer = lineBuffer.slice(nl + 1);
          if (line) newFiles++;
        }
        if (newFiles > 0) {
          extractedFiles += newFiles;
          emitProgress(extractedFiles);
        }
      });
    }

    proc.stderr.on('data', d => errOutput += d.toString());
    proc.on('close', code => {
      isClosed = true;
      clearInterval(heartbeat);
      if (activeOps[opKey]) delete activeOps[opKey];
      if (code !== 0) {
        io.to('panel_' + roomKey).emit('extract_done', { jobId, success: false, message: 'Gagal mengekstrak: ' + errOutput.slice(0, 200) });
      } else {
        io.to('panel_' + roomKey).emit('extract_progress', { jobId, percent: 100, processed: displayTotal, total: displayTotal });
        // Delay 600ms supaya animasi bar CSS (300ms transition) sempat jalan ke 100%
        // sebelum card fade-out dari extract_done — tanpa ini bar keliatan berhenti di 70%
        setTimeout(() => {
          io.to('panel_' + roomKey).emit('extract_done', { jobId, success: true });
        }, 600);
      }
    });
    proc.on('error', err => {
      isClosed = true;
      clearInterval(heartbeat);
      if (activeOps[opKey]) delete activeOps[opKey];
      io.to('panel_' + roomKey).emit('extract_done', { jobId, success: false, message: 'Gagal mengekstrak: ' + err.message });
    });
  }

  if (isZip) {
    // unzip -l: baca central directory ZIP (sangat cepat, tanpa decompress)
    // Output summary baris terakhir: "  123456789  10 files"
    let listOut = '';
    const listProc = spawn('unzip', ['-l', fullPath]);
    listProc.stdout.on('data', d => listOut += d.toString());
    listProc.on('close', () => {
      // Parsing baris summary: "   <totalBytes>   <N> files"
      const matchSummary = listOut.match(/^\s*(\d+)\s+(\d+)\s+files?\s*$/im);
      const totalBytes = matchSummary ? parseInt(matchSummary[1]) : 1024 * 1024 * 100;
      // Hitung totalFiles: dari angka di summary, fallback hitung baris data
      const totalFiles = matchSummary
        ? parseInt(matchSummary[2])
        : listOut.split('\n').filter(l => /^\s+\d+\s+\d{4}-\d{2}-\d{2}/.test(l)).length;
      runExtract(Math.max(totalFiles, 1), totalBytes);
    });
    listProc.on('error', () => {
      let srcSize = 0; try { srcSize = fs.statSync(fullPath).size; } catch(e) {}
      runExtract(0, Math.max(srcSize, 1024 * 1024 * 100));
    });
  } else {
    // tar -tf: list semua entry tanpa decompress data (cepat)
    // Setiap baris = satu path entry
    let listOut = '';
    const listProc = spawn('tar', ['-tf', fullPath]);
    listProc.stdout.on('data', d => listOut += d.toString());
    listProc.on('close', () => {
      const totalFiles = listOut.split('\n').filter(l => l.trim()).length;
      let srcSize = 0; try { srcSize = fs.statSync(fullPath).size; } catch(e) {}
      // Estimasi uncompressed untuk display: gz ~4x, bz2 ~5x, xz ~6x → pakai 4x sebagai rata-rata aman
      runExtract(Math.max(totalFiles, 1), Math.max(srcSize * 4, 1024 * 1024));
    });
    listProc.on('error', () => {
      let srcSize = 0; try { srcSize = fs.statSync(fullPath).size; } catch(e) {}
      runExtract(0, Math.max(srcSize * 4, 1024 * 1024));
    });
  }
});
app.post('/api/archive', checkAuth, (req, res) => {
  const srvName = getServerName(req);
  const username = req.session.username;
  const mcDir = getUserDir(srvName, username);
  const { items, archiveName, currentPath } = req.body;
  if (!items || !Array.isArray(items) || !archiveName || archiveName.includes('..')) return res.status(400).send("Data tidak valid");
  const targetDir = path.join(mcDir, currentPath || '');
  const safeItems = items.filter(item => !item.includes('..')).map(item => path.basename(item));
  if (!safeItems.length) return res.status(400).send("Tidak ada item yang valid");

  const isZip = archiveName.endsWith('.zip');
  const isTarGz = archiveName.endsWith('.tar.gz') || archiveName.endsWith('.tgz');
  const finalName = isZip ? archiveName : (isTarGz ? archiveName : archiveName + '.zip');
  const archivePath = path.join(targetDir, finalName);
  const roomKey = username + '::' + srvName;
  const jobId = crypto.randomBytes(6).toString('hex');
  const opKey = roomKey + '::' + jobId;

  // Hitung total bytes input (cepat, hanya baca metadata)
  const totalBytes = getTotalInputBytes(targetDir, safeItems);

  // Snapshot file yang sudah ada sebelum zip mulai (untuk deteksi temp file baru)
  let preExisting = new Set();
  try { preExisting = new Set(fs.readdirSync(targetDir)); } catch(e) {}

  // Catat operasi aktif (untuk restore popup jika user refresh)
  // preExisting, finalName, targetDir disimpan supaya /api/files bisa hide temp file zip
  activeOps[opKey] = { type: 'archive', percent: 0, processed: 0, total: totalBytes, preExisting, finalName, targetDir, jobId, roomKey };

  // Spawn proses archive. zip writes one line per archived entry to stdout;
  // stdout must be ignored (or drained), otherwise the child blocks when the
  // pipe buffer fills and the archive appears stuck at 97%.
  const proc = finalName.endsWith('.zip')
    ? spawn('zip', ['-r', '-1', archivePath, ...safeItems], { cwd: targetDir, stdio: ['ignore', 'ignore', 'pipe'] })
    : spawn('tar', ['-czf', archivePath, ...safeItems], { cwd: targetDir, env: { ...process.env, GZIP: '-1' }, stdio: ['ignore', 'ignore', 'pipe'] });

  // Polling ASYNC: jangan gunakan ukuran file arsip sebagai progress.
  // Ukuran ZIP hasil kompresi tidak sebanding dengan ukuran file sumber,
  // sehingga arsip besar bisa terlihat berhenti di angka 14%-23% padahal
  // proses zip masih berjalan.
  let lastPct = 0;
  let isClosed = false;  // Flag: proses selesai → stop polling langsung
  let pollTimer = null;
  const archiveStartedAt = Date.now();
  // Estimasi heartbeat hanya untuk tampilan; 100% tetap dikirim saat proses
  // benar-benar selesai. Batas atas mencegah progress palsu mencapai 100%.
  const estimatedArchiveMs = Math.max(
    3000,
    Math.min(30 * 60 * 1000, (totalBytes / (80 * 1024 * 1024)) * 1000)
  );

  function doArchivePoll() {
    if (isClosed) return;
    const elapsed = Date.now() - archiveStartedAt;
    const pct = Math.min(97, Math.max(lastPct, Math.round((elapsed / estimatedArchiveMs) * 92)));
    if (pct > lastPct) {
      lastPct = pct;
      const processed = Math.round((pct / 100) * totalBytes);
      if (activeOps[opKey]) { activeOps[opKey].percent = pct; activeOps[opKey].processed = processed; }
      io.to('panel_' + roomKey).emit('archive_progress', { jobId, percent: pct, processed, total: totalBytes });
    }
    pollTimer = setTimeout(doArchivePoll, 500);
  }
  doArchivePoll(); // Mulai polling async

  res.status(202).json({ jobId });

  let errOutput = '';
  proc.stderr.on('data', d => errOutput += d.toString());
  proc.on('close', code => {
    isClosed = true;
    if (pollTimer) clearTimeout(pollTimer);
    delete activeOps[opKey];
    if (code !== 0) {
      io.to('panel_' + roomKey).emit('archive_done', { jobId, success: false, message: 'Gagal membuat arsip: ' + errOutput.slice(0, 200) });
    } else {
      io.to('panel_' + roomKey).emit('archive_progress', { jobId, percent: 100, processed: totalBytes, total: totalBytes });
      // Let the browser paint the 100% state before removing the card.
      setTimeout(() => {
        io.to('panel_' + roomKey).emit('archive_done', { jobId, success: true, name: finalName });
      }, 600);
    }
  });
  proc.on('error', err => {
    isClosed = true;
    if (pollTimer) clearTimeout(pollTimer);
    delete activeOps[opKey];
    io.to('panel_' + roomKey).emit('archive_done', { jobId, success: false, message: 'Gagal membuat arsip: ' + err.message });
  });
});
app.post('/api/move', checkAuth, (req, res) => { const mcDir = getUserDir(getServerName(req), req.session.username); const { items, destination } = req.body; if (!items || !Array.isArray(items) || destination.includes('..')) return res.status(400).send("Data tidak valid"); const destPath = path.join(mcDir, destination); if (!fs.existsSync(destPath)) fs.mkdirSync(destPath, { recursive: true }); let errors = 0; items.forEach(itemPath => { if (itemPath.includes('..')) return; const fullPath = path.join(mcDir, itemPath); const newFullPath = path.join(destPath, path.basename(itemPath)); if (fs.existsSync(fullPath)) { try { fs.renameSync(fullPath, newFullPath); } catch (err) { errors++; } } }); if (errors > 0) return res.status(500).send(`Selesai tapi ada ${errors} file yang error dipindah`); res.send("Berhasil dipindahkan"); });

app.get('/api/plugin-meta', checkAuth, (req, res) => {
  const metaPath = path.join(getUserDir(getServerName(req), req.session.username), 'plugins', '.plugin_meta.json');
  try { res.json(fs.existsSync(metaPath) ? JSON.parse(fs.readFileSync(metaPath, 'utf8')) : {}); } catch(e) { res.json({}); }
});
app.post('/api/plugin-meta', checkAuth, (req, res) => {
  const pluginsDir = path.join(getUserDir(getServerName(req), req.session.username), 'plugins');
  const metaPath = path.join(pluginsDir, '.plugin_meta.json');
  try {
    let data = {};
    if (fs.existsSync(metaPath)) { try { data = JSON.parse(fs.readFileSync(metaPath, 'utf8')); } catch(e) {} }
    const { filename, meta, rename } = req.body;
    if (rename && rename.from && rename.to) { if (data[rename.from]) { data[rename.to] = data[rename.from]; delete data[rename.from]; } }
    else if (filename) { if (meta == null) { delete data[filename]; } else { data[filename] = meta; } }
    if (!fs.existsSync(pluginsDir)) fs.mkdirSync(pluginsDir, { recursive: true });
    fs.writeFileSync(metaPath, JSON.stringify(data, null, 2));
    res.json({ ok: true });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/mod-meta', checkAuth, (req, res) => {
  const metaPath = path.join(getUserDir(getServerName(req), req.session.username), 'mods', '.mod_meta.json');
  try { res.json(fs.existsSync(metaPath) ? JSON.parse(fs.readFileSync(metaPath, 'utf8')) : {}); } catch(e) { res.json({}); }
});
app.post('/api/mod-meta', checkAuth, (req, res) => {
  const modsDir = path.join(getUserDir(getServerName(req), req.session.username), 'mods');
  const metaPath = path.join(modsDir, '.mod_meta.json');
  try {
    let data = {};
    if (fs.existsSync(metaPath)) { try { data = JSON.parse(fs.readFileSync(metaPath, 'utf8')); } catch(e) {} }
    const { filename, meta, rename } = req.body;
    if (rename && rename.from && rename.to) { if (data[rename.from]) { data[rename.to] = data[rename.from]; delete data[rename.from]; } }
    else if (filename) { if (meta == null) { delete data[filename]; } else { data[filename] = meta; } }
    if (!fs.existsSync(modsDir)) fs.mkdirSync(modsDir, { recursive: true });
    fs.writeFileSync(metaPath, JSON.stringify(data, null, 2));
    res.json({ ok: true });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

function readNetStats() {
 try {
 const data = fs.readFileSync('/proc/net/dev', 'utf8');
 let rx = 0, tx = 0;
 const lines = data.split('\n').slice(2);
 for (const line of lines) {
 const parts = line.trim().split(/\s+/);
 if (parts.length < 10) continue;
 const iface = parts[0].replace(':', '');
 if (iface === 'lo' || iface === '') continue;
 rx += parseInt(parts[1]) || 0;
 tx += parseInt(parts[9]) || 0;
 }
 return { rx, tx, time: Date.now() };
 } catch(e) { return { rx: 0, tx: 0, time: Date.now() }; }
}

let prevNetStats = readNetStats();

let _ssNetCache = {};
function refreshSsNetStats() {
 exec("ss -ti 2>/dev/null", { timeout: 3000 }, (err, stdout) => {
  if (err || !stdout) return;
  const portBytes = {};
  const lines = stdout.split('\n');
  for (let i = 0; i < lines.length; i++) {
   const m = lines[i].match(/^(?:tcp\s+)?ESTAB\s+\d+\s+\d+\s+\S+:(\d+)\s+\S+:\S+/);
   if (!m) continue;
   const port = m[1];
   const statsLine = lines[i + 1] || '';
   const sent = parseInt(statsLine.match(/bytes_sent:(\d+)/)?.[1] || '0');
   const recv = parseInt(statsLine.match(/bytes_received:(\d+)/)?.[1] || '0');
   if (!portBytes[port]) portBytes[port] = { rx: 0, tx: 0 };
   portBytes[port].rx += recv;
   portBytes[port].tx += sent;
  }
  if (Object.keys(portBytes).length > 0) _ssNetCache = portBytes;
 });
}
setInterval(refreshSsNetStats, 2000);
refreshSsNetStats();

// Cache disk size: Map<dirPath, { size, ts }>
const diskSizeCache = new Map();
const DISK_CACHE_TTL = 30000; // 30 detik

async function getDirSizeAsync(dirPath) {
 const cached = diskSizeCache.get(dirPath);
 if (cached && (Date.now() - cached.ts) < DISK_CACHE_TTL) return cached.size;

 // Coba du -sb dulu (lebih akurat & cepat, sama dengan getDirSizeForPolling)
 const duSize = await new Promise(resolve => {
  exec(`du -sb "${dirPath.replace(/"/g, '\\"')}" 2>/dev/null`, { timeout: 15000 }, (err, stdout) => {
   if (!err && stdout) {
    const bytes = parseInt(stdout.trim().split(/\s+/)[0]);
    if (!isNaN(bytes)) return resolve(bytes);
   }
   resolve(null);
  });
 });

 if (duSize !== null) {
  diskSizeCache.set(dirPath, { size: duSize, ts: Date.now() });
  return duSize;
 }

 // Fallback: manual readdir+stat kalau du tidak tersedia
 async function calcSize(dir) {
  let size = 0;
  try {
   const files = await fs.promises.readdir(dir);
   await Promise.all(files.map(async file => {
    const fullPath = path.join(dir, file);
    try {
     const stats = await fs.promises.stat(fullPath);
     if (stats.isDirectory()) size += await calcSize(fullPath);
     else size += stats.size;
    } catch(e) {}
   }));
  } catch(e) {}
  return size;
 }
 const size = await calcSize(dirPath);
 diskSizeCache.set(dirPath, { size, ts: Date.now() });
 return size;
}

// Alias untuk kompatibilitas kode lama yang masih pakai getDirSizeGlobal
function getDirSizeGlobal(dirPath) {
 const cached = diskSizeCache.get(dirPath);
 if (cached && (Date.now() - cached.ts) < DISK_CACHE_TTL) return cached.size;
 // Trigger update async di background, return cache lama atau 0
 getDirSizeAsync(dirPath).catch(() => {});
 return cached ? cached.size : 0;
}

function parseRamMB(ramStr) {
 const s = String(ramStr || '2048M').trim().toUpperCase();
 if (s.endsWith('G')) return Math.round(parseFloat(s) * 1024);
 if (s.endsWith('M')) return Math.round(parseFloat(s));
 return parseInt(s) || 2048;
}

function capRam(ramStr, limitMB) {
 const mb = Math.min(parseRamMB(ramStr), limitMB || 2048);
 return (mb % 1024 === 0 && mb >= 1024) ? `${mb / 1024}G` : `${mb}M`;
}


function startResourceMonitor(srvName, state, uLog) {
 const settings = getUserSettings(srvName);
 const limits = settings.srvLimits || (() => { const ownerName = getOwner(srvName) || srvName; const u = readUsers()[ownerName]; return (u && u.limits) ? u.limits : { ram: 6144, cpu: 1000, disk: 32768 }; })();

 const CPU_LIMIT = limits.cpu || 100;
 const RAM_LIMIT_BYTES = (limits.ram || 2048) * 1024 * 1024;
 const DISK_LIMIT_BYTES = (limits.disk || 5120) * 1024 * 1024;
 // Loop lebih cepat = throttle lebih responsif
 const CPU_INTERVAL = 100;
 // Throttle langsung aktif di limit, tanpa toleransi tambahan
 const CPU_TARGET = CPU_LIMIT;

 let active = true;
 let isStopped = false;

 const stopAll = () => {
 active = false;
 clearInterval(diskInterval);
 if (isStopped) {
 try { if (state.process) state.process.kill('SIGCONT'); } catch(e) {}
 isStopped = false;
 }
 };

 // CPU throttle loop menggunakan SIGSTOP/SIGCONT
 const cpuLoop = () => {
 if (!active || !state.process) return;
 const pid = state.process.pid;
 if (!pid) { if (active) setTimeout(cpuLoop, CPU_INTERVAL); return; }

 pidusage(pid, (err, stats) => {
 if (!active || !state.process) return;
 if (err || !stats) { if (active) setTimeout(cpuLoop, CPU_INTERVAL); return; }

 // RAM: jika melebihi batas, matikan server
 if (stats.memory > RAM_LIMIT_BYTES * 1.1) {
 uLog(`\x1b[31m [Resource Limit] RAM melebihi batas (${(stats.memory/1024/1024).toFixed(0)}MB > ${limits.ram}MB). Server dimatikan!\x1b[0m\n`);
 try { state.process.kill('SIGKILL'); } catch(e) {}
 state.isStarting = false;
 stopAll();
 return;
 }

 // CPU: throttle dengan SIGSTOP/SIGCONT
 // Target: jaga CPU tepat di CPU_TARGET (= CPU_LIMIT)
 const cpuNow = stats.cpu;
 if (cpuNow > CPU_TARGET) {
 // Hitung pause fraction: semakin jauh dari limit, semakin agresif
 const excess = cpuNow - CPU_TARGET;
 // aggressiveness: mulai dari 1.5x langsung, max 3x saat overage besar
 const aggressiveness = Math.min(1.5 + (excess / CPU_TARGET) * 1.5, 3.0);
 const pauseFraction = Math.min((excess / cpuNow) * aggressiveness, 0.95);
 const pauseMs = Math.max(10, Math.round(CPU_INTERVAL * pauseFraction));
 const resumeDelay = Math.max(5, CPU_INTERVAL - pauseMs);
 try {
 state.process.kill('SIGSTOP');
 isStopped = true;
 setTimeout(() => {
 if (!state.process) { isStopped = false; return; }
 try { state.process.kill('SIGCONT'); isStopped = false; } catch(e) {}
 if (active) setTimeout(cpuLoop, resumeDelay);
 }, pauseMs);
 } catch(e) {
 if (active) setTimeout(cpuLoop, CPU_INTERVAL);
 }
 } else {
 if (isStopped) {
 try { if (state.process) { state.process.kill('SIGCONT'); isStopped = false; } } catch(e) {}
 }
 if (active) setTimeout(cpuLoop, CPU_INTERVAL);
 }
 });
 };

 setTimeout(cpuLoop, CPU_INTERVAL);

 // Disk: cek setiap 30 detik, matikan jika melebihi batas
 const diskInterval = setInterval(() => {
 if (!active || !state.process) { clearInterval(diskInterval); return; }
 const diskUsed = getDirSizeGlobal(getUserDir(srvName));
 if (diskUsed > DISK_LIMIT_BYTES) {
 uLog(`\x1b[31m [Resource Limit] Disk melebihi batas (${(diskUsed/1024/1024).toFixed(0)}MB > ${limits.disk}MB). Server dimatikan!\x1b[0m\n`);
 try { state.process.kill('SIGKILL'); } catch(e) {}
 state.isStarting = false;
 stopAll();
 }
 }, 30000);

 if (state.process) {
 state.process.once('close', stopAll);
 }
}

const lastCpuCache = {};
const cpuEmaCache = {};

function readProcStat(pid) {
 try {
  const stat = fs.readFileSync(`/proc/${pid}/stat`, 'utf8');
  const parts = stat.slice(stat.lastIndexOf(')') + 2).trim().split(' ');
  const utime = parseInt(parts[11]);
  const stime = parseInt(parts[12]);
  const cutime = parseInt(parts[13]);
  const cstime = parseInt(parts[14]);
  return { total: utime + stime + cutime + cstime };
 } catch(e) { return null; }
}

function readCpuTotal() {
 try {
  const line = fs.readFileSync('/proc/stat', 'utf8').split('\n')[0];
  const nums = line.trim().split(/\s+/).slice(1).map(Number);
  return nums.reduce((a, b) => a + b, 0);
 } catch(e) { return 0; }
}

const prevPidTicks = {};
let _prevCpuTotalSnapshot = readCpuTotal();
let _curCpuTotalSnapshot = _prevCpuTotalSnapshot;

function snapshotCpuTotal() {
 _prevCpuTotalSnapshot = _curCpuTotalSnapshot;
 _curCpuTotalSnapshot = readCpuTotal();
}

function getProcCpuPercent(pid) {
 const cpuDelta = _curCpuTotalSnapshot - _prevCpuTotalSnapshot;
 if (cpuDelta <= 0) return null;
 const procStat = readProcStat(pid);
 if (!procStat) return null;
 const prevTicks = prevPidTicks[pid] !== undefined ? prevPidTicks[pid] : procStat.total;
 const pidDelta = procStat.total - prevTicks;
 prevPidTicks[pid] = procStat.total;
 const numCpus = os.cpus().length;
 return (pidDelta / cpuDelta) * numCpus * 100;
}

setInterval(() => {
 snapshotCpuTotal();
 const curNet = readNetStats();
 const deltaRxGlobal = Math.max(0, curNet.rx - prevNetStats.rx);
 const deltaTxGlobal = Math.max(0, curNet.tx - prevNetStats.tx);
 prevNetStats = curNet;

 const users = readUsers();
 for (const stateKey in activeServers) {
  const state = activeServers[stateKey];
  const srvName = state._srvName || stateKey;
  const owner = state._owner || stateKey;
  const settings = getUserSettings(srvName, owner);
  const displayAddress = settings.alias ? `${settings.alias}:${settings.port}` : (settings.ip && settings.ip !== '0.0.0.0' ? `${settings.ip}:${settings.port}` : `0.0.0.0:${settings.port}`);

  if (!state.process) {
   lastCpuCache[stateKey] = 0;
   state._lastCpu = 0; state._lastRamMB = 0;
   io.to(owner).emit('dashboard_stats', { serverName: srvName, cpu: "0.00", ramMB: 0, isOnline: false, status: 'offline' });
   continue;
  }

  const _portStr = String(settings.port || '');
  const _portData = _ssNetCache[_portStr];
  let netInBytes, netOutBytes;
  if (_portData) {
   if (_portData.rx < state._lastSsRx) state.netAccumRx += state._lastSsRx;
   if (_portData.tx < state._lastSsTx) state.netAccumTx += state._lastSsTx;
   state._lastSsRx = _portData.rx; state._lastSsTx = _portData.tx;
   netInBytes = (state.netAccumRx || 0) + _portData.rx;
   netOutBytes = (state.netAccumTx || 0) + _portData.tx;
  } else {
   // Tidak ada data koneksi per-port dari `ss` untuk port server ini saat ini.
   // Fallback ke statistik network seluruh mesin (curNet).
   state.netAccumRx = (state.netAccumRx || 0) + deltaRxGlobal;
   state.netAccumTx = (state.netAccumTx || 0) + deltaTxGlobal;
   netInBytes = state.netAccumRx;
   netOutBytes = state.netAccumTx;
  }
  const srvLimits = settings.srvLimits || {};
  const userCpuLimit = srvLimits.cpu || users[owner]?.limits?.cpu || 100;
  const userRamLimitMB = srvLimits.ram || users[owner]?.limits?.ram || 2048;
  const userDiskLimitMB = srvLimits.disk || users[owner]?.limits?.disk || 32768;

  const mcPid = state.process.pid;
  const mcCpu = getProcCpuPercent(mcPid) ?? 0;
  let ramMB = 0;
  try {
   const statusLines = fs.readFileSync(`/proc/${mcPid}/status`, 'utf8').split('\n');
   const vmRss = statusLines.find(l => l.startsWith('VmRSS:'));
   if (vmRss) ramMB = parseInt(vmRss.split(/\s+/)[1]) / 1024;
  } catch(e) {}
  const cpuFormatted = mcCpu.toFixed(2);
  state._lastCpu = mcCpu; state._lastRamMB = ramMB;
  const currentStatus = state.isStarting ? 'starting' : 'running';
  io.to(owner).emit('dashboard_stats', { serverName: srvName, cpu: cpuFormatted, ramMB: ramMB, isOnline: true, status: currentStatus });
  io.to('panel_' + stateKey).emit('stats', { cpu: cpuFormatted, ramMB: ramMB, startTime: state.startTime, address: displayAddress, status: currentStatus, netIn: netInBytes, netOut: netOutBytes, cpuLimit: userCpuLimit, ramLimit: userRamLimitMB, diskLimit: userDiskLimitMB });
 }
}, 800);

io.on('connection', (socket) => {
 const reqSession = socket.request.session;
 if (!reqSession || !reqSession.loggedIn) { socket.emit('session_expired'); return socket.disconnect(); }
 
 const sessionUsername = reqSession.username;
 const users_s = readUsers();

 // Admin manage-user page: cukup ikut room username target biar dapet siaran
 // 'dashboard_stats' realtime buat SEMUA server user itu, tanpa perlu buka satu
 // server tertentu (beda kasus sama panel yang selalu terikat 1 activeServer).
 socket.on('admin_watch_user', (targetUsername) => {
  const isAdminReq = !!(users_s[sessionUsername] && users_s[sessionUsername].isAdmin);
  if (!isAdminReq || !targetUsername || !users_s[targetUsername]) return;
  socket.join(targetUsername);
  const targetServers = users_s[targetUsername].servers || [];
  targetServers.forEach(srvName => {
   const state = getUserState(srvName, targetUsername);
   const isOnline = !!(state.process || state.isStarting);
   socket.emit('dashboard_stats', {
    serverName: srvName,
    cpu: (state._lastCpu || 0).toFixed(2),
    ramMB: Math.round(state._lastRamMB || 0),
    isOnline,
    status: state.isStarting ? 'starting' : (isOnline ? 'running' : 'offline')
   });
  });
 });

 // Resolve server from tab-specific query param first (prevents cross-tab mixing).
 // Each browser tab passes its own panelServerId so connections never bleed into
 // each other even if the shared session switches currentServer.
 let username = (reqSession.viewAsUser && users_s[reqSession.viewAsUser]) ? reqSession.viewAsUser : sessionUsername;
 let activeServer = null;

 const panelServerId = socket.handshake.query && socket.handshake.query.panelServerId;
 if (panelServerId) {
  const info = resolveServerId(panelServerId);
  if (info) {
   const isOwner = sessionUsername === info.username;
   const isAdmin = !!(users_s[sessionUsername] && users_s[sessionUsername].isAdmin);
   if (isOwner || isAdmin) {
    activeServer = info.serverName;
    username = info.username; // actual owner of the server
   }
  }
 }

 // Fallback to session if no valid panelServerId was provided
 if (!activeServer) {
  const u_s = users_s[username];
  activeServer = reqSession.currentServer || (u_s && u_s.servers && u_s.servers.length > 0 ? u_s.servers[0] : null);
 }

 const roomKey = activeServer ? (username + '::' + activeServer) : null;
 socket.join(username);
 if (roomKey) {
  socket.join('panel_' + roomKey);
  // Kirim status operasi aktif ke socket baru (restore popup setelah refresh)
  // Kirim semua operasi aktif untuk room ini (bisa lebih dari satu)
  Object.values(activeOps).filter(op => op.roomKey === roomKey).forEach(op => socket.emit('op_resume', op));
 }

 if (!activeServer) {
  socket.emit('stats', { cpu: "0.00", ramMB: 0, startTime: null, address: '0.0.0.0:25565', status: 'offline' });
  return;
 }

 const state = getUserState(activeServer, username);
 const mcDir = getUserDir(activeServer, username);
 const settings = getUserSettings(activeServer, username);
 let displayAddress = settings.alias ? `${settings.alias}:${settings.port}` : (settings.ip && settings.ip !== '0.0.0.0' ? `${settings.ip}:${settings.port}` : `0.0.0.0:${settings.port}`);

 const initSrvLimits = settings.srvLimits || {};
 const users_init = readUsers();
 const initOwner = Object.keys(users_init).find(u => users_init[u].servers && users_init[u].servers.includes(activeServer)) || activeServer;
 const initCpuLimit = initSrvLimits.cpu || users_init[initOwner]?.limits?.cpu || 100;
 const initRamLimit = initSrvLimits.ram || users_init[initOwner]?.limits?.ram || 2048;
 const initDiskLimit = initSrvLimits.disk || users_init[initOwner]?.limits?.disk || 32768;
 if (state.process || state.isStarting) {
 let currentStatus = state.isStarting ? 'starting' : 'running';
 socket.emit('stats', { cpu: "0.00", ramMB: 0, startTime: state.startTime, address: displayAddress, status: currentStatus, cpuLimit: initCpuLimit, ramLimit: initRamLimit, diskLimit: initDiskLimit });
 } else {
 socket.emit('stats', { cpu: "0.00", ramMB: 0, startTime: null, address: displayAddress, status: 'offline', cpuLimit: initCpuLimit, ramLimit: initRamLimit, diskLimit: initDiskLimit });
 }

 // Fix bug: kalau user refresh PAS lagi starting, terus Done() kedetect DI ANTARA
 // waktu tab lama disconnect dan socket baru ini selesai reconnect, broadcast
 // 'server_ready' yang cuma sekali tembak itu bisa keburu lewat & ke-miss total
 // (makanya uptime udah ijo tapi suara/notif ga pernah nyala). Solusinya: kalau pas
 // konek server udah "running" dan itu baru aja selesai boot (dalam 20 detik
 // terakhir), tembak ulang 'server_ready' KHUSUS ke socket ini biar suara/notif
 // tetap ke-trigger, tanpa nge-replay ke user yang emang refresh lama setelah online.
 if (state.process && !state.isStarting && state.readyAt && (Date.now() - state.readyAt) < 20000) {
 socket.emit('server_ready');
 }

 function userLog(msg) { 
 state.logs.push(msg); 
 if (state.logs.length > 500) state.logs.shift(); 
 io.to('panel_' + roomKey).emit('log', msg); 
 }

 // Meniru Pterodactyl 100% (dicek langsung sama punya asli): baris status paling atas
 // SELALU live/dinamis sesuai status TERKINI (offline/starting/running) tiap kali tab
 // dibuka/refresh. Di bawahnya HANYA "process log" (java -version, start command,
 // stdout/stderr proses termasuk log boot Minecraft) yang direplay — pesan daemon
 // (checking disk, updating config, pulling docker image, marked as starting) dan baris
 // "marked as running" yang nempel di tempatnya setelah Done() itu cuma tampil LIVE,
 // gak ikut direplay saat refresh. Ini sudah dicek langsung sama console Pterodactyl asli.
 if (state.process || state.isStarting) {
 const statusLine = state.isStarting
  ? `\x1b[38;2;234;179;8m\x1b[1mcontainer@manz4vps~\x1b[0m Server marked as starting...\n`
  : `\x1b[38;2;234;179;8m\x1b[1mcontainer@manz4vps~\x1b[0m Server marked as running...\n`;
 socket.emit('log_history', statusLine + state.processLog.join(''));
 } else {
 const freshStatusLine = `\x1b[38;2;234;179;8m\x1b[1mcontainer@manz4vps~\x1b[0m Server marked as offline...\n`;
 socket.emit('log_history', freshStatusLine);
 }
 socket.emit('download_lock_state', state.isDownloading, state.downloadKind || 'jar'); 
 socket.on('clear_logs', () => { state.logs = []; });

 socket.on('command', (cmd) => { 
 let commandText = cmd.trim();
 
 // ðŸ”¥ FITUR VPSINFO DENGAN TAMBAHAN HURUF 'B' (GB/MB) & CPU LOAD ðŸ”¥
 if (commandText.toLowerCase() === 'vpsinfo') {
 const cpus = os.cpus();
 const totalRamNum = os.totalmem() / (1024 ** 3);
 const freeRamNum = os.freemem() / (1024 ** 3);
 const usedRamNum = totalRamNum - freeRamNum;
 const ramPercent = Math.round((usedRamNum / totalRamNum) * 100);
 const ramColor = ramPercent >= 80 ? '\x1b[1;31m' : (ramPercent >= 60 ? '\x1b[1;33m' : '\x1b[1;32m');

 // --- SCRIPT TAMBAHAN UNTUK HITUNG CPU LOAD VPS ---
 const startCpu = os.cpus();
 setTimeout(() => {
 const endCpu = os.cpus();
 let totalIdle = 0, totalTick = 0;
 
 for (let i = 0; i < startCpu.length; i++) {
 const start = startCpu[i];
 const end = endCpu[i];
 
 const idle = end.times.idle - start.times.idle;
 let total = 0;
 for (type in end.times) {
 total += end.times[type] - start.times[type];
 }
 totalIdle += idle;
 totalTick += total;
 }
 
 // Gantilah baris ini di dalam skrip vpsinfo kemarin:
const cpuPercent = Math.round((1 - totalIdle / totalTick) * 100) * startCpu.length;
const cpuColor = cpuPercent >= (80 * startCpu.length) ? '\x1b[1;31m' : (cpuPercent >= (60 * startCpu.length) ? '\x1b[1;33m' : '\x1b[1;32m');
 // ----------------------------------------------------

 exec("df -h /", (err, stdout) => {
 let diskTotal = "?", diskUsed = "?", diskFree = "?", diskPercent = "?", diskColor = '\x1b[1;32m';
 if (!err && stdout) { 
 try {
 let parts = stdout.trim().split('\n')[1].trim().split(/\s+/); 
 
 const addB = (val) => val ? val.replace(/([KMGTP])$/i, '$1B') : "?";
 
 diskTotal = addB(parts[1]); 
 diskUsed = addB(parts[2]); 
 diskFree = addB(parts[3]); 
 diskPercent = parts[4] || "0%"; 
 
 let dpNum = parseInt((diskPercent || "0").replace('%', ''));
 if(!isNaN(dpNum)) diskColor = dpNum >= 80 ? '\x1b[1;31m' : (dpNum >= 60 ? '\x1b[1;33m' : '\x1b[1;32m');
 } catch(e) {} 
 }
 
 userLog(`\n\x1b[1;35m=== SPESIFIKASI VPS (MANZ4VPS) ===\x1b[0m\n`);
 userLog(`\x1b[1;36m OS Sistem :\x1b[0m ${os.type()} ${os.release()} (${os.arch()})\n`);
 userLog(`\x1b[1;36m Prosesor :\x1b[0m ${cpus[0].model}\n`);
 userLog(`\x1b[1;36m Total Core :\x1b[0m ${cpus.length} Cores\n`);
 userLog(`\x1b[1;36m CPU Load :\x1b[0m ${cpuColor}${cpuPercent}%\x1b[0m\n`); // <--- INI TAMBAHAN FITUR CPU-NYA BRO
 userLog(`\x1b[1;36m RAM :\x1b[0m ${usedRamNum.toFixed(2)}GB / ${totalRamNum.toFixed(2)}GB (${ramColor}${ramPercent}%\x1b[0m) / free ${freeRamNum.toFixed(2)}GB\n`);
 userLog(`\x1b[1;36m Disk Root :\x1b[0m ${diskUsed} / ${diskTotal} (${diskColor}${diskPercent}\x1b[0m) / free ${diskFree}\n`);
 userLog(`\x1b[1;35m====================================\x1b[0m\n\n`);
 });
 }, 500); // Mengukur beban CPU dalam jeda 500ms agar akurat
 return;
 }

 if (state.process) { 
 let parts = commandText.split(" "); parts[0] = parts[0].toLowerCase(); 
 state.process.stdin.write(parts.join(" ") + '\n'); 
 } 
 });

 function eksekusiProses(execCmd, execArgs, settings) {
 // "Process log" = output asli proses (java -version, start command, stdout/stderr server).
 // Ini yang direplay penuh saat refresh (mirip attach ke log container di Pterodactyl),
 // dipisah dari pesan daemon (checking disk, marked as starting, dst) yang cuma live.
 state.processLog = [];
 const procLog = (msg) => { userLog(msg); state.processLog.push(msg); if (state.processLog.length > 500) state.processLog.shift(); };

 const doExec = () => {
 procLog(`\x1b[38;2;234;179;8m\x1b[1mcontainer@manz4vps~\x1b[0m ${execCmd} ${execArgs.join(' ')}\n`);
 try {
 state.process = spawn(execCmd, execArgs, { cwd: mcDir, env: { ...process.env, TZ: 'Asia/Jakarta' } });
 state.startTime = Date.now();
 state.isStarting = true;
 startResourceMonitor(activeServer, state, userLog);
 
 state.process.stdout.on('data', (data) => {
 let output = data.toString();
 if (output.includes('Done (') && output.includes('! For help, type "help"')) {
  output = output.replace(/(Done \([\d.]+s\)!)/g, '\x1b[32m\x1b[1m$1\x1b[0m');
  state.isStarting = false;
  state.readyAt = Date.now();
  io.to('panel_' + roomKey).emit('server_ready');
  procLog(output);
  userLog(`\x1b[38;2;234;179;8m\x1b[1mcontainer@manz4vps~\x1b[0m Server marked as running...\n`);
  return;
 } else if (output.toLowerCase().includes('bot is online') || output.toLowerCase().includes('listening on port')) {
  state.isStarting = false;
  state.readyAt = Date.now();
  io.to('panel_' + roomKey).emit('server_ready');
  procLog(output);
  userLog(`\x1b[38;2;234;179;8m\x1b[1mcontainer@manz4vps~\x1b[0m Server marked as running...\n`);
  return;
 }
 procLog(output);
 });

 state.process.stderr.on('data', (data) => {
 const errOut = data.toString();
 procLog(`\x1b[31m${errOut}\x1b[0m`);
 });
 state.process.on('close', (code) => {
 userLog(`\x1b[38;2;234;179;8m\x1b[1mcontainer@manz4vps~\x1b[0m Server marked as offline...\n`);
 state.readyAt = null;
 pidusage.clear(); 
 if (state._restartKillTimer) { clearTimeout(state._restartKillTimer); state._restartKillTimer = null; }
 state.process = null; 
 state.startTime = null;
 state.isStarting = false;
 io.to('panel_' + roomKey).emit('stats', { cpu: "0.00", ramMB: 0, startTime: null, address: `${settings.ip}:${settings.port}`, status: 'offline', netIn: 0, netOut: 0 });
 if (state.isRestarting) { state.isRestarting = false; setTimeout(() => globalSpawn(activeServer, username, { keepLogs: true }), 2000); }
 });
 } catch(e) { 
 userLog(`\x1b[31mGagal eksekusi: ${e.message}\x1b[0m\n`); 
 state.isStarting = false;
 }
 };

 if (/java(\.exe)?$/i.test(execCmd)) {
 logJavaVersion(execCmd, procLog, doExec);
 } else {
 doExec();
 }
 }

 function startServer() {
 if (state.isDownloading) return userLog(`\x1b[33m Sistem sedang mengunduh file. Harap tunggu.\x1b[0m\n`);
 if (state.process || state.isStarting) return; 

 state.logs = []; // sesi baru dimulai, buang sisa log "Proses berhenti" dari sesi sebelumnya
 state.isStarting = true;
 const snap = readNetStats(); state.netBaseRx = snap.rx; state.netBaseTx = snap.tx;
 const settings = getUserSettings(activeServer);

 if (settings.engine !== 'node' && settings.engine !== 'python') {
  try { const eulaPath = path.join(mcDir, 'eula.txt'); if (!fs.existsSync(eulaPath) || !fs.readFileSync(eulaPath,'utf8').includes('eula=true')) { fs.writeFileSync(eulaPath, 'eula=true\n'); } } catch(e) {}
 }

 userLog(`\x1b[38;2;234;179;8m\x1b[1m[Manz4VPS Daemon]:\x1b[0m Checking server disk space usage, this could take a few seconds.\n`);
 setTimeout(() => userLog(`\x1b[38;2;234;179;8m\x1b[1m[Manz4VPS Daemon]:\x1b[0m Updating process configuration files...\n`), 600);
 setTimeout(() => userLog(`\x1b[38;2;234;179;8m\x1b[1m[Manz4VPS Daemon]:\x1b[0m Ensuring file permissions are set correctly, this could take a few seconds...\n`), 900);

 setTimeout(() => {
 userLog(`\x1b[38;2;234;179;8m\x1b[1mcontainer@manz4vps~\x1b[0m Server marked as starting...\n`);

 if (settings.engine === 'node') {
 eksekusiProses('sh', ['-c', `if [ -d .git ]; then git pull; fi; if [ -f package.json ]; then npm install; fi; exec node "${settings.jarFile}"`], settings);
 } else if (settings.engine === 'python') {
 eksekusiProses('python3', [settings.jarFile], settings);
 } else {
 const reqJavaVer = (settings.javaVersion && settings.javaVersion !== 'auto') ? parseInt(settings.javaVersion) : getRequiredJavaVersion(settings.installedVersion);
 userLog(`\x1b[38;2;234;179;8m\x1b[1m[Manz4VPS Daemon]:\x1b[0m Pulling Docker container image, this could take a few minutes to complete...\n`);
 userLog(`\x1b[38;2;234;179;8m\x1b[1m[Manz4VPS Daemon]:\x1b[0m Finished pulling Docker container image\n`);
 
 ensureJava(reqJavaVer, userLog, (err, javaPath) => {
 if (err) {
 userLog(`\x1b[31mGagal menginstal Java ${reqJavaVer}: ${err.message}\x1b[0m\n`);
 state.isStarting = false;
 return;
 }
 const userLimits = readUsers()[username]?.limits || { ram: 2048 };
 const ramMB = Math.min(parseRamMB(settings.ram), userLimits.ram);
 const defaultJvmFlags = [
  `-Dterminal.jline=false`,
  `-Dterminal.ansi=true`,
 ];
 // -Xmx dikunci dari RAM slider — selalu strip dari custom flags, pakai ramMB
 const customCmdStr = (settings.useCustomStartup && settings.customStartupCmd) ? settings.customStartupCmd.trim().replace(/-Xmx\S+\s*/gi, '').trim() : '';
 const jvmFlags = customCmdStr
  ? [`-Xmx${ramMB}M`, ...customCmdStr.split(/\s+/).filter(f => f.length > 0)]
  : [`-Xmx${ramMB}M`, ...defaultJvmFlags];
 const execArgs = [
  ...jvmFlags,
  `-jar`, settings.jarFile, `--port`, settings.port
 ];
 eksekusiProses(javaPath, execArgs, settings);
 });
 }
 }, 1200); 
 }

 socket.on('start', () => startServer());
 socket.on('restart', () => {
 if (state.isRestarting) { userLog(`\x1b[1;33m[Manz4VPS Daemon]:\x1b[0m Server sedang dalam proses restart, harap tunggu...\n`); return; }
 if (state.process) {
 state.isRestarting = true;
 userLog(`\x1b[38;2;234;179;8m\x1b[1m[Manz4VPS Daemon]:\x1b[0m Mengirim perintah restart...\n`);
 const restartSettings = getUserSettings(activeServer);
 if (restartSettings.engine === 'node' || restartSettings.engine === 'python') {
 try { state.process.kill('SIGTERM'); } catch(e) {}
 } else {
 try { state.process.stdin.write('stop\n'); } catch(e) {}
 }
 if (state._restartKillTimer) clearTimeout(state._restartKillTimer);
 state._restartKillTimer = setTimeout(() => {
 if (state.process && state.isRestarting) {
 userLog(`\x1b[1;33m[Manz4VPS Daemon]:\x1b[0m Proses tidak merespons dalam 45 detik, paksa berhenti...\n`);
 try { state.process.kill('SIGTERM'); } catch(e) {}
 setTimeout(() => { if (state.process && state.isRestarting) { try { state.process.kill('SIGKILL'); } catch(e) {} } }, 5000);
 }
 }, 45000);
 } else { globalSpawn(activeServer, username); }
 });
 socket.on('stop_aman', () => {
 if (state.process) {
 state.isRestarting = false;
 if (state._restartKillTimer) { clearTimeout(state._restartKillTimer); state._restartKillTimer = null; }
 userLog(`\x1b[38;2;234;179;8m\x1b[1mcontainer@manz4vps~\x1b[0m Server marked as stopping...\n`);
 const stopSettings = getUserSettings(activeServer);
 if (stopSettings.engine === 'node' || stopSettings.engine === 'python') {
  try { state.process.kill('SIGTERM'); } catch(e) {}
 } else {
  try { state.process.stdin.write('stop\n'); } catch(e) {}
 }
 }
 });
 
 socket.on('kill_paksa', () => { 
 if (state.process) { 
 // JANGAN reset isRestarting di sini kalau memang lagi proses restart —
 // biarkan flag itu tetap true supaya handler 'close' di bawah otomatis
 // nge-spawn ulang server. Kalau di-reset ke false, kill paksa saat restart
 // cuma akan mematikan server tanpa restart.
 if (!state.isRestarting) state.isRestarting = false;
 if (state._restartKillTimer) { clearTimeout(state._restartKillTimer); state._restartKillTimer = null; }
  try { state.process.kill('SIGKILL'); } catch(err) { }
 state.startTime = null;
 state.isStarting = false;
 const killSettings = getUserSettings(activeServer);
 io.to('panel_' + roomKey).emit('stats', { cpu: "0.00", ramMB: 0, startTime: null, address: `${killSettings.ip}:${killSettings.port}`, status: 'offline', netIn: 0, netOut: 0 });
 } 
 });
 
 socket.on('accept_eula', () => { try { fs.writeFileSync(path.join(mcDir, 'eula.txt'), 'eula=true'); userLog(`\x1b[32m EULA disetujui. Memulai ulang...\x1b[0m\n`); if (state.process) { state.isRestarting = true; try { state.process.stdin.write('stop\n'); } catch(e) {} } else { setTimeout(() => globalSpawn(activeServer, username), 2000); } } catch (e) { } });

 socket.on('download_jar', (url, versionName, isCleanInstall) => {
 if (state.isDownloading) return userLog(`\x1b[33m Proses unduhan lain sedang berjalan.\x1b[0m\n`);
 if (state.process) {
 userLog(`\x1b[33m[Manz4VPS Daemon]:\x1b[0m Server masih menyala, mematikan otomatis untuk mengganti versi...\n`);
 state.isRestarting = false;
 if (state._restartKillTimer) { clearTimeout(state._restartKillTimer); state._restartKillTimer = null; }
 try { state.process.kill('SIGKILL'); } catch(e) {}
 state.process = null; state.startTime = null; state.isStarting = false;
 const killSettings = getUserSettings(activeServer);
 io.to('panel_' + roomKey).emit('stats', { cpu: "0.00", ramMB: 0, startTime: null, address: `${killSettings.ip}:${killSettings.port}`, status: 'offline', netIn: 0, netOut: 0 });
 }
 state.isDownloading = true; state.downloadKind = 'jar'; io.to('panel_' + roomKey).emit('download_lock_state', true, 'jar'); 
 
 if (isCleanInstall) {
 userLog(`\x1b[33mMelakukan WIPE (Sapu Bersih) seluruh file...\x1b[0m\n`);
 try {
 const files = fs.readdirSync(mcDir);
 files.forEach(file => { if (file !== 'panel_settings.json') { try { fs.rmSync(path.join(mcDir, file), { recursive: true, force: true }); } catch (err) {} } });
 } catch(e) {}
 } else {
 const jarPath = path.join(mcDir, 'server.jar'); const backupPath = path.join(mcDir, 'server.jar.old'); 
 if (fs.existsSync(jarPath)) { try { if (fs.existsSync(backupPath)) fs.rmSync(backupPath, { force: true }); fs.renameSync(jarPath, backupPath); } catch(e) {} }
 }
 
 userLog(`\x1b[33mMemulai pengunduhan ${versionName}...\x1b[0m\n`);
 const downloader = spawn('curl', ['-L', '-#', '-A', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', '-o', 'server.jar', url], { cwd: mcDir });
 downloader.on('close', (code) => {
 if(code === 0) { 
 userLog(`\x1b[32m SUKSES! ${versionName} siap dimainkan.\x1b[0m\n`);
 const settings = getUserSettings(activeServer, username); settings.installedVersion = versionName; fs.writeFileSync(path.join(mcDir, 'panel_settings.json'), JSON.stringify(settings));
 try { fs.writeFileSync(path.join(mcDir, 'eula.txt'), 'eula=true\n'); } catch(e) {}
 userLog(`\x1b[34m[Manz4VPS Daemon]: eula.txt otomatis disetujui.\x1b[0m\n`);
 if (settings.engine !== 'node' && settings.engine !== 'python') {
 const reqJavaVer = (settings.javaVersion && settings.javaVersion !== 'auto') ? parseInt(settings.javaVersion) : getRequiredJavaVersion(versionName);
 userLog(`\x1b[38;2;234;179;8m\x1b[1m[Manz4VPS Daemon]:\x1b[0m Mendeteksi kebutuhan Java ${reqJavaVer} untuk versi [${versionName}]\n`);
 ensureJava(reqJavaVer, userLog, (err) => {
 if (err) { userLog(`\x1b[31mGagal menginstal Java ${reqJavaVer}: ${err.message}\x1b[0m\n`); }
 state.isDownloading = false; io.to('panel_' + roomKey).emit('download_lock_state', false, 'jar');
 io.to('panel_' + roomKey).emit('download_success_toast');
 });
 } else {
 state.isDownloading = false; io.to('panel_' + roomKey).emit('download_lock_state', false, 'jar');
 io.to('panel_' + roomKey).emit('download_success_toast');
 }
 } else {
 userLog(`\x1b[31mUnduhan gagal. (Kode: ${code})\x1b[0m\n`);
 state.isDownloading = false; io.to('panel_' + roomKey).emit('download_lock_state', false, 'jar');
 }
 });
 });

 socket.on('download_plugin', (url, filename) => {
 if (state.isDownloading) return;
 state.isDownloading = true; state.downloadKind = 'plugin'; io.to('panel_' + roomKey).emit('download_lock_state', true, 'plugin'); 
 const pluginsDir = path.join(mcDir, 'plugins'); if (!fs.existsSync(pluginsDir)) fs.mkdirSync(pluginsDir, { recursive: true });
 userLog(`\x1b[33mMengunduh plugin: ${filename}...\x1b[0m\n`);
 const tmpFile = filename + '.tmp_dl';
 const finalPath = path.join(pluginsDir, filename);
 const tmpPath = path.join(pluginsDir, tmpFile);
 const downloader = spawn('curl', ['-L', '--fail', '-A', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', '-o', tmpFile, url], { cwd: pluginsDir });
 downloader.on('close', (code) => {
 state.isDownloading = false; io.to('panel_' + roomKey).emit('download_lock_state', false, 'plugin'); 
 if(code === 0 && fs.existsSync(tmpPath)) {
  try { fs.renameSync(tmpPath, finalPath); } catch(e) { try { fs.unlinkSync(tmpPath); } catch(_) {} }
  userLog(`\x1b[32m SUKSES! Plugin ${filename} berhasil dipasang.\x1b[0m\n`); io.to('panel_' + roomKey).emit('plugin_success_toast', filename);
 } else {
  try { if (fs.existsSync(tmpPath)) fs.unlinkSync(tmpPath); } catch(_) {}
  userLog(`\x1b[31mGagal mengunduh plugin.\x1b[0m\n`);
 }
 });
 });

 socket.on('download_mod', (url, filename) => {
 if (state.isDownloading) return;
 state.isDownloading = true; state.downloadKind = 'mod'; io.to('panel_' + roomKey).emit('download_lock_state', true, 'mod'); 
 const modsDir = path.join(mcDir, 'mods'); if (!fs.existsSync(modsDir)) fs.mkdirSync(modsDir, { recursive: true });
 userLog(`\x1b[33mMengunduh mod: ${filename}...\x1b[0m\n`);
 const tmpFileMod = filename + '.tmp_dl';
 const finalPathMod = path.join(modsDir, filename);
 const tmpPathMod = path.join(modsDir, tmpFileMod);
 const downloader = spawn('curl', ['-L', '--fail', '-A', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', '-o', tmpFileMod, url], { cwd: modsDir });
 downloader.on('close', (code) => {
 state.isDownloading = false; io.to('panel_' + roomKey).emit('download_lock_state', false, 'mod'); 
 if(code === 0 && fs.existsSync(tmpPathMod)) {
  try { fs.renameSync(tmpPathMod, finalPathMod); } catch(e) { try { fs.unlinkSync(tmpPathMod); } catch(_) {} }
  userLog(`\x1b[32m SUKSES! Mod ${filename} berhasil dipasang.\x1b[0m\n`); io.to('panel_' + roomKey).emit('mod_success_toast', filename);
 } else {
  try { if (fs.existsSync(tmpPathMod)) fs.unlinkSync(tmpPathMod); } catch(_) {}
  userLog(`\x1b[31mGagal mengunduh mod.\x1b[0m\n`);
 }
 });
 });
});

function globalSpawn(srvName, ownerHint, opts = {}) {
 const ownerStr = ownerHint || getOwner(srvName) || srvName;
 const state = getUserState(srvName, ownerStr);
 if (state.process || state.isStarting || state.isDownloading) return;
 const settings = getUserSettings(srvName, ownerStr);
 const mcDir = getUserDir(srvName, ownerStr);
 const spawnRoomKey = ownerStr + '::' + srvName;
 const uLog = (msg) => { state.logs.push(msg); if (state.logs.length > 500) state.logs.shift(); io.to('panel_' + spawnRoomKey).emit('log', msg); };
 // Sesi baru dimulai: buang sisa log "Proses berhenti" dari sesi sebelumnya, KECUALI ini
 // respawn lanjutan dari Restart (keepLogs) yang memang harus terlihat menyambung.
 if (!opts.keepLogs) state.logs = [];
 const snap = readNetStats(); state.netBaseRx = snap.rx; state.netBaseTx = snap.tx;
 state.isStarting = true;

 // "Process log" = output asli proses (java -version, start command, stdout/stderr server).
 // Direplay penuh saat refresh, terpisah dari pesan daemon yang cuma live.
 state.processLog = [];
 const procLog = (msg) => { uLog(msg); state.processLog.push(msg); if (state.processLog.length > 500) state.processLog.shift(); };

 const doSpawn = (cmd, args, extraEnv = {}) => {
 const runSpawn = () => {
 procLog(`\x1b[38;2;234;179;8m\x1b[1mcontainer@manz4vps~\x1b[0m ${cmd} ${args.join(' ')}\n`);
 try {
 state.process = spawn(cmd, args, { cwd: mcDir, env: { ...process.env, TZ: 'Asia/Jakarta', ...extraEnv } });
 state.startTime = Date.now();
 startResourceMonitor(srvName, state, uLog);
 state.process.stdout.on('data', d => {
 let o = d.toString();
 if (o.includes('Done (') && o.includes('! For help, type "help"')) {
  o = o.replace(/(Done \([\d.]+s\)!)/g, '\x1b[32m\x1b[1m$1\x1b[0m');
  state.isStarting = false;
  state.readyAt = Date.now();
  io.to('panel_' + spawnRoomKey).emit('server_ready');
  procLog(o);
  uLog(`\x1b[38;2;234;179;8m\x1b[1mcontainer@manz4vps~\x1b[0m Server marked as running...\n`);
  return;
 } else if (/bot is online|listening on port/i.test(o)) {
  state.isStarting = false;
  state.readyAt = Date.now();
  io.to('panel_' + spawnRoomKey).emit('server_ready');
  procLog(o);
  uLog(`\x1b[38;2;234;179;8m\x1b[1mcontainer@manz4vps~\x1b[0m Server marked as running...\n`);
  return;
 }
 if (o.includes('You need to agree to the EULA') && !state._eulaHandled) {
  state._eulaHandled = true;
  uLog(`\x1b[33m[Manz4VPS Daemon]: EULA terdeteksi! Menyetujui otomatis & restart...\x1b[0m\n`);
  try { fs.writeFileSync(path.join(mcDir, 'eula.txt'), 'eula=true\n'); } catch(e) {}
  uLog(`\x1b[34m[Manz4VPS Daemon]: eula.txt berhasil disetujui.\x1b[0m\n`);
  state.isRestarting = true;
  setTimeout(() => { try { state.process.stdin.write('stop\n'); } catch(e) {} }, 1500);
 }
 procLog(o);
});
 state.process.stderr.on('data', d => {
 const errOut = d.toString();
 procLog(`\x1b[31m${errOut}\x1b[0m`);
 });
 state.process.on('close', code => {
 uLog(`\x1b[38;2;234;179;8m\x1b[1mcontainer@manz4vps~\x1b[0m Server marked as offline...\n`);
 state.readyAt = null;
 pidusage.clear();
 if (state._restartKillTimer) { clearTimeout(state._restartKillTimer); state._restartKillTimer = null; }
 state.process = null; state.startTime = null; state.isStarting = false; state._eulaHandled = false;
 state.netAccumRx = 0; state.netAccumTx = 0; state._lastSsRx = 0; state._lastSsTx = 0;
  const s2 = getUserSettings(srvName, ownerStr);
 io.to('panel_' + spawnRoomKey).emit('stats', { cpu: "0.00", ramMB: 0, startTime: null, address: `${s2.ip}:${s2.port}`, status: 'offline', netIn: 0, netOut: 0 });
 if (state.isRestarting) {
 state.isRestarting = false;
 setTimeout(() => globalSpawn(srvName, ownerStr, { keepLogs: true }), 2000);
 }
 });
 } catch(e) { uLog(`\x1b[31mGagal: ${e.message}\x1b[0m\n`); state.isStarting = false; }
 };

 if (/java(\.exe)?$/i.test(cmd)) {
 logJavaVersion(cmd, procLog, runSpawn);
 } else {
 runSpawn();
 }
 };

 uLog(`\x1b[38;2;234;179;8m\x1b[1m[Manz4VPS Daemon]:\x1b[0m Checking server disk space usage, this could take a few seconds.\n`);
 setTimeout(() => uLog(`\x1b[38;2;234;179;8m\x1b[1m[Manz4VPS Daemon]:\x1b[0m Updating process configuration files...\n`), 600);
 setTimeout(() => uLog(`\x1b[38;2;234;179;8m\x1b[1m[Manz4VPS Daemon]:\x1b[0m Ensuring file permissions are set correctly, this could take a few seconds...\n`), 900);

 setTimeout(() => {
 uLog(`\x1b[38;2;234;179;8m\x1b[1mcontainer@manz4vps~\x1b[0m Server marked as starting...\n`);

 if (settings.engine === 'node') {
 doSpawn('sh', ['-c', `if [ -d .git ]; then git pull; fi; if [ -f package.json ]; then npm install; fi; exec node "${settings.jarFile}"`]);
 } else if (settings.engine === 'python') {
 doSpawn('python3', [settings.jarFile]);
 } else {
 const reqJavaVer = (settings.javaVersion && settings.javaVersion !== 'auto') ? parseInt(settings.javaVersion) : getRequiredJavaVersion(settings.installedVersion);
 uLog(`\x1b[38;2;234;179;8m\x1b[1m[Manz4VPS Daemon]:\x1b[0m Pulling Docker container image, this could take a few minutes to complete...\n`);
 uLog(`\x1b[38;2;234;179;8m\x1b[1m[Manz4VPS Daemon]:\x1b[0m Finished pulling Docker container image\n`);
 ensureJava(reqJavaVer, uLog, (err, javaPath) => {
 if (err) { uLog(`\x1b[31mâŒ Gagal Java: ${err.message}\x1b[0m\n`); state.isStarting = false; return; }
 const ownerForCap = ownerStr;
 const ownerLimits = readUsers()[ownerForCap]?.limits || { ram: 2048 };
 const srvRamLimit = settings.srvLimits?.ram || ownerLimits.ram;
 const ramMBg = Math.min(parseRamMB(settings.ram), srvRamLimit);
 // -Xmx dikunci dari RAM slider — selalu strip dari custom flags, pakai ramMBg
 const autoCustomCmd = (settings.useCustomStartup && settings.customStartupCmd) ? settings.customStartupCmd.trim().replace(/-Xmx\S+\s*/gi, '').trim() : '';
 const autoJvmArgs = autoCustomCmd
  ? [`-Xmx${ramMBg}M`, ...autoCustomCmd.split(/\s+/).filter(f => f.length > 0)]
  : [`-Xmx${ramMBg}M`, `-Dterminal.jline=false`, `-Dterminal.ansi=true`];
 doSpawn(javaPath, [
  ...autoJvmArgs,
  `-jar`, settings.jarFile, `--port`, settings.port
 ]);
 });
 }
 }, 1200);
}


function bootAutoStart() {
 setTimeout(() => {
 try {
 const users = readUsers();
 for (const username in users) {
 const userServers = users[username].servers || [];
 userServers.forEach(srvName => {
 try {
 const settings = getUserSettings(srvName, username);
 if (!settings.autoStart) return;
 const state = getUserState(srvName, username);
 const autoRoomKey = username + '::' + srvName;
 const uLog = (msg) => { state.logs.push(msg); if (state.logs.length > 500) state.logs.shift(); io.to('panel_' + autoRoomKey).emit('log', msg); };
 uLog(`\x1b[38;2;234;179;8m\x1b[1m[Manz4VPS Daemon]:\x1b[0m Auto Start aktif. Memulai server ${srvName}...\n`);
 globalSpawn(srvName, username);
 } catch(e) {}
 });
 }
 } catch(e) {}
 }, 3000);
}

process.on('uncaughtException', (err) => {
 console.error(`[UNCAUGHT EXCEPTION] ${err.message}`);
 for (const key in activeServers) {
  const s = activeServers[key];
  const owner = s._owner || key;
  io.to(owner).emit('panel_error', { message: `Server error: ${err.message}` });
 }
});

process.on('unhandledRejection', (reason) => {
 const msg = reason instanceof Error ? reason.message : String(reason);
 console.error(`[UNHANDLED REJECTION] ${msg}`);
});

// Bersihkan alokasi port "nyangkut" — jaga-jaga kalau proses hapus server pernah
// terputus di tengah jalan (crash/restart) sebelum sempat releaseServerAllocations().
// Tanpa ini, port bisa tetap keliatan "dipakai" walau server pemiliknya sudah tidak ada.
function reconcileOrphanedAllocations() {
 try {
  const users = readUsers();
  const allocs = getAllocations();
  let changed = false;
  allocs.forEach(a => {
   if (!a.owner) return;
   const idx = a.owner.indexOf('::');
   if (idx === -1) return;
   const ownerUser = a.owner.slice(0, idx);
   const ownerServer = a.owner.slice(idx + 2);
   const stillOwned = users[ownerUser] && Array.isArray(users[ownerUser].servers) && users[ownerUser].servers.includes(ownerServer);
   if (!stillOwned) {
    a.owner = null; a.primary = false; changed = true;
   }
  });
  if (changed) saveAllocations(allocs);
 } catch(e) { console.error('[Reconcile] Gagal cek alokasi orphan:', e.message); }
}

const PTERO_PORT = process.env.PORT || 5000;
server.listen(PTERO_PORT, '0.0.0.0', () => {
 console.log(`\x1b[32mPANEL V29 (ULTIMATE)\x1b[0m`);
 migratePasswords();
 reconcileOrphanedAllocations();
 bootAutoStart();
});
