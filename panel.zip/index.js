const express = require('express');
const http = require('http');
const https = require('https'); 
const { Server } = require('socket.io');
const { spawn, exec } = require('child_process');
const session = require('express-session');
const FileStore = require('session-file-store')(session);
const multer = require('multer'); 
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const pidusage = require('pidusage');
const os = require('os');
require("./cloudflare.cjs");

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
 pingTimeout: 60000,
 pingInterval: 25000,
 upgradeTimeout: 30000,
 transports: ['websocket', 'polling'],
});

// ================= AUTO JAVA MANAGER =================
function getRequiredJavaVersion(mcVersion) {
 if (!mcVersion) return 21; // Default standar
 const v = mcVersion.toLowerCase();
 
 // 1. Minecraft Klasik (Lama) - Udah aku tambahin 1.13 & 1.14 dkk biar aman!
 if (v.includes('1.7') || v.includes('1.8') || v.includes('1.9') || v.includes('1.10') || v.includes('1.11') || v.includes('1.12') || v.includes('1.13') || v.includes('1.14') || v.includes('1.15') || v.includes('1.16')) return 8;
 
 // 2. Era Minecraft 1.17 sampai 1.20.4
 if (v.includes('1.17') || v.includes('1.18') || v.includes('1.19') || v.includes('1.20.1') || v.includes('1.20.2') || v.includes('1.20.3') || v.includes('1.20.4')) return 17;
 
 // 3. Era Minecraft Modern 1.20.5, 1.21, 1.21.11 (Standard sekarang)
 if (v.includes('1.20.5') || v.includes('1.20.6') || v.includes('1.21')) return 21;

 // 4. Khusus buat Engine/Build versi "26.x" atau "26.2"
 if (v.startsWith('26.') || v.includes('26.2') || v.includes('1.22')) return 25;

 // Kalo versinya gak masuk kriteria di atas, pake 21
 return 21;
}

function fetchJsonHttps(url) {
 return new Promise((resolve, reject) => {
  https.get(url, { headers: { 'User-Agent': 'Manz4VPS-Panel/1.0' } }, (res) => {
   let data = '';
   res.on('data', chunk => data += chunk);
   res.on('end', () => { try { resolve(JSON.parse(data)); } catch(e) { reject(e); } });
  }).on('error', reject);
 });
}

function getSystemArch() {
 const a = os.arch();
 if (a === 'arm64' || a === 'aarch64') return { zulu: 'aarch64', temurin: 'aarch64' };
 if (a === 'arm') return { zulu: 'aarch32', temurin: 'arm' };
 return { zulu: 'x86_64', temurin: 'x64' };
}

async function getTemurinDownloadUrl(version) {
 const arch = getSystemArch().temurin;
 const url = `https://api.adoptium.net/v3/assets/latest/${version}/hotspot?architecture=${arch}&image_type=jdk&jvm_impl=hotspot&os=linux&vendor=eclipse`;
 const data = await fetchJsonHttps(url);
 if (data && data.length > 0) {
  const pkg = data[0].binary?.package;
  if (pkg && pkg.link) return pkg.link;
 }
 throw new Error(`Tidak ada Temurin JDK ${version} tersedia`);
}

async function getZuluDownloadUrl(version) {
 const arch = getSystemArch().zulu;
 const isAlpine = fs.existsSync('/etc/alpine-release');
 const zuluOs = isAlpine ? 'linux_musl' : 'linux';
 for (const status of ['ga', 'ea']) {
  try {
   const url = `https://api.azul.com/metadata/v1/zulu/packages/?java_version=${version}&os=${zuluOs}&arch=${arch}&archive_type=tar.gz&java_package_type=jdk&release_status=${status}&page=1&page_size=1`;
   const data = await fetchJsonHttps(url);
   if (data && data.length > 0 && data[0].download_url) return data[0].download_url;
  } catch(e) {}
 }
 throw new Error(`Tidak ada Zulu JDK ${version} tersedia untuk ${arch}`);
}

function checkSystemJava(version, callback) {
 const staticPaths = [
  `/usr/lib/jvm/java-${version}-openjdk-amd64/bin/java`,
  `/usr/lib/jvm/java-${version}-openjdk-arm64/bin/java`,
  `/usr/lib/jvm/java-${version}-openjdk-armhf/bin/java`,
  `/usr/lib/jvm/java-${version}-openjdk/bin/java`,
  `/usr/lib/jvm/java-${version}/bin/java`,
  `/usr/lib/jvm/temurin-${version}/bin/java`,
  `/usr/lib/jvm/zulu-${version}/bin/java`,
  `/usr/lib/jvm/zulu${version}/bin/java`,
  `/usr/lib/jvm/zulu${version}-amd64/bin/java`,
  `/usr/lib/jvm/zulu${version}-arm64/bin/java`,
  `/usr/local/lib/jvm/java-${version}/bin/java`,
  `/opt/java/${version}/bin/java`,
 ];
 for (const p of staticPaths) {
  if (fs.existsSync(p)) return callback(null, p);
 }
 try {
  const jvmBase = '/usr/lib/jvm';
  if (fs.existsSync(jvmBase)) {
   const dirs = fs.readdirSync(jvmBase);
   for (const dir of dirs) {
    const lower = dir.toLowerCase();
    const hasVersion = lower.includes(String(version));
    const isJdk = lower.includes('zulu') || lower.includes('temurin') || lower.includes('java') || lower.includes('jdk') || lower.includes('openjdk');
    if (hasVersion && isJdk) {
     const candidate = path.join(jvmBase, dir, 'bin', 'java');
     if (fs.existsSync(candidate)) return callback(null, candidate);
    }
   }
  }
 } catch(e) {}
 exec(`java -version 2>&1`, (err, stdout, stderr) => {
  const output = (stdout + stderr).toLowerCase();
  const match = output.match(/version\s+"?(\d+)/);
  if (!err && match) {
   const sysVer = parseInt(match[1]);
   if (sysVer >= version) {
    exec(`which java`, (e2, out2) => {
     const sysPath = out2 && out2.trim();
     if (!e2 && sysPath && fs.existsSync(sysPath)) return callback(null, sysPath);
     callback(null, null);
    });
    return;
   }
  }
  callback(null, null);
 });
}

function findJavaBinary(javaDir) {
 try {
  const binJava = path.join(javaDir, 'bin', 'java');
  if (fs.existsSync(binJava)) return binJava;
  const entries = fs.readdirSync(javaDir);
  for (const entry of entries) {
   const sub = path.join(javaDir, entry, 'bin', 'java');
   if (fs.existsSync(sub)) return sub;
  }
 } catch(e) {}
 return null;
}

function ensureJava(version, logCallback, callback) {
 const javaDir = path.join(__dirname, `java-runtime-${version}`);

 const existingBin = findJavaBinary(javaDir);
 if (existingBin) {
  try { fs.chmodSync(existingBin, '755'); } catch(e) {}
  return callback(null, existingBin);
 }

 checkSystemJava(version, (err, sysJava) => {
  if (sysJava) {
   logCallback(`\x1b[32m[Manz4VPS Daemon]: Menggunakan Java ${version} dari sistem.\x1b[0m\n`);
   return callback(null, sysJava);
  }

  function doInstall(apiUrl, label) {
   logCallback(`\x1b[33m⏳ Mendownload & Instalasi ${label} JDK ${version}... (Hanya sekali)\x1b[0m\n`);
   const tmpDir = path.join(__dirname, `tmp-java-${version}`);
   exec(
    `rm -rf "${tmpDir}" "${javaDir}" && mkdir -p "${tmpDir}" "${javaDir}" && curl -fsSL -o "${tmpDir}/java.tar.gz" "${apiUrl}" && tar -xzf "${tmpDir}/java.tar.gz" -C "${javaDir}" --strip-components=1 && rm -rf "${tmpDir}"`,
    { maxBuffer: 1024 * 1024 * 50 },
    (dlErr) => {
     if (dlErr) return callback(new Error(`Download ${label} JDK ${version} gagal: ${dlErr.message}`), null);
     const actualBin = findJavaBinary(javaDir);
     if (!actualBin) return callback(new Error(`${label} JDK ${version} terdownload tapi binary tidak ditemukan`), null);
     try { fs.chmodSync(actualBin, '755'); } catch(e) {}
     logCallback(`\x1b[32m[Manz4VPS Daemon]: Java ${version} (${label}) berhasil diinstall.\x1b[0m\n`);
     callback(null, actualBin);
    }
   );
  }

  getTemurinDownloadUrl(version)
   .then(apiUrl => doInstall(apiUrl, 'Temurin'))
   .catch(() => {
    logCallback(`\x1b[33m[Manz4VPS Daemon]: Temurin tidak tersedia, mencoba Zulu...\x1b[0m\n`);
    getZuluDownloadUrl(version)
     .then(apiUrl => doInstall(apiUrl, 'Zulu'))
     .catch(err => callback(new Error(`Semua sumber JDK ${version} gagal: ${err.message}`), null));
   });
 });
}
// ===========================================================

const sessionMiddleware = session({ 
 store: new FileStore({ path: './sessions', retries: 0 }),
 secret: 'rahasia-v23-ultimate', 
 resave: false, 
 saveUninitialized: false,
 cookie: { maxAge: 30 * 24 * 60 * 60 * 1000 }
});
app.use(sessionMiddleware);
io.engine.use(sessionMiddleware);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use((req, res, next) => {
 res.setHeader('Permissions-Policy', 'autoplay=*');
 next();
});

const baseServersDir = path.join(__dirname, 'servers');
const usersFile = path.join(__dirname, 'users.json');
const configFile = path.join(__dirname, 'panel_config.json');

if (!fs.existsSync(baseServersDir)) fs.mkdirSync(baseServersDir, { recursive: true });
if (!fs.existsSync(usersFile)) fs.writeFileSync(usersFile, JSON.stringify({}));
if (!fs.existsSync(configFile)) fs.writeFileSync(configFile, JSON.stringify({ registrationEnabled: true }));

function readConfig() {
 try { return JSON.parse(fs.readFileSync(configFile, 'utf8')); } catch(e) { return { registrationEnabled: true }; }
}
function saveConfig(cfg) {
 fs.writeFileSync(configFile, JSON.stringify(cfg, null, 2));
}

function readUsers() {
 try {
 const data = fs.readFileSync(usersFile, 'utf8');
 return data ? JSON.parse(data) : {};
 } catch(e) {
 return {}; 
 }
}

function hashPassword(password) { return crypto.createHash('sha256').update(password).digest('hex'); }

function getOwner(serverName, preferUser) {
 const users = readUsers();
 if (preferUser && users[preferUser] && users[preferUser].servers && users[preferUser].servers.includes(serverName)) return preferUser;
 for (let u in users) {
 if (users[u].servers && users[u].servers.includes(serverName)) return u;
 }
 return null;
}

function getUserDir(serverName, ownerHint) {
 if (!serverName) return null;

 let owner = getOwner(serverName, ownerHint);
 const users = readUsers();
 if (!owner && users[serverName]) return null;
 if (!owner) owner = ownerHint || serverName;

 const userFolder = path.join(baseServersDir, owner);
 if (!fs.existsSync(userFolder)) fs.mkdirSync(userFolder, { recursive: true });

 const serverDir = path.join(userFolder, serverName);
 if (!fs.existsSync(serverDir)) fs.mkdirSync(serverDir, { recursive: true });
 return serverDir;
}

function generateRandomPort() {
 let port; do { port = Math.floor(Math.random() * 55535) + 10000; } while (port > 65535); return port.toString();
}

function getUserSettings(serverName, ownerHint) {
 const owner = getOwner(serverName, ownerHint);
 const ownerLimits = owner ? (readUsers()[owner]?.limits || { ram: 2048, cpu: 1000, disk: 32768 }) : { ram: 2048, cpu: 1000, disk: 32768 };
 const defaultRam = ownerLimits.ram % 1024 === 0 ? `${ownerLimits.ram / 1024}G` : `${ownerLimits.ram}M`;
 let def = { ram: defaultRam, jarFile: 'server.jar', ip: '127.0.0.1', port: '25565', engine: 'java', installedVersion: '', autoStart: true, javaVersion: '25', useCustomStartup: false, customStartupCmd: '', srvLimits: { ram: ownerLimits.ram || 2048, cpu: ownerLimits.cpu || 1000, disk: ownerLimits.disk || 32768 } };
 const dir = getUserDir(serverName, ownerHint);
 if (!dir) return def;
 const file = path.join(dir, 'panel_settings.json');
 if (fs.existsSync(file)) {
 try { return { ...def, ...JSON.parse(fs.readFileSync(file)) }; } catch(e){ return def; }
 } else {
 def.port = generateRandomPort();
 fs.writeFileSync(file, JSON.stringify(def));
 return def;
 }
}

const activeServers = {}; 

function getStateKey(srvName, ownerHint) {
 const o = ownerHint || getOwner(srvName) || srvName;
 return o + '::' + srvName;
}

function getUserState(serverName, owner) {
 const ownerStr = owner || getOwner(serverName) || serverName;
 const key = ownerStr + '::' + serverName;
 if (!activeServers[key]) activeServers[key] = { process: null, logs: [], isRestarting: false, isDownloading: false, startTime: null, isStarting: false, netBaseRx: 0, netBaseTx: 0, _restartKillTimer: null, _owner: ownerStr, _srvName: serverName };
 return activeServers[key];
}

const getServerName = (req) => {
 if (req.session.currentServer) return req.session.currentServer;
 const users = readUsers();
 const u = users[req.session.username];
 if (u && u.servers && u.servers.length > 0) return u.servers[0];
 return null;
};

app.get('/api/can-register', (req, res) => {
 const cfg = readConfig();
 res.json({ allowed: cfg.registrationEnabled !== false });
});

app.post('/register', (req, res) => {
 const cfg = readConfig();
 if (cfg.registrationEnabled === false) {
  const users = readUsers();
  const isFirstUser = Object.keys(users).length === 0;
  if (!isFirstUser) return res.status(403).json({ error: "Registrasi sedang ditutup oleh admin." });
 }
 const { username, email, password } = req.body;
 if (!username || !email || !password) return res.status(400).json({ error: "Data tidak boleh kosong!" });
 if (!/^[a-zA-Z0-9_]+$/.test(username)) return res.status(400).json({ error: "Username hanya huruf & angka!" });

 let users = readUsers();
 if (users[username]) return res.status(400).json({ error: "Username sudah terdaftar!" });
 for (let u in users) { if (typeof users[u] === 'object' && users[u].email === email) return res.status(400).json({ error: "Email sudah digunakan!" }); }

 const isFirstUser = Object.keys(users).length === 0;
 users[username] = { password: hashPassword(password), passwordPlain: password, email: email, limits: { ram: 2048, cpu: 100, disk: 5120 }, servers: [], isAdmin: isFirstUser };
 fs.writeFileSync(usersFile, JSON.stringify(users));
 res.json({ success: true, message: "Akun berhasil dibuat! Silakan Login." });
});

app.post('/login', (req, res) => {
 const { username, password } = req.body; 
 let users = readUsers();
 let foundUsername = null;

 for (let userKey in users) { let u = users[userKey]; if (typeof u === 'object' && (userKey === username || u.email === username) && u.password === hashPassword(password)) { foundUsername = userKey; break; } }
 if (!foundUsername) return res.status(401).json({ error: "Username/Email atau password salah!" });

 req.session.loggedIn = true; req.session.username = foundUsername;
 res.json({ success: true });
});

app.get('/logout', (req, res) => { req.session.destroy(); res.redirect('/'); });
const checkAuth = (req, res, next) => { 
 res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
 res.header('Expires', '-1');
 res.header('Pragma', 'no-cache');

 if (req.session && req.session.loggedIn && req.session.username) return next(); 
 if (req.path.startsWith('/api/')) return res.status(401).json({ error: 'Sesi berakhir.' }); 
 res.redirect('/'); 
};

const checkAdmin = (req, res, next) => {
 res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
 res.header('Expires', '-1');
 res.header('Pragma', 'no-cache');
 if (req.session && req.session.loggedIn && req.session.username) {
 const users = readUsers();
 if (users[req.session.username] && users[req.session.username].isAdmin) return next();
 }
 if (req.path.startsWith('/api/')) return res.status(403).json({ error: 'Akses ditolak.' });
 res.redirect('/');
};

app.use(express.static('public'));
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public', 'login.html')));
app.get('/dashboard.html', checkAuth, (req, res) => { req.session.currentServer = null; req.session.viewAsUser = null; res.sendFile(path.join(__dirname, 'public', 'dashboard.html')) });
app.get('/panel.html', checkAuth, (req, res) => { if(!req.session.currentServer) return res.redirect('/dashboard.html'); res.sendFile(path.join(__dirname, 'public', 'panel.html')) });
app.get('/admin.html', checkAdmin, (req, res) => res.sendFile(path.join(__dirname, 'public', 'admin.html')));

app.get('/api/admin/system-stats', checkAdmin, (req, res) => {
 const t1 = os.cpus();
 setTimeout(() => {
  const t2 = os.cpus();
  let idle = 0, total = 0;
  for (let i = 0; i < t1.length; i++) {
   const s = Object.values(t1[i].times).reduce((a, b) => a + b, 0);
   const e = Object.values(t2[i].times).reduce((a, b) => a + b, 0);
   idle += t2[i].times.idle - t1[i].times.idle;
   total += e - s;
  }
  const cpuPct = total > 0 ? parseFloat(((1 - idle / total) * 100).toFixed(1)) : 0;
  const ramTotal = os.totalmem();
  const ramUsed = ramTotal - os.freemem();
  function getDirSz(p) { let s = 0; try { fs.readdirSync(p).forEach(f => { const fp = path.join(p, f); const st = fs.statSync(fp); s += st.isDirectory() ? getDirSz(fp) : st.size; }); } catch(e) {} return s; }
  const diskUsed = getDirSz('servers');
  const users = readUsers();
  let totalSrv = 0, onlineSrv = 0;
  for (const u in users) { const srvs = users[u].servers || []; totalSrv += srvs.length; for (const sv of srvs) { if (activeServers[u + '::' + sv] && activeServers[u + '::' + sv].process) onlineSrv++; } }
  res.json({ cpu: cpuPct, ramUsed, ramTotal, diskUsed, totalSrv, onlineSrv, cores: t1.length, uptime: os.uptime() });
 }, 250);
});

app.get('/api/admin/config', checkAdmin, (req, res) => {
 res.json(readConfig());
});

app.post('/api/admin/config', checkAdmin, (req, res) => {
 const cfg = readConfig();
 if (typeof req.body.registrationEnabled === 'boolean') cfg.registrationEnabled = req.body.registrationEnabled;
 saveConfig(cfg);
 res.json({ success: true, config: cfg });
});

app.get('/api/admin/users', checkAdmin, (req, res) => {
 const users = readUsers();
 const result = [];
 for (const username in users) {
 const u = users[username];
 const servers = (u.servers || []).map(srvName => {
 const stateKey = username + '::' + srvName;
 const state = activeServers[stateKey];
 const srvSettings = getUserSettings(srvName, username);
 const isOnline = !!(state && state.startTime);
 return {
  name: srvName,
  owner: username,
  isOnline,
  cpu: isOnline ? parseFloat((state._lastCpu || 0).toFixed(2)) : 0,
  ramMB: isOnline ? Math.round(state._lastRamMB || 0) : 0,
  srvLimits: srvSettings.srvLimits || { ram: u.limits?.ram || 2048, cpu: u.limits?.cpu || 100, disk: u.limits?.disk || 32768 }
 };
 });
 result.push({ username, email: u.email || '', limits: u.limits || { ram: 2048, cpu: 100, disk: 5120 }, servers, balance: u.balance || 0, freePackageUsed: u.freePackageUsed || false });
 }
 res.json(result);
});

app.post('/api/admin/view-server', checkAdmin, (req, res) => {
 const { serverName, ownerUsername } = req.body;
 if (!serverName || !ownerUsername) return res.status(400).json({ error: 'serverName dan ownerUsername wajib diisi' });
 req.session.currentServer = serverName;
 req.session.viewAsUser = ownerUsername;
 res.json({ success: true });
});

app.post('/api/admin/start-server', checkAdmin, (req, res) => {
 const { serverName, ownerUsername } = req.body;
 if (!serverName) return res.status(400).json({ error: 'Nama server tidak valid.' });
 const owner = ownerUsername || getOwner(serverName) || serverName;
 const state = getUserState(serverName, owner);
 if (state.process || state.isStarting) return res.status(400).json({ error: 'Server sudah berjalan.' });
 globalSpawn(serverName, owner);
 res.json({ success: true });
});

app.post('/api/admin/restart-server', checkAdmin, (req, res) => {
 const { serverName, ownerUsername } = req.body;
 if (!serverName) return res.status(400).json({ error: 'Nama server tidak valid.' });
 const owner = ownerUsername || getOwner(serverName) || serverName;
 const stateKey = owner + '::' + serverName;
 const state = activeServers[stateKey];
 if (!state || !state.process) return res.status(400).json({ error: 'Server tidak berjalan.' });
 try {
 state.isRestarting = true;
 const settings = getUserSettings(serverName, owner);
 if (settings.engine === 'node' || settings.engine === 'python') {
 try { state.process.kill('SIGTERM'); } catch(e) {}
 } else {
 try { state.process.stdin.write('stop\n'); } catch(e) {}
 }
 if (state._restartKillTimer) clearTimeout(state._restartKillTimer);
 state._restartKillTimer = setTimeout(() => {
 if (state.process && state.isRestarting) {
 try { state.process.kill('SIGTERM'); } catch(e) {}
 setTimeout(() => { if (state.process && state.isRestarting) { try { state.process.kill('SIGKILL'); } catch(e) {} } }, 5000);
 }
 }, 45000);
 res.json({ success: true });
 } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/admin/stop-server', checkAdmin, (req, res) => {
 const { serverName, force, ownerUsername } = req.body;
 const owner = ownerUsername || getOwner(serverName) || serverName;
 const stateKey = owner + '::' + serverName;
 const state = activeServers[stateKey];
 if (!state || !state.process) return res.status(400).json({ error: 'Server tidak berjalan.' });
 try {
 state.process.kill(force ? 'SIGKILL' : 'SIGTERM');
 res.json({ success: true });
 } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/admin/delete-user', checkAdmin, (req, res) => {
 const { username } = req.body;
 if (!username) return res.status(400).json({ error: 'Tidak valid.' });
 const users2 = readUsers();
 if (users2[username] && users2[username].isAdmin) return res.status(400).json({ error: 'Tidak bisa menghapus admin.' });
 let users = readUsers();
 if (!users[username]) return res.status(404).json({ error: 'User tidak ditemukan.' });
 (users[username].servers || []).forEach(srvName => {
 const _key = username + '::' + srvName;
 const state = activeServers[_key];
 if (state && state.process) { try { state.process.kill('SIGKILL'); } catch(e){} delete activeServers[_key]; }
 });
 const userDirPath = path.join(baseServersDir, username);
 if (fs.existsSync(userDirPath)) { try { fs.rmSync(userDirPath, { recursive: true, force: true }); } catch(e){} }
 delete users[username];
 fs.writeFileSync(usersFile, JSON.stringify(users));
 res.json({ success: true });
});

app.post('/api/admin/update-limits', checkAdmin, (req, res) => {
 const { username, ram, cpu, disk } = req.body;
 if (!username) return res.status(400).json({ error: 'Tidak valid.' });
 let users = readUsers();
 if (!users[username]) return res.status(404).json({ error: 'User tidak ditemukan.' });
 if (!users[username].limits) users[username].limits = {};
 if (ram) {
 const ramMB = parseInt(ram);
 users[username].limits.ram = ramMB;
 const ramStr = ramMB % 1024 === 0 ? `${ramMB / 1024}G` : `${ramMB}M`;
 const userServers = users[username].servers || [];
 userServers.forEach(srvName => {
 const srvSettingsFile = path.join(baseServersDir, username, srvName, 'panel_settings.json');
 if (fs.existsSync(srvSettingsFile)) {
 try {
 const srvSettings = JSON.parse(fs.readFileSync(srvSettingsFile, 'utf8'));
 srvSettings.ram = ramStr;
 if (!srvSettings.srvLimits) srvSettings.srvLimits = {};
 srvSettings.srvLimits.ram = ramMB;
 fs.writeFileSync(srvSettingsFile, JSON.stringify(srvSettings));
 } catch(e) {}
 }
 });
 }
 if (cpu) users[username].limits.cpu = parseInt(cpu);
 if (disk) users[username].limits.disk = parseInt(disk);
 fs.writeFileSync(usersFile, JSON.stringify(users));
 res.json({ success: true });
});

app.post('/api/admin/update-server-limits', checkAdmin, (req, res) => {
 const { serverName, ram, cpu, disk } = req.body;
 if (!serverName) return res.status(400).json({ error: 'Nama server wajib diisi.' });
 const settingsFile = path.join(getUserDir(serverName), 'panel_settings.json');
 const settings = getUserSettings(serverName);
 if (!settings.srvLimits) settings.srvLimits = {};
 if (ram) { settings.srvLimits.ram = parseInt(ram); const ramStr = parseInt(ram) % 1024 === 0 ? `${parseInt(ram)/1024}G` : `${parseInt(ram)}M`; settings.ram = ramStr; }
 if (cpu) settings.srvLimits.cpu = parseInt(cpu);
 if (disk) settings.srvLimits.disk = parseInt(disk);
 fs.writeFileSync(settingsFile, JSON.stringify(settings));
 res.json({ success: true });
});

app.post('/api/admin/reset-password', checkAdmin, (req, res) => {
 const { username, newPassword } = req.body;
 if (!username) return res.status(400).json({ error: 'Tidak valid.' });
 if (!newPassword || newPassword.length < 6) return res.status(400).json({ error: 'Password minimal 6 karakter.' });
 let users = readUsers();
 if (!users[username]) return res.status(404).json({ error: 'User tidak ditemukan.' });
 users[username].password = hashPassword(newPassword);
 users[username].passwordPlain = newPassword;
 fs.writeFileSync(usersFile, JSON.stringify(users));
 res.json({ success: true });
});

app.post('/api/admin/view-password', checkAdmin, (req, res) => {
 const { username } = req.body;
 if (!username) return res.status(400).json({ error: 'Tidak valid.' });
 const users = readUsers();
 if (!users[username]) return res.status(404).json({ error: 'User tidak ditemukan.' });
 res.json({ passwordPlain: users[username].passwordPlain || null });
});

app.post('/api/admin/copy-server', checkAdmin, (req, res) => {
 const { sourceServer, targetUser, newServerName } = req.body;
 if (!sourceServer || !targetUser || !newServerName) return res.status(400).json({ error: 'Data tidak lengkap.' });
 if (!/^[a-zA-Z0-9_-]+$/.test(newServerName)) return res.status(400).json({ error: 'Nama server hanya boleh huruf, angka, _ dan -' });
 const users = readUsers();
 if (!users[targetUser]) return res.status(404).json({ error: 'Target user tidak ditemukan.' });
 if (getOwner(newServerName)) return res.status(400).json({ error: `Nama server "${newServerName}" sudah digunakan.` });
 const srcDir = getUserDir(sourceServer);
 if (!fs.existsSync(srcDir)) return res.status(404).json({ error: 'Server asal tidak ditemukan.' });
 const destDir = path.join(baseServersDir, targetUser, newServerName);
 if (fs.existsSync(destDir)) return res.status(400).json({ error: 'Folder server sudah ada.' });
 try {
 fs.cpSync(srcDir, destDir, { recursive: true });
 const destSettingsFile = path.join(destDir, 'panel_settings.json');
 let newSettings = {};
 if (fs.existsSync(destSettingsFile)) { try { newSettings = JSON.parse(fs.readFileSync(destSettingsFile, 'utf8')); } catch(e){} }
 newSettings.port = generateRandomPort();
 fs.writeFileSync(destSettingsFile, JSON.stringify(newSettings));
 if (!users[targetUser].servers) users[targetUser].servers = [];
 users[targetUser].servers.push(newServerName);
 fs.writeFileSync(usersFile, JSON.stringify(users));
 res.json({ success: true });
 } catch(e) { res.status(500).json({ error: `Gagal menyalin: ${e.message}` }); }
});

app.post('/api/admin/delete-server', checkAdmin, (req, res) => {
  const { serverName } = req.body;
  if (!serverName) return res.status(400).json({ error: 'Nama server wajib diisi.' });
  const users = readUsers();
  const owner = getOwner(serverName);
  if (!owner) return res.status(404).json({ error: 'Server tidak ditemukan.' });
  const _adminDelKey = owner + '::' + serverName;
  const state = activeServers[_adminDelKey];
  if (state && state.process) { try { state.process.kill('SIGKILL'); } catch(e){} delete activeServers[_adminDelKey]; }
  const dirPath = getUserDir(serverName);
  if (fs.existsSync(dirPath)) { try { fs.rmSync(dirPath, { recursive: true, force: true }); } catch(e){} }
  users[owner].servers = (users[owner].servers || []).filter(s => s !== serverName);
  fs.writeFileSync(usersFile, JSON.stringify(users));
  res.json({ success: true });
});

app.post('/api/admin/update-server-network', checkAdmin, (req, res) => {
  const { serverName, ip, port } = req.body;
  if (!serverName) return res.status(400).json({ error: 'Nama server wajib diisi.' });
  const settingsFile = path.join(getUserDir(serverName), 'panel_settings.json');
  const settings = getUserSettings(serverName);
  if (ip !== undefined && ip.trim()) settings.ip = ip.trim();
  if (port !== undefined && String(port).trim()) {
    const p = parseInt(port);
    if (isNaN(p) || p < 1 || p > 65535) return res.status(400).json({ error: 'Port tidak valid (1-65535).' });
    settings.port = String(p);
  }
  fs.writeFileSync(settingsFile, JSON.stringify(settings));
  res.json({ success: true });
});

app.get('/api/admin/server-settings/:serverName', checkAdmin, (req, res) => {
  const { serverName } = req.params;
  const settings = getUserSettings(serverName);
  res.json({
    ip: settings.ip || '127.0.0.1',
    port: settings.port || '',
    engine: settings.engine || 'java',
    ram: settings.ram || '2G',
    jarFile: settings.jarFile || '',
    javaVersion: settings.javaVersion || '',
    autoStart: settings.autoStart !== undefined ? settings.autoStart : true,
    srvLimits: settings.srvLimits || { ram: 2048, cpu: 100, disk: 5120 }
  });
});

app.post('/api/reset-password', (req, res) => {
 const { username, email, newPassword } = req.body;
 if (!username || !email || !newPassword) return res.status(400).json({ error: 'Data tidak lengkap.' });
 if (newPassword.length < 6) return res.status(400).json({ error: 'Password minimal 6 karakter.' });
 const users = readUsers();
 const user = users[username];
 if (!user || user.email !== email) return res.status(400).json({ error: 'Username atau email tidak cocok.' });
 users[username].password = hashPassword(newPassword);
 users[username].passwordPlain = newPassword;
 fs.writeFileSync(usersFile, JSON.stringify(users));
 res.json({ success: true, message: 'Password berhasil direset! Silakan login.' });
});

app.post('/api/delete-account', checkAuth, (req, res) => {
 const username = req.session.username; 
 let users = readUsers();
 
 if (!users[username]) return res.status(400).json({ error: "Akun tidak ditemukan." });

 if (users[username].servers && Array.isArray(users[username].servers)) {
 users[username].servers.forEach(serverName => {
 const _key = username + '::' + serverName;
 const state = activeServers[_key];
 if (state && state.process) { 
 try { state.process.kill('SIGKILL'); } catch (e) {} 
 delete activeServers[_key]; 
 }
 });
 }

 const userDirPath = path.join(baseServersDir, username);
 if (fs.existsSync(userDirPath)) { 
 try { fs.rmSync(userDirPath, { recursive: true, force: true }); } catch (e) {} 
 }

 delete users[username];
 fs.writeFileSync(usersFile, JSON.stringify(users));
 
 req.session.destroy();
 res.json({ success: true });
});

app.post('/api/change-password', checkAuth, (req, res) => {
 const { oldPassword, newPassword } = req.body;
 if (!oldPassword || !newPassword) return res.status(400).json({ error: 'Data tidak lengkap.' });
 if (newPassword.length < 6) return res.status(400).json({ error: 'Password baru minimal 6 karakter.' });
 let users = readUsers();
 const username = req.session.username;
 if (!users[username]) return res.status(404).json({ error: 'User tidak ditemukan.' });
 if (users[username].password !== hashPassword(oldPassword)) return res.status(400).json({ error: 'Password lama salah.' });
 users[username].password = hashPassword(newPassword);
 users[username].passwordPlain = newPassword;
 fs.writeFileSync(usersFile, JSON.stringify(users));
 res.json({ success: true });
});

app.post('/api/delete-current-server', checkAuth, (req, res) => {
 const username = req.session.username;
 const serverName = req.session.currentServer;
 if (!serverName) return res.status(400).json({ error: 'Tidak ada server yang dipilih.' });
 let users = readUsers();
 if (!users[username]) return res.status(404).json({ error: 'User tidak ditemukan.' });
 const _curDelKey = username + '::' + serverName;
 const state = activeServers[_curDelKey];
 if (state && state.process) {
  try { state.process.kill('SIGKILL'); } catch(e) {}
  delete activeServers[_curDelKey];
 }
 const srvDir = path.join(baseServersDir, username, serverName);
 if (fs.existsSync(srvDir)) { try { fs.rmSync(srvDir, { recursive: true, force: true }); } catch(e) {} }
 users[username].servers = (users[username].servers || []).filter(s => s !== serverName);
 fs.writeFileSync(usersFile, JSON.stringify(users));
 req.session.currentServer = null;
 res.json({ success: true });
});

app.get('/api/servers-list', checkAuth, (req, res) => {
 const username = req.session.username; let users = readUsers();
 if (!users[username]) return res.json([]);
 if (!users[username].servers) { users[username].servers = [username]; fs.writeFileSync(usersFile, JSON.stringify(users)); }
 const servers = users[username].servers; let results = [];

 servers.forEach(srv => {
 const state = getUserState(srv, username); const mcDir = getUserDir(srv, username);
 function getDirSizeSync(dirPath) { let size = 0; try { const files = fs.readdirSync(dirPath); files.forEach(file => { const fullPath = path.join(dirPath, file); const stats = fs.statSync(fullPath); if (stats.isDirectory()) size += getDirSizeSync(fullPath); else size += stats.size; }); } catch (e) {} return size; }
 const srvSettings = getUserSettings(srv, username);
 const srvLimits = srvSettings.srvLimits || users[username]?.limits || { ram: 2048, cpu: 100, disk: 5120 };
 results.push({ name: srv, isOnline: state.startTime !== null, diskUsed: getDirSizeSync(mcDir), srvLimits });
 });
 res.json(results);
});

app.post('/api/delete-server', checkAuth, (req, res) => {
 const { serverName } = req.body; const username = req.session.username; let users = readUsers();
 if (!users[username] || !users[username].servers || !users[username].servers.includes(serverName)) return res.status(403).json({ error: "Akses ditolak / Server tidak ditemukan." });
 const _delKey = username + '::' + serverName;
 const state = activeServers[_delKey];
 if (state && state.process) { try { state.process.kill('SIGKILL'); } catch (e) {} delete activeServers[_delKey]; }
 
 const dirPath = getUserDir(serverName);
 if (fs.existsSync(dirPath)) { try { fs.rmSync(dirPath, { recursive: true, force: true }); } catch (e) { } }
 
 users[username].servers = users[username].servers.filter(s => s !== serverName); fs.writeFileSync(usersFile, JSON.stringify(users));
 res.json({ success: true });
});

app.post('/api/create-server', checkAuth, (req, res) => {
 const { serverName } = req.body;
 if (!serverName || !/^[a-zA-Z0-9_-]+$/.test(serverName)) return res.status(400).json({error: "Nama hanya boleh huruf, angka, strip, dan underscore."});
 let users = readUsers(); const username = req.session.username;
 if (!users[username]) return res.status(403).json({ error: 'Akun tidak ditemukan.' });
 if (!users[username].servers) users[username].servers = [];
 if (users[username].servers.includes(serverName)) return res.status(400).json({error: "Kamu sudah punya server dengan nama ini, coba nama lain!"});
 users[username].servers.push(serverName); fs.writeFileSync(usersFile, JSON.stringify(users));
 getUserDir(serverName, username); getUserSettings(serverName); 
 res.json({success: true});
});

app.post('/api/select-server', checkAuth, (req, res) => { req.session.currentServer = req.body.serverName; res.json({success: true}); });
app.get('/api/whoami', checkAuth, (req, res) => { const users = readUsers(); const u = users[req.session.username]; res.json({ username: req.session.username, email: u?.email || '', isAdmin: !!(u && u.isAdmin) }); });

app.get('/api/settings', checkAuth, (req, res) => { res.json(getUserSettings(getServerName(req), req.session.username)); });

app.post('/api/settings', checkAuth, (req, res) => { const srv = getServerName(req); const u = req.session.username; const settings = getUserSettings(srv, u); if (req.body.ram) settings.ram = req.body.ram.trim(); if (req.body.jarFile) settings.jarFile = req.body.jarFile.trim(); if (req.body.ip !== undefined) settings.ip = req.body.ip.trim(); if (req.body.port) settings.port = String(req.body.port).trim(); if (req.body.engine) settings.engine = String(req.body.engine).trim(); if (req.body.autoStart !== undefined) settings.autoStart = Boolean(req.body.autoStart); if (req.body.javaVersion !== undefined) settings.javaVersion = String(req.body.javaVersion).trim(); if (req.body.useCustomStartup !== undefined) settings.useCustomStartup = Boolean(req.body.useCustomStartup); if (req.body.customStartupCmd !== undefined) settings.customStartupCmd = String(req.body.customStartupCmd); fs.writeFileSync(path.join(getUserDir(srv, u), 'panel_settings.json'), JSON.stringify(settings)); res.send('Pengaturan disimpan'); });
app.get('/api/dashboard-stats', checkAuth, (req, res) => { const srv = getServerName(req); const username = req.session.username; const users = readUsers(); const userLimits = users[username]?.limits || { ram: 2048, cpu: 100, disk: 51200 }; const mcDir = getUserDir(srv, username); const state = getUserState(srv, username); function getDirSizeSync(dirPath) { let size = 0; try { const files = fs.readdirSync(dirPath); files.forEach(file => { const fullPath = path.join(dirPath, file); const stats = fs.statSync(fullPath); if (stats.isDirectory()) size += getDirSizeSync(fullPath); else size += stats.size; }); } catch (e) {} return size; } let diskBytes = getDirSizeSync(mcDir); if (state.process) { pidusage(state.process.pid, (err, stats) => { if (!err && stats) { res.json({ name: srv, cpu: stats.cpu.toFixed(2), ramUsed: stats.memory, ramTotal: userLimits.ram * 1024 * 1024, diskUsed: diskBytes, diskTotal: userLimits.disk * 1024 * 1024 }); } else { res.json({ name: srv, cpu: "0.00", ramUsed: 0, ramTotal: userLimits.ram * 1024 * 1024, diskUsed: diskBytes, diskTotal: userLimits.disk * 1024 * 1024 }); } }); } else { res.json({ name: srv, cpu: "0.00", ramUsed: 0, ramTotal: userLimits.ram * 1024 * 1024, diskUsed: diskBytes, diskTotal: userLimits.disk * 1024 * 1024 }); } });
function getRawDate(filePath) { try { if (!fs.existsSync(filePath)) return null; return fs.statSync(filePath).mtime.toISOString(); } catch (e) { return null; } }
function formatBytes(bytes) { if (!+bytes) return '0 B'; const k = 1024, sizes = ['B', 'KB', 'MB', 'GB', 'TB'], i = Math.floor(Math.log(bytes) / Math.log(k)); return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`; }

app.get('/api/files', checkAuth, (req, res) => { try { const mcDir = getUserDir(getServerName(req), req.session.username); let subPath = req.query.path || ''; if (subPath.includes('..')) return res.status(403).json({ error: 'Akses ditolak!' }); let targetDir = path.join(mcDir, subPath); if (!fs.existsSync(targetDir)) targetDir = mcDir; const files = fs.readdirSync(targetDir, { withFileTypes: true }); let fileList = files.filter(dirent => !(subPath === '' && dirent.name === 'panel_settings.json') && dirent.name !== '.plugin_meta.json').map(dirent => { const currentFilePath = path.join(targetDir, dirent.name); let size = ''; if (!dirent.isDirectory()) { try { size = formatBytes(fs.statSync(currentFilePath).size); } catch(e){} } return { name: dirent.name, isDirectory: dirent.isDirectory(), path: subPath === '' ? dirent.name : `${subPath}/${dirent.name}`, date: getRawDate(currentFilePath), size: size }; }); fileList.sort((a, b) => (a.isDirectory === b.isDirectory) ? a.name.localeCompare(b.name) : (a.isDirectory ? -1 : 1)); res.json(fileList); } catch (e) { res.status(500).json({ error: e.message }); } });
app.get('/api/file', checkAuth, (req, res) => { let subPath = req.query.path || ''; if (subPath.includes('..')) return res.status(403).send("Akses ditolak!"); fs.readFile(path.join(getUserDir(getServerName(req), req.session.username), subPath), 'utf8', (err, data) => res.send(err ? "Gagal membaca file" : data)); });

// FITUR DOWNLOAD FILE AMAN (DITAMBAHKAN DI SINI) 
app.get('/api/download', checkAuth, (req, res) => {
 let subPath = req.query.path || '';
 if (subPath.includes('..')) return res.status(403).send("Akses ditolak!");
 
 const fileTarget = path.join(getUserDir(getServerName(req), req.session.username), subPath);
 if (!fs.existsSync(fileTarget)) return res.status(404).send("File tidak ditemukan!");
 
 res.download(fileTarget);
});

app.post('/api/file', checkAuth, (req, res) => { let subPath = req.body.path || ''; if (subPath.includes('..')) return res.status(403).send("Akses ditolak!"); fs.writeFile(path.join(getUserDir(getServerName(req), req.session.username), subPath), req.body.content, (err) => res.send(err ? "Gagal menyimpan" : "Tersimpan")); });
app.post('/api/folder', checkAuth, (req, res) => { let subPath = req.body.path || ''; if (subPath.includes('..')) return res.status(403).send("Akses ditolak!"); try { fs.mkdirSync(path.join(getUserDir(getServerName(req), req.session.username), subPath), { recursive: true }); res.send("OK"); } catch(e) { res.status(500).send("Err"); } });

// === ðŸ”¥ SISTEM UPLOAD MANUAL (SOCKET.IO TRACKER) ðŸ”¥ ===
const tempUploadsDir = path.join(__dirname, 'tmp_uploads'); 
if (!fs.existsSync(tempUploadsDir)) fs.mkdirSync(tempUploadsDir, { recursive: true });
try { fs.readdirSync(tempUploadsDir).forEach(f => fs.unlinkSync(path.join(tempUploadsDir, f))); } catch(e){}

const diskStorage = multer.diskStorage({
 destination: function (req, file, cb) { cb(null, tempUploadsDir); },
 filename: function (req, file, cb) {
 const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
 cb(null, uniqueSuffix + '.tmp');
 }
});

const upload = multer({ storage: diskStorage });

app.post('/api/upload', checkAuth, (req, res, next) => {
 const srv = getServerName(req);
 const uploadId = req.query.uploadId;
 let loadedBytes = 0;
 
 if (uploadId) {
 req.on('data', (chunk) => {
 loadedBytes += chunk.length;
 io.to('panel_' + req.session.username + '::' + srv).emit('manual_upload_progress', { uploadId: uploadId, loaded: loadedBytes });
 });
 }
 next();
}, upload.single('file'), (req, res) => {
 const srv = getServerName(req);
 const username = req.session.username;
 const subPath = req.body.path || '';
 const originalName = req.body.filename;

 if (!req.file || !originalName) return res.status(400).send("Data tidak lengkap");
 if ((subPath || '').includes('..') || originalName.includes('..')) {
 if (fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
 return res.status(403).send("Akses ditolak!");
 }

 const targetDir = path.join(getUserDir(srv, username), subPath);
 if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir, { recursive: true });
 const finalFilePath = path.join(targetDir, originalName);

 try {
 fs.renameSync(req.file.path, finalFilePath);
 res.send('Selesai');
 } catch (err) {
 if (fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
 res.status(500).send("Error memindahkan file.");
 }
});

// === ðŸ”¥ SISTEM REMOTE DOWNLOAD (BYPASS GDRIVE) ðŸ”¥ ===
function fetchWithRedirects(urlStr, cookies = '', depth = 0) {
 return new Promise((resolve) => {
  if (depth > 10) return resolve({ body: '', cookies, finalUrl: urlStr });
  let parsedUrl;
  try { parsedUrl = new URL(urlStr); } catch(e) { return resolve({ body: '', cookies, finalUrl: urlStr }); }
  const options = {
   hostname: parsedUrl.hostname,
   path: parsedUrl.pathname + parsedUrl.search,
   headers: {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
    'Cookie': cookies,
    'Accept': 'text/html,application/xhtml+xml,*/*'
   }
  };
  https.get(options, (res) => {
   const newCookieStr = (res.headers['set-cookie'] || []).map(c => c.split(';')[0]).join('; ');
   const combinedCookies = [cookies, newCookieStr].filter(Boolean).join('; ');
   if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
    let nextUrl = res.headers.location;
    if (!nextUrl.startsWith('http')) nextUrl = `https://${parsedUrl.hostname}${nextUrl}`;
    resolve(fetchWithRedirects(nextUrl, combinedCookies, depth + 1));
   } else {
    let body = '';
    res.on('data', chunk => body += chunk);
    res.on('end', () => resolve({ body, cookies: combinedCookies, finalUrl: urlStr }));
   }
  }).on('error', () => resolve({ body: '', cookies, finalUrl: urlStr }));
 });
}

async function getDriveDownloadInfo(fileId) {
 const directUrl = `https://drive.usercontent.google.com/download?id=${fileId}&export=download&confirm=t`;
 const { body, cookies, finalUrl } = await fetchWithRedirects(directUrl);

 if (body && body.includes('<form') && body.includes('download')) {
  const actionMatch = body.match(/action="([^"]+)"/);
  const confirmMatch = body.match(/name="confirm"[^>]*value="([^"]+)"/);
  const uuidMatch = body.match(/name="uuid"[^>]*value="([^"]+)"/);
  const atMatch = body.match(/name="at"[^>]*value="([^"]+)"/);

  let action = actionMatch ? actionMatch[1].replace(/&amp;/g, '&') : `https://drive.usercontent.google.com/download`;
  if (action.startsWith('/')) action = `https://drive.usercontent.google.com${action}`;

  const confirm = confirmMatch ? confirmMatch[1] : 't';
  const uuidStr = uuidMatch ? `&uuid=${uuidMatch[1]}` : '';
  const atStr = atMatch ? `&at=${atMatch[1]}` : '';

  return { url: `${action}?id=${fileId}&export=download&confirm=${confirm}${uuidStr}${atStr}`, cookie: cookies };
 }

 return { url: finalUrl || directUrl, cookie: cookies };
}

app.post('/api/remote-download', checkAuth, async (req, res) => {
 const srv = getServerName(req);
 const username = req.session.username;
 const { url, filename, path: subPath } = req.body;
 
 if (!url || !filename) return res.status(400).send("Data tidak lengkap");
 if (filename.includes('..') || (subPath || '').includes('..')) return res.status(403).send("Akses ditolak");

 const targetDir = path.join(getUserDir(srv, username), subPath || '');
 if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir, { recursive: true });

 let finalUrl = url;
 let targetFilePath = path.join(targetDir, filename);

 const gdrivePatterns = [
  /drive\.google\.com\/file\/d\/([-\w]{25,})/i,
  /drive\.google\.com\/open\?.*id=([-\w]{25,})/i,
  /drive\.google\.com\/uc\?.*id=([-\w]{25,})/i,
  /drive\.google\.com\/.*[?&]id=([-\w]{25,})/i,
  /docs\.google\.com\/.*\/d\/([-\w]{25,})/i,
 ];
 let fileId = null;
 for (const re of gdrivePatterns) { const m = url.match(re); if (m) { fileId = m[1]; break; } }

 if (fileId) {
  finalUrl = `https://drive.usercontent.google.com/download?id=${fileId}&export=download&confirm=t`;
 }

 const curlArgs = [
  '-L', '--max-redirs', '10',
  '--max-time', '3600',
  '--connect-timeout', '30',
  '-H', 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
  '-o', filename,
  finalUrl
 ];

 res.json({ success: true });

 const dlProcess = spawn('curl', curlArgs, { cwd: targetDir });
 let isDone = false;

 const monitor = setInterval(() => {
 if (isDone) {
 clearInterval(monitor);
 return;
 }
 if (fs.existsSync(targetFilePath)) {
 try {
 const stats = fs.statSync(targetFilePath);
 io.to('panel_' + username + '::' + srv).emit('remote_dl_progress', { filename: filename, loaded: stats.size });
 } catch(e) {}
 }
 }, 500);
 
 dlProcess.on('close', (code) => {
 isDone = true;
 clearInterval(monitor);
 if (code === 0) {
 io.to('panel_' + username + '::' + srv).emit('remote_dl_done', filename);
 } else {
 io.to('panel_' + username + '::' + srv).emit('remote_dl_error', { filename: filename, code: code });
 }
 });
});
// ====================================================

app.post('/api/delete', checkAuth, (req, res) => { const mcDir = getUserDir(getServerName(req), req.session.username); const { items } = req.body; if (!items || !Array.isArray(items)) return res.status(400).send('Data tidak valid'); items.forEach(itemPath => { if (itemPath.includes('..')) return; const fullPath = path.join(mcDir, itemPath); if (fs.existsSync(fullPath)) { try { fs.rmSync(fullPath, { recursive: true, force: true }); } catch (err) {} } }); res.send('Berhasil dihapus'); });
app.post('/api/rename', checkAuth, (req, res) => { const mcDir = getUserDir(getServerName(req), req.session.username); const { oldPath, newName } = req.body; if (!oldPath || !newName || oldPath.includes('..') || newName.includes('..') || newName.includes('/')) return res.status(400).send("Format tidak valid"); const fullOldPath = path.join(mcDir, oldPath); const fullNewPath = path.join(path.dirname(fullOldPath), newName); if (!fs.existsSync(fullOldPath)) return res.status(404).send("File tidak ditemukan"); if (fs.existsSync(fullNewPath)) return res.status(400).send("Nama sudah digunakan"); try { fs.renameSync(fullOldPath, fullNewPath); res.send("Berhasil diubah"); } catch (err) { res.status(500).send("Gagal mengubah nama"); } });
app.post('/api/extract', checkAuth, (req, res) => { const mcDir = getUserDir(getServerName(req), req.session.username); const { filePath, destination } = req.body; if (!filePath || filePath.includes('..')) return res.status(403).send("Akses ditolak!"); const fullPath = path.join(mcDir, filePath); const destPath = path.join(mcDir, destination || path.dirname(filePath)); if (!fs.existsSync(fullPath)) return res.status(404).send("File tidak ditemukan"); let cmd = ''; if (filePath.endsWith('.zip')) cmd = `unzip -o "${fullPath}" -d "${destPath}"`; else if (filePath.endsWith('.tar.gz') || filePath.endsWith('.tgz')) cmd = `tar -xzf "${fullPath}" -C "${destPath}"`; else return res.status(400).send("Format didukung. Gunakan .zip atau .tar.gz"); exec(cmd, (err, stdout, stderr) => { if (err) return res.status(500).send("Gagal mengekstrak: " + stderr); res.send("Berhasil diekstrak"); }); });
app.post('/api/archive', checkAuth, (req, res) => { const mcDir = getUserDir(getServerName(req), req.session.username); const { items, archiveName, currentPath } = req.body; if (!items || !Array.isArray(items) || !archiveName || archiveName.includes('..')) return res.status(400).send("Data tidak valid"); const targetDir = path.join(mcDir, currentPath || ''); const finalName = archiveName.endsWith('.tar.gz') ? archiveName : archiveName + '.tar.gz'; const archivePath = path.join(targetDir, finalName); const safeItems = items.filter(item => !item.includes('..')).map(item => `"${path.basename(item)}"`).join(' '); if (!safeItems) return res.status(400).send("Tidak ada item yang valid"); const cmd = `cd "${targetDir}" && tar -czf "${archivePath}" ${safeItems}`; exec(cmd, (err, stdout, stderr) => { if (err) return res.status(500).send("Gagal membuat arsip: " + stderr); res.send("Berhasil diarsipkan"); }); });
app.post('/api/move', checkAuth, (req, res) => { const mcDir = getUserDir(getServerName(req), req.session.username); const { items, destination } = req.body; if (!items || !Array.isArray(items) || destination.includes('..')) return res.status(400).send("Data tidak valid"); const destPath = path.join(mcDir, destination); if (!fs.existsSync(destPath)) fs.mkdirSync(destPath, { recursive: true }); let errors = 0; items.forEach(itemPath => { if (itemPath.includes('..')) return; const fullPath = path.join(mcDir, itemPath); const newFullPath = path.join(destPath, path.basename(itemPath)); if (fs.existsSync(fullPath)) { try { fs.renameSync(fullPath, newFullPath); } catch (err) { errors++; } } }); if (errors > 0) return res.status(500).send(`Selesai tapi ada ${errors} file yang error dipindah`); res.send("Berhasil dipindahkan"); });

app.get('/api/plugin-meta', checkAuth, (req, res) => {
  const metaPath = path.join(getUserDir(getServerName(req), req.session.username), 'plugins', '.plugin_meta.json');
  try { res.json(fs.existsSync(metaPath) ? JSON.parse(fs.readFileSync(metaPath, 'utf8')) : {}); } catch(e) { res.json({}); }
});
app.post('/api/plugin-meta', checkAuth, (req, res) => {
  const pluginsDir = path.join(getUserDir(getServerName(req), req.session.username), 'plugins');
  const metaPath = path.join(pluginsDir, '.plugin_meta.json');
  try {
    let data = {};
    if (fs.existsSync(metaPath)) { try { data = JSON.parse(fs.readFileSync(metaPath, 'utf8')); } catch(e) {} }
    const { filename, meta, rename } = req.body;
    if (rename && rename.from && rename.to) { if (data[rename.from]) { data[rename.to] = data[rename.from]; delete data[rename.from]; } }
    else if (filename) { if (meta == null) { delete data[filename]; } else { data[filename] = meta; } }
    if (!fs.existsSync(pluginsDir)) fs.mkdirSync(pluginsDir, { recursive: true });
    fs.writeFileSync(metaPath, JSON.stringify(data, null, 2));
    res.json({ ok: true });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

function readNetStats() {
 try {
 const data = fs.readFileSync('/proc/net/dev', 'utf8');
 let rx = 0, tx = 0;
 const lines = data.split('\n').slice(2);
 for (const line of lines) {
 const parts = line.trim().split(/\s+/);
 if (parts.length < 10) continue;
 const iface = parts[0].replace(':', '');
 if (iface === 'lo' || iface === '') continue;
 rx += parseInt(parts[1]) || 0;
 tx += parseInt(parts[9]) || 0;
 }
 return { rx, tx, time: Date.now() };
 } catch(e) { return { rx: 0, tx: 0, time: Date.now() }; }
}

let prevNetStats = readNetStats();

function getDirSizeGlobal(dirPath) {
 let size = 0;
 try {
 const files = fs.readdirSync(dirPath);
 files.forEach(file => {
 const fullPath = path.join(dirPath, file);
 try {
 const stats = fs.statSync(fullPath);
 if (stats.isDirectory()) size += getDirSizeGlobal(fullPath);
 else size += stats.size;
 } catch(e) {}
 });
 } catch(e) {}
 return size;
}

function parseRamMB(ramStr) {
 const s = String(ramStr || '2048M').trim().toUpperCase();
 if (s.endsWith('G')) return Math.round(parseFloat(s) * 1024);
 if (s.endsWith('M')) return Math.round(parseFloat(s));
 return parseInt(s) || 2048;
}

function capRam(ramStr, limitMB) {
 const mb = Math.min(parseRamMB(ramStr), limitMB || 2048);
 return (mb % 1024 === 0 && mb >= 1024) ? `${mb / 1024}G` : `${mb}M`;
}


function startResourceMonitor(srvName, state, uLog) {
 const settings = getUserSettings(srvName);
 const limits = settings.srvLimits || (() => { const ownerName = getOwner(srvName) || srvName; const u = readUsers()[ownerName]; return (u && u.limits) ? u.limits : { ram: 6144, cpu: 1000, disk: 32768 }; })();

 const CPU_LIMIT = limits.cpu || 100;
 const RAM_LIMIT_BYTES = (limits.ram || 2048) * 1024 * 1024;
 const DISK_LIMIT_BYTES = (limits.disk || 5120) * 1024 * 1024;
 const CPU_INTERVAL = 250;

 let active = true;
 let isStopped = false;

 const stopAll = () => {
 active = false;
 clearInterval(diskInterval);
 if (isStopped) {
 try { if (state.process) state.process.kill('SIGCONT'); } catch(e) {}
 isStopped = false;
 }
 };

 // CPU throttle loop menggunakan SIGSTOP/SIGCONT (seperti cpulimit)
 const cpuLoop = () => {
 if (!active || !state.process) return;
 const pid = state.process.pid;
 if (!pid) { if (active) setTimeout(cpuLoop, CPU_INTERVAL); return; }

 pidusage(pid, (err, stats) => {
 if (!active || !state.process) return;
 if (err || !stats) { if (active) setTimeout(cpuLoop, CPU_INTERVAL); return; }

 // RAM: jika melebihi batas, matikan server
 if (stats.memory > RAM_LIMIT_BYTES * 1.1) {
 uLog(`\x1b[31m [Resource Limit] RAM melebihi batas (${(stats.memory/1024/1024).toFixed(0)}MB > ${limits.ram}MB). Server dimatikan!\x1b[0m\n`);
 try { state.process.kill('SIGKILL'); } catch(e) {}
 state.isStarting = false;
 stopAll();
 return;
 }

 // CPU: throttle dengan SIGSTOP/SIGCONT
 const cpuNow = stats.cpu;
 if (cpuNow > CPU_LIMIT * 1.05) {
 const throttleRatio = (cpuNow - CPU_LIMIT) / cpuNow;
 const pauseMs = Math.max(10, Math.min(CPU_INTERVAL * throttleRatio, CPU_INTERVAL * 0.92));
 try {
 state.process.kill('SIGSTOP');
 isStopped = true;
 setTimeout(() => {
 if (!state.process) { isStopped = false; return; }
 try { state.process.kill('SIGCONT'); isStopped = false; } catch(e) {}
 if (active) setTimeout(cpuLoop, Math.max(10, CPU_INTERVAL - pauseMs));
 }, pauseMs);
 } catch(e) {
 if (active) setTimeout(cpuLoop, CPU_INTERVAL);
 }
 } else {
 if (isStopped) {
 try { if (state.process) { state.process.kill('SIGCONT'); isStopped = false; } } catch(e) {}
 }
 if (active) setTimeout(cpuLoop, CPU_INTERVAL);
 }
 });
 };

 setTimeout(cpuLoop, CPU_INTERVAL);

 // Disk: cek setiap 30 detik, matikan jika melebihi batas
 const diskInterval = setInterval(() => {
 if (!active || !state.process) { clearInterval(diskInterval); return; }
 const diskUsed = getDirSizeGlobal(getUserDir(srvName));
 if (diskUsed > DISK_LIMIT_BYTES) {
 uLog(`\x1b[31m [Resource Limit] Disk melebihi batas (${(diskUsed/1024/1024).toFixed(0)}MB > ${limits.disk}MB). Server dimatikan!\x1b[0m\n`);
 try { state.process.kill('SIGKILL'); } catch(e) {}
 state.isStarting = false;
 stopAll();
 }
 }, 30000);

 if (state.process) {
 state.process.once('close', stopAll);
 }
}

const lastCpuCache = {};
const cpuEmaCache = {};
const prevProcStat = {};

function readProcStat(pid) {
 try {
  const stat = fs.readFileSync(`/proc/${pid}/stat`, 'utf8');
  const parts = stat.slice(stat.lastIndexOf(')') + 2).trim().split(' ');
  const utime = parseInt(parts[11]);
  const stime = parseInt(parts[12]);
  const cutime = parseInt(parts[13]);
  const cstime = parseInt(parts[14]);
  return { total: utime + stime + cutime + cstime };
 } catch(e) { return null; }
}

function readCpuTotal() {
 try {
  const line = fs.readFileSync('/proc/stat', 'utf8').split('\n')[0];
  const nums = line.trim().split(/\s+/).slice(1).map(Number);
  return nums.reduce((a, b) => a + b, 0);
 } catch(e) { return 0; }
}

const HZ = 100;
const prevPidTicks = {};
let _prevCpuTotalSnapshot = readCpuTotal();
let _curCpuTotalSnapshot = _prevCpuTotalSnapshot;

function snapshotCpuTotal() {
 _prevCpuTotalSnapshot = _curCpuTotalSnapshot;
 _curCpuTotalSnapshot = readCpuTotal();
}

function getProcCpuPercent(pid) {
 const cpuDelta = _curCpuTotalSnapshot - _prevCpuTotalSnapshot;
 if (cpuDelta <= 0) return null;
 const procStat = readProcStat(pid);
 if (!procStat) return null;
 const prevTicks = prevPidTicks[pid] !== undefined ? prevPidTicks[pid] : procStat.total;
 const pidDelta = procStat.total - prevTicks;
 prevPidTicks[pid] = procStat.total;
 const numCpus = os.cpus().length;
 return (pidDelta / cpuDelta) * numCpus * 100;
}

setInterval(() => {
 snapshotCpuTotal();
 const curNet = readNetStats();
 prevNetStats = curNet;

 let users = readUsers();
 for (const stateKey in activeServers) {
 const state = activeServers[stateKey];
 const srvName = state._srvName || stateKey;
 const owner = state._owner || stateKey;
 const settings = getUserSettings(srvName, owner);
 let displayAddress = settings.ip ? `${settings.ip}:${settings.port}` : `0.0.0.0:${settings.port}`;

 if (!state.process) {
 lastCpuCache[stateKey] = 0;
 state._lastCpu = 0; state._lastRamMB = 0;
 io.to(owner).emit('dashboard_stats', { serverName: srvName, cpu: "0.00", ramMB: 0, isOnline: false, status: 'offline' });
 continue; 
 }
 
 const netInBytes = Math.max(0, curNet.rx - state.netBaseRx);
 const netOutBytes = Math.max(0, curNet.tx - state.netBaseTx);

 const srvLimits = settings.srvLimits || {};
 const userCpuLimit = srvLimits.cpu || users[owner]?.limits?.cpu || 100;
 const userRamLimitMB = srvLimits.ram || users[owner]?.limits?.ram || 2048;
 const userDiskLimitMB = srvLimits.disk || users[owner]?.limits?.disk || 32768;

 const mcPid = state.process.pid;
 const mcCpu = getProcCpuPercent(mcPid) ?? 0;
 let ramMB = 0;
 try {
  const statusLines = fs.readFileSync(`/proc/${mcPid}/status`, 'utf8').split('\n');
  const vmRss = statusLines.find(l => l.startsWith('VmRSS:'));
  if (vmRss) ramMB = parseInt(vmRss.split(/\s+/)[1]) / 1024;
 } catch(e) {}
 const EMA_ALPHA = 0.4;
 const prevEma = cpuEmaCache[stateKey] || 0;
 const ema = mcCpu > 0 ? EMA_ALPHA * mcCpu + (1 - EMA_ALPHA) * prevEma : prevEma * 0.85;
 cpuEmaCache[stateKey] = ema;
 let cpuRaw = ema;
 let cpuFormatted = cpuRaw.toFixed(2);
 state._lastCpu = cpuRaw; state._lastRamMB = ramMB;
 let currentStatus = state.isStarting ? 'starting' : 'running';
 io.to(owner).emit('dashboard_stats', { serverName: srvName, cpu: cpuFormatted, ramMB: ramMB, isOnline: true, status: currentStatus });
 io.to('panel_' + stateKey).emit('stats', { cpu: cpuFormatted, ramMB: ramMB, startTime: state.startTime, address: displayAddress, status: currentStatus, netIn: netInBytes, netOut: netOutBytes, cpuLimit: userCpuLimit, ramLimit: userRamLimitMB, diskLimit: userDiskLimitMB });
 }
}, 1000);

io.on('connection', (socket) => {
 const reqSession = socket.request.session;
 if (!reqSession || !reqSession.loggedIn) { socket.emit('session_expired'); return socket.disconnect(); }
 
 const sessionUsername = reqSession.username;
 const users_s = readUsers();
 const username = (reqSession.viewAsUser && users_s[reqSession.viewAsUser]) ? reqSession.viewAsUser : sessionUsername;
 const u_s = users_s[username];
 const activeServer = reqSession.currentServer || (u_s && u_s.servers && u_s.servers.length > 0 ? u_s.servers[0] : null);

 const roomKey = activeServer ? (username + '::' + activeServer) : null;
 socket.join(username);
 if (roomKey) socket.join('panel_' + roomKey);

 if (!activeServer) {
  socket.emit('stats', { cpu: "0.00", ramMB: 0, startTime: null, address: '0.0.0.0:25565', status: 'offline' });
  return;
 }

 const state = getUserState(activeServer, username);
 const mcDir = getUserDir(activeServer, username);
 const settings = getUserSettings(activeServer, username);
 let displayAddress = settings.ip ? `${settings.ip}:${settings.port}` : `0.0.0.0:${settings.port}`;

 const initSrvLimits = settings.srvLimits || {};
 const users_init = readUsers();
 const initOwner = Object.keys(users_init).find(u => users_init[u].servers && users_init[u].servers.includes(activeServer)) || activeServer;
 const initCpuLimit = initSrvLimits.cpu || users_init[initOwner]?.limits?.cpu || 100;
 const initRamLimit = initSrvLimits.ram || users_init[initOwner]?.limits?.ram || 2048;
 const initDiskLimit = initSrvLimits.disk || users_init[initOwner]?.limits?.disk || 32768;
 if (state.process) {
 let currentStatus = state.isStarting ? 'starting' : 'running';
 socket.emit('stats', { cpu: "0.00", ramMB: 0, startTime: state.startTime, address: displayAddress, status: currentStatus, cpuLimit: initCpuLimit, ramLimit: initRamLimit, diskLimit: initDiskLimit });
 } else {
 socket.emit('stats', { cpu: "0.00", ramMB: 0, startTime: null, address: displayAddress, status: 'offline', cpuLimit: initCpuLimit, ramLimit: initRamLimit, diskLimit: initDiskLimit });
 }

 function userLog(msg) { 
 state.logs.push(msg); 
 if (state.logs.length > 300) state.logs.shift(); 
 io.to('panel_' + roomKey).emit('log', msg); 
 }

 socket.emit('log_history', state.logs.join(''));
 socket.emit('download_lock_state', state.isDownloading); 
 socket.on('clear_logs', () => { state.logs = []; });

 socket.on('command', (cmd) => { 
 let commandText = cmd.trim();
 
 // ðŸ”¥ FITUR VPSINFO DENGAN TAMBAHAN HURUF 'B' (GB/MB) & CPU LOAD ðŸ”¥
 if (commandText.toLowerCase() === 'vpsinfo') {
 const cpus = os.cpus();
 const totalRamNum = os.totalmem() / (1024 ** 3);
 const freeRamNum = os.freemem() / (1024 ** 3);
 const usedRamNum = totalRamNum - freeRamNum;
 const ramPercent = Math.round((usedRamNum / totalRamNum) * 100);
 const ramColor = ramPercent >= 80 ? '\x1b[1;31m' : (ramPercent >= 60 ? '\x1b[1;33m' : '\x1b[1;32m');

 // --- SCRIPT TAMBAHAN UNTUK HITUNG CPU LOAD VPS ---
 const startCpu = os.cpus();
 setTimeout(() => {
 const endCpu = os.cpus();
 let totalIdle = 0, totalTick = 0;
 
 for (let i = 0; i < startCpu.length; i++) {
 const start = startCpu[i];
 const end = endCpu[i];
 
 const idle = end.times.idle - start.times.idle;
 let total = 0;
 for (type in end.times) {
 total += end.times[type] - start.times[type];
 }
 totalIdle += idle;
 totalTick += total;
 }
 
 // Gantilah baris ini di dalam skrip vpsinfo kemarin:
const cpuPercent = Math.round((1 - totalIdle / totalTick) * 100) * startCpu.length;
const cpuColor = cpuPercent >= (80 * startCpu.length) ? '\x1b[1;31m' : (cpuPercent >= (60 * startCpu.length) ? '\x1b[1;33m' : '\x1b[1;32m');
 // ----------------------------------------------------

 exec("df -h /", (err, stdout) => {
 let diskTotal = "?", diskUsed = "?", diskFree = "?", diskPercent = "?", diskColor = '\x1b[1;32m';
 if (!err && stdout) { 
 try {
 let parts = stdout.trim().split('\n')[1].trim().split(/\s+/); 
 
 const addB = (val) => val ? val.replace(/([KMGTP])$/i, '$1B') : "?";
 
 diskTotal = addB(parts[1]); 
 diskUsed = addB(parts[2]); 
 diskFree = addB(parts[3]); 
 diskPercent = parts[4] || "0%"; 
 
 let dpNum = parseInt((diskPercent || "0").replace('%', ''));
 if(!isNaN(dpNum)) diskColor = dpNum >= 80 ? '\x1b[1;31m' : (dpNum >= 60 ? '\x1b[1;33m' : '\x1b[1;32m');
 } catch(e) {} 
 }
 
 userLog(`\n\x1b[1;35m=== SPESIFIKASI VPS (MANZ4VPS) ===\x1b[0m\n`);
 userLog(`\x1b[1;36m OS Sistem :\x1b[0m ${os.type()} ${os.release()} (${os.arch()})\n`);
 userLog(`\x1b[1;36m Prosesor :\x1b[0m ${cpus[0].model}\n`);
 userLog(`\x1b[1;36m Total Core :\x1b[0m ${cpus.length} Cores\n`);
 userLog(`\x1b[1;36m CPU Load :\x1b[0m ${cpuColor}${cpuPercent}%\x1b[0m\n`); // <--- INI TAMBAHAN FITUR CPU-NYA BRO
 userLog(`\x1b[1;36m RAM :\x1b[0m ${usedRamNum.toFixed(2)}GB / ${totalRamNum.toFixed(2)}GB (${ramColor}${ramPercent}%\x1b[0m) / free ${freeRamNum.toFixed(2)}GB\n`);
 userLog(`\x1b[1;36m Disk Root :\x1b[0m ${diskUsed} / ${diskTotal} (${diskColor}${diskPercent}\x1b[0m) / free ${diskFree}\n`);
 userLog(`\x1b[1;35m====================================\x1b[0m\n\n`);
 });
 }, 500); // Mengukur beban CPU dalam jeda 500ms agar akurat
 return;
 }

 if (state.process) { 
 let parts = commandText.split(" "); parts[0] = parts[0].toLowerCase(); 
 state.process.stdin.write(parts.join(" ") + '\n'); 
 } 
 });

 function eksekusiProses(execCmd, execArgs, settings) {
 userLog(`\x1b[38;2;234;179;8m\x1b[1mcontainer@manz4vps~\x1b[0m ${execCmd} ${execArgs.join(' ')}\n`);
 try {
 state.process = spawn(execCmd, execArgs, { cwd: mcDir, env: { ...process.env, TZ: 'Asia/Jakarta' } });
 state.startTime = Date.now();
 state.isStarting = true;
 startResourceMonitor(activeServer, state, userLog);
 
 state.process.stdout.on('data', (data) => {
 let output = data.toString();
 if (output.includes('Done (') && output.includes('! For help, type "help"')) {
  output = output.replace(/(Done \([\d.]+s\)!)/g, '\x1b[32m\x1b[1m$1\x1b[0m');
  state.isStarting = false;
  io.to('panel_' + roomKey).emit('server_ready');
 } else if (output.toLowerCase().includes('bot is online') || output.toLowerCase().includes('ready') || output.toLowerCase().includes('listening on port')) {
  state.isStarting = false;
  io.to('panel_' + roomKey).emit('server_ready');
 }
 userLog(output);
 });

 state.process.stderr.on('data', (data) => userLog(`\x1b[31m${data.toString()}\x1b[0m`));
 state.process.on('close', (code) => {
 userLog(`\x1b[31mProses berhenti (Kode: ${code})\x1b[0m\n`);
 pidusage.clear(); 
 if (state._restartKillTimer) { clearTimeout(state._restartKillTimer); state._restartKillTimer = null; }
 state.process = null; 
 state.startTime = null;
 state.isStarting = false;
 io.to('panel_' + roomKey).emit('stats', { cpu: "0.00", ramMB: 0, startTime: null, address: `${settings.ip}:${settings.port}`, status: 'offline', netIn: 0, netOut: 0 });
 if (state.isRestarting) { state.isRestarting = false; userLog(`\x1b[1;36m[Manz4VPS Daemon]:\x1b[0m Memulai ulang dalam 2 detik...\x1b[0m\n`); setTimeout(() => globalSpawn(activeServer, username), 2000); }
 });
 } catch(e) { 
 userLog(`\x1b[31mGagal eksekusi: ${e.message}\x1b[0m\n`); 
 state.isStarting = false;
 }
 }

 function startServer() {
 if (state.isDownloading) return userLog(`\x1b[33m Sistem sedang mengunduh file. Harap tunggu.\x1b[0m\n`);
 if (state.process || state.isStarting) return; 

 state.isStarting = true;
 const snap = readNetStats(); state.netBaseRx = snap.rx; state.netBaseTx = snap.tx;
 const settings = getUserSettings(activeServer);

 userLog(`\x1b[1;36m[Manz4VPS Daemon]:\x1b[0m Checking server disk space usage...\n`);
 setTimeout(() => userLog(`\x1b[1;36m[Manz4VPS Daemon]:\x1b[0m Updating process configuration files...\n`), 600);

 setTimeout(() => {
 userLog(`\x1b[38;2;234;179;8m\x1b[1mcontainer@manz4vps~\x1b[0m Server marked as starting...\n`);

 if (settings.engine === 'node') {
 eksekusiProses('sh', ['-c', `if [ -d .git ]; then git pull; fi; if [ -f package.json ]; then npm install; fi; exec node "${settings.jarFile}"`], settings);
 } else if (settings.engine === 'python') {
 eksekusiProses('python3', [settings.jarFile], settings);
 } else {
 const reqJavaVer = (settings.javaVersion && settings.javaVersion !== 'auto') ? parseInt(settings.javaVersion) : getRequiredJavaVersion(settings.installedVersion);
 userLog(`\x1b[1;36m[Manz4VPS Daemon]:\x1b[0m Mendeteksi kebutuhan Java ${reqJavaVer} untuk versi [${settings.installedVersion || 'Default'}]\n`);
 
 ensureJava(reqJavaVer, userLog, (err, javaPath) => {
 if (err) {
 userLog(`\x1b[31mGagal menginstal Java ${reqJavaVer}: ${err.message}\x1b[0m\n`);
 state.isStarting = false;
 return;
 }
 const userLimits = readUsers()[username]?.limits || { ram: 2048 };
 const ramMB = Math.min(parseRamMB(settings.ram), userLimits.ram);
 const defaultJvmFlags = [
  `-XX:+UseG1GC`, `-XX:+ParallelRefProcEnabled`, `-XX:MaxGCPauseMillis=200`,
  `-XX:+UnlockExperimentalVMOptions`, `-XX:+DisableExplicitGC`,
  `-XX:G1NewSizePercent=30`, `-XX:G1MaxNewSizePercent=40`, `-XX:G1HeapRegionSize=8M`,
  `-XX:G1ReservePercent=20`, `-XX:InitiatingHeapOccupancyPercent=30`,
  `-XX:+PerfDisableSharedMem`,
 ];
 const jvmFlags = (settings.useCustomStartup && settings.customStartupCmd && settings.customStartupCmd.trim())
  ? settings.customStartupCmd.trim().split(/\s+/).filter(f => f.length > 0)
  : defaultJvmFlags;
 const execArgs = [
  `-Xms256M`, `-Xmx${ramMB}M`,
  ...jvmFlags,
  `-jar`, settings.jarFile, `--nogui`, `--port`, settings.port
 ];
 eksekusiProses(javaPath, execArgs, settings);
 });
 }
 }, 1200); 
 }

 socket.on('start', () => startServer());
 socket.on('restart', () => {
 if (state.process) {
 state.isRestarting = true;
 userLog(`\x1b[1;33m[Manz4VPS Daemon]:\x1b[0m Mengirim perintah restart...\n`);
 const restartSettings = getUserSettings(activeServer);
 if (restartSettings.engine === 'node' || restartSettings.engine === 'python') {
 try { state.process.kill('SIGTERM'); } catch(e) {}
 } else {
 try { state.process.stdin.write('stop\n'); } catch(e) {}
 }
 if (state._restartKillTimer) clearTimeout(state._restartKillTimer);
 state._restartKillTimer = setTimeout(() => {
 if (state.process && state.isRestarting) {
 userLog(`\x1b[1;33m[Manz4VPS Daemon]:\x1b[0m Proses tidak merespons dalam 45 detik, paksa berhenti...\n`);
 try { state.process.kill('SIGTERM'); } catch(e) {}
 setTimeout(() => { if (state.process && state.isRestarting) { try { state.process.kill('SIGKILL'); } catch(e) {} } }, 5000);
 }
 }, 45000);
 } else { globalSpawn(activeServer, username); }
 });
 socket.on('stop_aman', () => {
 if (state.process) {
 state.isRestarting = false;
 if (state._restartKillTimer) { clearTimeout(state._restartKillTimer); state._restartKillTimer = null; }
 state.process.stdin.write('stop\n');
 }
 });
 
 socket.on('kill_paksa', () => { 
 if (state.process) { 
 state.isRestarting = false;
 if (state._restartKillTimer) { clearTimeout(state._restartKillTimer); state._restartKillTimer = null; }
 try { state.process.kill('SIGKILL'); userLog(`\x1b[31mProses dimatikan paksa (SIGKILL).\x1b[0m\n`); } catch(err) { }
 state.startTime = null;
 state.isStarting = false;
 } 
 });
 
 socket.on('accept_eula', () => { try { fs.writeFileSync(path.join(mcDir, 'eula.txt'), 'eula=true'); userLog(`\x1b[32m EULA disetujui. Memulai ulang...\x1b[0m\n`); if (state.process) { state.isRestarting = true; try { state.process.stdin.write('stop\n'); } catch(e) {} } else { setTimeout(() => globalSpawn(activeServer, username), 2000); } } catch (e) { } });
 
 socket.on('download_jar', (url, versionName, isCleanInstall) => {
 if (state.isDownloading) return userLog(`\x1b[33m Proses unduhan lain sedang berjalan.\x1b[0m\n`);
 if (state.process) return userLog(`\x1b[31mGAGAL: Server masih menyala!\x1b[0m\n`);
 state.isDownloading = true; io.to('panel_' + roomKey).emit('download_lock_state', true); 
 
 if (isCleanInstall) {
 userLog(`\x1b[33mMelakukan WIPE (Sapu Bersih) seluruh file...\x1b[0m\n`);
 try {
 const files = fs.readdirSync(mcDir);
 files.forEach(file => { if (file !== 'panel_settings.json') { try { fs.rmSync(path.join(mcDir, file), { recursive: true, force: true }); } catch (err) {} } });
 } catch(e) {}
 } else {
 const jarPath = path.join(mcDir, 'server.jar'); const backupPath = path.join(mcDir, 'server.jar.old'); 
 if (fs.existsSync(jarPath)) { try { if (fs.existsSync(backupPath)) fs.rmSync(backupPath, { force: true }); fs.renameSync(jarPath, backupPath); } catch(e) {} }
 }
 
 userLog(`\x1b[33mMemulai pengunduhan ${versionName}...\x1b[0m\n`);
 const downloader = spawn('curl', ['-L', '-#', '-o', 'server.jar', url], { cwd: mcDir });
 downloader.on('close', (code) => {
 state.isDownloading = false; io.to('panel_' + roomKey).emit('download_lock_state', false); 
 if(code === 0) { 
 userLog(`\x1b[32m SUKSES! ${versionName} siap dimainkan.\x1b[0m\n`); io.to('panel_' + roomKey).emit('download_success_toast');
 const settings = getUserSettings(activeServer, username); settings.installedVersion = versionName; fs.writeFileSync(path.join(mcDir, 'panel_settings.json'), JSON.stringify(settings));
 } else { userLog(`\x1b[31mUnduhan gagal. (Kode: ${code})\x1b[0m\n`); }
 });
 });

 socket.on('download_plugin', (url, filename) => {
 if (state.isDownloading) return;
 state.isDownloading = true; io.to('panel_' + roomKey).emit('download_lock_state', true); 
 const pluginsDir = path.join(mcDir, 'plugins'); if (!fs.existsSync(pluginsDir)) fs.mkdirSync(pluginsDir, { recursive: true });
 userLog(`\x1b[33mMengunduh plugin: ${filename}...\x1b[0m\n`);
 const downloader = spawn('curl', ['-L', '-#', '-o', filename, url], { cwd: pluginsDir });
 downloader.on('close', (code) => {
 state.isDownloading = false; io.to('panel_' + roomKey).emit('download_lock_state', false); 
 if(code === 0) { userLog(`\x1b[32m SUKSES! Plugin ${filename} berhasil dipasang.\x1b[0m\n`); io.to('panel_' + roomKey).emit('plugin_success_toast', filename); } 
 else { userLog(`\x1b[31mGagal mengunduh plugin.\x1b[0m\n`); }
 });
 });
});

function globalSpawn(srvName, ownerHint) {
 const ownerStr = ownerHint || getOwner(srvName) || srvName;
 const state = getUserState(srvName, ownerStr);
 if (state.process || state.isStarting || state.isDownloading) return;
 const settings = getUserSettings(srvName, ownerStr);
 const mcDir = getUserDir(srvName, ownerStr);
 const spawnRoomKey = ownerStr + '::' + srvName;
 const uLog = (msg) => { state.logs.push(msg); if (state.logs.length > 300) state.logs.shift(); io.to('panel_' + spawnRoomKey).emit('log', msg); };
 const snap = readNetStats(); state.netBaseRx = snap.rx; state.netBaseTx = snap.tx;
 state.isStarting = true;

 const doSpawn = (cmd, args, extraEnv = {}) => {
 uLog(`\x1b[38;2;234;179;8m\x1b[1mcontainer@manz4vps~\x1b[0m ${cmd} ${args.join(' ')}\n`);
 try {
 state.process = spawn(cmd, args, { cwd: mcDir, env: { ...process.env, TZ: 'Asia/Jakarta', ...extraEnv } });
 state.startTime = Date.now();
 startResourceMonitor(srvName, state, uLog);
 state.process.stdout.on('data', d => { let o = d.toString(); if (o.includes('Done (') && o.includes('! For help, type "help"')) { o = o.replace(/(Done \([\d.]+s\)!)/g, '\x1b[32m\x1b[1m$1\x1b[0m'); state.isStarting = false; io.to('panel_' + spawnRoomKey).emit('server_ready'); } else if (/bot is online|ready|listening on port/i.test(o)) { state.isStarting = false; io.to('panel_' + spawnRoomKey).emit('server_ready'); } uLog(o); });
 state.process.stderr.on('data', d => uLog(`\x1b[31m${d.toString()}\x1b[0m`));
 state.process.on('close', code => {
 uLog(`\x1b[31mProses berhenti (Kode: ${code})\x1b[0m\n`);
 pidusage.clear();
 if (state._restartKillTimer) { clearTimeout(state._restartKillTimer); state._restartKillTimer = null; }
 state.process = null; state.startTime = null; state.isStarting = false;
 const s2 = getUserSettings(srvName, ownerStr);
 io.to('panel_' + spawnRoomKey).emit('stats', { cpu: "0.00", ramMB: 0, startTime: null, address: `${s2.ip}:${s2.port}`, status: 'offline', netIn: 0, netOut: 0 });
 if (state.isRestarting) {
 state.isRestarting = false;
 uLog(`\x1b[1;36m[Manz4VPS Daemon]:\x1b[0m Memulai ulang dalam 2 detik...\n`);
 setTimeout(() => globalSpawn(srvName, ownerStr), 2000);
 }
 });
 } catch(e) { uLog(`\x1b[31mGagal: ${e.message}\x1b[0m\n`); state.isStarting = false; }
 };

 if (settings.engine === 'node') {
 doSpawn('sh', ['-c', `if [ -d .git ]; then git pull; fi; if [ -f package.json ]; then npm install; fi; exec node "${settings.jarFile}"`]);
 } else if (settings.engine === 'python') {
 doSpawn('python3', [settings.jarFile]);
 } else {
 const reqJavaVer = (settings.javaVersion && settings.javaVersion !== 'auto') ? parseInt(settings.javaVersion) : getRequiredJavaVersion(settings.installedVersion);
 if (settings.javaVersion && settings.javaVersion !== 'auto') { uLog(`\x1b[1;36m[Manz4VPS Daemon]:\x1b[0m Menggunakan Java ${reqJavaVer} (pilihan manual)\n`); } else { uLog(`\x1b[1;36m[Manz4VPS Daemon]:\x1b[0m Mendeteksi kebutuhan Java ${reqJavaVer}\n`); }
 ensureJava(reqJavaVer, uLog, (err, javaPath) => {
 if (err) { uLog(`\x1b[31mâŒ Gagal Java: ${err.message}\x1b[0m\n`); state.isStarting = false; return; }
 const ownerForCap = ownerStr;
 const ownerLimits = readUsers()[ownerForCap]?.limits || { ram: 2048 };
 const srvRamLimit = settings.srvLimits?.ram || ownerLimits.ram;
 const ramMBg = Math.min(parseRamMB(settings.ram), srvRamLimit);
 if (settings.useCustomStartup && settings.customStartupCmd && settings.customStartupCmd.trim()) {
  const javaBinDir = path.dirname(javaPath);
  uLog(`\x1b[1;35m[Manz4VPS Daemon]:\x1b[0m Menggunakan Custom Startup Command.\n`);
  doSpawn('sh', ['-c', settings.customStartupCmd.trim()], { PATH: javaBinDir + ':' + (process.env.PATH || '') });
  return;
 }
 doSpawn(javaPath, [
  `-Xms256M`, `-Xmx${ramMBg}M`,
  `-XX:+UseG1GC`, `-XX:+ParallelRefProcEnabled`, `-XX:MaxGCPauseMillis=200`,
  `-XX:+UnlockExperimentalVMOptions`, `-XX:+DisableExplicitGC`,
  `-XX:G1NewSizePercent=30`, `-XX:G1MaxNewSizePercent=40`, `-XX:G1HeapRegionSize=8M`,
  `-XX:G1ReservePercent=20`, `-XX:InitiatingHeapOccupancyPercent=30`,
  `-XX:+PerfDisableSharedMem`,
  `-jar`, settings.jarFile, `--nogui`, `--port`, settings.port
 ]);
 });
 }
}


function bootAutoStart() {
 setTimeout(() => {
 try {
 const users = readUsers();
 for (const username in users) {
 const userServers = users[username].servers || [];
 userServers.forEach(srvName => {
 try {
 const settings = getUserSettings(srvName, username);
 if (!settings.autoStart) return;
 const state = getUserState(srvName, username);
 const autoRoomKey = username + '::' + srvName;
 const uLog = (msg) => { state.logs.push(msg); if (state.logs.length > 300) state.logs.shift(); io.to('panel_' + autoRoomKey).emit('log', msg); };
 uLog(`\x1b[1;36m[Manz4VPS Daemon]:\x1b[0m Auto Start aktif. Memulai server ${srvName}...\n`);
 globalSpawn(srvName, username);
 } catch(e) {}
 });
 }
 } catch(e) {}
 }, 3000);
}

const PTERO_PORT = process.env.PORT || 5000;
server.listen(PTERO_PORT, '0.0.0.0', () => {
 console.log(`\x1b[32mðŸš€ PANEL V26 (ULTIMATE)\x1b[0m`);
 bootAutoStart();
});
